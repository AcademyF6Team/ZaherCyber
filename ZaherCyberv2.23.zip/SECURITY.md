# Security and privacy notes

- ZaherCyber is an RSS reader and software catalogue; it does not remotely control a device or run downloaded security tools.
- Release binaries are downloaded directly from HTTPS links published by the relevant upstream project. The app never silently installs APK files.
- On Android, APK installation is handed to the Android package installer and requires the user's system permission and confirmation.
- SHA-256 is calculated after download. A publisher checksum is compared only when the official release metadata supplies one; a calculated hash alone is not proof of publisher authenticity.
- Downloaded Windows installers are files for transfer/storage on Android and cannot execute on Android.
- Bookmarks, feed cache, preferences, and download-job metadata are stored locally using app storage. No ZaherCyber account or private API key is required.
- Protection Center checklist progress and product-watch terms are also stored locally in app storage. Terms are matched on-device against up to 300 recent CISA KEV entries; the app does not upload the watchlist or send push notifications.
- The app currently does not translate news/article text; it shows publisher-provided excerpts and links to original pages.
- RSS, GitHub and CISA requests disclose ordinary network metadata (for example, IP address) to those upstream services. This app has no first-party analytics endpoint.
- Always verify project, platform, architecture, license and publisher signatures before installing software. Perform security testing only with explicit authorization.
- The example release signing uses the debug key for buildability and local testing only. Use a private production signing key for distribution and keep it out of source control.
