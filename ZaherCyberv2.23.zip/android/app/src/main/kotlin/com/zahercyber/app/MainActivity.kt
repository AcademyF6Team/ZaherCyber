package com.zahercyber.app

import android.app.Activity
import android.content.ContentValues
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    private val channelName = "com.zahercyber/native"
    private val storagePermissionRequestCode = 7351
    private val backupPickRequestCode = 7352

    private data class PendingDownloadSave(
        val source: File,
        val fileName: String,
        val mimeType: String,
        val result: MethodChannel.Result,
    )

    private var pendingDownloadSave: PendingDownloadSave? = null
    private var pendingBackupPick: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "saveToDownloads" -> {
                        val sourcePath = call.argument<String>("path")
                        val fileName = call.argument<String>("fileName")
                        val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
                        if (sourcePath.isNullOrBlank() || fileName.isNullOrBlank()) {
                            result.error("invalid_arguments", "A file path and name are required.", null)
                        } else {
                            saveToPublicDownloads(File(sourcePath), fileName, mimeType, result)
                        }
                    }
                    "installApk" -> {
                        val path = call.argument<String>("path")
                        if (path.isNullOrBlank()) {
                            result.error("invalid_arguments", "APK path is missing.", null)
                        } else {
                            installApk(File(path), result)
                        }
                    }
                    "deleteDownload" -> {
                        val value = call.argument<String>("uri")
                        if (value.isNullOrBlank()) {
                            result.success(false)
                        } else {
                            try {
                                result.success(contentResolver.delete(Uri.parse(value), null, null) > 0)
                            } catch (error: Exception) {
                                result.error("delete_failed", error.message, null)
                            }
                        }
                    }
                    "shareText" -> {
                        val text = call.argument<String>("text") ?: ""
                        val title = call.argument<String>("title") ?: "ZaherCyber"
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        startActivity(Intent.createChooser(send, title))
                        result.success(true)
                    }
                    "pickLearningBackup" -> {
                        if (pendingBackupPick != null) {
                            result.error("backup_pick_in_progress", "Another backup file is being selected.", null)
                        } else {
                            pendingBackupPick = result
                            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = "application/json"
                            }
                            startActivityForResult(intent, backupPickRequestCode)
                        }
                    }
                    "deviceSecuritySnapshot" -> {
                        val developmentEnabled = try {
                            Settings.Global.getInt(
                                contentResolver,
                                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED,
                                0,
                            ) == 1
                        } catch (_: Exception) {
                            false
                        }
                        val canInstall = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            packageManager.canRequestPackageInstalls()
                        } else {
                            false
                        }
                        result.success(
                            mapOf(
                                "sdk" to Build.VERSION.SDK_INT,
                                "release" to Build.VERSION.RELEASE,
                                "securityPatch" to Build.VERSION.SECURITY_PATCH,
                                "developerMode" to developmentEnabled,
                                "canRequestPackageInstalls" to canInstall,
                                "scopedStorage" to (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q),
                                "debuggable" to ((applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0),
                            ),
                        )
                    }
                    "shareFile" -> {
                        val path = call.argument<String>("path")
                        val fileName = call.argument<String>("fileName") ?: "download"
                        val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
                        if (path.isNullOrBlank()) {
                            result.error("invalid_arguments", "File path is missing.", null)
                        } else {
                            try {
                                val source = File(path)
                                check(source.isFile) { "Downloaded file does not exist." }
                                val file = stageForFileProvider(source, "shared")
                                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = mimeType
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    putExtra(Intent.EXTRA_TITLE, fileName)
                                    clipData = ClipData.newUri(contentResolver, fileName, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                startActivity(Intent.createChooser(send, fileName))
                                result.success(true)
                            } catch (error: Exception) {
                                result.error("share_failed", error.message, null)
                            }
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    @Deprecated("Required for the local learning backup picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != backupPickRequestCode) return
        val pending = pendingBackupPick
        pendingBackupPick = null
        if (pending == null) return
        if (resultCode != Activity.RESULT_OK || data?.data == null) {
            pending.success(null)
            return
        }
        try {
            val uri = data.data!!
            val content = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: error("Could not read the selected backup.")
            pending.success(content)
        } catch (error: Exception) {
            pending.error("backup_read_failed", error.message, null)
        }
    }

    private fun saveToPublicDownloads(
        source: File,
        fileName: String,
        mimeType: String,
        result: MethodChannel.Result,
    ) {
        // Public Downloads requires this runtime permission on Android 9 and older.
        // Android 10+ uses scoped MediaStore and must not request broad storage access.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                PackageManager.PERMISSION_GRANTED
        ) {
            if (pendingDownloadSave != null) {
                result.error(
                    "permission_request_in_progress",
                    "Another storage permission request is in progress.",
                    null,
                )
                return
            }
            pendingDownloadSave = PendingDownloadSave(source, fileName, mimeType, result)
            requestPermissions(
                arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE),
                storagePermissionRequestCode,
            )
            return
        }
        try {
            result.success(copyIntoDownloads(source, fileName, mimeType))
        } catch (error: Exception) {
            result.error("save_failed", error.message, null)
        }
    }

    @Deprecated("Required by Flutter's permission callback on Android 9 and below")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != storagePermissionRequestCode) return
        val pending = pendingDownloadSave ?: return
        pendingDownloadSave = null
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            try {
                pending.result.success(
                    copyIntoDownloads(pending.source, pending.fileName, pending.mimeType),
                )
            } catch (error: Exception) {
                pending.result.error("save_failed", error.message, null)
            }
        } else {
            pending.result.error(
                "storage_permission_denied",
                "تم رفض إذن التخزين؛ بقي الملف داخل مساحة التطبيق ويمكن مشاركته.",
                null,
            )
        }
    }

    private fun copyIntoDownloads(source: File, fileName: String, mimeType: String): String {
        check(source.isFile) { "Downloaded file does not exist." }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/ZaherCyber")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Android could not create a Downloads entry.")
            try {
                contentResolver.openOutputStream(uri, "w").use { output ->
                    checkNotNull(output) { "Android could not open the Downloads destination." }
                    source.inputStream().use { input -> input.copyTo(output) }
                }
                val completed = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                contentResolver.update(uri, completed, null, null)
                return uri.toString()
            } catch (error: Exception) {
                contentResolver.delete(uri, null, null)
                throw error
            }
        }

        val directory = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "ZaherCyber",
        )
        check(directory.exists() || directory.mkdirs()) { "Could not create Downloads/ZaherCyber." }
        val destination = File(directory, fileName)
        source.inputStream().use { input ->
            destination.outputStream().use { output -> input.copyTo(output) }
        }
        return destination.absolutePath
    }

    private fun installApk(apk: File, result: MethodChannel.Result) {
        if (!apk.isFile || !apk.name.endsWith(".apk", ignoreCase = true)) {
            result.error("invalid_apk", "The downloaded file is not an APK.", null)
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
                val settings = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(settings)
                result.success("permission_required")
                return
            }
            val stagedApk = stageForFileProvider(apk, "apk-install")
            val contentUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", stagedApk)
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/vnd.android.package-archive")
                clipData = ClipData.newUri(contentResolver, stagedApk.name, contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(installIntent)
            result.success("installer_opened")
        } catch (error: Exception) {
            result.error("install_open_failed", error.message, null)
        }
    }

    /**
     * FileProvider is intentionally scoped to these cache subdirectories.
     * Flutter documents live under app_flutter/, outside Android's files-path;
     * copy to cache first instead of broadening provider access to app data.
     */
    private fun stageForFileProvider(source: File, subdirectory: String): File {
        check(source.isFile) { "Source file does not exist." }
        require(subdirectory == "shared" || subdirectory == "apk-install") {
            "Unsupported FileProvider staging directory."
        }
        val directory = File(cacheDir, subdirectory)
        check(directory.exists() || directory.mkdirs()) {
            "Could not create the private staging directory."
        }
        val now = System.currentTimeMillis()
        directory.listFiles()?.forEach { oldFile ->
            if (oldFile.isFile && now - oldFile.lastModified() > 7L * 24 * 60 * 60 * 1000) {
                oldFile.delete()
            }
        }
        val safeName = source.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val staged = File(directory, "${now}_$safeName")
        try {
            source.inputStream().use { input ->
                staged.outputStream().use { output -> input.copyTo(output) }
            }
            return staged
        } catch (error: Exception) {
            staged.delete()
            throw error
        }
    }
}
