# سجل التحقق من المصادر — ZaherCyber 2.3.0

تسجل هذه الوثيقة موجزات RSS/Atom والمشاريع والمراجع الخارجية التي راجعها البحث قبل إضافتها. قد تتغير حالة أي خدمة لاحقاً؛ الروابط الرسمية هي المرجع الأحدث.

## الأمن السيبراني والتنبيهات الحكومية

### موجزات RSS/Atom
- **CERT-EU Security Advisories** — [https://cert.europa.eu/publications/security-advisories-rss](https://cert.europa.eu/publications/security-advisories-rss)
  - الناشر: [https://cert.europa.eu/publications/security-advisories/2026](https://cert.europa.eu/publications/security-advisories/2026)
  - التحقق: CERT-EU's official advisory index links this exact HTTPS RSS endpoint. The endpoint returned a populated RSS feed; a real item is 2026-016 (Critical Vulnerability in GitLab CE and EE), published 2026-10-12, with a linked advisory.
- **FortiGuard Labs Threat Signal Report** — [https://filestore.fortinet.com/fortiguard/rss/threatsignal.xml](https://filestore.fortinet.com/fortiguard/rss/threatsignal.xml)
  - الناشر: [https://www.fortiguard.com/rss-feeds](https://www.fortiguard.com/rss-feeds)
  - التحقق: FortiGuard's official RSS page lists this exact HTTPS endpoint under Threat Signal Report. It returned a populated RSS feed; the real lead item is Citrix NetScaler RCE zero-day Vulnerabilities, published 2026-10-08, linked to FortiGuard's report.
- **SonicWall PSIRT Advisories** — [https://psirtapi.global.sonicwall.com/api/v1/feed/rss.xml](https://psirtapi.global.sonicwall.com/api/v1/feed/rss.xml)
  - الناشر: [https://psirt.global.sonicwall.com/rss-feeds](https://psirt.global.sonicwall.com/rss-feeds)
  - التحقق: SonicWall's official PSIRT RSS page links this exact HTTPS endpoint. It returned a populated RSS feed; the real lead item is SonicWall SMA1000 Series Appliances Affected By Multiple Vulnerabilities, published 2026-10-06, with a vulnerability-detail link.

### مشاريع مفتوحة المصدر
- **CVE Binary Tool** — [ossf/cve-bin-tool](https://github.com/ossf/cve-bin-tool); الترخيص المعلن: `GPL-3.0`.
  - الصفحة الرسمية: [https://github.com/ossf/cve-bin-tool](https://github.com/ossf/cve-bin-tool)
  - التحقق: Official GitHub API/repository identifies ossf/cve-bin-tool, reports archived=false and pushed_at 2026-10-12. GitHub's declared license metadata has SPDX ID GPL-3.0; the repository README documents the vulnerability-scanning purpose and Linux/Windows requirements.
- **OWASP Threat Dragon** — [OWASP/threat-dragon](https://github.com/OWASP/threat-dragon); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://owasp.org/www-project-threat-dragon/](https://owasp.org/www-project-threat-dragon/)
  - التحقق: Official OWASP GitHub API/repository reports archived=false and pushed_at 2026-10-12. GitHub's declared license metadata has SPDX ID Apache-2.0; the README documents web and desktop releases for Windows, macOS, and Linux.

### مراجع ومصادر تعلم
- **NIST NICE: Free and Low Cost Online Cybersecurity Learning Content** — [https://www.nist.gov/itl/applied-cybersecurity/nice/resources/online-learning-content](https://www.nist.gov/itl/applied-cybersecurity/nice/resources/online-learning-content)
  - التحقق: The official NIST HTTPS page exists and states that it is continually updated; it provides categorized practical training links and descriptions.
- **MITRE ATT&CK CTI Training and Learning Resources** — [https://attack.mitre.org/resources/learn-more-about-attack/](https://attack.mitre.org/resources/learn-more-about-attack/)
  - التحقق: The official MITRE ATT&CK HTTPS page exists and directly provides a CTI Training link, presentations, and reading materials for applying and understanding ATT&CK.

## الذكاء الاصطناعي وتعلم الآلة

### موجزات RSS/Atom
- **Hugging Face Blog** — [https://huggingface.co/blog/feed.xml](https://huggingface.co/blog/feed.xml)
  - الناشر: [https://huggingface.co/blog](https://huggingface.co/blog)
  - التحقق: The exact HTTPS endpoint returned a valid feed titled "Hugging Face - Blog" with real items including "Waypoint-1.5: Higher-Fidelity Interactive Worlds for Everyday GPUs" and "Multimodal Embedding & Reranker Models with Sentence Transformers"; the official blog page is live and lists current articles.
- **Google Research Blog** — [https://research.google/blog/rss/](https://research.google/blog/rss/)
  - الناشر: [https://research.google/blog/](https://research.google/blog/)
  - التحقق: The official blog explicitly links this exact RSS URL. Direct fetch returned RSS 2.0 with a current lastBuildDate and real items including "Does better work always mean better workers?", "Toward provably private learning from federated data", and "How Diffusion Controller unifies and simplifies AI image generation".
- **Microsoft Research** — [https://www.microsoft.com/en-us/research/feed/](https://www.microsoft.com/en-us/research/feed/)
  - الناشر: [https://www.microsoft.com/en-us/research/](https://www.microsoft.com/en-us/research/)
  - التحقق: The exact HTTPS endpoint returned RSS 2.0 with channel title "Microsoft Research" and real item "ADeLe: Predicting and explaining AI performance across tasks"; the official Research homepage links to this RSS feed and shows current AI research updates.

### مشاريع مفتوحة المصدر
- **MLX** — [ml-explore/mlx](https://github.com/ml-explore/mlx); الترخيص المعلن: `MIT`.
  - الصفحة الرسمية: [https://github.com/ml-explore/mlx](https://github.com/ml-explore/mlx)
  - التحقق: Official GitHub API identifies full_name ml-explore/mlx, description "MLX: An array framework for Apple silicon", archived=false, SPDX license MIT, and a push on 2026-10-13; the repository page confirms the MIT license and Apple ML research origin.
- **OpenVINO** — [openvinotoolkit/openvino](https://github.com/openvinotoolkit/openvino); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://github.com/openvinotoolkit/openvino](https://github.com/openvinotoolkit/openvino)
  - التحقق: Official GitHub API identifies full_name openvinotoolkit/openvino, archived=false, SPDX license Apache-2.0, and a push on 2026-10-13; the repository page describes it as an open-source AI inference toolkit and shows active documentation/tutorial links.
- **NVIDIA NeMo Speech** — [NVIDIA-NeMo/Speech](https://github.com/NVIDIA-NeMo/Speech); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://github.com/NVIDIA-NeMo/Speech](https://github.com/NVIDIA-NeMo/Speech)
  - التحقق: The official GitHub API resolves the requested NVIDIA/NeMo path to the current exact repository NVIDIA-NeMo/Speech; metadata shows archived=false, SPDX license Apache-2.0, and a push on 2026-10-13. The repository README marks the project active and documents NeMo Speech 3.0.0.

### مراجع ومصادر تعلم
- **Machine Learning Systems (MLSysBook)** — [https://www.mlsysbook.ai/](https://www.mlsysbook.ai/)
  - التحقق: The official site exists and identifies itself as a two-volume Machine Learning Systems textbook/curriculum from Harvard University and MIT Press; it states it is actively maintained and links working volumes, labs, TinyTorch, and hardware kits.
- **Full Stack Deep Learning** — [https://fullstackdeeplearning.com/](https://fullstackdeeplearning.com/)
  - التحقق: The official site exists, describes itself as resources for people building AI-powered products, and provides maintained 2022 Deep Learning and 2023 LLM Bootcamp course pages covering end-to-end production practice.

## البرمجة وهندسة البرمجيات

### موجزات RSS/Atom
- **Google Testing Blog** — [https://testing.googleblog.com/feeds/posts/default](https://testing.googleblog.com/feeds/posts/default)
  - الناشر: [https://testing.googleblog.com/](https://testing.googleblog.com/)
  - التحقق: Verified the HTTPS endpoint returns HTTP 200 Atom XML with real entries; the first current item is “Two-Way Doors: Don’t Code Yourself into a Corner” (2026-10-05). The publisher site identifies it as Google’s Testing Blog and shows current testing/engineering posts.
- **Kotlin Blog** — [https://blog.jetbrains.com/kotlin/feed/](https://blog.jetbrains.com/kotlin/feed/)
  - الناشر: [https://blog.jetbrains.com/kotlin/](https://blog.jetbrains.com/kotlin/)
  - التحقق: Verified the HTTPS endpoint returns HTTP 200 RSS XML with real items, including “Compose Multiplatform 1.12.0 Released” (2026-08-26). JetBrains’ official Kotlin page links this exact RSS endpoint and lists current Kotlin language/toolchain posts.

### مشاريع مفتوحة المصدر
- **ArchUnit** — [https://github.com/TNG/ArchUnit](https://github.com/TNG/ArchUnit); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://www.archunit.org/](https://www.archunit.org/)
  - التحقق: Official GitHub API for TNG/ArchUnit reports archived=false, recent pushes on 2026-10-13, and license.spdx_id=Apache-2.0. The official site and README describe architecture checks for Java code and link the same repository.
- **PIT** — [https://github.com/hcoles/pitest](https://github.com/hcoles/pitest); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://pitest.org/](https://pitest.org/)
  - التحقق: Official GitHub API for hcoles/pitest reports archived=false, a push on 2026-10-13, and license.spdx_id=Apache-2.0. The official PIT site identifies it as actively developed mutation testing and links the repository as its source.
- **detekt** — [https://github.com/detekt/detekt](https://github.com/detekt/detekt); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://detekt.dev/](https://detekt.dev/)
  - التحقق: Official GitHub API for detekt/detekt reports archived=false, a push on 2026-10-10, and license.spdx_id=Apache-2.0. The official site and README describe Kotlin static analysis, Gradle/Maven/Bazel integration, and extensible rules.

### مراجع ومصادر تعلم
- **Google Engineering Practices Documentation** — [https://google.github.io/eng-practices/](https://google.github.io/eng-practices/)
  - التحقق: Verified the official Google Engineering Practices documentation page exists and explicitly provides generalized engineering practices plus linked reviewer and change-author code-review guides.
- **C4 Model** — [https://c4model.com/](https://c4model.com/)
  - التحقق: Verified the official C4 Model site exists, describes system/container/component/code abstractions and corresponding diagrams, and identifies itself as written by creator Simon Brown.

## Linux والأنظمة مفتوحة المصدر

### موجزات RSS/Atom
- **Linux Kernel Archives – Distribution RSS** — [https://www.kernel.org/feeds/kdist.xml](https://www.kernel.org/feeds/kdist.xml)
  - الناشر: [https://www.kernel.org/](https://www.kernel.org/)
  - التحقق: The official kernel.org FAQ explicitly publishes this exact feed URL. Direct HTTPS retrieval parsed as RSS 2.0 with 9 item elements; first real item was ‘7.3-rc7: mainline’ (12 Oct 2026).
- **openSUSE News** — [https://news.opensuse.org/feed/](https://news.opensuse.org/feed/)
  - الناشر: [https://news.opensuse.org/](https://news.opensuse.org/)
  - التحقق: Direct HTTPS retrieval returned a valid RSS 2.0 document whose channel identifies ‘Latest news from the openSUSE Project’ and contained 10 items; first real item was ‘Post-Quantum Backups Land in openSUSE Factory with ZUPT’ (4 Oct 2026).
- **Fedora Magazine** — [https://fedoramagazine.org/feed/](https://fedoramagazine.org/feed/)
  - الناشر: [https://fedoramagazine.org/](https://fedoramagazine.org/)
  - التحقق: Direct HTTPS retrieval returned a valid RSS 2.0 document with 10 items; first real item was ‘Podman Test Week: Help test the Rust-based conmon v3’ (7 Oct 2026). The publisher describes the site as guides, information and news about Fedora for users, developers and administrators.

### مشاريع مفتوحة المصدر
- **Glance** — [glanceapp/glance](https://github.com/glanceapp/glance); الترخيص المعلن: `AGPL-3.0`.
  - الصفحة الرسمية: [https://github.com/glanceapp/glance](https://github.com/glanceapp/glance)
  - التحقق: Official GitHub repository page identifies the exact repo and AGPL-3.0 license; GitHub API returned archived=false and license.spdx_id=AGPL-3.0. The README documents RSS, Docker-status and server-statistics widgets and a small binary/container.
- **Syncthing** — [syncthing/syncthing](https://github.com/syncthing/syncthing); الترخيص المعلن: `MPL-2.0`.
  - الصفحة الرسمية: [https://github.com/syncthing/syncthing](https://github.com/syncthing/syncthing)
  - التحقق: Official GitHub repository page identifies syncthing/syncthing and MPLv2; GitHub API returned archived=false and license.spdx_id=MPL-2.0. README states it synchronizes files between two or more computers and provides Linux, macOS and Windows GUI implementations.
- **SeaweedFS** — [seaweedfs/seaweedfs](https://github.com/seaweedfs/seaweedfs); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://github.com/seaweedfs/seaweedfs](https://github.com/seaweedfs/seaweedfs)
  - التحقق: Official GitHub repository page identifies the exact repo, describes S3/POSIX/Iceberg capabilities, and declares Apache License 2.0; GitHub API returned archived=false and license.spdx_id=Apache-2.0. The repository includes Docker and Kubernetes deployment material.

### مراجع ومصادر تعلم
- **ArchWiki** — [https://wiki.archlinux.org/](https://wiki.archlinux.org/)
  - التحقق: The official HTTPS page exists, labels itself ‘ArchWiki’ and states it is the source for Arch Linux documentation; it links to the installation guide, general recommendations and application index. Page was last edited 18 Dec 2025.
- **Linux From Scratch (LFS)** — [https://www.linuxfromscratch.org/](https://www.linuxfromscratch.org/)
  - التحقق: The official HTTPS LFS homepage exists and explicitly describes the project as step-by-step instructions for building a custom Linux system from source; it links maintained LFS, BLFS, ALFS, MLFS, GLFS and SLFS subprojects.

## السحابة وDevOps

### موجزات RSS/Atom
- **The Crossplane Blog** — [https://blog.crossplane.io/rss/](https://blog.crossplane.io/rss/)
  - الناشر: [https://blog.crossplane.io/](https://blog.crossplane.io/)
  - التحقق: Official Crossplane publisher page links to this exact Subscribe endpoint. The endpoint returned a parseable RSS feed with real current items, including ‘Cutting Provider Memory by 80%: crossplane-runtime v2.4 and Client Caching’ (2026-10-08).
- **OpenTofu Blog** — [https://opentofu.org/blog/rss.xml](https://opentofu.org/blog/rss.xml)
  - الناشر: [https://opentofu.org/blog/](https://opentofu.org/blog/)
  - التحقق: Opened the official OpenTofu RSS endpoint directly; it returned a valid feed with current real items, including ‘OpenTofu v1.13.0’ (2026-09-29). The official blog page independently shows the same current post.
- **Cilium Blog** — [https://cilium.io/blog/rss.xml](https://cilium.io/blog/rss.xml)
  - الناشر: [https://cilium.io/blog/](https://cilium.io/blog/)
  - التحقق: Opened the official Cilium feed endpoint directly; it returned a valid RSS feed with multiple real items, including ‘Cilium 1.20, Network Policy enhancements, Multi Pool IPAM goes stable, IPv6 progress, and more!’ (2026-07-31) and ‘Securing CI/CD for an open source project: lessons from Cilium’ (2026-05-06).

### مشاريع مفتوحة المصدر
- **K8GB** — [https://github.com/k8gb-io/k8gb](https://github.com/k8gb-io/k8gb); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://github.com/k8gb-io/k8gb](https://github.com/k8gb-io/k8gb)
  - التحقق: Official repository k8gb-io/k8gb was inspected; GitHub API reports archived=false and license.spdx_id=Apache-2.0. The repository was pushed 2026-10-13 and its README describes the Kubernetes Global Balancer and Helm deployment.
- **KubeVela** — [https://github.com/kubevela/kubevela](https://github.com/kubevela/kubevela); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://github.com/kubevela/kubevela](https://github.com/kubevela/kubevela)
  - التحقق: Official repository kubevela/kubevela was inspected; GitHub API reports archived=false and license.spdx_id=Apache-2.0. The repository was pushed 2026-10-12 and its README identifies KubeVela as a modern application delivery platform for hybrid and multi-cloud environments.
- **Kubescape** — [https://github.com/kubescape/kubescape](https://github.com/kubescape/kubescape); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://github.com/kubescape/kubescape](https://github.com/kubescape/kubescape)
  - التحقق: Official repository kubescape/kubescape was inspected; GitHub API reports archived=false and license.spdx_id=Apache-2.0. The repository was pushed 2026-10-13 and its README documents Kubernetes security coverage from development through runtime.

### مراجع ومصادر تعلم
- **Platform Engineering University: Kubernetes Cluster Lifecycle Management** — [https://university.platformengineering.org/kubernetes-cluster-lifecycle-management-in-platform-engineering](https://university.platformengineering.org/kubernetes-cluster-lifecycle-management-in-platform-engineering)
  - التحقق: The official Platform Engineering University page exists and explicitly lists the course as free, on-demand, two hours, with four modules covering declarative management, fleet-scale Day 2 operations, governance, policy, and security.
- **OpenTofu Documentation: Introduction** — [https://opentofu.org/docs/intro/](https://opentofu.org/docs/intro/)
  - التحقق: The official OpenTofu documentation page exists and explains the core workflow, provider model, state, reusable modules, and managing cloud and on-premises infrastructure.

## Android والهواتف المحمولة

### موجزات RSS/Atom
- **F-Droid Blog** — [https://f-droid.org/feed.xml](https://f-droid.org/feed.xml)
  - الناشر: [https://f-droid.org/en/](https://f-droid.org/en/)
  - التحقق: تم فتح نقطة النهاية المباشرة عبر HTTPS وأعادت Atom XML صالحاً بعنوان F-Droid - Free and Open Source Android App Repository؛ يتضمن عناصر حقيقية، منها Taking F-Droid to IndiaFOSS بتاريخ 2026-10-02 ورابطه الرسمي.
- **LineageOS News** — [https://lineageos.org/feed.xml](https://lineageos.org/feed.xml)
  - الناشر: [https://lineageos.org/](https://lineageos.org/)
  - التحقق: تم فتح https://lineageos.org/feed.xml مباشرة وأعادت RSS 2.0 صالحاً؛ يتضمن عناصر حقيقية، منها Changelog 32 - Slick Seventeen, Awesome Applications, Universal USB Tools بتاريخ 2026-10-11 ورابطه الرسمي.
- **Android Developers Blog** — [https://android-developers.googleblog.com/feeds/posts/default](https://android-developers.googleblog.com/feeds/posts/default)
  - الناشر: [https://android-developers.googleblog.com/](https://android-developers.googleblog.com/)
  - التحقق: تم فتح نقطة النهاية المباشرة عبر HTTPS وأعادت Atom صالحاً بعنوان Android Developers Blog؛ يتضمن عناصر حقيقية، منها Device Streaming and Android skills - available in Android CLI بتاريخ 2026-10-02، مع رابط المقال الرسمي في المدونة.

### مشاريع مفتوحة المصدر
- **Rethink DNS + Firewall + VPN** — [https://github.com/celzero/rethink-app](https://github.com/celzero/rethink-app); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://github.com/celzero/rethink-app](https://github.com/celzero/rethink-app)
  - التحقق: المستودع الرسمي celzero/rethink-app غير مؤرشف وفق GitHub API (archived=false)، وآخر دفع مسجل 2026-10-12؛ GitHub يعلن SPDX license=Apache-2.0، والـREADME يصف ميزات DoH/DoT/DNSCrypt والجدار الناري وWireGuard.
- **Molly** — [https://github.com/mollyim/mollyim-android](https://github.com/mollyim/mollyim-android); الترخيص المعلن: `AGPL-3.0`.
  - الصفحة الرسمية: [https://github.com/mollyim/mollyim-android](https://github.com/mollyim/mollyim-android)
  - التحقق: المستودع الرسمي mollyim/mollyim-android غير مؤرشف وفق GitHub API (archived=false)، وآخر دفع مسجل 2026-10-09؛ GitHub يعلن SPDX license=AGPL-3.0، والـREADME يحدد الترخيص AGPL-3.0-only ويصف إصدار Molly-FOSS وميزات التشفير وUnifiedPush.
- **Obtainium** — [https://github.com/ImranR98/Obtainium](https://github.com/ImranR98/Obtainium); الترخيص المعلن: `GPL-3.0`.
  - الصفحة الرسمية: [https://github.com/ImranR98/Obtainium](https://github.com/ImranR98/Obtainium)
  - التحقق: المستودع الرسمي ImranR98/Obtainium غير مؤرشف وفق GitHub API (archived=false)، وآخر دفع مسجل 2026-09-13؛ GitHub يعلن SPDX license=GPL-3.0، والـREADME يذكر دعم GitHub/GitLab/Forgejo/F-Droid وIzzyOnDroid ومصادر أخرى.

### مراجع ومصادر تعلم
- **Android Developers Training** — [https://developer.android.com/courses](https://developer.android.com/courses)
  - التحقق: تم فتح الصفحة الرسمية بنجاح؛ عنوانها Training courses وتعرض دورة Android Basics with Compose ومسارات Compose وAndroid app architecture وAccessibility.
- **AOSP Android Security documentation** — [https://source.android.com/docs/security](https://source.android.com/docs/security)
  - التحقق: تم فتح صفحة AOSP الرسمية بنجاح؛ تعرض Security overview وSecurity features وSecurity bulletins وTesting وBest practices، ومذكور أنها محدثة في 2026-09-30 UTC.

## الخصوصية والأجهزة والتقنية الاستهلاكية

### موجزات RSS/Atom
- **Internet Society** — [https://www.internetsociety.org/feed/](https://www.internetsociety.org/feed/)
  - الناشر: [https://www.internetsociety.org/](https://www.internetsociety.org/)
  - التحقق: تم فتح نقطة النهاية المباشرة عبر HTTPS؛ وهي RSS 2.0 وتحتوي على رابط self صحيح وعناصر حقيقية، منها The EU KIDS Act Should Make Services Safer, Not Create an Internet Badge بتاريخ 2026-10-12. الوصف الرسمي يركز على إنترنت مفتوح وآمن وموثوق.
- **F-Droid News** — [https://f-droid.org/feed.xml](https://f-droid.org/feed.xml)
  - الناشر: [https://f-droid.org/](https://f-droid.org/)
  - التحقق: تم فتح عنوان RSS المباشر عبر HTTPS؛ القناة معنونة F-Droid - Free and Open Source Android App Repository وتحتوي عناصر فعلية، منها Taking F-Droid to IndiaFOSS بتاريخ 2026-10-02. المصدر الرسمي يعرّف نفسه كمنظومة توزيع تطبيقات أندرويد حرة ومفتوحة المصدر.
- **GrapheneOS Releases** — [https://grapheneos.org/releases.atom](https://grapheneos.org/releases.atom)
  - الناشر: [https://grapheneos.org/releases](https://grapheneos.org/releases)
  - التحقق: صفحة الإصدارات الرسمية تؤكد أن /releases.atom موجز Atom للاستخدام مع قارئات الخلاصات؛ تم فتح نقطة النهاية المباشرة ووجدت عناصر إصدار حقيقية، منها 2026092500 بتاريخ 2026-09-25.

### مشاريع مفتوحة المصدر
- **Rethink DNS + Firewall + VPN** — [https://github.com/celzero/rethink-app](https://github.com/celzero/rethink-app); الترخيص المعلن: `Apache-2.0`.
  - الصفحة الرسمية: [https://rethinkdns.com/](https://rethinkdns.com/)
  - التحقق: المستودع الرسمي celzero/rethink-app فُتح مباشرة؛ صفحة GitHub تصفه كتطبيق DNS-over-HTTPS/DNS-over-Tor/DNSCrypt وWireGuard وجدار ناري، وتعرض Apache-2.0. فحص GitHub API يؤكد archived=false وlicense.spdx_id=Apache-2.0 وتحديثاً حديثاً في 2026-10-13.
- **Technitium DNS Server** — [https://github.com/TechnitiumSoftware/DnsServer](https://github.com/TechnitiumSoftware/DnsServer); الترخيص المعلن: `GPL-3.0`.
  - الصفحة الرسمية: [https://technitium.com/dns/](https://technitium.com/dns/)
  - التحقق: المستودع الرسمي TechnitiumSoftware/DnsServer فُتح مباشرة؛ README يذكر الاستضافة الذاتية للخصوصية والأمان وDoH/DoT/DoQ، وصفحة GitHub تعرض GPL-3.0. فحص GitHub API يؤكد archived=false وlicense.spdx_id=GPL-3.0 وتحديثاً حديثاً في 2026-10-13.
- **Portmaster** — [https://github.com/safing/portmaster](https://github.com/safing/portmaster); الترخيص المعلن: `GPL-3.0`.
  - الصفحة الرسمية: [https://safing.io/](https://safing.io/)
  - التحقق: المستودع الرسمي safing/portmaster فُتح مباشرة؛ README يصفه كتطبيق جدار ناري حر ومفتوح المصدر مع مراقبة الشبكة وDoH/DoT، وصفحة GitHub تعرض GPL-3.0. فحص GitHub API يؤكد archived=false وlicense.spdx_id=GPL-3.0 وتحديثاً حديثاً في 2026-10-13.

### مراجع ومصادر تعلم
- **Internet Society: Privacy Course** — [https://www.internetsociety.org/learning/privacy/](https://www.internetsociety.org/learning/privacy/)
  - التحقق: تم فتح صفحة المورد الرسمية؛ الصفحة تعرض أهداف الدورة ووحداتها، وتذكر أنها متاحة عبر الإنترنت طوال العام وبصيغة تعليمية ذاتية تقارب 20 ساعة، بالإنجليزية والفرنسية والإسبانية.
- **Privacy Guides: Why Privacy Matters** — [https://www.privacyguides.org/en/basics/why-privacy-matters/](https://www.privacyguides.org/en/basics/why-privacy-matters/)
  - التحقق: تم فتح صفحة Privacy Guides الرسمية؛ الصفحة موجودة ضمن Knowledge Base وتشرح الفروق بين الخصوصية والأمن وإخفاء الهوية، وتربط مباشرة بصفحات نمذجة التهديدات وكلمات المرور والعتاد وDNS وأنظمة التشغيل.

## مصادر التقنية العربية والتعليم

### موجزات RSS/Atom
- **التقنية السورية Syrian Tech** — [https://syriantech.com/feed/](https://syriantech.com/feed/)
  - الناشر: [https://syriantech.com/](https://syriantech.com/)
  - التحقق: تم فتح صفحة الناشر الرسمية والخلاصة المباشرة؛ endpoint يعيد RSS 2.0 صالحاً بعنوان التقنية السورية، language=ar، lastBuildDate=2026-10-13، وعدة عناصر حقيقية حديثة، منها «جوجل تكشف عن سوار Fitbit Edge ببطارية قابلة للاستبدال».

### مشاريع مفتوحة المصدر
- **SC-100 Microsoft Cybersecurity Architect** — [SiteQ8/SC-100](https://github.com/SiteQ8/SC-100); الترخيص المعلن: `MIT`.
  - الصفحة الرسمية: [https://github.com/SiteQ8/SC-100](https://github.com/SiteQ8/SC-100)
  - التحقق: فحصت صفحة GitHub وGitHub API للمستودع المحدد: public، archived=false، وlicense.spdx_id=MIT؛ الصفحة تعرض 35 commit وآخر تحديث API في 2026-10-12، كما تنص README على وجود إرشادات عربية لكل موضوع.
- **sayf-eval** — [qcri/sayf-eval](https://github.com/qcri/sayf-eval); الترخيص المعلن: `MIT`.
  - الصفحة الرسمية: [https://github.com/qcri/sayf-eval](https://github.com/qcri/sayf-eval)
  - التحقق: فحصت صفحة GitHub وGitHub API للمستودع المحدد: public، archived=false، وlicense.spdx_id=MIT؛ API يذكر updated_at=2026-10-04 و86 commit، وREADME يثبت نطاق تقييم benchmarks للأمن السيبراني ودعم النماذج المستضافة والمحلية.
- **Arabic/RTL Agent Security Lab** — [mirogate/arabic-rtl-agent-security-lab](https://github.com/mirogate/arabic-rtl-agent-security-lab); الترخيص المعلن: `MIT`.
  - الصفحة الرسمية: [https://github.com/mirogate/arabic-rtl-agent-security-lab](https://github.com/mirogate/arabic-rtl-agent-security-lab)
  - التحقق: فحصت صفحة GitHub وGitHub API للمستودع المحدد: public، archived=false، وlicense.spdx_id=MIT؛ README يثبت 20 سيناريو اصطناعياً قابلاً للتنفيذ mapped إلى OWASP Top 10 for Agentic Applications، وAPI يذكر updated_at=2026-08-09.

### مراجع ومصادر تعلم
- **مركز التعلم — أكاديمية سينباي** — [https://academysenpai.com/learning](https://academysenpai.com/learning)
  - التحقق: تم فتح الصفحة الرسمية؛ تعرض 130+ مصدراً، و17+ منصة/مختبراً، وأقساماً مستقلة للقنوات والمنصات والشهادات وpayloads وbug bounty وسيناريوهات الهجوم، مع روابط مباشرة.
- **الأدلة الإرشادية — سايبرنس** — [https://www.nist.gov/cyberframework](https://www.nist.gov/cyberframework)
  - التحقق: تم فتح الصفحة الرسمية؛ تعرض 12 دليلاً تفاعلياً مجانياً، وأكثر من 100 نصيحة عملية قابلة للتطبيق فوراً، مع روابط الأدلة التفصيلية.
