# سجل فحص مرشحي المصادر — 20 أكتوبر 2026

استُخدمت صفحات الناشرين الرسمية أو المستودعات الرسمية، لا مقتطفات نتائج البحث وحدها. التصنيف `resource` يعني مرجعاً/صفحة ويب ثابتة، لا موجز RSS/Atom. لم تُختبر روابط الصفحات الثابتة اختبار HTTP مستقلاً؛ اختبرت صفحة المصدر الرسمية بالمراجعة. لا تنشر خلاصات أو واجهات تلقائية لم تُثبت.

## تنبيهات عربية وموارد التعلم

- **Saudi CERT — التنبيهات الأمنية**، صفحة مورد، عربي/إنجليزي: https://nca.gov.sa/ar/cert/ — الدليل الرسمي المفتوح: https://nca.gov.sa/ar/cert/8063/ . لم يُتحقق من RSS/Atom.
- **EG-CERT — Cybersecurity Alerts**، أرشيف تنبيهات رسمي: https://egcert.eg/alerts/ — الدليل المفتوح: https://egcert.eg/alerts/f5-3/ . لم يُتحقق من RSS/Atom.
- **Cisco Networking Academy — محلل الأمن السيبراني المبتدئ**، مسار عربي: https://www.netacad.com/career-paths/cybersecurity?courseLang=ar-SA . الصفحة الرسمية تذكر مساراً تمهيدياً عربياً؛ دورات المسار مجانية وفق الصفحة، والشهادة قد تكون منفصلة.
- **ITI — أكاديمية الأمن السيبراني للمبتدئين على مهارة-تك**: https://itimooca.iti.gov.eg/mod/page/view.php?id=14058 . الصفحة الرسمية تذكر دورات مجانية والتعلم الذاتي، والتسجيل يجمع بيانات اتصال حسب بيان الخصوصية.
- **مبادرة المجتمع الرقمي الآمن — وزارة الاتصالات المصرية**: https://www.basicict.gov.eg/faqCisEN.aspx . صفحة أسئلة رسمية تذكر مقررات مجانية؛ تحقق اللغة والإتاحة بحسب وصف المقرر.
- **Google — أمان تكنولوجيا المعلومات: الحماية من الهجمات الرقمية**: https://www.coursera.org/learn/it-security-ar . صفحة الدورة تعرض لغة التدريس العربية وخيار تسجيل مجاني؛ لا يعني ذلك بالضرورة مجانية الشهادة أو كل التقييمات.

## موجز وتنبيهات مزودين

- **Google Chrome Releases — Atom**: https://chromereleases.googleblog.com/atom.xml . مدونة الإصدار الرسمية: https://chromereleases.googleblog.com/ . موجز إصدارات عام، ليس أمنياً صرفاً؛ يلزم اختبار HTTP/XML قبل الإضافة.
- **Microsoft Security Update Guide Notifications**: https://www.microsoft.com/en-us/msrc/technical-security-notifications . خدمة إشعارات بريدية رسمية، ليست RSS/Atom.

## السحابة والحاويات وخصوصية الأجهزة

- **Microsoft Defender for Containers — documentation**: https://learn.microsoft.com/en-us/azure/defender-for-cloud/defender-for-containers-introduction .
- **Google Cloud Enterprise foundations blueprint**: https://cloud.google.com/architecture/security-foundations . يتضمن أصول Terraform قد تنشئ موارد أو تكاليف.
- **Docker Engine security**: https://docs.docker.com/engine/security/ . ينبه إلى خطورة صلاحيات Docker daemon.
- **Secure GitLab CI/CD secrets with HashiCorp Vault**: https://developer.hashicorp.com/well-architected-framework/secure-systems/secure-applications/ci-cd-secrets/gitlab . استخدم أسراراً وهمية ومختبراً.
- **Android Help — security and privacy settings**: https://support.google.com/android/answer/13985942?hl=en . تتوفر ترجمات، وقد تختلف الإعدادات حسب الجهاز والإصدار.
- **Apple Personal Safety User Guide**: https://support.apple.com/guide/personal-safety/welcome/web . بعض إجراءات المشاركة قد تؤثر في السلامة أو تُخطر الآخرين.
- **EFF Surveillance Self-Defense**: https://ssd.eff.org/ . دليل توعوي غير ربحي، ليس موجزاً.

## أمن الذكاء الاصطناعي

- **NIST AI Risk Management Framework**: https://www.nist.gov/itl/ai-risk-management-framework . تحقق من وجوده في الجرد الحالي لتجنب التكرار قبل الإضافة.
- **NIST AI 100-2 E2025 — Adversarial Machine Learning**: https://csrc.nist.gov/pubs/ai/100/2/e2025/final .
- **OWASP Top 10 for LLM Applications — 2025**: https://genai.owasp.org/llm-top-10/ . تحقق من وجود المرجع في الجرد الحالي؛ لا تكرر.
- **MITRE ATLAS**: https://atlas.mitre.org/ . قاعدة معرفة متجددة، وليست RSS/Atom.

## الاستجابة والتحليل الجنائي

- **CISA Incident Response Training**: https://www.cisa.gov/resources-tools/programs/Incident-Response-Training . توفر الدورات/الأهلية متفاوت حسب البرنامج.
- **Blue Team Labs Online**: https://blueteamlabs.online/ . تحديات ومختبرات، بعضها مجاني وبعضها مدفوع.
- **CyberDefenders**: https://cyberdefenders.org/ . منصة تدريب وتحقيقات دفاعية؛ شروط الوصول تختلف.
- **SANS Digital Forensics & Incident Response**: https://www.sans.org/cybersecurity-focus-areas/digital-forensics-incident-response . معظم التدريب منظم/مدفوع.

## أدوات دفاعية مرشحة

- **Hayabusa**: https://github.com/Yamato-Security/hayabusa — مستودع رسمي، تصنيف دفاعي لتحليل سجلات Windows؛ صفحة المستودع تذكر AGPLv3. أُضيف بعد التحقق من المستودع، ودليل التوافر HTTP 200 والترخيص AGPLv3؛ يظهر كأداة تحليل سجلات Windows بمستوى متقدم.
- **Tetragon**: https://github.com/cilium/tetragon — Apache-2.0 وفق المستودع؛ تحقق من التكرار.
- **Falco**: https://github.com/falcosecurity/falco — Apache-2.0 وفق المستودع؛ تحقق من التكرار.

## ملاحظات تحقق

اختُبر موجز Chrome Atom فرجع بمحتوى Atom، لكنه يعيد التوجيه إلى HTTP غير مشفر، لذلك لم يُعتمد كمصدر داخل التطبيق. لم تُعتمد روابط RSS لمصادر CERT العربية أو Microsoft أو الصفحات الثابتة. نتائج صفحات التدريب والأدوات تُعرض بوصفها روابط للمصدر الأصلي؛ لم يُثبت التسجيل أو الإتاحة الإقليمية لحساب المستخدم. استخدم المختبرات فقط في بيئة مملوكة أو مصرّح بها واتبع شروط الخدمة والترخيص. لم يُجر البحث دعوى تغطية شاملة لكل مصدر عربي أو عالمي.


## نتائج فحص المرشحين التي استُخدمت لقرار الإصدار 2.10.0

في 20 أكتوبر 2026 أعادت 200 روابط Saudi CERT وChrome Atom (لكن Atom حوّل إلى HTTP، فاستُبعد) وMicrosoft SUG وMicrosoft Defender for Containers وDocker وHashiCorp وAndroid Help وApple Personal Safety وOWASP GenAI وMITRE ATLAS وBlue Team Labs Online وSANS DFIR وCisco NetAcad وCoursera وGitHub Hayabusa. تعذر التحقق من EG-CERT وITI وBasicICT بسبب أخطاء TLS، وأعادت صفحة CISA IR تدريب استجابة 403 من بيئة الاختبار، لذا لم تُضف هذه الصفحات في هذا الإصدار. هذا اختبار اتصال في بيئة التطوير وليس ضمان توافر دائم أو نتيجة تصل إلى كل جهاز.
