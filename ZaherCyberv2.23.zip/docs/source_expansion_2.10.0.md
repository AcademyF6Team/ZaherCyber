# توسعة المصادر — ZaherCyber 2.10.0

أُضيفت 13 صفحة معرفة رسمية/مرجعية جديدة موزعة على الأمن العربي، أمن المنصات، خصوصية الهواتف، أمن الذكاء الاصطناعي، والتحقيق والاستجابة. الروابط تفتح مواقع الناشرين؛ التطبيق لا ينسخ محتواهم، ولا يشغّل مختبراتهم أو أدواتهم.

## مصادر عربية وتنبيهات وتعلّم

- [Saudi CERT — التنبيهات الأمنية](https://nca.gov.sa/ar/cert/) — تنبيهات رسمية؛ صفحة ثابتة وليست موجز RSS.
- [Cisco Networking Academy — المسار العربي لمحلل الأمن السيبراني المبتدئ](https://www.netacad.com/career-paths/cybersecurity?courseLang=ar-SA) — تمهيدي؛ قد تكون الشهادة منفصلة عن الدروس.
- [Google IT Security (Coursera) — دورة عربية](https://www.coursera.org/learn/it-security-ar) — التسجيل المجاني لا يعني بالضرورة مجانية كل التقييمات أو الشهادة.

## أمن السحابة والحاويات والمنصات

- [Microsoft Security Update Guide Notifications](https://www.microsoft.com/en-us/msrc/technical-security-notifications) — إشعارات بريدية رسمية، وليست موجز RSS.
- [Microsoft Defender for Containers](https://learn.microsoft.com/en-us/azure/defender-for-cloud/defender-for-containers-introduction) — توثيق تقييم وحماية الحاويات؛ قد تتطلب خدمات Azure تكلفة/ترخيصاً.
- [Docker Engine security](https://docs.docker.com/engine/security/) — مرجع رسمي؛ صلاحية الوصول إلى Docker daemon قد تمنح امتيازات قوية على المضيف.
- [HashiCorp Vault — GitLab CI/CD secrets](https://developer.hashicorp.com/well-architected-framework/secure-systems/secure-applications/ci-cd-secrets/gitlab) — استخدم أسراراً وهمية في التدريب، لا بيانات إنتاج.

## خصوصية وسلامة الأجهزة المحمولة

- [Android Help — إعدادات الأمان والخصوصية](https://support.google.com/android/answer/13985942?hl=en) — تختلف الإعدادات باختلاف الجهاز وإصدار النظام.
- [Apple Personal Safety User Guide](https://support.apple.com/guide/personal-safety/welcome/web) — راعِ تبعات السلامة قبل تغيير مشاركة الموقع أو الوصول.

## أمن تطبيقات الذكاء الاصطناعي

- [OWASP Top 10 for LLM Applications — 2025](https://genai.owasp.org/llm-top-10/) — مرجع للمخاطر والضوابط الدفاعية؛ الاختبار للأنظمة المصرح بها فقط.
- [MITRE ATLAS](https://atlas.mitre.org/) — قاعدة معرفة لتهديدات أنظمة الذكاء الاصطناعي وتخفيفاتها.

## التحقيق والاستجابة

- [Blue Team Labs Online](https://blueteamlabs.online/) — تحديات دفاعية؛ تختلف الإتاحة بين المجاني والمدفوع وتطبق شروط التسجيل.
- [SANS Digital Forensics & Incident Response](https://www.sans.org/cybersecurity-focus-areas/digital-forensics-incident-response) — فهرس تدريب احترافي؛ تحقق من الرسوم وشروط التسجيل.

## الأداة المضافة

- [Hayabusa — Yamato-Security](https://github.com/Yamato-Security/hayabusa) — أداة دفاعية مفتوحة المصدر لتحليل سجلات أحداث Windows وصيد التهديدات بقواعد Sigma. يذكر المستودع ترخيص AGPL-3.0؛ أُدرجت بمستوى خبرة متقدم وعلى Windows/Linux. لا تُستخدم إلا مع سجلات تملكها أو لديك تفويض لتحليلها.

## منهج التحقق وما لم يُضف

أعاد فحص HTTP في 20 أكتوبر 2026 الحالة 200 للروابط أعلاه ولصفحة GitHub الرسمية لـHayabusa. هذه نتيجة اتصال من بيئة التطوير وليست ضماناً للتوفر الدائم أو الإقليمي. لم يُضف Chrome Atom لأنه أعاد التوجيه إلى HTTP غير مشفر، ولم تُضف EG-CERT وITI وBasicICT بسبب أخطاء شهادة TLS، كما لم تُضف صفحة تدريب CISA التي أعادت 403 في بيئة الاختبار. لم يُضف موجز أخبار جديد في هذا الإصدار: رابط Chrome غير آمن، وصفحة Microsoft للإشعارات خدمة بريد لا RSS؛ بقيت 86 موجز أخبار و7 موجزات شروحات كما هي.

تتطلب المختبرات والحسابات الخارجية اتصالاً وشروط خدمة خاصة؛ بعض المحتوى أو الشهادات قد تكون مدفوعة. هذه الروابط التعليمية لا تمثل تأييداً أو فحصاً أمنياً من ZaherCyber.
