# مركز الحماية والاستجابة العملية

## النطاق

مركز مستقل عن «المعرفة»، يقدّم إرشادات عملية عامة للمستخدم ولا يفحص الجهاز أو الشبكة، ولا يشغّل أدوات أمنية، ولا يغيّر إعدادات النظام تلقائياً. الخطوات الثنائية اللغة تربط كل إجراء بمصدر رسمي أو بوثائق المورّد ذات الصلة، وتنبّه إلى اختلاف القوائم حسب إصدار النظام والطراز ومزود الخدمة.

## قوائم تقوية الأنظمة

| المنصة | عدد الإجراءات | محاور مختارة |
|---|---:|---|
| Android | 8 | تحديثات النظام، Play Protect، مصادر تثبيت التطبيقات، أذونات التطبيقات، قفل الشاشة، حماية السرقة، Find Hub، Advanced Protection |
| Windows | 8 | Windows Update، Microsoft Defender، جدار الحماية، Controlled folder access، تشفير الجهاز، مفتاح BitLocker، التحقق بخطوتين، النسخ الاحتياطية |
| Ubuntu/Linux | 7 | التحديثات التلقائية، UFW، OpenSSH، أقلّ الامتيازات، AppArmor، مصادقة FIDO/U2F حيث تتوفر، أذونات مجلدات المستخدم |

تُعرض المخاطر بوصفها **أولوية إرشادية** لا درجة CVSS ولا ضماناً للسلامة. بعض الخطوات تعتمد على دعم الجهاز أو إصدار النظام؛ وتشرح البطاقة هذا القيد قبل تقديم الرابط الرسمي.

## أدلة الاستجابة للحوادث

تتضمن المكتبة خمسة أدلة مفصلة، لكل منها ملخص، وتسلسل إجراء، وروابط مرجعية، ومتى يجب إيقاف المعالجة الذاتية وطلب مساعدة مختص:

1. استعادة حساب يُشتبه في الاستيلاء عليه.
2. التعامل مع رسالة تصيد أو مرفق/رابط مشبوه.
3. الاستجابة لبرمجية فدية على جهاز محمول.
4. فقدان أو سرقة هاتف Android.
5. إبطال رمز أو سر GitHub مكشوف والتعامل مع تاريخ المستودع بحذر.

في «نظرة عامة» توجد اختيارات سريعة بعنوان **«ماذا حدث؟ ابدأ من هنا»** للحساب المخترق، والرسالة/الملف المشبوه، وفدية الهاتف، والهاتف المفقود، والرمز/السر المكشوف. يؤدي الاختيار إلى الدليل الموافق وفتحه مباشرةً، مع تمييز الإجراء الأول، ويمكن للمستخدم الرجوع إلى قائمة الأدلة كلها. إذا كان هناك خطر مباشر على الأشخاص، يُطلب الاتصال بخدمات الطوارئ المحلية أولاً. لا يُدخل المستخدم كلمات مرور أو رموز تحقق في التطبيق.

توضح الخطوات أن إجراءات مثل إعادة ضبط المصنع أو مسح الهاتف أو إعادة كتابة تاريخ Git قد تكون مدمّرة أو تؤدي إلى فقد بيانات/تعطيل خدمات؛ لا توصي بها لمجرد السرعة وتعرض نقاط التصعيد المناسبة. أدلة الحوادث معلومات عامة، وليست بديلاً عن فريق استجابة للحوادث أو دعم المزوّد أو المشورة القانونية/الطبية/المالية عند انطباقها.

## قائمة متابعة المنتجات والمشاريع

- تُدخل أسماء المنتجات أو المشاريع يدوياً، ويمكن اختيار مشروع موجود من «الترسانة».
- تُحفظ الكلمات وحالة إنجاز القوائم محلياً في مساحة التطبيق. لا تُرفع إلى خادم ZaherCyber.
- تطابق القائمة نصياً (دون ادعاء اكتشاف أسماء بديلة أو تحليل إصدارات) مع أحدث **300 سجل مخزن** من CISA Known Exploited Vulnerabilities (KEV)، ومع ما يصل إلى 12 مادة محمّلة من موجزات الأخبار/الشروحات تطابق المصطلح في العنوان أو المقتطف أو اسم المصدر.
- يُحدّث مخبأ KEV عند الطلب يدوياً، أو بعد انتهاء مدة التخزين المؤقت البالغة 8 ساعات عندما يتوفر اتصال. رادار قسم «المعرفة» يعرض أحدث 60 بنداً، بينما قائمة المتابعة تستعمل مجموعة 300 بند.
- CISA KEV قائمة بالثغرات التي ثبت استغلالها في الواقع وليست فهرساً شاملاً لكل CVE أو بديلاً لفحص الأصول. غياب نتيجة لا يثبت أن المنتج خالٍ من الثغرات، وقد تؤثر أسماء المنتجات/المورّدين أو السجلات الأقدم من نافذة 300 نتيجة المطابقة.
- تظهر النتائج والتنبيهات داخل التطبيق فقط. لا يفحص التطبيق الشبكة أو الجهاز. تعتمد التحديثات على فتح القسم أو طلب التحديث يدوياً.

## المصادر المرجعية

تتضمن البطاقات روابط المصدر الأصلي لكل خطوة. الجهات المستخدمة تشمل Google/Android، Microsoft، Canonical/Ubuntu، CISA، UK NCSC، U.S. FTC، Apple، وGitHub Docs. تُراجع الروابط من داخل البطاقة؛ وقد يحدّث الناشر مسارات الصفحات أو أسماء الإعدادات.

## الخصوصية

- لا يحتاج المركز إلى حساب ZaherCyber أو مفتاح API خاص.
- تقدم القوائم وكلمات المتابعة محفوظ محلياً باستخدام تخزين التطبيق؛ يوصى بمراجعة النسخ الاحتياطية/حذف بيانات التطبيق قبل بيع الجهاز.
- لا تضيف الاختيارات السريعة أو التوصيات أي تصدير أو ملف أو إرسال بيانات؛ سلوك التخزين المحلي الحالي لقوائم الإنجاز وكلمات المتابعة لم يتغير.
- تذهب طلبات تحديث KEV أو RSS مباشرة إلى الجهة الناشرة، التي تستقبل بيانات الشبكة الاعتيادية مثل عنوان IP.
- لا تُرسل بيانات الأجهزة إلى المركز، لأنه لا يجري فحصاً للجهاز ولا يقرأ إعداداته.

## فهرس المصادر التي تظهر داخل البطاقات

عدد الروابط الفريدة: **45**. تفتح الروابط الأصلية مباشرة؛ يحتفظ التطبيق بعناوين المراجع الواردة في المصدر الذي استُند إليه كل إجراء.

- [Alternative distribution options](https://developer.android.com/distribute/marketing-tools/alternative-distribution)
- [AppArmor](https://ubuntu.com/server/docs/how-to/security/apparmor/)
- [Apple Personal Safety User Guide — Restore device to factory settings](https://support.apple.com/guide/personal-safety/restore-device-to-factory-settings-ips4603248a8/web)
- [Back Up Your BitLocker Recovery Key](https://support.microsoft.com/en-us/windows/security/encryption/back-up-your-bitlocker-recovery-key)
- [Change app permissions on your Android phone](https://support.google.com/android/answer/9431959?hl=en)
- [Check & update your Android version](https://support.google.com/android/answer/7680439?hl=en)
- [CISA — I've Been Hit By Ransomware!](https://www.cisa.gov/stopransomware/ive-been-hit-ransomware)
- [CISA — Recognize and Report Phishing](https://www.cisa.gov/secure-our-world/recognize-and-report-phishing)
- [Cyber Threats to Mobile Phones — Cybersecurity and Infrastructure Security Agency (CISA)](https://www.cisa.gov/sites/default/files/publications/cyber_threats_to_mobile_phones.pdf)
- [Device Encryption in Windows](https://support.microsoft.com/en-us/windows/security/encryption/device-encryption-in-windows)
- [Find, secure, or erase a lost Android device](https://support.google.com/android/answer/6160491?hl=en)
- [Find, secure, or erase a lost Android device — Google Account Help](https://support.google.com/accounts/answer/6160491?hl=en)
- [Firewall](https://ubuntu.com/server/docs/how-to/security/firewalls/)
- [FTC — Malware: How To Protect Against, Detect, and Remove It](https://www.ftc.gov/media/79889)
- [Google Account Help — Remove malware or unsafe software (Android phone & tablet)](https://support.google.com/accounts/answer/9924802?hl=en&co=GENIE.Platform%3DAndroid)
- [Google Gmail Help — Avoid & report phishing emails](https://support.google.com/mail/answer/8253?hl=en)
- [How to Protect the Data that is Stored on Your Devices](https://www.cisa.gov/resources-tools/training/how-protect-data-stored-your-devices)
- [How to recover a hacked or compromised Microsoft account — Microsoft Support](https://support.microsoft.com/en-us/accounts-billing/manage/how-to-recover-a-hacked-or-compromised-microsoft-account)
- [How To Recover Your Hacked Email or Social Media Account — U.S. Federal Trade Commission (FTC)](https://consumer.ftc.gov/consumer-alerts/2024/10/email-or-social-media-hacked-heres-what-do)
- [How to use two-step verification with your Microsoft account](https://support.microsoft.com/en-us/accounts-billing/security/how-to-use-two-step-verification-with-your-microsoft-account)
- [If you think your Apple Account has been compromised — Apple Support](https://support.apple.com/en-us/102560)
- [Improve device security with Advanced Protection for Android](https://support.google.com/android/answer/16339980?hl=en)
- [Install Windows Updates](https://support.microsoft.com/en-us/windows/deployment/updates-lifecycle/install-windows-updates)
- [Lock or erase your lost phone or computer — Google Account Help](https://support.google.com/accounts/answer/7177579?hl=en)
- [Lock your lost or stolen Android device — Android/Google Find Hub Remote Lock](https://www.android.com/lock)
- [Microsoft Support — Protect yourself from phishing](https://support.microsoft.com/en-us/security/protect-yourself-from-phishing)
- [NCSC — Ransomware attack](https://www.ncsc.gov.uk/section/respond-recover/sole-ransomware-attack)
- [OpenSSH server](https://ubuntu.com/server/docs/how-to/security/openssh-server/)
- [Protect your personal data against theft](https://support.google.com/android/answer/15146908?hl=en)
- [Push protection](https://docs.github.com/en/code-security/concepts/secret-security/push-protection)
- [Recover from hacking — Australian Signals Directorate’s Australian Cyber Security Centre (ASD’s ACSC)](https://www.cyber.gov.au/guidance/recover-from-email-and-online-account-compromise)
- [Recovering a hacked account — UK National Cyber Security Centre (NCSC)](https://www.ncsc.gov.uk/guidance/recovering-a-hacked-account)
- [Remediating a leaked secret in your repository](https://docs.github.com/en/code-security/tutorials/remediate-leaked-secrets/remediating-a-leaked-secret)
- [Removing sensitive data from a repository](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/removing-sensitive-data-from-a-repository)
- [Responding to a security incident](https://docs.github.com/en/enterprise-cloud@latest/code-security/tutorials/secure-your-organization/respond-to-a-security-incident)
- [Security suggestions](https://ubuntu.com/server/docs/explanation/security/security_suggestions/)
- [Set screen lock on an Android device](https://support.google.com/android/answer/9079129?hl=en)
- [SIM Swap Scams: How to Protect Yourself — Federal Trade Commission](https://www.ctia.org/protecting-against-sim-swap-fraud)
- [Token expiration and revocation](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/token-expiration-and-revocation)
- [Two factor authentication with U2F/FIDO](https://ubuntu.com/server/docs/how-to/security/two-factor-authentication-with-u2f-or-fido/)
- [UK National Cyber Security Centre — Phishing scams: If you've shared sensitive information](https://www.ncsc.gov.uk/collection/phishing-scams/what-to-do)
- [Use Google Play Protect to help keep your apps safe & your data private](https://support.google.com/android/answer/2812853?hl=en)
- [User management](https://ubuntu.com/server/docs/how-to/security/user-management/)
- [Virus and threat protection in the Windows Security app](https://support.microsoft.com/en-us/windows/security/threat-malware-protection/virus-and-threat-protection-in-the-windows-security-app)
- [Windows Firewall overview](https://learn.microsoft.com/en-us/windows/security/operating-system-security/network-security/windows-firewall/)
