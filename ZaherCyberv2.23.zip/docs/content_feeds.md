# مصادر ZaherCyber والمحتوى الحي

## كيف يصل المحتوى؟

يحتوي الإصدار على **88 موجزاً للأخبار** و**7 موجزات مستقلة للمقالات والشروحات**. يجلب التطبيق عناصر RSS/Atom من الناشرين أنفسهم، مع تاريخ النشر ورابط المقال الأصلي. المقتطف الظاهر هو ما يتيحه الناشر في الموجز؛ ولا يستخرج التطبيق النص الكامل من صفحات محمية أو يعيد استضافته.

عند تفعيل التحديث التلقائي يجلب التطبيق عند التشغيل والعودة إلى الواجهة، ثم كل 15 أو 30 أو 60 دقيقة بحسب اختيار المستخدم ما دام التطبيق مفتوحاً. يتاح التحديث اليدوي أيضاً. يستخدم كل موجز ETag وLast-Modified عند توفرهما، ويُحفظ آخر المحتوى محلياً؛ عند رد الخادم HTTP 304 يعاد استخدام النسخة المخزنة بدلاً من تنزيل المحتوى مجدداً. قد يوقف Android التحديث بعد إغلاق التطبيق، لذلك لا يدّعي هذا المشروع التحديث اللحظي في الخلفية.

**قائمة الناشرين منسقة داخل التطبيق وليست دليلاً يُمسح تلقائياً على الإنترنت**؛ أما محتوى الموجزات فيتجدد من الناشرين، واكتشاف مشاريع GitHub المرخصة يتجدد يومياً في سبعة مجالات. تتأثر التحديثات بتوفر الشبكة، وحالة الناشر، وحدود الخدمة. يمكن تعطيل المصادر من الإعدادات.

لا تتضمن النسخة 2.3.0 ترجمة داخل التطبيق للأخبار والمقالات؛ تظهر المواد باللغة التي نشرها المصدر وبوسم اللغة المتاح.

## مركز الحماية ومتابعة المنتجات

إلى جانب موجزات المقالات، يتضمن التطبيق مركز حماية مستقلاً فيه 32 خطوة تقوية موثقة و7 أدلة استجابة. يستخدم المصطلحات التي يضيفها المستخدم لمطابقة ما حُمّل محلياً من أحدث 300 عنصر CISA KEV ومن موجزات الأخبار/الشروحات. هذه مطابقة نصية تقريبية داخل التطبيق؛ وتظهر التنبيهات داخل التطبيق أثناء الاستخدام فقط. راجع [نطاق المحتوى والمراجع والقيود](protection_center.md).

## الأخبار والتنبيهات

| المجال | الناشر | اللغة | موجز RSS/Atom |
| --- | --- | --- | --- |
| Cybersecurity | The Hacker News | EN | [https://feeds.feedburner.com/TheHackersNews](https://feeds.feedburner.com/TheHackersNews) |
| Cybersecurity | Krebs on Security | EN | [https://krebsonsecurity.com/feed/](https://krebsonsecurity.com/feed/) |
| Cybersecurity | BleepingComputer | EN | [https://www.bleepingcomputer.com/feed/](https://www.bleepingcomputer.com/feed/) |
| Cybersecurity | Dark Reading | EN | [https://www.darkreading.com/rss.xml](https://www.darkreading.com/rss.xml) |
| Cybersecurity | SecurityWeek | EN | [https://www.securityweek.com/feed/](https://www.securityweek.com/feed/) |
| Cybersecurity | Help Net Security | EN | [https://www.helpnetsecurity.com/feed/](https://www.helpnetsecurity.com/feed/) |
| Cybersecurity | CyberScoop | EN | [https://cyberscoop.com/feed/](https://cyberscoop.com/feed/) |
| Cybersecurity | The Record | EN | [https://therecord.media/feed](https://therecord.media/feed) |
| Cybersecurity | WeLiveSecurity | EN | [https://www.welivesecurity.com/en/rss/feed/](https://www.welivesecurity.com/en/rss/feed/) |
| Malware | Malwarebytes Labs | EN | [https://www.malwarebytes.com/blog/feed/index.xml](https://www.malwarebytes.com/blog/feed/index.xml) |
| Threat Intelligence | SANS Internet Storm Center | EN | [https://isc.sans.edu/rssfeed.xml](https://isc.sans.edu/rssfeed.xml) |
| Threat Intelligence | SANS ISC Daily Diary | EN | [https://isc.sans.edu/rssfeed_full.xml](https://isc.sans.edu/rssfeed_full.xml) |
| Alerts | CISA Cybersecurity Advisories | EN | [https://www.cisa.gov/cybersecurity-advisories/all.xml](https://www.cisa.gov/cybersecurity-advisories/all.xml) |
| Standards | NIST News | EN | [https://www.nist.gov/news-events/news/rss.xml](https://www.nist.gov/news-events/news/rss.xml) |
| Technology | Google Security Blog | EN | [https://security.googleblog.com/feeds/posts/default](https://security.googleblog.com/feeds/posts/default) |
| Cloud Security | Cloudflare Blog | EN | [https://blog.cloudflare.com/rss/](https://blog.cloudflare.com/rss/) |
| Threat Intelligence | Cisco Talos | EN | [https://blog.talosintelligence.com/rss/](https://blog.talosintelligence.com/rss/) |
| Threat Intelligence | Unit 42 | EN | [https://unit42.paloaltonetworks.com/feed/](https://unit42.paloaltonetworks.com/feed/) |
| Cybersecurity | Rapid7 Blog | EN | [https://www.rapid7.com/blog/rss/](https://www.rapid7.com/blog/rss/) |
| Technology | Wired Security | EN | [https://www.wired.com/feed/category/security/latest/rss](https://www.wired.com/feed/category/security/latest/rss) |
| Technology | TechCrunch Security | EN | [https://techcrunch.com/category/security/feed/](https://techcrunch.com/category/security/feed/) |
| Vulnerabilities | Project Zero | EN | [https://googleprojectzero.blogspot.com/feeds/posts/default](https://googleprojectzero.blogspot.com/feeds/posts/default) |
| Analysis | Schneier on Security | EN | [https://www.schneier.com/feed/atom/](https://www.schneier.com/feed/atom/) |
| Exploits | Exploit-DB | EN | [https://www.exploit-db.com/rss.xml](https://www.exploit-db.com/rss.xml) |
| AppSec | GitHub Security Lab | EN | [https://github.blog/tag/security/feed/](https://github.blog/tag/security/feed/) |
| Android | Android Developers Blog | EN | [https://android-developers.googleblog.com/feeds/posts/default](https://android-developers.googleblog.com/feeds/posts/default) |
| Android | XDA Developers | EN | [https://www.xda-developers.com/feed/](https://www.xda-developers.com/feed/) |
| Technology | Arabhardware | AR | [https://arabhardware.net/feed](https://arabhardware.net/feed) |
| Technology | عالم التقنية | AR | [https://www.tech-wd.com/wd/feed/](https://www.tech-wd.com/wd/feed/) |
| Technology | البوابة العربية للأخبار التقنية | AR | [https://aitnews.com/feed/](https://aitnews.com/feed/) |
| Technology | The Verge | EN | [https://www.theverge.com/rss/index.xml](https://www.theverge.com/rss/index.xml) |
| Technology | BBC Technology | EN | [https://feeds.bbci.co.uk/news/technology/rss.xml](https://feeds.bbci.co.uk/news/technology/rss.xml) |
| Cybersecurity | Security Affairs | EN | [https://securityaffairs.com/feed](https://securityaffairs.com/feed) |
| Cybersecurity | Infosecurity Magazine | EN | [https://www.infosecurity-magazine.com/rss/news/](https://www.infosecurity-magazine.com/rss/news/) |
| Cybersecurity | The Register Security | EN | [https://www.theregister.com/security/headlines.atom](https://www.theregister.com/security/headlines.atom) |
| AppSec | Mozilla Security Blog | EN | [https://blog.mozilla.org/security/feed/](https://blog.mozilla.org/security/feed/) |
| Cloud Security | AWS Security Blog | EN | [https://aws.amazon.com/blogs/security/feed/](https://aws.amazon.com/blogs/security/feed/) |
| Threat Intelligence | SentinelOne Labs | EN | [https://www.sentinelone.com/labs/feed/](https://www.sentinelone.com/labs/feed/) |
| Alerts | UK National Cyber Security Centre | EN | [https://www.ncsc.gov.uk/api/1/services/v1/all-rss-feed.xml](https://www.ncsc.gov.uk/api/1/services/v1/all-rss-feed.xml) |
| Technology | Ars Technica | EN | [https://feeds.arstechnica.com/arstechnica/index](https://feeds.arstechnica.com/arstechnica/index) |
| Cybersecurity | TechRadar Security | EN | [https://www.techradar.com/feeds/tag/security](https://www.techradar.com/feeds/tag/security) |
| Cybersecurity | ZDNET Security | EN | [https://www.zdnet.com/topic/security/rss.xml](https://www.zdnet.com/topic/security/rss.xml) |
| Technology | TechRepublic Security | EN | [https://www.techrepublic.com/rssfeeds/topic/security/](https://www.techrepublic.com/rssfeeds/topic/security/) |
| Cybersecurity | Cybernews | EN | [https://cybernews.com/feed/](https://cybernews.com/feed/) |
| Vulnerabilities | Zero Day Initiative | EN | [https://www.zerodayinitiative.com/blog?format=rss](https://www.zerodayinitiative.com/blog?format=rss) |
| Threat Intelligence | CERT Polska | EN | [https://www.cert.pl/en/feed/](https://www.cert.pl/en/feed/) |
| Cybersecurity | Google News — الأمن السيبراني | AR | [https://news.google.com/rss/search?q=%D8%A7%D9%84%D8%A3%D9%85%D9%86%20%D8%A7%D9%84%D8%B3%D9%8A%D8%A8%D8%B1%D8%A7%D9%86%D9%8A&hl=ar&gl=SA&ceid=SA:ar](https://news.google.com/rss/search?q=%D8%A7%D9%84%D8%A3%D9%85%D9%86%20%D8%A7%D9%84%D8%B3%D9%8A%D8%A8%D8%B1%D8%A7%D9%86%D9%8A&hl=ar&gl=SA&ceid=SA:ar) |
| Technology | Google News — أخبار التقنية | AR | [https://news.google.com/rss/search?q=%D8%A3%D8%AE%D8%A8%D8%A7%D8%B1%20%D8%A7%D9%84%D8%AA%D9%82%D9%86%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar](https://news.google.com/rss/search?q=%D8%A3%D8%AE%D8%A8%D8%A7%D8%B1%20%D8%A7%D9%84%D8%AA%D9%82%D9%86%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar) |
| Exploits | Google News — ثغرات أمنية | AR | [https://news.google.com/rss/search?q=%D8%AB%D8%BA%D8%B1%D8%A7%D8%AA%20%D8%A3%D9%85%D9%86%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar](https://news.google.com/rss/search?q=%D8%AB%D8%BA%D8%B1%D8%A7%D8%AA%20%D8%A3%D9%85%D9%86%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar) |
| Android | Google News — Android مفتوح المصدر | AR | [https://news.google.com/rss/search?q=%D8%A3%D9%86%D8%AF%D8%B1%D9%88%D9%8A%D8%AF%20%D8%AA%D8%B7%D8%A8%D9%8A%D9%82%D8%A7%D8%AA%20%D9%85%D9%81%D8%AA%D9%88%D8%AD%D8%A9%20%D8%A7%D9%84%D9%85%D8%B5%D8%AF%D8%B1&hl=ar&gl=SA&ceid=SA:ar](https://news.google.com/rss/search?q=%D8%A3%D9%86%D8%AF%D8%B1%D9%88%D9%8A%D8%AF%20%D8%AA%D8%B7%D8%A8%D9%8A%D9%82%D8%A7%D8%AA%20%D9%85%D9%81%D8%AA%D9%88%D8%AD%D8%A9%20%D8%A7%D9%84%D9%85%D8%B5%D8%AF%D8%B1&hl=ar&gl=SA&ceid=SA:ar) |
| Threat Intelligence | Google News — هجمات سيبرانية | AR | [https://news.google.com/rss/search?q=%D9%87%D8%AC%D9%85%D8%A7%D8%AA%20%D8%B3%D9%8A%D8%A8%D8%B1%D8%A7%D9%86%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar](https://news.google.com/rss/search?q=%D9%87%D8%AC%D9%85%D8%A7%D8%AA%20%D8%B3%D9%8A%D8%A8%D8%B1%D8%A7%D9%86%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar) |
| Open Source | Google News — برمجيات مفتوحة المصدر | AR | [https://news.google.com/rss/search?q=%D8%A8%D8%B1%D9%85%D8%AC%D9%8A%D8%A7%D8%AA%20%D9%85%D9%81%D8%AA%D9%88%D8%AD%D8%A9%20%D8%A7%D9%84%D9%85%D8%B5%D8%AF%D8%B1&hl=ar&gl=SA&ceid=SA:ar](https://news.google.com/rss/search?q=%D8%A8%D8%B1%D9%85%D8%AC%D9%8A%D8%A7%D8%AA%20%D9%85%D9%81%D8%AA%D9%88%D8%AD%D8%A9%20%D8%A7%D9%84%D9%85%D8%B5%D8%AF%D8%B1&hl=ar&gl=SA&ceid=SA:ar) |
| Privacy | Google News — الخصوصية الرقمية | AR | [https://news.google.com/rss/search?q=%D8%A7%D9%84%D8%AE%D8%B5%D9%88%D8%B5%D9%8A%D8%A9%20%D8%A7%D9%84%D8%B1%D9%82%D9%85%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar](https://news.google.com/rss/search?q=%D8%A7%D9%84%D8%AE%D8%B5%D9%88%D8%B5%D9%8A%D8%A9%20%D8%A7%D9%84%D8%B1%D9%82%D9%85%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar) |
| Cybersecurity | Google News — الأمن والبرمجيات | AR | [https://news.google.com/rss/search?q=%D8%A8%D8%B1%D9%85%D8%AC%D9%8A%D8%A7%D8%AA%20%D8%A3%D9%85%D9%86%20%D8%B3%D9%8A%D8%A8%D8%B1%D8%A7%D9%86%D9%8A&hl=ar&gl=SA&ceid=SA:ar](https://news.google.com/rss/search?q=%D8%A8%D8%B1%D9%85%D8%AC%D9%8A%D8%A7%D8%AA%20%D8%A3%D9%85%D9%86%20%D8%B3%D9%8A%D8%A8%D8%B1%D8%A7%D9%86%D9%8A&hl=ar&gl=SA&ceid=SA:ar) |
| Cybersecurity | CERT-EU Security Advisories | EN | [https://cert.europa.eu/publications/security-advisories-rss](https://cert.europa.eu/publications/security-advisories-rss) |
| Cybersecurity | FortiGuard Labs Threat Signal Report | EN | [https://filestore.fortinet.com/fortiguard/rss/threatsignal.xml](https://filestore.fortinet.com/fortiguard/rss/threatsignal.xml) |
| Cybersecurity | SonicWall PSIRT Advisories | EN | [https://psirtapi.global.sonicwall.com/api/v1/feed/rss.xml](https://psirtapi.global.sonicwall.com/api/v1/feed/rss.xml) |
| AI | Hugging Face Blog | EN | [https://huggingface.co/blog/feed.xml](https://huggingface.co/blog/feed.xml) |
| AI | Google Research Blog | EN | [https://research.google/blog/rss/](https://research.google/blog/rss/) |
| AI | Microsoft Research | EN | [https://www.microsoft.com/en-us/research/feed/](https://www.microsoft.com/en-us/research/feed/) |
| Programming | Google Testing Blog | EN | [https://testing.googleblog.com/feeds/posts/default](https://testing.googleblog.com/feeds/posts/default) |
| Programming | Kotlin Blog | EN | [https://blog.jetbrains.com/kotlin/feed/](https://blog.jetbrains.com/kotlin/feed/) |
| Linux | Linux Kernel Archives – Distribution RSS | EN | [https://www.kernel.org/feeds/kdist.xml](https://www.kernel.org/feeds/kdist.xml) |
| Linux | openSUSE News | EN | [https://news.opensuse.org/feed/](https://news.opensuse.org/feed/) |
| Linux | Fedora Magazine | EN | [https://fedoramagazine.org/feed/](https://fedoramagazine.org/feed/) |
| Cloud | The Crossplane Blog | EN | [https://blog.crossplane.io/rss/](https://blog.crossplane.io/rss/) |
| Cloud | OpenTofu Blog | EN | [https://opentofu.org/blog/rss.xml](https://opentofu.org/blog/rss.xml) |
| Cloud | Cilium Blog | EN | [https://cilium.io/blog/rss.xml](https://cilium.io/blog/rss.xml) |
| Android | F-Droid Blog | EN | [https://f-droid.org/feed.xml](https://f-droid.org/feed.xml) |
| Android | LineageOS News | EN | [https://lineageos.org/feed.xml](https://lineageos.org/feed.xml) |
| Privacy | Internet Society | EN | [https://www.internetsociety.org/feed/](https://www.internetsociety.org/feed/) |
| Privacy | GrapheneOS Releases | EN | [https://grapheneos.org/releases.atom](https://grapheneos.org/releases.atom) |
| Technology | التقنية السورية Syrian Tech | AR | [https://syriantech.com/feed/](https://syriantech.com/feed/) |

## موجزات رسمية أضيفت في 2.6.3

اختُبرت العناوين التالية في بيئة التطوير بتاريخ 18 أكتوبر 2026، وأعادت HTTP 200 ونوع محتوى XML/RSS قابلاً للقراءة. لا يعني ذلك ضمان التوفر الدائم؛ يعرض التطبيق المحتوى المخزّن عند فشل المصدر.

| المجال | الناشر | اللغة | موجز RSS/Atom |
| --- | --- | --- | --- |
| Alerts | CISA News | EN | [https://www.cisa.gov/news.xml](https://www.cisa.gov/news.xml) |
| Alerts | CISA Blog | EN | [https://www.cisa.gov/cisa/blog.xml](https://www.cisa.gov/cisa/blog.xml) |
| Industrial Security | CISA ICS Advisories | EN | [https://www.cisa.gov/cybersecurity-advisories/ics-advisories.xml](https://www.cisa.gov/cybersecurity-advisories/ics-advisories.xml) |
| Healthcare Security | CISA ICS Medical Advisories | EN | [https://www.cisa.gov/cybersecurity-advisories/ics-medical-advisories.xml](https://www.cisa.gov/cybersecurity-advisories/ics-medical-advisories.xml) |
| Vendor Advisories | Cisco PSIRT Security Advisories | EN | [https://sec.cloudapps.cisco.com/security/center/psirtrss20/CiscoSecurityAdvisory.xml](https://sec.cloudapps.cisco.com/security/center/psirtrss20/CiscoSecurityAdvisory.xml) |
| Incident Response | Cisco Event Responses | EN | [https://sec.cloudapps.cisco.com/security/center/eventResponses_20.xml](https://sec.cloudapps.cisco.com/security/center/eventResponses_20.xml) |
| Vendor Advisories | FortiGuard PSIRT Advisories | EN | [https://filestore.fortinet.com/fortiguard/rss/ir.xml](https://filestore.fortinet.com/fortiguard/rss/ir.xml) |
| Linux Security | Debian Security Advisories | EN | [https://www.debian.org/security/dsa.rdf](https://www.debian.org/security/dsa.rdf) |

صفحات **NCA وJoCERT وaeCERT وCSA السنغافورية وAustralian Cyber Security Centre وAndroid Security Bulletins وMozilla Security Advisories** أُبقيت مراجع خارجية فقط في سجل البحث؛ لم تُحوّل إلى موجزات مفترضة.

## المقالات والشروحات

| المجال | الناشر | اللغة | موجز RSS/Atom |
| --- | --- | --- | --- |
| Tutorial · Web Security | PortSwigger Research & Tutorials | EN | [https://portswigger.net/blog/rss](https://portswigger.net/blog/rss) |
| Tutorial · Programming | freeCodeCamp News | EN | [https://www.freecodecamp.org/news/rss/](https://www.freecodecamp.org/news/rss/) |
| Tutorial · Developer Tools | GitHub Tutorials | EN | [https://github.blog/tag/tutorial/feed/](https://github.blog/tag/tutorial/feed/) |
| Tutorial · Cloud & Linux | DigitalOcean Community Tutorials | EN | [https://www.digitalocean.com/community/tutorials/feed](https://www.digitalocean.com/community/tutorials/feed) |
| Tutorial · Android & AI | Google Developers | EN | [https://developers.googleblog.com/feeds/posts/default](https://developers.googleblog.com/feeds/posts/default) |
| Tutorial · Open Source | Linux Foundation Blog | EN | [https://www.linuxfoundation.org/blog/rss.xml](https://www.linuxfoundation.org/blog/rss.xml) |
| Tutorial · Linux | Linux.com | EN | [https://www.linux.com/feed/](https://www.linux.com/feed/) |

## دليل ومستودع

- [Open Source Alternative](https://www.opensourcealternative.to/) دليل لاكتشاف بدائل البرمجيات، وليس ناشر أخبار أو موجزاً مضافاً.
- [LFX Community Data Platform (crowd.dev)](https://github.com/linuxfoundation/crowd.dev) مشروع مفتوح المصدر بترخيص Apache-2.0 في كتالوج الترسانة.
- راجع [سجل التحقق من المصادر](research_sources_2.3.0.md) لقائمة تدقيق مستقلة للناشرين والمشاريع والمراجع المضافة في الإصدار 2.3.0.
