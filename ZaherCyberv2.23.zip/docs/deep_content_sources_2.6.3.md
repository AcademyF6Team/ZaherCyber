# مصادر المحتوى المتعمق — الإصدار 2.6.3

تمت مراجعة المصادر الرسمية التالية قبل إضافة المحتوى الجديد إلى الترسانة ومركز الحماية:

- [CIS Critical Security Controls](https://www.cisecurity.org/controls/cis-controls-list): جرد الأصول والبرمجيات، إدارة الحسابات، إدارة السجلات، الدفاع من البرمجيات الخبيثة، واستعادة البيانات.
- [CISA Enhanced Visibility and Hardening Guidance](https://www.cisa.gov/resources-tools/resources/enhanced-visibility-and-hardening-guidance-communications-infrastructure): الرؤية المركزية، مراقبة تغييرات إعدادات الشبكة، عزل إدارة الأجهزة، التسجيل المركزي، وتقليل الخدمات المكشوفة.
- [Zeek](https://github.com/zeek/zeek): تحليل حركة الشبكة ومراقبة أمن الشبكات.
- [Falco](https://github.com/falcosecurity/falco): مراقبة وقت التشغيل للأنظمة السحابية الأصلية وقواعد كشف أحداث النظام.
- [Wazuh](https://github.com/wazuh/wazuh): منصة مفتوحة المصدر للوقاية والكشف والاستجابة ومراقبة سلامة الملفات والسجلات.
- [osquery](https://github.com/osquery/osquery): استعلام حالة نظام التشغيل بطريقة SQL للمراقبة والجرد والتحليل.
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework): إدارة المخاطر وتحديد أولويات الضوابط الأمنية.

جميع الأوصاف داخل التطبيق تشير إلى الاستخدام على أصول يملكها المستخدم أو يملك تصريحاً لاختبارها، ولا تقدم تعليمات لاستهداف أنظمة خارج النطاق المصرح به.
