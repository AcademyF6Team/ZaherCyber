# تكامل Academy F6-Team داخل المعرفة

## السلوك

- تظهر بطاقة **Academy F6-Team** ضمن «المعرفة» في ZaherCyber باللغتين العربية والإنجليزية.
- تحتفظ صفحة Academy المضمّنة بتصميمها ومحتواها العربي الأصلي، وتُحفظ كاملة داخل التطبيق للقراءة والتمرير دون اتصال بالإنترنت.
- يتضمن دليل القنوات رابط **ZaherCyber Project**: `https://t.me/+nRjn9nPpbzliMTIy`.
- تُعترض روابط `http/https` داخل WebView وتُفتح بواسطة نظام Android في التطبيق المناسب (مثل Telegram أو Facebook)، مع المتصفح كبديل عند الحاجة. فتح هذه الروابط يحتاج اتصالاً بالإنترنت.
- الحزمة صفحة ويب ثابتة، وليست APK داخل APK، ولا تجلب منشورات Telegram الحية. يبقى الانضمام إلى قناة خاصة خاضعاً لدعوة Telegram وصلاحيات القناة، وقد يتطلب حساب Telegram.

## طريقة التضمين

تستخدم شاشة Flutter `WebViewController.loadFlutterAsset`. وعلى Android تُحمّل الأصول بهذه الطريقة عبر `file://`؛ وتحميل JavaScript module وCSS من ملفات منفصلة قد يُحظر بسبب CORS. لذلك حُوّلت نسخة Academy المبنية إلى ملف HTML واحد يحتوي CSS وJavaScript مضمّنين، واختُبر هذا الملف مباشرة عبر `file://`. لا يحتاج WebView إلى خادم محلي أو اتصال شبكة لعرض الصفحة.

تحتوي `assets/academy_offline/` على صفحة HTML الوحيدة اللازمة. يلتقط اختبار Flutter وجود محتوى Academy والقناة والرابط، ويتحقق من تضمين CSS وJavaScript وعدم الرجوع إلى ملفات خارجية.

## تحديث النسخة المضمّنة

في مصدر Academy المعدّل، من جذر المشروع:

```bash
pnpm install --frozen-lockfile --ignore-scripts
pnpm build:offline
```

ينشئ الأمر `dist/offline/index.html`. انسخه إلى:

```text
ZaherCyber/assets/academy_offline/index.html
```

بعد تحديث الملف، شغّل `flutter pub get` ثم التحليل والاختبارات وبناء Android. لا تُدرج `node_modules` أو `dist` الخاصة بـAcademy أو نواتج Flutter/Gradle في ZIP المصدر؛ ملف `assets/academy_offline/index.html` هو المورد الثابت الوحيد المطلوب للتشغيل.

## مراجع تقنية

- [webview_flutter على pub.dev](https://pub.dev/packages/webview_flutter) — تحميل الأصول المحلية داخل Flutter WebView.
- [url_launcher على pub.dev](https://pub.dev/packages/url_launcher) — فتح الروابط خارج التطبيق.
- [أسئلة Telegram الرسمية عن القنوات](https://telegram.org/faq_channels) — الوصول إلى القنوات العامة والخاصة.
- [محتوى Telegram المحمي](https://telegram.org/blog/protected-content-delete-by-date-and-more) — يمكن لمالك القناة منع حفظ/إعادة توجيه محتواها.
