# توسعة المحتوى والتحقق من المصادر — 2.7.2

أُجري فحص الروابط في 20 أكتوبر 2026 من بيئة التنفيذ عبر HTTPS بطلبات GET عادية وبـ User-Agent وصفي. اختُبرت الموجزات الخمسة للتحقق من HTTP 200 ونوع المحتوى القائم على XML وقابلية تحليل XML. بقيت هذه روابط ناشرين أصلية؛ التطبيق يعرض مقتطفات وبيانات الموجز ويترك المقال الأصلي لدى الناشر.

| المصدر | النوع | نتيجة الاختبار | المجال |
| --- | --- | --- | --- |
| Ubuntu Security Notices | RSS/XML (`https://ubuntu.com/security/notices/rss.xml`) | HTTP 200، 10 عناصر، أحدث منشور 2026-10-09، `text/xml`، XML صالح من نوع RSS | تحديثات Linux |
| Kubernetes | RSS/XML (`https://kubernetes.io/feed.xml`) | HTTP 200، 50 عنصراً، أحدث منشور 2026-10-14، `application/xml`، RSS صالح | أمن السحابة والمنصة |
| OpenSSF Blog | RSS/XML (`https://openssf.org/feed/`) | HTTP 200، 10 عناصر، أحدث منشور 2026-10-16، `application/rss+xml`، RSS صالح | أمن سلسلة التوريد |
| CERT/CC Vulnerability Notes | Atom/XML (`https://kb.cert.org/vuls/atomfeed/`) | HTTP 200، 15 عنصراً، أحدث منشور 2026-10-14، `application/atom+xml`، Atom صالح | نشرات الثغرات |
| Australian Cyber Security Centre | RSS/XML (`https://www.cyber.gov.au/rss/alerts`) | HTTP 200، 8 عناصر، أحدث منشور 2026-10-14، `application/rss+xml`، RSS صالح | تنبيهات وطنية |

اختُبرت روابط إضافية مرشحة ولم تُدرج كموجزات: صفحة Apple الأمنية وACSC وواجهات نشر عادية تعيد HTML ليست موجزات. أُسقطت روابط Android وGoogle Cloud وOWASP وRed Hat التي أعادت 404. واجهة Microsoft MSRC CVRF أعادت JSON صالحاً؛ لم تُدرج كـ RSS لأن خدمة التطبيق الحالية تتعامل مع RSS/Atom ولم تُنفّذ لها طبقة JSON منفصلة. وهي ليست جزءاً من عدد الموجزات المضافة.

## مراجع المعرفة

اختُبرت ثمانية روابط مرجعية بطلب GET. أعادت جميعها HTTP 200 ونوع محتوى HTML، وتظل صفحات مرجعية لا موجزات مباشرة: Android Security Bulletins، Apple Security Releases، Ubuntu Security Notices، Australian ACSC Essential Eight، NIST CSF Online Learning، NIST CSF 2.0 Resources، CIS Critical Security Controls، وOpenSSF Scorecard. لا ينسخ التطبيق محتوى هذه الصفحات.

## الترسانة

استُعلم GitHub REST API عن المستودعات الجديدة المرشحة. استجابت المستودعات الأربعة بـ HTTP 200، وكانت الأسماء الرسمية غير موجودة في القائمة الحالية وقت الفحص:

- DefectDojo — `DefectDojo/django-DefectDojo` — BSD-3-Clause.
- Prowler — `prowler-cloud/prowler` — Apache-2.0.
- OpenSSF Scorecard — `ossf/scorecard` — Apache-2.0.
- OpenBao — `openbao/openbao` — MPL-2.0.

أُضيف لكل مشروع وصف عربي وإنجليزي ومجال ورابط رسمي ومنصات ملائمة وترخيص المستودع ومستوى صعوبة تقديري. الحالة المعروضة تقتصر على كون المستودع غير مؤرشف عند الفحص، ولا تعني وحدها أن المشروع يُصان بنشاط. تظهر الحقول الاختيارية في شرائح تفاصيل الأداة القائمة من دون تغيير تصميم الصفحة. جرى استبعاد مستودعات أخرى كانت موجودة بالفعل مثل OSV-Scanner وSyft.

## ما لم يُنفذ

لم تضف هذه الدفعة خدمة MSRC JSON، أو مدقق SBOM، أو فاحص روابط، أو إرسالاً إلى خدمات خارجية. بقيت القائمة المصدرية المنسقة داخل التطبيق مستقلة عن تحديث الأخبار؛ تنسيق المصادر أو فشلها لا يعني أن بقية الموجزات فشلت. لم تتوفر Flutter وDart وAndroid SDK في بيئة التنفيذ، ولذلك لم تُشغّل أو تُدّعَ نتائج `dart format` أو `flutter analyze` أو `flutter test` أو Release build. أضيفت اختبارات Dart للمصادر والمراجع والمشاريع الجديدة، لكنها تحتاج إلى بيئة Flutter لتشغيلها.

## مركز الحماية والاستجابة

أضيف دليل واحد جديد لإدارة تحديث أمني حرج، من التحقق من النشرة ونطاق المنتج إلى تقييم التعرض، والنسخ الاحتياطي والرجوع، والتطبيق من مصدر موثوق، والتحقق والتوثيق. الدليل عربي/إنجليزي ويشير إلى NIST وCISA، ويطلب التصعيد عند الاستغلال النشط أو تعذر التصحيح أو تأثر أنظمة حرجة. الأدلة السابقة للحسابات المخترقة والتصيد والفدية وفقد الهاتف وتسريب أسرار GitHub حُفظت دون حذف.
