import 'package:flutter_test/flutter_test.dart';

import 'package:zaher_cyber/data/f6_security_tools.dart';

void main() {
  test('F6 Security Tools includes the advanced intelligence catalog', () {
    final ids = f6SecurityTools.map((tool) => tool.id).toSet();
    expect(ids, containsAll([
      'mailaccess',
      'horus',
      'unfurl',
      'huggingface-spaces',
      'egm-downloader',
      'skipii',
      'drift',
      'delphi-tools',
      'shodan',
      'censys',
      'urlscan',
      'virustotal',
      'abuseipdb',
      'crtsh',
      'hibp',
      'misp',
      'mitre-attack',
      'cisa-kev',
    ]));
    expect(f6SecurityTools.length, 18);
    expect(f6SecurityTools.every((tool) => tool.url.startsWith('https://')), isTrue);
    expect(f6SecurityTools.every((tool) => tool.accessAr.isNotEmpty && tool.accessEn.isNotEmpty), isTrue);
  });
}
