import 'package:flutter_test/flutter_test.dart';
import 'package:zaher_cyber/data/api_catalog.dart';

void main() {
  test('Workbench contains a large curated API catalog with unique secure links', () {
    expect(apiCatalog.length, greaterThanOrEqualTo(80));
    expect(apiCatalog.map((item) => item.id).toSet().length, apiCatalog.length);
    expect(apiCatalog.every((item) => item.url.startsWith('https://')), isTrue);
    expect(apiCatalog.any((item) => item.id == 'cisa-kev'), isTrue);
    expect(apiCatalog.any((item) => item.id == 'urlhaus'), isTrue);
    expect(apiCatalog.any((item) => item.id == 'postman-echo'), isTrue);
  });
}
