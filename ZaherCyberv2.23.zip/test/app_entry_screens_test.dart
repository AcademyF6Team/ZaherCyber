import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:zaher_cyber/screens/app_entry_screens.dart';
import 'package:zaher_cyber/theme/app_theme.dart';

Widget _shell(Widget child) => MaterialApp(
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      theme: AppThemes.build(0),
      home: child,
    );

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('onboarding has three pages and finishes once', (tester) async {
    var finished = false;
    await tester.pumpWidget(
      _shell(OnboardingScreen(onFinished: () => finished = true)),
    );

    expect(find.byKey(const ValueKey('onboarding-screen')), findsOneWidget);
    expect(find.text('ZaherCyber — مركزك السيبراني'), findsOneWidget);
    expect(find.text('التالي'), findsOneWidget);

    await tester.tap(find.text('التالي'));
    await tester.pumpAndSettle();
    expect(find.text('خصوصيتك أولاً'), findsOneWidget);

    await tester.tap(find.text('التالي'));
    await tester.pumpAndSettle();
    expect(find.text('تعلّم، افحص، وتحقق'), findsOneWidget);

    await tester.tap(find.text('ابدأ الآن'));
    await tester.pumpAndSettle();
    expect(finished, isTrue);
    expect(tester.takeException(), isNull);
  });

  testWidgets('cyber boot screen completes and never throws', (tester) async {
    var finished = false;
    await tester.pumpWidget(
      _shell(CyberBootScreen(onFinished: () => finished = true)),
    );
    expect(find.byKey(const ValueKey('cyber-boot-screen')), findsOneWidget);
    expect(find.text('ZAHERCYBER'), findsOneWidget);
    await tester.pump(const Duration(milliseconds: 2300));
    expect(finished, isTrue);
    expect(tester.takeException(), isNull);
  });
}
