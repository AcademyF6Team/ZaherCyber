import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zaher_cyber/data/sources.dart';
import 'package:zaher_cyber/services/feed_service.dart';
import 'package:zaher_cyber/services/source_health_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const source = NewsSource(
    'Example Feed',
    'https://example.org/rss.xml',
    'Test',
    'EN',
  );

  FeedSourceFailure failure({
    required DateTime at,
    int? status,
    String failureClass = 'http',
  }) => FeedSourceFailure(
    source: source,
    checkedAt: at,
    failureClass: failureClass,
    reason: 'test failure',
    statusCode: status,
  );

  setUp(() => SharedPreferences.setMockInitialValues({}));

  test(
    'source is quarantined only after 3 eligible failures spanning 48 hours',
    () async {
      final health = FeedSourceHealthService('health_test');
      await health.load();
      final start = DateTime.utc(2026, 1, 1);

      await health.recordCycle(
        successfulUrls: const {},
        failures: [failure(at: start, status: 503)],
        globalConnectivityFailure: false,
        now: start,
      );
      await health.recordCycle(
        successfulUrls: const {},
        failures: [
          failure(at: start.add(const Duration(hours: 24)), status: 503),
        ],
        globalConnectivityFailure: false,
        now: start.add(const Duration(hours: 24)),
      );
      expect(health.quarantinedUrls, isEmpty);

      final threshold = start.add(const Duration(hours: 48));
      await health.recordCycle(
        successfulUrls: const {},
        failures: [failure(at: threshold, status: 503)],
        globalConnectivityFailure: false,
        now: threshold,
      );
      expect(health.quarantinedUrls, contains(source.url));
    },
  );

  test('global transport failure and HTTP 403/429 are not counted', () async {
    final health = FeedSourceHealthService('health_test');
    await health.load();
    final now = DateTime.utc(2026, 2, 1);

    await health.recordCycle(
      successfulUrls: const {},
      failures: [failure(at: now, failureClass: 'transport')],
      globalConnectivityFailure: true,
      now: now,
    );
    await health.recordCycle(
      successfulUrls: const {},
      failures: [failure(at: now, status: 403)],
      globalConnectivityFailure: false,
      now: now,
    );
    await health.recordCycle(
      successfulUrls: const {},
      failures: [failure(at: now, status: 429)],
      globalConnectivityFailure: false,
      now: now,
    );
    expect(health.records, isEmpty);
  });

  test('quarantined source is probe-eligible after 24 hours and success restores it', () async {
    final health = FeedSourceHealthService('health_test');
    await health.load();
    final start = DateTime.utc(2026, 3, 1);
    for (final hour in [0, 24, 48]) {
      final now = start.add(Duration(hours: hour));
      await health.recordCycle(
        successfulUrls: const {},
        failures: [failure(at: now, status: 404)],
        globalConnectivityFailure: false,
        now: now,
      );
    }
    final quarantinedAt = start.add(const Duration(hours: 48));
    expect(
      health.probesDueFor([
        source.url,
      ], now: quarantinedAt.add(const Duration(hours: 23))),
      isEmpty,
    );
    expect(
      health.probesDueFor([
        source.url,
      ], now: quarantinedAt.add(const Duration(hours: 24))),
      contains(source.url),
    );

    await health.recordCycle(
      successfulUrls: {source.url},
      failures: const [],
      globalConnectivityFailure: false,
      now: quarantinedAt.add(const Duration(hours: 24)),
    );
    expect(health.quarantinedUrls, isEmpty);
    expect(health.records, isEmpty);
  });

  test('state persists locally and can be manually restored', () async {
    final health = FeedSourceHealthService('health_test');
    await health.load();
    final now = DateTime.utc(2026, 4, 1);
    for (final hour in [0, 24, 49]) {
      final at = now.add(Duration(hours: hour));
      await health.recordCycle(
        successfulUrls: const {},
        failures: [failure(at: at, status: 410)],
        globalConnectivityFailure: false,
        now: at,
      );
    }
    final restored = FeedSourceHealthService('health_test');
    await restored.load();
    expect(restored.quarantinedUrls, contains(source.url));
    await restored.restore(source.url);
    expect(restored.quarantinedUrls, isEmpty);
  });
}
