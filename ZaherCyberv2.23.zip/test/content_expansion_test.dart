import 'package:flutter_test/flutter_test.dart';
import 'package:zaher_cyber/data/learning_content.dart';
import 'package:zaher_cyber/data/protection_guides.dart';
import 'package:zaher_cyber/data/learning_resources.dart';
import 'package:zaher_cyber/data/sources.dart';
import 'package:zaher_cyber/data/tool_projects.dart';
import 'package:zaher_cyber/utils/app_version.dart';

void main() {
  test('new official feeds are present and unique', () {
    const expected = {
      'https://www.cisa.gov/news.xml',
      'https://www.cisa.gov/cisa/blog.xml',
      'https://www.cisa.gov/cybersecurity-advisories/ics-advisories.xml',
      'https://www.cisa.gov/cybersecurity-advisories/ics-medical-advisories.xml',
      'https://sec.cloudapps.cisco.com/security/center/psirtrss20/CiscoSecurityAdvisory.xml',
      'https://sec.cloudapps.cisco.com/security/center/eventResponses_20.xml',
      'https://filestore.fortinet.com/fortiguard/rss/ir.xml',
      'https://www.debian.org/security/dsa.rdf',
    };
    final urls = newsSources.map((source) => source.url).toList();
    expect(urls.toSet().length, urls.length);
    expect(urls.toSet(), containsAll(expected));
  });

  test('new official live feeds are unique and categorized', () {
    const expected = {
      'https://ubuntu.com/security/notices/rss.xml',
      'https://kubernetes.io/feed.xml',
      'https://openssf.org/feed/',
      'https://kb.cert.org/vuls/atomfeed/',
      'https://www.cyber.gov.au/rss/alerts',
    };
    final urls = newsSources.map((source) => source.url).toList();
    expect(urls.toSet().length, urls.length);
    expect(urls.toSet(), containsAll(expected));
  });
  test('new defensive projects have unique ids and repositories', () {
    final ids = toolProjects.map((project) => project.id).toSet();
    final repos = toolProjects
        .map((project) => project.githubRepo)
        .whereType<String>()
        .toSet();
    expect(ids.length, toolProjects.length);
    expect(
      repos.length,
      toolProjects
          .map((project) => project.githubRepo)
          .whereType<String>()
          .length,
    );
    expect(
      ids,
      containsAll([
        'defectdojo',
        'prowler',
        'openssf-scorecard',
        'openbao',
        'hayabusa',
      ]),
    );
    final additions = toolProjects.where(
      (project) =>
          ids.contains(project.id) &&
          [
            'defectdojo',
            'prowler',
            'openssf-scorecard',
            'openbao',
            'hayabusa',
          ].contains(project.id),
    );
    expect(
      additions.every(
        (project) =>
            project.difficulty != null &&
            project.repositoryStatus == 'not_archived',
      ),
      isTrue,
    );
  });
  test('new learning references preserve official source URLs', () {
    final resources = [
      for (final section in learningResourceSections) ...section.items,
    ];
    final urls = resources.map((resource) => resource.url).toSet();
    expect(
      urls,
      containsAll([
        'https://source.android.com/docs/security/bulletin',
        'https://ubuntu.com/security/notices',
        'https://support.apple.com/en-us/100100',
        'https://www.cyber.gov.au/essential-eight',
        'https://www.nist.gov/cyberframework/csf-11-online-learning',
        'https://www.cisecurity.org/controls',
        'https://scorecard.dev/',
        'https://www.nist.gov/cyberframework/resources',
      ]),
    );
  });
  test('curated catalogue ids and repositories are unique', () {
    final ids = toolProjects.map((project) => project.id).toList();
    final repos = toolProjects
        .map((project) => project.githubRepo)
        .whereType<String>()
        .toList();
    expect(ids.toSet().length, ids.length);
    expect(repos.toSet().length, repos.length);
    expect(ids, containsAll(['semgrep', 'kube-bench', 'openscap']));
    expect(ids, containsAll(['owasp-dependency-check', 'bearer']));
  });

  test('new knowledge references point to the original publishers', () {
    final resources = [
      for (final section in learningResourceSections) ...section.items,
    ];
    final names = resources.map((resource) => resource.name).toSet();
    final urls = resources.map((resource) => resource.url).toSet();
    expect(
      names,
      containsAll([
        'OSV.dev API',
        'GitHub Advisory Database',
        'ENISA Publications',
        'NIST CSRC Publications',
        'arXiv cs.CR',
        'USENIX Security Proceedings',
        'CyLab Security Academy / picoCTF',
        'OverTheWire Wargames',
      ]),
    );
    expect(resources, hasLength(148));
    expect(urls.length, resources.length);
    expect(
      names,
      containsAll([
        'Saudi CERT — التنبيهات الأمنية',
        'Cisco Networking Academy — محلل الأمن السيبراني المبتدئ',
        'Microsoft Defender for Containers — documentation',
        'Docker Engine security',
        'Android Help — إعدادات الأمان والخصوصية',
        'Apple Personal Safety User Guide',
        'OWASP Top 10 for LLM Applications — 2025',
        'MITRE ATLAS — تهديدات أنظمة الذكاء الاصطناعي',
        'Blue Team Labs Online',
        'SANS Digital Forensics & Incident Response',
      ]),
    );
    expect(
      resources.every((resource) => resource.url.startsWith('https://')),
      isTrue,
    );
  });

  test(
    'critical patching playbook is bilingual, linked, and uniquely identified',
    () {
      final matches = incidentPlaybooks
          .where((item) => item.id == 'critical-security-update-response')
          .toList();
      expect(matches, hasLength(1));
      expect(matches.single.steps.length, 5);
      expect(
        matches.single.steps.every(
          (step) => step.officialUrl.startsWith('https://'),
        ),
        isTrue,
      );
      expect(matches.single.whenExpertAr, isNotEmpty);
      expect(matches.single.whenExpertEn, isNotEmpty);
    },
  );
  test(
    'learning paths, lessons, questions, and cards are unique and linked',
    () {
      final pathIds = learningPaths.map((item) => item.id).toSet();
      expect(pathIds.length, learningPaths.length);
      expect(
        learningLessons.map((item) => item.id).toSet().length,
        learningLessons.length,
      );
      expect(
        learningQuestions.map((item) => item.id).toSet().length,
        learningQuestions.length,
      );
      expect(
        learningFlashcards.map((item) => item.id).toSet().length,
        learningFlashcards.length,
      );
      expect(
        learningLessons.every((item) => pathIds.contains(item.pathId)),
        isTrue,
      );
      expect(
        learningQuestions.every((item) => pathIds.contains(item.pathId)),
        isTrue,
      );
      expect(
        learningFlashcards.every((item) => pathIds.contains(item.pathId)),
        isTrue,
      );
      expect(
        learningQuestions.every(
          (item) =>
              item.correctIndex >= 0 &&
              item.correctIndex < item.optionsAr.length,
        ),
        isTrue,
      );
    },
  );

  test('release metadata has a single user-facing version label', () {
    expect(appVersionLabel, '2.12.0+27');
  });
}
