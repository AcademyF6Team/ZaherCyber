import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:zaher_cyber/widgets/page_navigation_controls.dart';

void main() {
  testWidgets('back returns one level and home clears nested routes', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Builder(
          builder: (context) => Scaffold(
            key: const ValueKey('root-page'),
            body: Center(
              child: FilledButton(
                key: const ValueKey('open-level-one'),
                onPressed: () => Navigator.of(context).push<void>(
                  MaterialPageRoute(
                    builder: (_) => const _NavigationPage(level: 1),
                  ),
                ),
                child: const Text('Open'),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.byKey(const ValueKey('open-level-one')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('navigation-level-1')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('open-level-two')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('navigation-level-2')), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('page-back-navigation')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('navigation-level-1')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('open-level-two')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('page-home-navigation')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('root-page')), findsOneWidget);
    expect(find.byKey(const ValueKey('navigation-level-1')), findsNothing);
  });
}

class _NavigationPage extends StatelessWidget {
  const _NavigationPage({required this.level});
  final int level;

  @override
  Widget build(BuildContext context) => Scaffold(
    key: ValueKey('navigation-level-$level'),
    appBar: AppBar(
      leading: pageBackButton(context),
      actions: pageNavigationActions(context),
      title: Text('Level $level'),
    ),
    body: level == 1
        ? Center(
            child: FilledButton(
              key: const ValueKey('open-level-two'),
              onPressed: () => Navigator.of(context).push<void>(
                MaterialPageRoute(
                  builder: (_) => const _NavigationPage(level: 2),
                ),
              ),
              child: const Text('Open nested'),
            ),
          )
        : const SizedBox.shrink(),
  );
}
