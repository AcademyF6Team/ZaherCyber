import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:zaher_cyber/services/fahes_service.dart';
import 'package:zaher_cyber/services/url_audit_service.dart';

void main() {
  const url = 'https://example.com/login?campaign=sample';
  final local = UrlAuditService().analyze(url);

  test(
    'queries PhishTank without an app key and flags a verified active phish',
    () async {
      var calls = 0;
      final service = FahesService(
        client: MockClient((request) async {
          calls++;
          expect(request.method, 'POST');
          expect(request.url.scheme, 'https');
          expect(request.url.host, 'checkurl.phishtank.com');
          expect(request.headers['user-agent'], contains('ZaherCyber-FAHES'));
          expect(request.bodyFields['format'], 'json');
          expect(request.bodyFields.containsKey('app_key'), isFalse);
          expect(utf8.decode(base64Decode(request.bodyFields['url']!)), url);
          return http.Response(
            jsonEncode({
              'results': {
                'url': url,
                'in_database': true,
                'verified': true,
                'valid': true,
              },
            }),
            200,
          );
        }),
      );
      final result = await service.checkUrl(url: url, localAudit: local);
      expect(calls, 1);
      expect(result.sources, hasLength(3));
      expect(result.sources[0].verdict, FahesVerdict.listed);
      expect(result.sources[1].verdict, FahesVerdict.keyRequired);
      expect(result.sources[2].verdict, FahesVerdict.keyRequired);
      service.dispose();
    },
  );

  test('URLhaus uses Auth-Key and distinguishes a listed URL', () async {
    final service = FahesService(
      client: MockClient((request) async {
        if (request.url.host == 'checkurl.phishtank.com') {
          return http.Response(
            jsonEncode({
              'results': {'in_database': false},
            }),
            200,
          );
        }
        expect(request.url.host, 'urlhaus-api.abuse.ch');
        expect(request.url.path, '/v1/url/');
        expect(
          request.headers.entries.any(
            (e) =>
                e.key.toLowerCase() == 'auth-key' &&
                e.value == 'urlhaus-test-key',
          ),
          isTrue,
        );
        expect(request.bodyFields['url'], url);
        return http.Response(
          jsonEncode({
            'query_status': 'ok',
            'url_status': 'online',
            'threat': 'malware_download',
          }),
          200,
        );
      }),
    );
    final result = await service.checkUrl(
      url: url,
      localAudit: local,
      urlhausAuthKey: 'urlhaus-test-key',
    );
    expect(result.sources[0].verdict, FahesVerdict.notListed);
    expect(result.sources[1].verdict, FahesVerdict.listed);
    expect(result.sources[1].detail, contains('online'));
    expect(result.sources[2].verdict, FahesVerdict.keyRequired);
    service.dispose();
  });

  test('ThreatFox requests exact URL then host if needed', () async {
    final threatFoxTerms = <String>[];
    final service = FahesService(
      client: MockClient((request) async {
        if (request.url.host == 'checkurl.phishtank.com') {
          return http.Response(
            jsonEncode({
              'results': {'in_database': false},
            }),
            200,
          );
        }
        expect(request.url.host, 'threatfox-api.abuse.ch');
        expect(
          request.headers.entries.any(
            (e) =>
                e.key.toLowerCase() == 'auth-key' &&
                e.value == 'threatfox-test-key',
          ),
          isTrue,
        );
        expect(request.bodyFields['query'], 'search_ioc');
        expect(request.bodyFields['exact_match'], 'true');
        threatFoxTerms.add(request.bodyFields['search_term']!);
        if (threatFoxTerms.length == 1) {
          expect(threatFoxTerms.last, url);
          return http.Response(
            jsonEncode({'query_status': 'no_result', 'data': []}),
            200,
          );
        }
        expect(threatFoxTerms.last, 'example.com');
        return http.Response(
          jsonEncode({
            'query_status': 'ok',
            'data': [
              {
                'ioc': 'example.com',
                'ioc_type': 'domain',
                'ioc_type_desc': 'Domain used as a threat indicator',
                'malware_printable': 'Test malware',
                'confidence_level': 85,
              },
            ],
          }),
          200,
        );
      }),
    );
    final result = await service.checkUrl(
      url: url,
      localAudit: local,
      threatFoxAuthKey: 'threatfox-test-key',
    );
    expect(threatFoxTerms, [url, 'example.com']);
    expect(result.sources[2].verdict, FahesVerdict.listed);
    expect(result.sources[2].recordCount, 1);
    expect(result.sources[2].detail, contains('Test malware'));
    service.dispose();
  });

  test('does not perform database lookup for invalid local input', () async {
    var calls = 0;
    final service = FahesService(
      client: MockClient((_) async {
        calls++;
        return http.Response('{}', 200);
      }),
    );
    await expectLater(
      service.checkUrl(
        url: 'file:///etc/passwd',
        localAudit: UrlAuditService().analyze('file:///etc/passwd'),
      ),
      throwsArgumentError,
    );
    expect(calls, 0);
    service.dispose();
  });
}
