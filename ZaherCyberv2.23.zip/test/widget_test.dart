import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zaher_cyber/services/feed_service.dart';
import 'package:zaher_cyber/data/sources.dart';
import 'package:zaher_cyber/data/learning_resources.dart';
import 'package:zaher_cyber/data/external_resources.dart';
import 'package:zaher_cyber/data/project_links.dart';
import 'package:zaher_cyber/data/protection_guides.dart';
import 'package:zaher_cyber/data/tool_projects.dart';
import 'package:zaher_cyber/models/article.dart';
import 'package:zaher_cyber/models/kev_item.dart';
import 'package:zaher_cyber/models/protection_content.dart';
import 'package:zaher_cyber/models/tool_release.dart';
import 'package:zaher_cyber/models/tool_project.dart';
import 'package:zaher_cyber/utils/secure_release_url.dart';
import 'package:zaher_cyber/utils/kev_watch_match.dart';
import 'package:zaher_cyber/services/vulnerability_service.dart';
import 'package:zaher_cyber/screens/protection_center_screen.dart';
import 'package:zaher_cyber/theme/app_theme.dart';

void main() {
  test(
    'bundles a self-contained Academy page and the ZaherCyber channel',
    () async {
      final html = await rootBundle.loadString(
        'assets/academy_offline/index.html',
      );
      expect(html, contains('Academy F6-Team'));
      expect(html, contains('ZaherCyber Project'));
      expect(html, contains('t.me/+nRjn9nPpbzliMTIy'));
      expect(html, contains('<script type="module">'));
      expect(html, contains('<style>'));
      expect(html, isNot(contains('<script type="module" crossorigin src=')));
      expect(html, isNot(contains('<link rel="stylesheet"')));
    },
  );

  test('uses the official ZaherCyber Project Telegram invite', () {
    expect(zaherCyberProjectTelegramUrl, 'https://t.me/+nRjn9nPpbzliMTIy');
    expect(Uri.parse(zaherCyberProjectTelegramUrl).scheme, 'https');
  });

  test('provides a broad Arabic and international news feed library', () {
    expect(newsSources.length, greaterThanOrEqualTo(73));
    expect(newsSources.any((source) => source.language == 'AR'), isTrue);
    expect(newsSources.any((source) => source.language == 'EN'), isTrue);
  });

  test('provides a separate live tutorial feed library', () {
    expect(tutorialSources.length, greaterThanOrEqualTo(7));
    expect(
      tutorialSources.every((source) => source.category.startsWith('Tutorial')),
      isTrue,
    );
    expect(
      allFeedSources.map((source) => source.url).toSet().length,
      allFeedSources.length,
    );
  });

  test('normalizes secure release download URLs', () {
    expect(
      secureReleaseUrl('  HTTPS://GITHUB.COM/owner/repo/releases/file.zip  '),
      'https://github.com/owner/repo/releases/file.zip',
    );
    expect(
      secureReleaseUrl('http://github.com/owner/repo/releases/file.apk'),
      'https://github.com/owner/repo/releases/file.apk',
    );
    expect(secureReleaseUrl('http://example.invalid/file.zip'), isNull);
    expect(secureReleaseUrl('javascript:alert(1)'), isNull);
    expect(secureReleaseUrl(''), isNull);
    expect(
      secureReleaseUrl('https%3A%2F%2Fgithub.com%2Fowner%2Frepo%2Ffile.apk'),
      'https://github.com/owner/repo/file.apk',
    );
    expect(
      secureReleaseUrl('https:/github.com/owner/repo/file.apk'),
      'https://github.com/owner/repo/file.apk',
    );
    expect(
      secureReleaseUrl('\u200Bhttps://github.com/owner/repo/file.apk\uFEFF'),
      'https://github.com/owner/repo/file.apk',
    );
  });

  test('restores cached release assets whose URL is stored under url', () {
    final release = ToolRelease.fromJson({
      'repo': 'owner/project',
      'assets': [
        {
          'name': 'project.apk',
          'url':
              'https://github.com/owner/project/releases/download/v1/project.apk',
          'size': 100,
          'sha256': 'abc123',
        },
        {'name': 'broken.apk', 'url': ''},
      ],
    }, cached: true);

    expect(release.cached, isTrue);
    expect(release.assets, hasLength(1));
    expect(
      release.assets.single.url,
      'https://github.com/owner/project/releases/download/v1/project.apk',
    );
    expect(release.assets.single.sha256, 'abc123');
  });

  test('expanded open-source arsenal and learning library stay usable', () {
    expect(toolProjects.length, greaterThanOrEqualTo(99));
    expect(
      toolProjects.map((project) => project.id).toSet().length,
      toolProjects.length,
    );
    expect(learningResourceSections.length, greaterThanOrEqualTo(18));
    expect(
      learningResourceSections.expand((section) => section.items).length,
      greaterThanOrEqualTo(80),
    );
    expect(AppThemes.presets.length, 10);
    expect(AppThemes.presets.any((theme) => theme.id == 'terminal'), isTrue);
    expect(AppThemes.presets.any((theme) => theme.id == 'dark'), isTrue);
    expect(AppThemes.presets.any((theme) => theme.id == 'ocean'), isTrue);
    expect(AppThemes.presets.any((theme) => theme.id == 'crimson'), isTrue);
    expect(AppThemes.presets.any((theme) => theme.id == 'sand'), isTrue);
    expect(AppThemes.presets.any((theme) => theme.id == 'rose'), isTrue);
  });

  test('external resources include the requested official catalog and safety metadata', () {
    final ids = externalResources.map((item) => item.id).toSet();
    expect(ids, containsAll([
      'kc7', 'cyberdefenders', 'crapi', 'internetnl', 'dnsviz', 'tor', 'ooni',
      'tryhackme', 'htb-academy', 'portswigger', 'overthewire', 'picocylab',
      'root-me', 'letsdefend', 'btlo', 'juice-shop', 'webgoat', 'dvwa', 'vulnhub',
    ]));
    expect(externalResources.every((item) => item.url.startsWith('https://')), isTrue);
    expect(externalResources.where((item) => item.requiresIsolation).map((item) => item.id), containsAll(['crapi', 'juice-shop', 'webgoat', 'dvwa', 'vulnhub']));
    expect(externalResources.every((item) => item.accessAr.isNotEmpty && item.accessEn.isNotEmpty), isTrue);
  });

  test('includes Crowd.dev and Open Source Alternative', () {
    final crowd = toolProjects.singleWhere(
      (project) => project.id == 'crowd-dev',
    );
    expect(crowd.githubRepo, 'linuxfoundation/crowd.dev');
    expect(crowd.licenseHint, 'Apache-2.0');
    final resources = learningResourceSections
        .expand((section) => section.items)
        .toList();
    expect(
      resources.any(
        (resource) => resource.url == 'https://www.opensourcealternative.to/',
      ),
      isTrue,
    );
  });

  test('includes verified feeds, projects, and learning references', () {
    final feedNames = newsSources.map((source) => source.name).toSet();
    for (final name in [
      'CERT-EU Security Advisories',
      'Hugging Face Blog',
      'Kotlin Blog',
      'openSUSE News',
      'Internet Society',
      'GrapheneOS Releases',
      'التقنية السورية Syrian Tech',
    ]) {
      expect(feedNames, contains(name));
    }
    final projectIds = toolProjects.map((project) => project.id).toSet();
    for (final id in [
      'cve-bin-tool',
      'mlx',
      'archunit',
      'glance',
      'technitium-dns-server',
      'portmaster',
      'siteq8-sc-100',
      'qcri-sayf-eval',
      'arabic-rtl-agent-security-lab',
    ]) {
      expect(projectIds, contains(id));
    }
    final resourceNames = learningResourceSections
        .expand((section) => section.items)
        .map((resource) => resource.name)
        .toSet();
    for (final name in [
      'Machine Learning Systems (MLSysBook)',
      'C4 Model',
      'ArchWiki',
      'NIST NICE: Free and Low Cost Online Cybersecurity Learning Content',
      'Android Developers Training',
      'Internet Society: Privacy Course',
      'مركز التعلم — أكاديمية سينباي',
      'الأدلة الإرشادية — سايبرنس',
    ]) {
      expect(resourceNames, contains(name));
    }
  });

  test('adds verified Arabic and international cyber knowledge sources', () {
    final resources = learningResourceSections
        .expand((section) => section.items)
        .toList();
    final urls = resources.map((resource) => resource.url).toSet();

    expect(urls.length, resources.length);
    for (final url in [
      'https://www.cisa.gov/resources-tools',
      'https://www.cisa.gov/report',
      'https://www.ncsc.gov.uk/collection/incident-management',
      'https://www.ancs.tn/',
      'https://www.ncsc.gov.bh/en/about/who-are-we.html',
      'https://www.enisa.europa.eu/topics/cyber-threats/threat-landscape',
      'https://www.kb.cert.org/vuls/',
      'https://projectzero.google/',
      'https://msrc.microsoft.com/',
    ]) {
      expect(urls, contains(url));
    }
  });

  test('classifies dynamically discovered projects by broader topics', () {
    final aiProject = ToolProject.fromGitHubSearch({
      'full_name': 'sample/ai-project',
      'html_url': 'https://github.com/sample/ai-project',
      'license': {'spdx_id': 'MIT'},
      'topics': ['machine-learning', 'linux'],
    }, 'ai');
    expect(aiProject.category, 'Artificial Intelligence');
    expect(aiProject.platforms, contains('linux'));
    expect(aiProject.discovered, isTrue);

    final privacyProject = ToolProject.fromGitHubSearch({
      'full_name': 'sample/privacy-tool',
      'html_url': 'https://github.com/sample/privacy-tool',
      'license': {'spdx_id': 'Apache-2.0'},
      'topics': ['privacy'],
    }, 'privacy');
    expect(privacyProject.category, 'Privacy');
    expect(privacyProject.platforms, isEmpty);
  });

  test(
    'protection center contains extensive cited device and incident guidance',
    () {
      expect(protectionChecks.length, greaterThanOrEqualTo(20));
      expect(
        protectionChecks.map((item) => item.id).toSet().length,
        protectionChecks.length,
      );
      expect(
        protectionChecks.map((item) => item.platform).toSet(),
        containsAll(['Android', 'Windows', 'Linux']),
      );
      expect(
        protectionChecks.every(
          (item) => item.officialUrl.startsWith('https://'),
        ),
        isTrue,
      );
      expect(incidentPlaybooks.length, greaterThanOrEqualTo(5));
      expect(
        incidentPlaybooks.every((playbook) => playbook.steps.length >= 3),
        isTrue,
      );
      expect(
        incidentPlaybooks
            .expand((playbook) => playbook.steps)
            .every((step) => step.officialUrl.startsWith('https://')),
        isTrue,
      );
    },
  );

  test('product watchlist matches recent KEV and feed terms locally', () {
    const item = KevItem(
      cveId: 'CVE-2021-44228',
      vendor: 'Apache',
      product: 'Log4j',
      name: 'Remote code execution',
      dateAdded: '2021-12-10',
      description: 'Apache Log4j vulnerability',
      requiredAction: 'Apply the vendor update',
      knownRansomwareUse: false,
    );
    expect(matchesKevWatchTerms(item, ['  log4j  ']), isTrue);
    expect(matchesKevWatchTerms(item, ['OpenSSL']), isFalse);
    expect(
      matchesWatchTermsInText('New Microsoft Exchange advisory', ['exchange']),
      isTrue,
    );
    expect(matchesWatchTermsInText('New product bulletin', ['x']), isFalse);
    expect(
      VulnerabilityService.watchlistLimit,
      greaterThan(VulnerabilityService.visibleLimit),
    );
  });

  testWidgets(
    'protection center stores checklist progress and filters watch items',
    (tester) async {
      SharedPreferences.setMockInitialValues({});
      const check = ProtectionCheck(
        id: 'test-android-check',
        platform: 'Android',
        groupAr: 'تقوية Android',
        groupEn: 'Android hardening',
        titleAr: 'حدّث الجهاز',
        titleEn: 'Update the device',
        detailAr: 'ثبّت تحديثات الأمان الرسمية.',
        detailEn: 'Install official security updates.',
        risk: 'high',
        officialUrl: 'https://support.google.com/android/',
        sourceTitle: 'Android Help',
      );
      const playbook = IncidentPlaybook(
        id: 'test-incident',
        titleAr: 'حساب مخترق',
        titleEn: 'Compromised account',
        summaryAr: 'استعد السيطرة على الحساب.',
        summaryEn: 'Recover the account.',
        whenExpertAr: 'اتصل بمزود الحساب.',
        whenExpertEn: 'Contact the account provider.',
        steps: [
          ResponseStep(
            titleAr: 'غيّر كلمة المرور',
            titleEn: 'Change the password',
            detailAr: 'استخدم الموقع الرسمي.',
            detailEn: 'Use the official website.',
            risk: 'high',
            officialUrl: 'https://support.google.com/accounts/',
            sourceTitle: 'Account Help',
          ),
        ],
      );
      const kevItem = KevItem(
        cveId: 'CVE-2021-44228',
        vendor: 'Apache',
        product: 'Log4j',
        name: 'Log4Shell',
        dateAdded: '2021-12-10',
        description: 'Apache Log4j vulnerability',
        requiredAction: 'Update',
        knownRansomwareUse: false,
      );
      await tester.pumpWidget(
        MaterialApp(
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          theme: ThemeData(
            extensions: <ThemeExtension<dynamic>>[
              AppThemes.presets.first.palette,
            ],
          ),
          home: Scaffold(
            body: ProtectionCenterScreen(
              checks: const [check],
              playbooks: const [playbook],
              kevItems: const [kevItem],
              articles: const [
                Article(
                  title: 'Log4j security update',
                  link: 'https://example.org/log4j',
                  summary: 'Update Log4j',
                  source: 'Security feed',
                  category: 'Cybersecurity',
                ),
              ],
              tools: const [],
              isLoadingKev: false,
              onRefreshKev: () async {},
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('تقوية الأجهزة').first);
      await tester.pumpAndSettle();
      expect(find.text('حدّث الجهاز'), findsOneWidget);
      await tester.tap(find.byType(Checkbox).first);
      await tester.pumpAndSettle();
      final prefs = await SharedPreferences.getInstance();
      expect(
        prefs.getStringList('protection_checks_done_v1'),
        contains('test-android-check'),
      );
      await tester.tap(find.text('المتابعة'));
      await tester.pumpAndSettle();
      await tester.enterText(find.byType(TextField).first, 'Log4j');
      await tester.tap(find.byTooltip('إضافة'));
      await tester.pumpAndSettle();
      expect(find.text('CVE-2021-44228'), findsOneWidget);
    },
  );

  testWidgets(
    'quick incident choices open one guide and can return to all playbooks',
    (tester) async {
      SharedPreferences.setMockInitialValues({});
      await tester.pumpWidget(
        MaterialApp(
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          theme: ThemeData(
            extensions: <ThemeExtension<dynamic>>[
              AppThemes.presets.first.palette,
            ],
          ),
          home: Scaffold(
            body: ProtectionCenterScreen(
              checks: protectionChecks,
              playbooks: incidentPlaybooks,
              kevItems: const [],
              articles: const [],
              tools: const [],
              isLoadingKev: false,
              onRefreshKev: () async {},
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      final selected = incidentPlaybooks.first;
      await tester.tap(find.byKey(ValueKey('quick-response-${selected.id}')));
      await tester.pumpAndSettle();
      expect(find.text(selected.summaryAr), findsOneWidget);
      expect(find.text('ابدأ بهذه الخطوة أولاً'), findsOneWidget);
      expect(
        find.byKey(const ValueKey('incident-show-all-guides')),
        findsOneWidget,
      );

      await tester.tap(find.byKey(const ValueKey('incident-show-all-guides')));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('incident-show-all-guides')),
        findsNothing,
      );
      expect(find.text(selected.titleAr), findsOneWidget);
    },
  );

  testWidgets(
    'protection branches retain readable content while scrolling and switching',
    (tester) async {
      SharedPreferences.setMockInitialValues({});
      await tester.pumpWidget(
        MaterialApp(
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          theme: ThemeData(
            extensions: <ThemeExtension<dynamic>>[
              AppThemes.presets.first.palette,
            ],
          ),
          home: Scaffold(
            body: ProtectionCenterScreen(
              checks: protectionChecks,
              playbooks: incidentPlaybooks,
              kevItems: const [],
              articles: const [],
              tools: const [],
              isLoadingKev: false,
              onRefreshKev: () async {},
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.byType(ChoiceChip).at(1));
      await tester.pumpAndSettle();
      final lastCheckTitle = protectionChecks.last.titleAr;
      final hardeningScroll = find
          .descendant(
            of: find.byKey(const PageStorageKey('protection-hardening')),
            matching: find.byType(Scrollable),
          )
          .first;
      await tester.scrollUntilVisible(
        find.text(lastCheckTitle),
        450,
        scrollable: hardeningScroll,
      );
      expect(find.text(lastCheckTitle), findsOneWidget);

      await tester.tap(find.byType(ChoiceChip).at(2));
      await tester.pumpAndSettle();
      final firstPlaybook = incidentPlaybooks.first;
      await tester.tap(find.text(firstPlaybook.titleAr));
      await tester.pumpAndSettle();
      expect(find.text(firstPlaybook.summaryAr), findsOneWidget);
      final incidentScroll = find
          .descendant(
            of: find.byKey(const PageStorageKey('protection-incidents')),
            matching: find.byType(Scrollable),
          )
          .first;
      await tester.scrollUntilVisible(
        find.text(incidentPlaybooks.last.titleAr),
        450,
        scrollable: incidentScroll,
      );
      expect(find.text(incidentPlaybooks.last.titleAr), findsOneWidget);

      await tester.tap(find.byType(ChoiceChip).at(3));
      await tester.pumpAndSettle();
      expect(find.text('متابعة المنتجات والثغرات'), findsOneWidget);
      await tester.tap(find.byType(ChoiceChip).at(0));
      await tester.pumpAndSettle();
      expect(find.text('مركز الحماية'), findsOneWidget);
    },
  );

  test('English article detection considers language code and actual text', () {
    expect(isLikelyEnglish('en-US', 'عنوان باللغة العربية فقط'), isTrue);
    expect(
      isLikelyEnglish(
        'AR',
        'A long English cybersecurity incident report with detailed analysis',
      ),
      isTrue,
    );
    expect(isLikelyEnglish('AR', 'خبر أمني عربي عن تحديثات الحماية'), isFalse);
  });

  test(
    'RSS requests use conditional validators and retain cached entries',
    () async {
      SharedPreferences.setMockInitialValues({});
      const source = NewsSource(
        'Example Tech',
        'https://example.test/feed.xml',
        'Technology',
        'EN',
      );
      const xml =
          '<rss version="2.0"><channel><item><title>Live security update</title><link>https://example.test/story/1</link><description>Publisher excerpt</description><pubDate>Tue, 13 Oct 2026 11:00:00 GMT</pubDate></item></channel></rss>';
      final firstService = FeedService(
        client: MockClient((request) async {
          expect(request.headers['if-none-match'], isNull);
          return http.Response(xml, 200, headers: {'etag': '"feed-v1"'});
        }),
      );
      final first = await firstService.fetchAll(sources: const [source]);
      expect(first, hasLength(1));
      expect(first.single.title, 'Live security update');
      firstService.dispose();

      final secondService = FeedService(
        client: MockClient((request) async {
          expect(request.headers['if-none-match'], '"feed-v1"');
          return http.Response('', 304);
        }),
      );
      final second = await secondService.fetchAll(sources: const [source]);
      expect(second, hasLength(1));
      expect(second.single.link, 'https://example.test/story/1');
      expect(secondService.lastSuccessfulSources, 1);
      expect(secondService.lastFailedSources, 0);
      secondService.dispose();
    },
  );
}

// The internal external-resources catalog is intentionally tested separately so
// link and safety metadata remain available without opening any external URL.
