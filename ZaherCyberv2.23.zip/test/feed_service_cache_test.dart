import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zaher_cyber/data/sources.dart';
import 'package:zaher_cyber/services/feed_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const source = NewsSource(
    'Example Publisher',
    'https://example.org/feed.xml',
    'Test',
    'EN',
  );

  setUp(() => SharedPreferences.setMockInitialValues({}));

  test(
    'keeps the last cached articles when a feed later returns HTTP 503',
    () async {
      final first = FeedService(
        client: MockClient(
          (request) async => http.Response(
            '<?xml version="1.0"?><rss version="2.0"><channel><item><title>Cached security story</title><link>https://example.org/story</link><description>Saved locally</description><pubDate>Mon, 01 Jan 2026 10:00:00 GMT</pubDate></item></channel></rss>',
            200,
            headers: {'content-type': 'application/rss+xml'},
          ),
        ),
      );
      final firstItems = await first.fetchAll(sources: const [source]);
      expect(firstItems, hasLength(1));
      first.dispose();

      final second = FeedService(
        client: MockClient(
          (request) async => http.Response('unavailable', 503),
        ),
      );
      final items = await second.fetchAll(sources: const [source]);
      expect(items, hasLength(1));
      expect(items.single.title, 'Cached security story');
      expect(second.lastFailedSources, 1);
      expect(second.lastSourceFailures.single.statusCode, 503);
      expect(second.lastCycleWasGlobalConnectivityFailure, isFalse);
      second.dispose();
    },
  );
  test('suppresses same-day story titles repeated across publishers', () async {
    SharedPreferences.setMockInitialValues({});
    const otherSource = NewsSource(
      'Other Publisher',
      'https://other.example.org/feed.xml',
      'Test',
      'EN',
    );
    final client = MockClient(
      (request) async => http.Response(
        '<?xml version="1.0"?><rss version="2.0"><channel><item><title>Same security story!</title><link>https://example.org/story-one</link><pubDate>Mon, 01 Jan 2026 10:00:00 GMT</pubDate></item></channel></rss>',
        200,
      ),
    );
    final service = FeedService(client: client);
    final items = await service.fetchAll(sources: const [source, otherSource]);
    expect(items, hasLength(1));
    expect(service.lastDuplicateCount, 1);
    service.dispose();
  });
}
