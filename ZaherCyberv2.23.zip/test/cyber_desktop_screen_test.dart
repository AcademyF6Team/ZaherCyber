import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:zaher_cyber/data/learning_content.dart';
import 'package:zaher_cyber/models/article.dart';
import 'package:zaher_cyber/screens/cyber_desktop_screen.dart';
import 'package:zaher_cyber/screens/learning_center_screen.dart';
import 'package:zaher_cyber/screens/external_resources_screen.dart';
import 'package:zaher_cyber/screens/f6_security_tools_screen.dart';
import 'package:zaher_cyber/theme/app_theme.dart';

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  Widget app({
    required ValueChanged<String> onOpenSection,
    ValueChanged<String>? onGlobalSearch,
    ValueChanged<String?>? onOpenLearning,
    VoidCallback? onOpenExternalResources,
    VoidCallback? onOpenSecurityTools,
  }) => MaterialApp(
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: AppThemes.build(0),
    home: Scaffold(
      body: CyberDesktopScreen(
        articles: const [
          Article(
            title: 'خبر أمني تجريبي',
            link: 'https://example.org/story',
            summary: 'ملخص محلي للاختبار.',
            source: 'مصدر اختباري',
            category: 'security',
            language: 'AR',
          ),
        ],
        lastUpdated: null,
        isUpdating: false,
        updateFailed: false,
        updatedSources: 0,
        failedSources: 0,
        onRefresh: () async {},
        onGlobalSearch: onGlobalSearch ?? (_) {},
        onOpenSection: onOpenSection,
        onOpenLearning: onOpenLearning,
        onOpenAcademy: () {},
        onOpenCtf: () {},
        onOpenExternalResources: onOpenExternalResources,
        onOpenSecurityTools: onOpenSecurityTools,
        onOpenArticle: (_) {},
      ),
    ),
  );

  Future<void> scrollToDesktopWidget(WidgetTester tester, Finder target) async {
    final scrollable = find
        .descendant(
          of: find.byKey(const PageStorageKey<String>('cyber-desktop-scroll')),
          matching: find.byType(Scrollable),
        )
        .first;
    for (var attempt = 0; attempt < 14; attempt++) {
      final count = target.evaluate().length;
      if (count == 1) {
        await tester.ensureVisible(target.first);
        return;
      }
      if (count > 1)
        throw StateError('Expected one target widget, found $count.');
      await tester.drag(scrollable, const Offset(0, -450));
      await tester.pumpAndSettle();
    }
    expect(target, findsOneWidget);
    await tester.ensureVisible(target.first);
  }

  testWidgets('shows desktop workspace and launches an existing section', (
    tester,
  ) async {
    String? opened;
    await tester.pumpWidget(app(onOpenSection: (section) => opened = section));
    await tester.pumpAndSettle();

    expect(find.text('F6-OS'), findsOneWidget);
    expect(find.text('تطبيقاتي'), findsOneWidget);
    final arsenal = find.byKey(const ValueKey('desktop-app-arsenal'));
    await tester.ensureVisible(arsenal);
    await tester.tap(arsenal);
    expect(opened, 'arsenal');
  });

  testWidgets('desktop search forwards a query to local content search', (
    tester,
  ) async {
    String? searched;
    await tester.pumpWidget(
      app(onOpenSection: (_) {}, onGlobalSearch: (query) => searched = query),
    );
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextField).first, 'CVE-2026');
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('بحث شامل'));
    expect(searched, 'CVE-2026');
  });

  testWidgets('FAHES offers local analysis and asks before external checks', (
    tester,
  ) async {
    await tester.pumpWidget(app(onOpenSection: (_) {}));
    await tester.pumpAndSettle();
    await tester.tap(find.text('أدواتي'));
    await tester.pumpAndSettle();

    final urlAuditor = find.byKey(const ValueKey('desktop-app-fahes'));
    await tester.ensureVisible(urlAuditor);
    await tester.tap(urlAuditor);
    await tester.pumpAndSettle();

    final auditorScreen = find.byKey(const ValueKey('fahes-screen'));
    expect(
      find.descendant(of: auditorScreen, matching: find.text('فاحص | FAHES')),
      findsOneWidget,
    );
    expect(find.text('تحليل محلي فقط'), findsOneWidget);
    expect(find.byKey(const ValueKey('fahes-remote-results')), findsNothing);
    await tester.enterText(
      find.byKey(const ValueKey('fahes-url-input')),
      'http://bit.ly/login?next=https%3A%2F%2Fevil.example',
    );
    await tester.tap(find.byKey(const ValueKey('fahes-local-check')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('fahes-local-result')), findsOneWidget);
    expect(
      find.textContaining('الاتصال يستخدم HTTP غير المشفر'),
      findsOneWidget,
    );
    expect(find.textContaining('خدمة اختصار روابط معروفة'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('fahes-check-sources')));
    await tester.pumpAndSettle();
    expect(find.text('إرسال الرابط إلى قواعد خارجية؟'), findsOneWidget);
    await tester.tap(find.text('إلغاء'));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('fahes-remote-results')), findsNothing);
    await tester.tap(find.byTooltip('إغلاق'));
    await tester.pumpAndSettle();
    expect(find.text('تحليل محلي فقط'), findsNothing);
  });

  testWidgets(
    'external domain tools explain data sharing and can be cancelled',
    (tester) async {
      await tester.pumpWidget(app(onOpenSection: (_) {}));
      await tester.pumpAndSettle();

      final internetTest = find.byKey(
        const ValueKey('desktop-external-internetnl'),
      );
      await scrollToDesktopWidget(tester, internetTest);
      tester.widget<ListTile>(internetTest).onTap!.call();
      await tester.pumpAndSettle();

      expect(find.text('متابعة إلى الموقع'), findsOneWidget);
      expect(find.textContaining('تعالجه الخدمة'), findsOneWidget);
      await tester.tap(find.text('إلغاء'));
      await tester.pumpAndSettle();
      expect(find.text('متابعة إلى الموقع'), findsNothing);
    },
  );

  testWidgets('tracks recent apps and wires continuation to the next lesson', (
    tester,
  ) async {
    String? nextLessonId;
    var learningOpened = false;
    SharedPreferences.setMockInitialValues({
      'learning_progress_v2': jsonEncode({
        'completedLessons': learningLessons
            .skip(1)
            .map((lesson) => lesson.id)
            .toList(),
        'quizBestScores': <String, int>{},
        'flashcardRatings': <String, int>{},
        'updatedAt': '',
      }),
    });
    await tester.pumpWidget(
      app(
        onOpenSection: (_) {},
        onOpenLearning: (lessonId) {
          learningOpened = true;
          nextLessonId = lessonId;
        },
      ),
    );
    await tester.pumpAndSettle();
    final newsApp = find.byKey(const ValueKey('desktop-app-news'));
    await tester.ensureVisible(newsApp);
    await tester.tap(newsApp);
    await tester.pumpAndSettle();
    expect(find.text('المستخدمة مؤخراً'), findsOneWidget);

    final learning = find.byKey(const ValueKey('desktop-widget-learning'));
    await scrollToDesktopWidget(tester, learning);
    final continueButton = find.text('متابعة المسارات');
    await scrollToDesktopWidget(tester, continueButton);
    final action = tester.widget<TextButton>(
      find
          .ancestor(of: continueButton, matching: find.byType(TextButton))
          .first,
    );
    action.onPressed!.call();
    expect(learningOpened, isTrue);
    expect(nextLessonId, learningLessons.first.id);
  });

  testWidgets('Continue learning opens the requested lesson, tabs, and back path', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        theme: AppThemes.build(0),
        home: Scaffold(
          body: CyberDesktopScreen(
            articles: const [],
            lastUpdated: null,
            isUpdating: false,
            updateFailed: false,
            updatedSources: 0,
            failedSources: 0,
            onRefresh: () async {},
            onGlobalSearch: (_) {},
            onOpenSection: (_) {},
            onOpenAcademy: () {},
            onOpenCtf: () {},
            onOpenLearning: (lessonId) => Navigator.of(tester.element(find.byType(CyberDesktopScreen))).push<void>(
              MaterialPageRoute<void>(builder: (_) => LearningCenterScreen(initialLessonId: lessonId)),
            ),
            onOpenArticle: (_) {},
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    final continueButton = find.text('متابعة المسارات');
    await scrollToDesktopWidget(tester, continueButton);
    await tester.tap(continueButton);
    await tester.pumpAndSettle();

    expect(find.text('مركز التعلم'), findsOneWidget);
    expect(find.text('المسارات'), findsOneWidget);
    expect(find.text('اختبارات'), findsOneWidget);
    expect(find.text('بطاقات'), findsOneWidget);
    expect(find.text(learningLessons.first.titleAr), findsOneWidget);
    expect(tester.takeException(), isNull);

    await tester.tap(find.byKey(const ValueKey('page-back-navigation')));
    await tester.pumpAndSettle();
    expect(find.text('F6-OS'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('external resources app opens an internal searchable screen', (tester) async {
    await tester.pumpWidget(MaterialApp(
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      theme: AppThemes.build(0),
      home: Builder(builder: (context) => Scaffold(body: CyberDesktopScreen(
        articles: const [], lastUpdated: null, isUpdating: false, updateFailed: false,
        updatedSources: 0, failedSources: 0, onRefresh: () async {}, onGlobalSearch: (_) {},
        onOpenSection: (_) {}, onOpenAcademy: () {}, onOpenCtf: () {},
        onOpenExternalResources: () => Navigator.of(context).push<void>(MaterialPageRoute<void>(builder: (_) => const ExternalResourcesScreen())),
        onOpenArticle: (_) {},
      ))),
    ));
    await tester.pumpAndSettle();
    final tile = find.byKey(const ValueKey('desktop-app-external-resources'));
    await tester.ensureVisible(tile);
    await tester.tap(tile);
    await tester.pumpAndSettle();
    expect(find.text('مختبرات وخدمات خارجية'), findsOneWidget);
    expect(find.text('TryHackMe'), findsOneWidget);
    await tester.enterText(find.byType(TextField), 'VulnHub');
    await tester.pumpAndSettle();
    expect(find.text('VulnHub'), findsOneWidget);
    expect(find.text('TryHackMe'), findsNothing);
    await tester.tap(find.byKey(const ValueKey('page-back-navigation')));
    await tester.pumpAndSettle();
    expect(find.text('F6-OS'), findsOneWidget);
  });


  testWidgets('F6 Security Tools opens internally, filters tools, and returns safely', (
    tester,
  ) async {
    await tester.pumpWidget(
      app(
        onOpenSection: (_) {},
        onOpenSecurityTools: () => Navigator.of(
          tester.element(find.byType(CyberDesktopScreen)),
        ).push<void>(
          MaterialPageRoute<void>(
            builder: (_) => const F6SecurityToolsScreen(),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    final tile = find.byKey(const ValueKey('desktop-app-f6-security-tools'));
    await tester.ensureVisible(tile);
    await tester.tap(tile);
    await tester.pumpAndSettle();

    expect(find.text('F6 Security Tools'), findsOneWidget);
    expect(find.text('MailAccess'), findsOneWidget);
    expect(find.text('Horus'), findsOneWidget);
    expect(find.text('Unfurl'), findsOneWidget);
    expect(tester.takeException(), isNull);

    await tester.enterText(
      find.byKey(const ValueKey('f6-security-tools-search')),
      'Horus',
    );
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('f6-security-tool-horus')), findsOneWidget);
    expect(find.byKey(const ValueKey('f6-security-tool-mailaccess')), findsNothing);

    await tester.tap(find.byKey(const ValueKey('page-back-navigation')));
    await tester.pumpAndSettle();
    expect(find.text('F6-OS'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

}
