import 'package:flutter_test/flutter_test.dart';
import 'package:zaher_cyber/firebase_options.dart';

void main() {
  test('Firebase Android configuration targets ZaherCyber package project', () {
    const options = DefaultFirebaseOptions.android;
    expect(options.projectId, 'zahercyber-project');
    expect(options.messagingSenderId, '574521473108');
    expect(options.appId, startsWith('1:574521473108:android:'));
  });
}
