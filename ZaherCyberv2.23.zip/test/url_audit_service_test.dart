import 'package:flutter_test/flutter_test.dart';
import 'package:zaher_cyber/services/url_audit_service.dart';

void main() {
  final service = UrlAuditService();

  test('normalizes a hostname without scheme to HTTPS locally', () {
    final result = service.analyze('example.com/path');
    expect(result.valid, isTrue);
    expect(result.host, 'example.com');
    expect(result.usesHttps, isTrue);
    expect(result.normalizedUrl, 'https://example.com/path');
    expect(result.findings, isNotEmpty);
    expect(
      result.findings.first.titleEn,
      'No structural indicators matched local rules',
    );
  });

  test(
    'flags insecure HTTP, shorteners, sensitive terms and redirect keys',
    () {
      final result = service.analyze(
        'http://bit.ly/login?next=https%3A%2F%2Fevil.example',
      );
      expect(result.valid, isTrue);
      expect(result.usesHttps, isFalse);
      expect(
        result.findings.map((finding) => finding.titleEn),
        containsAll([
          'The URL uses unencrypted HTTP',
          'Known URL shortener',
          'Sensitive words in the URL path',
          'The URL contains a redirect parameter',
        ]),
      );
      expect(result.mediumCount, 1);
      expect(result.lowCount, 3);
    },
  );

  test(
    'flags Punycode, direct IP addresses, many labels, and unusual ports',
    () {
      final result = service.analyze(
        'https://xn--paypa1-4ve.example.sub.domain.test:8443/',
      );
      expect(result.valid, isTrue);
      expect(
        result.findings.map((finding) => finding.titleEn),
        containsAll([
          'Unusual port: 8443',
          'The host contains an encoded IDN (Punycode)',
          'The hostname has many labels (5)',
        ]),
      );

      final ipResult = service.analyze('https://192.0.2.1/path');
      expect(
        ipResult.findings.map((finding) => finding.titleEn),
        contains('The host is a direct IP address'),
      );
    },
  );

  test(
    'rejects embedded credentials, unsupported schemes and oversized URLs',
    () {
      expect(
        service.analyze('https://user:password@example.com').valid,
        isFalse,
      );
      expect(service.analyze('ftp://example.com/file').valid, isFalse);
      expect(service.analyze('   ').valid, isFalse);
      expect(
        service.analyze('https://example.com/${'a' * 4100}').valid,
        isFalse,
      );
    },
  );

  test('warns on unusually long URLs without calling them malicious', () {
    final result = service.analyze('https://example.com/${'a' * 200}');
    expect(result.valid, isTrue);
    expect(
      result.findings.map((finding) => finding.titleEn),
      contains('Unusually long URL (220 characters)'),
    );
    expect(result.highCount, 0);
  });
}
