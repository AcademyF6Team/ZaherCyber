import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:zaher_cyber/screens/about_center_screen.dart';
import 'package:zaher_cyber/theme/app_theme.dart';

void main() {
  testWidgets('privacy center opens a separate confirmed bookmarks action', (
    tester,
  ) async {
    var clearedBookmarks = 0;
    await tester.pumpWidget(
      MaterialApp(
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        theme: AppThemes.build(0),
        home: AboutCenterScreen(
          locale: const Locale('ar'),
          sourceCount: 10,
          projectCount: 5,
          resourceCount: 20,
          quarantinedCount: 1,
          onManageSources: () {},
          onClearFeedCache: () async {},
          onClearBookmarks: () async {
            clearedBookmarks++;
          },
          onClearLearningProgress: () async {},
          onResetDesktop: () async {},
          onOpenProtection: () {},
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.text('الخصوصية وإدارة البيانات'));
    await tester.pumpAndSettle();
    expect(find.text('الخصوصية والبيانات'), findsOneWidget);

    final clear = find.text('مسح المحفوظات والوسوم');
    await tester.scrollUntilVisible(clear, 260);
    await tester.tap(clear);
    await tester.pumpAndSettle();
    expect(find.text('تأكيد'), findsOneWidget);
    await tester.tap(find.text('تأكيد'));
    await tester.pumpAndSettle();
    expect(clearedBookmarks, 1);
  });
}
