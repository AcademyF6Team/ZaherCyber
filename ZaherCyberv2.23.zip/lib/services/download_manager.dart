import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/secure_release_url.dart';

class ManagedDownload {
  final String id;
  final String projectId;
  final String projectName;
  final String fileName;
  final String url;
  final String localPath;
  final String status;
  final int received;
  final int total;
  final String? expectedSha256;
  final String? actualSha256;
  final String? publicLocation;
  final String? error;
  final DateTime createdAt;

  const ManagedDownload({
    required this.id,
    required this.projectId,
    required this.projectName,
    required this.fileName,
    required this.url,
    required this.localPath,
    required this.status,
    required this.received,
    required this.total,
    required this.createdAt,
    this.expectedSha256,
    this.actualSha256,
    this.publicLocation,
    this.error,
  });

  ManagedDownload copyWith({
    String? status,
    int? received,
    int? total,
    String? actualSha256,
    String? publicLocation,
    String? error,
    bool clearError = false,
  }) => ManagedDownload(
    id: id,
    projectId: projectId,
    projectName: projectName,
    fileName: fileName,
    url: url,
    localPath: localPath,
    status: status ?? this.status,
    received: received ?? this.received,
    total: total ?? this.total,
    expectedSha256: expectedSha256,
    actualSha256: actualSha256 ?? this.actualSha256,
    publicLocation: publicLocation ?? this.publicLocation,
    error: clearError ? null : (error ?? this.error),
    createdAt: createdAt,
  );

  Map<String, Object?> toJson() => {
    'id': id,
    'projectId': projectId,
    'projectName': projectName,
    'fileName': fileName,
    'url': url,
    'localPath': localPath,
    'status': status,
    'received': received,
    'total': total,
    'expectedSha256': expectedSha256,
    'actualSha256': actualSha256,
    'publicLocation': publicLocation,
    'error': error,
    'createdAt': createdAt.toIso8601String(),
  };

  factory ManagedDownload.fromJson(Map<String, dynamic> json) =>
      ManagedDownload(
        id: json['id']?.toString() ?? '',
        projectId: json['projectId']?.toString() ?? '',
        projectName: json['projectName']?.toString() ?? '',
        fileName: json['fileName']?.toString() ?? '',
        url: json['url']?.toString() ?? '',
        localPath: json['localPath']?.toString() ?? '',
        status: json['status']?.toString() ?? 'interrupted',
        received: (json['received'] as num?)?.toInt() ?? 0,
        total: (json['total'] as num?)?.toInt() ?? 0,
        expectedSha256: json['expectedSha256']?.toString(),
        actualSha256: json['actualSha256']?.toString(),
        publicLocation: json['publicLocation']?.toString(),
        error: json['error']?.toString(),
        createdAt:
            DateTime.tryParse(json['createdAt']?.toString() ?? '') ??
            DateTime.now(),
      );
}

class DownloadManagerService extends ChangeNotifier {
  DownloadManagerService({Dio? dio})
    : _dio =
          dio ??
          Dio(
            BaseOptions(
              connectTimeout: const Duration(seconds: 20),
              receiveTimeout: const Duration(minutes: 20),
              followRedirects: true,
              maxRedirects: 8,
              headers: const {'User-Agent': 'ZaherCyber/1.0'},
            ),
          );

  static const _storageKey = 'download_jobs_v2';
  static const _native = MethodChannel('com.zahercyber/native');
  final Dio _dio;
  final List<ManagedDownload> _jobs = [];
  final Map<String, CancelToken> _cancelTokens = {};
  bool _ready = false;
  List<ManagedDownload> get jobs => List.unmodifiable(_jobs);
  bool get isReady => _ready;

  Future<void> initialize() async {
    if (_ready) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw != null) {
      try {
        final rows = (jsonDecode(raw) as List).whereType<Map>();
        _jobs.addAll(
          rows
              .map(
                (e) => ManagedDownload.fromJson(Map<String, dynamic>.from(e)),
              )
              .map((job) {
                if (job.status == 'downloading')
                  return job.copyWith(
                    status: 'interrupted',
                    error: 'The previous download was interrupted.',
                  );
                return job;
              }),
        );
      } catch (_) {
        _jobs.clear();
      }
    }
    _ready = true;
    notifyListeners();
  }

  Future<void> startDownload({
    required String projectId,
    required String projectName,
    required String fileName,
    required String url,
    String? expectedSha256,
  }) async {
    final safeUrl = secureReleaseUrl(url);
    if (safeUrl == null) {
      throw ArgumentError(
        'رابط التنزيل غير صالح أو غير آمن. نقبل HTTPS فقط، ونحوّل روابط HTTP لمصادر الإصدارات المعروفة إلى HTTPS.',
      );
    }
    await initialize();
    final base = await getApplicationDocumentsDirectory();
    final directory = Directory('${base.path}/ZaherCyber/Downloads');
    await directory.create(recursive: true);
    final safeName = fileName
        .replaceAll(RegExp(r'[/\\:*?"<>|\x00-\x1f]'), '_')
        .trim();
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final localPath = '${directory.path}/${projectId}_${stamp}_$safeName';
    final job = ManagedDownload(
      id: '$projectId-$stamp',
      projectId: projectId,
      projectName: projectName,
      fileName: safeName,
      url: safeUrl,
      localPath: localPath,
      status: 'downloading',
      received: 0,
      total: 0,
      expectedSha256: expectedSha256,
      createdAt: DateTime.now(),
    );
    _jobs.insert(0, job);
    final token = CancelToken();
    _cancelTokens[job.id] = token;
    await _persist();
    notifyListeners();

    try {
      await _dio.download(
        safeUrl,
        localPath,
        cancelToken: token,
        deleteOnError: false,
        onReceiveProgress: (received, total) {
          final index = _jobs.indexWhere((e) => e.id == job.id);
          if (index < 0) return;
          _jobs[index] = _jobs[index].copyWith(
            received: received,
            total: total,
          );
          notifyListeners();
        },
      );
      final file = File(localPath);
      if (!await file.exists() || await file.length() == 0)
        throw StateError('The downloaded file is empty.');
      final actual = (await sha256.bind(file.openRead()).first).toString();
      final size = await file.length();
      final expected = expectedSha256?.toLowerCase().trim();
      if (expected != null &&
          expected.isNotEmpty &&
          actual.toLowerCase() != expected) {
        await file.delete();
        throw StateError('SHA-256 verification failed. The file was removed.');
      }

      String? publicLocation;
      String? storageWarning;
      try {
        publicLocation = await _native.invokeMethod<String>('saveToDownloads', {
          'path': localPath,
          'fileName': safeName,
          'mimeType': _mimeType(safeName),
        });
      } on PlatformException catch (error) {
        publicLocation = null;
        storageWarning =
            error.message ??
            'لم تُحفظ نسخة في مجلد التنزيلات العام؛ الملف متاح داخل التطبيق ويمكن مشاركته.';
      } on MissingPluginException {
        publicLocation = null;
        storageWarning =
            'تعذر نقل الملف إلى Downloads؛ الملف محفوظ داخل التطبيق ويمكن مشاركته.';
      }
      _update(
        job.id,
        (old) => old.copyWith(
          status: 'completed',
          received: size,
          total: size,
          actualSha256: actual,
          publicLocation: publicLocation,
          error: storageWarning,
          clearError: storageWarning == null,
        ),
      );
    } on DioException catch (error) {
      if (CancelToken.isCancel(error)) {
        final file = File(localPath);
        if (await file.exists()) await file.delete();
        _update(
          job.id,
          (old) => old.copyWith(status: 'cancelled', error: null),
        );
      } else {
        _update(
          job.id,
          (old) => old.copyWith(
            status: 'failed',
            error: error.message ?? 'Network download failed.',
          ),
        );
      }
    } catch (error) {
      _update(
        job.id,
        (old) => old.copyWith(
          status: 'failed',
          error: error.toString().replaceFirst('Bad state: ', ''),
        ),
      );
    } finally {
      _cancelTokens.remove(job.id);
      await _persist();
      notifyListeners();
    }
  }

  void _update(String id, ManagedDownload Function(ManagedDownload) update) {
    final index = _jobs.indexWhere((e) => e.id == id);
    if (index >= 0) _jobs[index] = update(_jobs[index]);
    notifyListeners();
  }

  Future<void> cancel(String id) async {
    _cancelTokens[id]?.cancel('User cancelled download');
  }

  Future<void> restart(ManagedDownload job) => startDownload(
    projectId: job.projectId,
    projectName: job.projectName,
    fileName: job.fileName,
    url: job.url,
    expectedSha256: job.expectedSha256,
  );

  Future<String?> installApk(ManagedDownload job) async {
    if (!job.fileName.toLowerCase().endsWith('.apk')) return 'not_apk';
    return _native.invokeMethod<String>('installApk', {'path': job.localPath});
  }

  Future<void> delete(ManagedDownload job) async {
    try {
      final local = File(job.localPath);
      if (await local.exists()) await local.delete();
    } catch (_) {}
    final uri = job.publicLocation;
    if (uri != null && uri.startsWith('content://')) {
      try {
        await _native.invokeMethod<void>('deleteDownload', {'uri': uri});
      } catch (_) {}
    }
    _jobs.removeWhere((e) => e.id == job.id);
    await _persist();
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _storageKey,
      jsonEncode(_jobs.map((e) => e.toJson()).toList()),
    );
  }

  String _mimeType(String name) {
    final lower = name.toLowerCase();
    if (lower.endsWith('.apk'))
      return 'application/vnd.android.package-archive';
    if (lower.endsWith('.exe'))
      return 'application/vnd.microsoft.portable-executable';
    if (lower.endsWith('.msi')) return 'application/x-msi';
    if (lower.endsWith('.zip')) return 'application/zip';
    if (lower.endsWith('.7z')) return 'application/x-7z-compressed';
    if (lower.endsWith('.gz') || lower.endsWith('.tgz'))
      return 'application/gzip';
    if (lower.endsWith('.dmg')) return 'application/x-apple-diskimage';
    return 'application/octet-stream';
  }

  @override
  void dispose() {
    for (final token in _cancelTokens.values) {
      token.cancel('App closed');
    }
    _dio.close(force: true);
    super.dispose();
  }
}
