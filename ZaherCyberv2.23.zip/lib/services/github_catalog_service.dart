import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/tool_project.dart';
import '../models/tool_release.dart';

class GitHubCatalogService {
  GitHubCatalogService({Dio? dio})
    : _dio =
          dio ??
          Dio(
            BaseOptions(
              connectTimeout: const Duration(seconds: 12),
              receiveTimeout: const Duration(seconds: 16),
              headers: const {
                'Accept': 'application/vnd.github+json',
                'X-GitHub-Api-Version': '2022-11-28',
                'User-Agent': 'ZaherCyber/1.0 (open-source software catalogue)',
              },
            ),
          );

  final Dio _dio;
  static const _releaseTtl = Duration(hours: 12);
  static const _discoveryTtl = Duration(hours: 24);

  Future<ToolRelease?> latestRelease(
    ToolProject project, {
    bool force = false,
  }) async {
    final repo = project.githubRepo;
    if (repo == null || repo.trim().isEmpty) return null;
    final preferences = await SharedPreferences.getInstance();
    final key = 'gh_release_v2_${repo.toLowerCase()}';
    final raw = preferences.getString(key);
    Map<String, dynamic>? stored;
    ToolRelease? cached;
    String? etag;
    if (raw != null) {
      try {
        stored = jsonDecode(raw) as Map<String, dynamic>;
        cached = ToolRelease.fromJson(
          Map<String, dynamic>.from(stored['release'] as Map),
          cached: true,
        );
        etag = stored['etag']?.toString();
        final fetchedAt = DateTime.tryParse(
          stored['fetchedAt']?.toString() ?? '',
        );
        if (!force &&
            fetchedAt != null &&
            DateTime.now().difference(fetchedAt) < _releaseTtl)
          return cached;
      } catch (_) {
        cached = null;
        stored = null;
      }
    }

    try {
      final response = await _dio.get<dynamic>(
        'https://api.github.com/repos/$repo/releases/latest',
        options: Options(
          headers: etag == null ? null : {'If-None-Match': etag},
          validateStatus: (status) => status != null && status < 500,
        ),
      );
      if (response.statusCode == 304 && cached != null) return cached;
      if (response.statusCode != 200 || response.data is! Map) return cached;
      final data = Map<String, dynamic>.from(response.data as Map);
      final release = ToolRelease.fromGitHub(
        repo,
        data,
        license: project.licenseHint,
      );
      await preferences.setString(
        key,
        jsonEncode({
          'fetchedAt': DateTime.now().toIso8601String(),
          'etag': response.headers.value('etag'),
          'release': release.toJson(),
        }),
      );
      return release;
    } on DioException {
      return cached;
    } catch (_) {
      return cached;
    }
  }

  Future<String?> repositoryLicense(ToolProject project) async {
    final repo = project.githubRepo;
    if (repo == null || repo.isEmpty) return project.licenseHint;
    final preferences = await SharedPreferences.getInstance();
    final key = 'gh_license_v1_${repo.toLowerCase()}';
    final cachedJson = preferences.getString(key);
    if (cachedJson != null) {
      try {
        final data = jsonDecode(cachedJson) as Map<String, dynamic>;
        final fetchedAt = DateTime.tryParse(
          data['fetchedAt']?.toString() ?? '',
        );
        if (fetchedAt != null &&
            DateTime.now().difference(fetchedAt) < const Duration(days: 7)) {
          return data['license']?.toString() ?? project.licenseHint;
        }
      } catch (_) {}
    }
    try {
      final response = await _dio.get<dynamic>(
        'https://api.github.com/repos/$repo',
        options: Options(
          validateStatus: (status) => status != null && status < 500,
        ),
      );
      if (response.statusCode == 200 && response.data is Map) {
        final license = ((response.data as Map)['license'] as Map?)?['spdx_id']
            ?.toString();
        final usable = license == null || license == 'NOASSERTION'
            ? project.licenseHint
            : license;
        await preferences.setString(
          key,
          jsonEncode({
            'fetchedAt': DateTime.now().toIso8601String(),
            'license': usable,
          }),
        );
        return usable;
      }
    } catch (_) {}
    return project.licenseHint;
  }

  /// Discovers licensed projects from GitHub once per day. Search queries are
  /// deliberately limited and cached to respect GitHub's unauthenticated API limits.
  Future<List<ToolProject>> discoverOpenSourceProjects({
    bool force = false,
  }) async {
    final preferences = await SharedPreferences.getInstance();
    const key = 'github_discovery_v3';
    final raw = preferences.getString(key);
    if (raw != null) {
      try {
        final stored = jsonDecode(raw) as Map<String, dynamic>;
        final fetchedAt = DateTime.tryParse(
          stored['fetchedAt']?.toString() ?? '',
        );
        final cached = ((stored['items'] as List?) ?? const [])
            .whereType<Map>()
            .map((e) => _projectFromCache(Map<String, dynamic>.from(e)))
            .toList();
        if (!force &&
            fetchedAt != null &&
            DateTime.now().difference(fetchedAt) < _discoveryTtl)
          return cached;
        if (cached.isNotEmpty && !force) {
          // Keep existing results available if a fresh request fails; the refresh
          // below will replace them only after at least one successful query.
        }
      } catch (_) {}
    }

    const queries = <String, String>{
      'android': 'topic:android-security',
      'windows': 'topic:windows-security',
      'linux': 'topic:cybersecurity-tools',
      'ai': 'topic:machine-learning language:python',
      'dev': 'topic:developer-tools',
      'cloud': 'topic:cloud-security',
      'privacy': 'topic:privacy-tools',
    };
    final found = <String, ToolProject>{};
    var successfulQueries = 0;
    for (final entry in queries.entries) {
      try {
        final response = await _dio.get<dynamic>(
          'https://api.github.com/search/repositories',
          queryParameters: {
            'q': entry.value,
            'sort': 'stars',
            'order': 'desc',
            'per_page': 12,
          },
          options: Options(
            validateStatus: (status) => status != null && status < 500,
          ),
        );
        if (response.statusCode != 200 || response.data is! Map) continue;
        successfulQueries++;
        final items = ((response.data as Map)['items'] as List?) ?? const [];
        for (final value in items.whereType<Map>()) {
          final json = Map<String, dynamic>.from(value);
          final license = (json['license'] as Map?)?['spdx_id']?.toString();
          final fullName = json['full_name']?.toString() ?? '';
          if (fullName.isEmpty ||
              license == null ||
              license == 'NOASSERTION' ||
              json['archived'] == true ||
              json['fork'] == true)
            continue;
          final project = ToolProject.fromGitHubSearch(json, entry.key);
          found.putIfAbsent(fullName.toLowerCase(), () => project);
        }
      } catch (_) {
        // Continue to the remaining discovery queries.
      }
    }

    if (successfulQueries > 0) {
      final projects = found.values.toList();
      await preferences.setString(
        key,
        jsonEncode({
          'fetchedAt': DateTime.now().toIso8601String(),
          'items': projects.map(_projectToCache).toList(),
        }),
      );
      return projects;
    }
    if (raw != null) {
      try {
        final stored = jsonDecode(raw) as Map<String, dynamic>;
        return ((stored['items'] as List?) ?? const [])
            .whereType<Map>()
            .map((e) => _projectFromCache(Map<String, dynamic>.from(e)))
            .toList();
      } catch (_) {}
    }
    return const [];
  }

  Map<String, Object?> _projectToCache(ToolProject project) => {
    'id': project.id,
    'name': project.name,
    'description': project.descriptionEn,
    'repo': project.githubRepo,
    'sourceUrl': project.sourceUrl,
    'license': project.licenseHint,
    'platforms': project.platforms.toList(),
    'category': project.category,
  };

  ToolProject _projectFromCache(Map<String, dynamic> json) => ToolProject(
    id: json['id']?.toString() ?? '',
    name: json['name']?.toString() ?? '',
    descriptionAr: json['description']?.toString() ?? '',
    descriptionEn: json['description']?.toString() ?? '',
    category: json['category']?.toString() ?? 'Discovered',
    githubRepo: json['repo']?.toString(),
    sourceUrl: json['sourceUrl']?.toString() ?? '',
    platforms: ((json['platforms'] as List?) ?? const [])
        .map((e) => e.toString())
        .toSet(),
    licenseHint: json['license']?.toString(),
    discovered: true,
  );

  Future<String?> fdroidSuggestedVersion(String packageId) async {
    final preferences = await SharedPreferences.getInstance();
    final key = 'fdroid_version_$packageId';
    final stored = preferences.getString(key);
    if (stored != null) {
      try {
        final json = jsonDecode(stored) as Map<String, dynamic>;
        final saved = DateTime.tryParse(json['savedAt']?.toString() ?? '');
        if (saved != null &&
            DateTime.now().difference(saved) < const Duration(hours: 24))
          return json['version']?.toString();
      } catch (_) {}
    }
    try {
      final response = await _dio.get<dynamic>(
        'https://f-droid.org/api/v1/packages/$packageId',
        options: Options(
          validateStatus: (status) => status != null && status < 500,
        ),
      );
      if (response.statusCode != 200 || response.data is! Map) return null;
      final data = response.data as Map;
      final packages = data['packages'] as List?;
      final packageVersion =
          packages != null && packages.isNotEmpty && packages.last is Map
          ? (packages.last as Map)['versionName']?.toString()
          : null;
      final version = data['suggestedVersion']?.toString() ?? packageVersion;
      if (version != null)
        await preferences.setString(
          key,
          jsonEncode({
            'savedAt': DateTime.now().toIso8601String(),
            'version': version,
          }),
        );
      return version;
    } catch (_) {
      return null;
    }
  }

  void dispose() => _dio.close(force: true);
}
