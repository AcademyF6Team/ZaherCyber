enum UrlAuditSeverity { high, medium, low }

class UrlAuditFinding {
  const UrlAuditFinding({
    required this.severity,
    required this.titleAr,
    required this.titleEn,
    required this.detailAr,
    required this.detailEn,
  });

  final UrlAuditSeverity severity;
  final String titleAr;
  final String titleEn;
  final String detailAr;
  final String detailEn;
}

class UrlAuditResult {
  const UrlAuditResult({
    required this.input,
    required this.valid,
    required this.normalizedUrl,
    required this.host,
    required this.usesHttps,
    required this.findings,
    this.errorAr,
    this.errorEn,
  });

  final String input;
  final bool valid;
  final String? normalizedUrl;
  final String? host;
  final bool usesHttps;
  final List<UrlAuditFinding> findings;
  final String? errorAr;
  final String? errorEn;

  int get highCount => findings
      .where((finding) => finding.severity == UrlAuditSeverity.high)
      .length;

  int get mediumCount => findings
      .where((finding) => finding.severity == UrlAuditSeverity.medium)
      .length;

  int get lowCount => findings
      .where((finding) => finding.severity == UrlAuditSeverity.low)
      .length;
}

/// A deterministic, offline-only URL structure audit. This does not resolve DNS,
/// contact the website, inspect TLS, download content, or consult reputation feeds.
class UrlAuditService {
  static const _shorteners = <String>{
    'bit.ly',
    'tinyurl.com',
    't.co',
    'is.gd',
    'cutt.ly',
    'ow.ly',
    'buff.ly',
    'rb.gy',
    'lnkd.in',
  };

  static const _sensitiveWords = <String>{
    'login',
    'log-in',
    'signin',
    'sign-in',
    'verify',
    'verification',
    'password',
    'passwd',
    'wallet',
    'billing',
    'payment',
    'account',
    'secure',
    'confirm',
    'recover',
    'webscr',
  };

  static const _redirectParameters = <String>{
    'redirect',
    'redirect_uri',
    'redirect_url',
    'return',
    'returnto',
    'next',
    'continue',
    'dest',
    'destination',
    'target',
    'url',
  };

  UrlAuditResult analyze(String input) {
    final raw = input.trim();
    if (raw.isEmpty) {
      return _invalid(input, 'أدخل رابطاً لتحليله.', 'Enter a URL to analyze.');
    }
    if (raw.length > 4096) {
      return _invalid(
        input,
        'الرابط أطول من الحد المسموح للتحليل المحلي (4096 محرفاً).',
        'The URL exceeds the local analysis limit (4096 characters).',
      );
    }

    final hasExplicitScheme = RegExp(
      r'^[a-z][a-z0-9+.-]*://',
      caseSensitive: false,
    ).hasMatch(raw);
    final candidate = hasExplicitScheme ? raw : 'https://$raw';
    final uri = Uri.tryParse(candidate);
    if (uri == null ||
        !{'http', 'https'}.contains(uri.scheme.toLowerCase()) ||
        uri.host.isEmpty ||
        uri.host.contains(RegExp(r'\s')) ||
        uri.userInfo.isNotEmpty) {
      return _invalid(
        input,
        'تعذّر تحليل الرابط. استخدم نطاقاً صالحاً؛ لا تُقبل بيانات الدخول المضمنة في الرابط.',
        'Could not parse this URL. Use a valid host; embedded credentials are not accepted.',
      );
    }

    final host = uri.host.toLowerCase().replaceFirst(RegExp(r'\.$'), '');
    final findings = <UrlAuditFinding>[];
    final normalized = uri.replace(scheme: uri.scheme.toLowerCase()).toString();

    if (uri.scheme.toLowerCase() != 'https') {
      findings.add(
        const UrlAuditFinding(
          severity: UrlAuditSeverity.medium,
          titleAr: 'الاتصال يستخدم HTTP غير المشفر',
          titleEn: 'The URL uses unencrypted HTTP',
          detailAr:
              'يمكن أن يكون الاتصال عرضة للاعتراض أو التعديل. وجود HTTPS لا يثبت أن الموقع موثوق.',
          detailEn:
              'The connection may be exposed to interception or modification. HTTPS alone does not prove a site is trustworthy.',
        ),
      );
    }

    if (uri.hasPort &&
        !((uri.scheme == 'http' && uri.port == 80) ||
            (uri.scheme == 'https' && uri.port == 443))) {
      findings.add(
        UrlAuditFinding(
          severity: UrlAuditSeverity.medium,
          titleAr: 'المنفذ غير اعتيادي: ${uri.port}',
          titleEn: 'Unusual port: ${uri.port}',
          detailAr:
              'تحقق من سبب استخدام المنفذ قبل فتح الرابط. هذا الفحص لا يتصل به.',
          detailEn:
              'Verify why this port is used before opening the URL. This check does not connect to it.',
        ),
      );
    }

    if (_looksLikeIpAddress(host)) {
      findings.add(
        const UrlAuditFinding(
          severity: UrlAuditSeverity.medium,
          titleAr: 'المضيف عنوان IP مباشر',
          titleEn: 'The host is a direct IP address',
          detailAr:
              'العناوين المباشرة ليست ضارة بحد ذاتها، لكن يصعب التحقق من هوية الجهة وراءها.',
          detailEn:
              'Direct IP addresses are not inherently malicious, but the operator identity can be harder to verify.',
        ),
      );
    }

    if (host.split('.').any((label) => label.startsWith('xn--'))) {
      findings.add(
        const UrlAuditFinding(
          severity: UrlAuditSeverity.medium,
          titleAr: 'النطاق يحتوي صيغة IDN مرمّزة (Punycode)',
          titleEn: 'The host contains an encoded IDN (Punycode)',
          detailAr:
              'قد تخفي بعض الأحرف المتشابهة بصرياً اسم نطاق مختلفاً؛ اقرأ اسم المضيف حرفاً حرفاً.',
          detailEn:
              'Some visually similar characters can disguise a different domain. Inspect the hostname carefully.',
        ),
      );
    }

    final labels = host.split('.').where((label) => label.isNotEmpty).toList();
    if (labels.length >= 5) {
      findings.add(
        UrlAuditFinding(
          severity: UrlAuditSeverity.low,
          titleAr: 'النطاق متشعب (${labels.length} أجزاء)',
          titleEn: 'The hostname has many labels (${labels.length})',
          detailAr:
              'قد تُستخدم النطاقات الفرعية الطويلة لإخفاء النطاق الأساسي؛ تحقق من الجزء المسجل الفعلي.',
          detailEn:
              'Long subdomain chains can obscure the registered domain. Check the actual domain carefully.',
        ),
      );
    }

    if (_shorteners.contains(host)) {
      findings.add(
        const UrlAuditFinding(
          severity: UrlAuditSeverity.low,
          titleAr: 'خدمة اختصار روابط معروفة',
          titleEn: 'Known URL shortener',
          detailAr:
              'وجهة الرابط مخفية حتى فتحه أو توسيعه عبر أداة موثوقة. لا تفتحه إن لم تكن تتوقعه.',
          detailEn:
              'The destination is hidden until expanded with a trusted tool. Avoid it if unexpected.',
        ),
      );
    }

    final pathAndQuery = '${uri.path} ${uri.query}'.toLowerCase();
    final matchedWords = _sensitiveWords
        .where((word) => pathAndQuery.contains(word))
        .take(3)
        .toList();
    if (matchedWords.isNotEmpty) {
      findings.add(
        UrlAuditFinding(
          severity: UrlAuditSeverity.low,
          titleAr: 'كلمات حساسة في مسار الرابط',
          titleEn: 'Sensitive words in the URL path',
          detailAr:
              'ظهرت كلمات مثل ${matchedWords.join('، ')}. قد تكون طبيعية في مواقع شرعية أيضاً؛ افحص السياق.',
          detailEn:
              'Words such as ${matchedWords.join(', ')} appear. These can also occur on legitimate sites; check the context.',
        ),
      );
    }

    final redirectKeys = uri.queryParameters.keys
        .map((key) => key.toLowerCase())
        .where(_redirectParameters.contains)
        .toList();
    if (redirectKeys.isNotEmpty) {
      findings.add(
        UrlAuditFinding(
          severity: UrlAuditSeverity.low,
          titleAr: 'الرابط يتضمن معامل تحويل',
          titleEn: 'The URL contains a redirect parameter',
          detailAr:
              'قد ينقل معامل ${redirectKeys.first} المستخدم إلى مضيف آخر. افحص الوجهة قبل المتابعة.',
          detailEn:
              'The ${redirectKeys.first} parameter may send users to another host. Check the destination before continuing.',
        ),
      );
    }

    if (raw.length >= 180) {
      findings.add(
        UrlAuditFinding(
          severity: raw.length >= 300
              ? UrlAuditSeverity.medium
              : UrlAuditSeverity.low,
          titleAr: 'الرابط طويل بشكل ملحوظ (${raw.length} محرفاً)',
          titleEn: 'Unusually long URL (${raw.length} characters)',
          detailAr:
              'الطول وحده لا يثبت الضرر، لكنه قد يصعّب قراءة النطاق والوجهة.',
          detailEn:
              'Length alone is not proof of harm, but it can make the host and destination harder to inspect.',
        ),
      );
    }

    if (findings.isEmpty) {
      findings.add(
        const UrlAuditFinding(
          severity: UrlAuditSeverity.low,
          titleAr: 'لم تظهر مؤشرات تركيبية ضمن القواعد المحلية',
          titleEn: 'No structural indicators matched local rules',
          detailAr:
              'هذه نتيجة محدودة وليست حكماً بأن الرابط آمن أو معروف السمعة.',
          detailEn:
              'This is a limited result, not a verdict that the URL is safe or reputable.',
        ),
      );
    }

    return UrlAuditResult(
      input: input,
      valid: true,
      normalizedUrl: normalized,
      host: host,
      usesHttps: uri.scheme.toLowerCase() == 'https',
      findings: List.unmodifiable(findings),
    );
  }

  static bool _looksLikeIpAddress(String host) {
    final unbracketed = host.replaceAll(RegExp(r'^\[|\]$'), '');
    final ipv4 = RegExp(r'^\d{1,3}(?:\.\d{1,3}){3}$');
    return ipv4.hasMatch(unbracketed) || unbracketed.contains(':');
  }

  static UrlAuditResult _invalid(String input, String ar, String en) =>
      UrlAuditResult(
        input: input,
        valid: false,
        normalizedUrl: null,
        host: null,
        usesHttps: false,
        findings: const [],
        errorAr: ar,
        errorEn: en,
      );
}
