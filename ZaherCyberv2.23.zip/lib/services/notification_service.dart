import 'dart:convert';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../firebase_options.dart';

const AndroidNotificationChannel _notificationChannel = AndroidNotificationChannel(
  'zahercyber_general',
  'ZaherCyber notifications',
  description: 'General notifications from ZaherCyber.',
  importance: Importance.high,
);

final FlutterLocalNotificationsPlugin _localNotifications =
    FlutterLocalNotificationsPlugin();
void Function(RemoteMessage message)? _onMessageOpenedCallback;

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await _initializeLocalNotifications();

  // Notification-payload messages are displayed by Android automatically in
  // the background. Data-only messages need a local notification instead.
  if (message.notification == null) {
    await _showLocalNotification(message);
  }
}

Future<void> _initializeLocalNotifications() async {
  const settings = InitializationSettings(
    android: AndroidInitializationSettings('@mipmap/ic_launcher'),
  );
  await _localNotifications.initialize(
    settings,
    onDidReceiveNotificationResponse: (response) {
      final payload = response.payload;
      if (payload == null || _onMessageOpenedCallback == null) return;
      try {
        final data = jsonDecode(payload);
        if (data is Map) {
          _onMessageOpenedCallback!(RemoteMessage(
            data: Map<String, String>.from(data),
          ));
        }
      } catch (_) {
        // Ignore malformed optional notification data.
      }
    },
  );
  await _localNotifications
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(_notificationChannel);
}

Future<void> _showLocalNotification(RemoteMessage message) async {
  final title = message.notification?.title ?? message.data['title'] ?? 'ZaherCyber';
  final body = message.notification?.body ?? message.data['body'] ?? '';
  if (body.toString().trim().isEmpty) return;

  await _localNotifications.show(
    message.hashCode,
    title.toString(),
    body.toString(),
    const NotificationDetails(
      android: AndroidNotificationDetails(
        'zahercyber_general',
        'ZaherCyber notifications',
        channelDescription: 'General notifications from ZaherCyber.',
        importance: Importance.high,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
      ),
    ),
    payload: jsonEncode(message.data),
  );
}

class NotificationService {
  NotificationService._();

  static bool _initialized = false;

  static Future<void> initialize({
    required void Function(RemoteMessage message) onMessageOpened,
  }) async {
    if (_initialized) return;
    _initialized = true;
    _onMessageOpenedCallback = onMessageOpened;

    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
    await _initializeLocalNotifications();

    FirebaseMessaging.onMessage.listen(_showLocalNotification);
    FirebaseMessaging.onMessageOpenedApp.listen(onMessageOpened);
    final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) onMessageOpened(initialMessage);
  }

  static Future<void> requestPermission(BuildContext context) async {
    final messaging = FirebaseMessaging.instance;
    final current = await messaging.getNotificationSettings();
    if (current.authorizationStatus != AuthorizationStatus.notDetermined) return;
    final preferences = await SharedPreferences.getInstance();
    if (preferences.getBool('notification_prompt_shown_v1') ?? false) return;
    if (!context.mounted) return;

    await preferences.setBool('notification_prompt_shown_v1', true);

    final shouldAsk = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('صلاحيات ZaherCyber'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: const [
              Text(
                'نطلب الصلاحية الضرورية فقط، ويمكنك رفضها دون تعطيل التطبيق.',
                style: TextStyle(height: 1.35),
              ),
              SizedBox(height: 14),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.notifications_active_outlined),
                title: Text('الإشعارات'),
                subtitle: Text(
                  'لتنبيهات تحديثات التطبيق، الأخبار الأمنية، تحديثات CVE، والدروس الجديدة. لا نرسل بياناتك الخاصة داخل الإشعار.',
                ),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.system_update_alt_outlined),
                title: Text('تثبيت تحديث APK'),
                subtitle: Text(
                  'لا يُطلب الآن. يظهر طلب Android الخاص فقط عندما تختار يدويًا تنزيل وتثبيت تحديث من داخل التطبيق.',
                ),
              ),
              SizedBox(height: 4),
              Text(
                'لا يطلب التطبيق الوصول إلى جهات الاتصال أو الميكروفون أو الكاميرا أو الموقع.',
                style: TextStyle(fontSize: 12, height: 1.35),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('لاحقًا'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('متابعة'),
          ),
        ],
      ),
    );
    if (shouldAsk != true) return;

    await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );
  }
}
