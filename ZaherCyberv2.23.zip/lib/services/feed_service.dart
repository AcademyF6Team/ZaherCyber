import 'dart:async';
import 'dart:convert';
import 'dart:io' show HttpDate, HttpException;

import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:xml/xml.dart';

import '../data/sources.dart';
import '../models/article.dart';

class FeedFetchException implements Exception {
  const FeedFetchException(this.statusCode, this.message);
  final int statusCode;
  final String message;
  @override
  String toString() => message;
}

class FeedSourceFailure {
  const FeedSourceFailure({
    required this.source,
    required this.checkedAt,
    required this.failureClass,
    required this.reason,
    this.statusCode,
  });

  final NewsSource source;
  final DateTime checkedAt;
  final String failureClass;
  final String reason;
  final int? statusCode;

  /// Avoid automatically hiding feeds blocked by authentication or rate limits.
  bool get eligibleForQuarantine =>
      statusCode == 404 ||
      statusCode == 410 ||
      (statusCode != null && statusCode! >= 500 && statusCode! <= 599) ||
      failureClass == 'invalid' ||
      failureClass == 'transport';
}

class FeedService {
  FeedService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;
  static const int maxConcurrentFeeds = 24;
  static const String sourceCachePrefix = 'feed_source_cache_v2_';
  int lastSuccessfulSources = 0;
  int lastFailedSources = 0;
  DateTime? lastFetchedAt;
  Set<String> lastSuccessfulUrls = {};
  List<FeedSourceFailure> lastSourceFailures = [];
  bool lastCycleWasGlobalConnectivityFailure = false;
  int lastDuplicateCount = 0;

  Future<List<Article>> fetchAll({
    Set<String> excludedUrls = const {},
    List<NewsSource> sources = newsSources,
  }) async {
    final selectedSources = sources
        .where((source) => !excludedUrls.contains(source.url))
        .toList();
    final bySource = List<List<Article>>.filled(
      selectedSources.length,
      const <Article>[],
      growable: false,
    );
    final failed = List<bool>.filled(
      selectedSources.length,
      false,
      growable: false,
    );
    final sourceFailures = List<FeedSourceFailure?>.filled(
      selectedSources.length,
      null,
      growable: false,
    );
    var cursor = 0;

    Future<void> worker() async {
      while (true) {
        final index = cursor++;
        if (index >= selectedSources.length) return;
        final source = selectedSources[index];
        try {
          bySource[index] = await _fetch(source);
        } catch (error) {
          failed[index] = true;
          final failureClass = error is FeedFetchException
              ? 'http'
              : error is FormatException
              ? 'invalid'
              : 'transport';
          final status = error is FeedFetchException ? error.statusCode : null;
          sourceFailures[index] = FeedSourceFailure(
            source: source,
            checkedAt: DateTime.now(),
            failureClass: failureClass,
            reason: error.toString(),
            statusCode: status,
          );
          // Preserve this publisher's last usable items while its endpoint is down.
          bySource[index] = await _readCachedArticles(source);
        }
      }
    }

    final workerCount = selectedSources.length < maxConcurrentFeeds
        ? selectedSources.length
        : maxConcurrentFeeds;
    await Future.wait(
      List.generate(workerCount, (_) => worker()),
      eagerError: false,
    );
    lastSuccessfulSources =
        selectedSources.length - failed.where((value) => value).length;
    lastFailedSources = failed.where((value) => value).length;
    lastSuccessfulUrls = {
      for (var i = 0; i < selectedSources.length; i++)
        if (!failed[i]) selectedSources[i].url,
    };
    lastSourceFailures = sourceFailures.whereType<FeedSourceFailure>().toList();
    lastCycleWasGlobalConnectivityFailure =
        selectedSources.isNotEmpty &&
        lastFailedSources == selectedSources.length &&
        lastSourceFailures.every(
          (failure) =>
              failure.failureClass == 'transport' ||
              failure.statusCode == null ||
              const [401, 403, 429].contains(failure.statusCode),
        );
    lastFetchedAt = DateTime.now();

    final articles = bySource.expand((items) => items).toList();
    final byLink = <String, Article>{};
    for (final article in articles) {
      byLink.putIfAbsent(article.link, () => article);
    }
    final sorted = byLink.values.toList()
      ..sort(
        (a, b) => (b.publishedAt ?? DateTime(2000)).compareTo(
          a.publishedAt ?? DateTime(2000),
        ),
      );
    final seenStories = <String>{};
    final deduplicated = <Article>[];
    for (final article in sorted) {
      final normalizedTitle = article.title
          .toLowerCase()
          .replaceAll(RegExp(r'[^a-z0-9\u0600-\u06ff]+'), ' ')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      final date = article.publishedAt;
      final day = date == null
          ? 'unknown'
          : '${date.year}-${date.month}-${date.day}';
      final storyKey = '$day|$normalizedTitle';
      if (normalizedTitle.isNotEmpty && !seenStories.add(storyKey)) continue;
      deduplicated.add(article);
    }
    lastDuplicateCount = articles.length - deduplicated.length;
    return deduplicated;
  }

  Future<List<Article>> _readCachedArticles(NewsSource source) async {
    final preferences = await SharedPreferences.getInstance();
    final cacheKey =
        '$sourceCachePrefix${sha256.convert(utf8.encode(source.url))}';
    final raw = preferences.getString(cacheKey);
    if (raw == null) return const [];
    try {
      final saved = jsonDecode(raw) as Map<String, dynamic>;
      return ((saved['articles'] as List?) ?? const [])
          .whereType<Map>()
          .map((row) => Article.fromJson(Map<String, dynamic>.from(row)))
          .toList();
    } catch (_) {
      return const [];
    }
  }

  Future<List<Article>> _fetch(NewsSource source) async {
    final preferences = await SharedPreferences.getInstance();
    final cacheKey =
        '$sourceCachePrefix${sha256.convert(utf8.encode(source.url))}';
    String? etag;
    String? lastModified;
    List<Article> cached = const [];
    final rawCache = preferences.getString(cacheKey);
    if (rawCache != null) {
      try {
        final saved = jsonDecode(rawCache) as Map<String, dynamic>;
        etag = saved['etag']?.toString();
        lastModified = saved['lastModified']?.toString();
        cached = ((saved['articles'] as List?) ?? const [])
            .whereType<Map>()
            .map((row) => Article.fromJson(Map<String, dynamic>.from(row)))
            .toList();
      } catch (_) {
        cached = const [];
      }
    }

    const baseHeaders = {
      'User-Agent':
          'ZaherCyber/1.0 (independent RSS reader; contact via project page)',
      'Accept': 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*',
    };
    final headers = <String, String>{...baseHeaders};
    if (etag != null && etag.isNotEmpty) headers['If-None-Match'] = etag;
    if (lastModified != null && lastModified.isNotEmpty) {
      headers['If-Modified-Since'] = lastModified;
    }

    try {
      var response = await _client
          .get(Uri.parse(source.url), headers: headers)
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 304) {
        if (cached.isNotEmpty) return cached;
        // A server may retain a validator after the local body was cleared.
        response = await _client
            .get(Uri.parse(source.url), headers: baseHeaders)
            .timeout(const Duration(seconds: 8));
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw FeedFetchException(
          response.statusCode,
          'HTTP ${response.statusCode}',
        );
      }
      final document = XmlDocument.parse(response.body);
      final nodes = [
        ...document.findAllElements('item'),
        ...document.findAllElements('entry'),
      ];
      final parsed = nodes
          .take(25)
          .map((item) {
            String text(String name) =>
                item.findElements(name).firstOrNull?.innerText.trim() ?? '';
            final linkNode = item.findElements('link').firstOrNull;
            final link =
                (linkNode?.getAttribute('href') ?? linkNode?.innerText ?? '')
                    .trim();
            final title = _clean(text('title'));
            final rawDate = text('pubDate').isNotEmpty
                ? text('pubDate')
                : (text('published').isNotEmpty
                      ? text('published')
                      : text('updated'));
            final description = text('description');
            final atomSummary = text('summary');
            final encodedContent =
                item
                    .findAllElements(
                      'encoded',
                      namespace: 'http://purl.org/rss/1.0/modules/content/',
                    )
                    .firstOrNull
                    ?.innerText
                    .trim() ??
                '';
            final atomContent =
                item.findAllElements('content').firstOrNull?.innerText.trim() ??
                '';
            final rawSummary = [
              description,
              atomSummary,
              encodedContent,
              atomContent,
            ].firstWhere((value) => value.isNotEmpty, orElse: () => '');
            final summary = _clean(rawSummary);
            return Article(
              title: title.isEmpty ? 'Untitled' : title,
              link: link,
              summary: summary.length > 1200
                  ? '${summary.substring(0, 1200)}…'
                  : summary,
              source: source.name,
              category: source.category,
              language: source.language,
              publishedAt: _parseDate(rawDate),
            );
          })
          .where(
            (article) =>
                article.link.startsWith('https://') && article.title.isNotEmpty,
          )
          .toList();
      if (parsed.isEmpty) throw const FormatException('No RSS entries found.');
      try {
        await preferences.setString(
          cacheKey,
          jsonEncode({
            'etag': response.headers['etag'] ?? etag,
            'lastModified': response.headers['last-modified'] ?? lastModified,
            'articles': parsed.map((article) {
              final json = article.toJson();
              final summary = json['summary']?.toString() ?? '';
              if (summary.length > 450) {
                json['summary'] = '${summary.substring(0, 450)}…';
              }
              return json;
            }).toList(),
          }),
        );
      } catch (_) {
        // A cache-write failure must not discard articles just fetched online.
      }
      return parsed;
    } on FeedFetchException {
      rethrow;
    } on HttpException {
      rethrow;
    } catch (_) {
      rethrow;
    }
  }

  String _clean(String value) => value
      .replaceAll(
        RegExp(r'<script\b[^>]*>[\s\S]*?</script>', caseSensitive: false),
        ' ',
      )
      .replaceAll(
        RegExp(r'<style\b[^>]*>[\s\S]*?</style>', caseSensitive: false),
        ' ',
      )
      .replaceAll(RegExp('<[^>]*>'), ' ')
      .replaceAll('&amp;', '&')
      .replaceAll('&nbsp;', ' ')
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'")
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  DateTime? _parseDate(String value) {
    final parsed = DateTime.tryParse(value);
    if (parsed != null) return parsed;
    try {
      return HttpDate.parse(value);
    } catch (_) {
      return null;
    }
  }

  void dispose() => _client.close();
}

extension<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
