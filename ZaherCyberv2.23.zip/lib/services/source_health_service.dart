import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'feed_service.dart';

class FeedSourceHealthRecord {
  const FeedSourceHealthRecord({
    required this.url,
    required this.firstFailureAt,
    required this.lastFailureAt,
    required this.consecutiveFailures,
    this.lastStatusCode,
    this.quarantinedAt,
    this.lastProbeAt,
  });

  final String url;
  final DateTime firstFailureAt;
  final DateTime lastFailureAt;
  final int consecutiveFailures;
  final int? lastStatusCode;
  final DateTime? quarantinedAt;
  final DateTime? lastProbeAt;

  bool get isQuarantined => quarantinedAt != null;

  Map<String, Object?> toJson() => {
    'firstFailureAt': firstFailureAt.toUtc().toIso8601String(),
    'lastFailureAt': lastFailureAt.toUtc().toIso8601String(),
    'consecutiveFailures': consecutiveFailures,
    'lastStatusCode': lastStatusCode,
    'quarantinedAt': quarantinedAt?.toUtc().toIso8601String(),
    'lastProbeAt': lastProbeAt?.toUtc().toIso8601String(),
  };

  factory FeedSourceHealthRecord.fromJson(
    String url,
    Map<String, dynamic> json,
  ) {
    final first = DateTime.tryParse(json['firstFailureAt']?.toString() ?? '');
    final last = DateTime.tryParse(json['lastFailureAt']?.toString() ?? '');
    if (first == null || last == null) {
      throw const FormatException('Invalid source health record.');
    }
    return FeedSourceHealthRecord(
      url: url,
      firstFailureAt: first,
      lastFailureAt: last,
      consecutiveFailures:
          int.tryParse(json['consecutiveFailures']?.toString() ?? '') ?? 1,
      lastStatusCode: int.tryParse(json['lastStatusCode']?.toString() ?? ''),
      quarantinedAt: DateTime.tryParse(json['quarantinedAt']?.toString() ?? ''),
      lastProbeAt: DateTime.tryParse(json['lastProbeAt']?.toString() ?? ''),
    );
  }

  FeedSourceHealthRecord copyWith({
    DateTime? firstFailureAt,
    DateTime? lastFailureAt,
    int? consecutiveFailures,
    int? lastStatusCode,
    DateTime? quarantinedAt,
    DateTime? lastProbeAt,
  }) => FeedSourceHealthRecord(
    url: url,
    firstFailureAt: firstFailureAt ?? this.firstFailureAt,
    lastFailureAt: lastFailureAt ?? this.lastFailureAt,
    consecutiveFailures: consecutiveFailures ?? this.consecutiveFailures,
    lastStatusCode: lastStatusCode ?? this.lastStatusCode,
    quarantinedAt: quarantinedAt ?? this.quarantinedAt,
    lastProbeAt: lastProbeAt ?? this.lastProbeAt,
  );
}

/// On-device feed health tracking. It never deletes a configured source.
class FeedSourceHealthService {
  FeedSourceHealthService(this.storageKey);

  final String storageKey;
  static const quarantineAfter = Duration(hours: 48);
  static const probeInterval = Duration(hours: 24);
  static const minimumFailures = 3;

  final Map<String, FeedSourceHealthRecord> _records = {};
  List<FeedSourceHealthRecord> get records =>
      List.unmodifiable(_records.values);
  Set<String> get quarantinedUrls => _records.values
      .where((record) => record.isQuarantined)
      .map((record) => record.url)
      .toSet();

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(storageKey);
    _records.clear();
    if (raw == null) return;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map) return;
      for (final entry in decoded.entries) {
        if (entry.value is Map) {
          try {
            _records[entry.key.toString()] = FeedSourceHealthRecord.fromJson(
              entry.key.toString(),
              Map<String, dynamic>.from(entry.value as Map),
            );
          } catch (_) {
            // Ignore a single corrupt row and retain other source states.
          }
        }
      }
    } catch (_) {
      _records.clear();
    }
  }

  Set<String> probesDueFor(Iterable<String> candidateUrls, {DateTime? now}) {
    final current = now ?? DateTime.now();
    return candidateUrls.where((url) {
      final record = _records[url];
      if (record == null || !record.isQuarantined) return false;
      final reference = record.lastProbeAt ?? record.quarantinedAt!;
      return current.difference(reference) >= probeInterval;
    }).toSet();
  }

  Future<void> markProbesStarted(Set<String> urls, {DateTime? now}) async {
    if (urls.isEmpty) return;
    final current = now ?? DateTime.now();
    for (final url in urls) {
      final record = _records[url];
      if (record != null && record.isQuarantined) {
        _records[url] = record.copyWith(lastProbeAt: current);
      }
    }
    await _save();
  }

  Future<void> recordCycle({
    required Set<String> successfulUrls,
    required List<FeedSourceFailure> failures,
    required bool globalConnectivityFailure,
    DateTime? now,
  }) async {
    if (globalConnectivityFailure) return;
    final current = now ?? DateTime.now();
    var changed = false;
    for (final url in successfulUrls) {
      changed = _records.remove(url) != null || changed;
    }
    for (final failure in failures) {
      if (!failure.eligibleForQuarantine) {
        changed = _records.remove(failure.source.url) != null || changed;
        continue;
      }
      final old = _records[failure.source.url];
      final first = old?.firstFailureAt ?? current;
      final count = (old?.consecutiveFailures ?? 0) + 1;
      final shouldQuarantine =
          current.difference(first) >= quarantineAfter &&
          count >= minimumFailures;
      _records[failure.source.url] = FeedSourceHealthRecord(
        url: failure.source.url,
        firstFailureAt: first,
        lastFailureAt: current,
        consecutiveFailures: count,
        lastStatusCode: failure.statusCode,
        quarantinedAt:
            old?.quarantinedAt ?? (shouldQuarantine ? current : null),
        lastProbeAt: old?.lastProbeAt,
      );
      changed = true;
    }
    if (changed) await _save();
  }

  Future<void> restore(String url) async {
    if (_records.remove(url) != null) await _save();
  }

  Future<void> clear() async {
    _records.clear();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(storageKey);
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      storageKey,
      jsonEncode({
        for (final entry in _records.entries) entry.key: entry.value.toJson(),
      }),
    );
  }
}
