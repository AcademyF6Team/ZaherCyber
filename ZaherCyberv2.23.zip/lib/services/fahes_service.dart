import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'url_audit_service.dart';

enum FahesVerdict { listed, unverified, notListed, keyRequired, unavailable }

class FahesSourceResult {
  const FahesSourceResult({
    required this.source,
    required this.verdict,
    this.detail,
    this.recordCount,
  });

  final String source;
  final FahesVerdict verdict;
  final String? detail;
  final int? recordCount;
}

class FahesCheckResult {
  const FahesCheckResult({required this.localAudit, required this.sources});

  final UrlAuditResult localAudit;
  final List<FahesSourceResult> sources;
}

/// Checks community threat-intelligence databases only after explicit consent.
/// The caller provides individual Auth-Keys; this service never persists or logs them.
class FahesService {
  FahesService({http.Client? client}) : _client = client ?? http.Client();

  static final _phishTankEndpoint = Uri.https(
    'checkurl.phishtank.com',
    '/checkurl/',
  );
  static final _urlhausEndpoint = Uri.https('urlhaus-api.abuse.ch', '/v1/url/');
  static final _threatFoxEndpoint = Uri.https(
    'threatfox-api.abuse.ch',
    '/api/v1/',
  );

  final http.Client _client;

  Future<FahesCheckResult> checkUrl({
    required String url,
    required UrlAuditResult localAudit,
    String? urlhausAuthKey,
    String? threatFoxAuthKey,
  }) async {
    if (!localAudit.valid || localAudit.normalizedUrl == null) {
      throw ArgumentError.value(url, 'url', 'A valid HTTP(S) URL is required.');
    }
    final normalizedUrl = localAudit.normalizedUrl!;
    final host = localAudit.host!;
    final results = await Future.wait([
      _checkPhishTank(normalizedUrl),
      _checkUrlhaus(normalizedUrl, urlhausAuthKey?.trim() ?? ''),
      _checkThreatFox(normalizedUrl, host, threatFoxAuthKey?.trim() ?? ''),
    ]);
    return FahesCheckResult(
      localAudit: localAudit,
      sources: List.unmodifiable(results),
    );
  }

  Future<FahesSourceResult> _checkPhishTank(String url) async {
    try {
      final response = await _client
          .post(
            _phishTankEndpoint,
            headers: {
              'accept': 'application/json',
              'user-agent': 'ZaherCyber-FAHES/2.12',
            },
            body: {'url': base64Encode(utf8.encode(url)), 'format': 'json'},
          )
          .timeout(const Duration(seconds: 20));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        return const FahesSourceResult(
          source: 'PhishTank',
          verdict: FahesVerdict.unavailable,
          detail: 'PhishTank did not return a successful response.',
        );
      }
      final body = _decode(response.body);
      final rawResults = body['results'];
      final record = rawResults is Map
          ? Map<String, dynamic>.from(rawResults)
          : <String, dynamic>{};
      if (_asBool(record['in_database'])) {
        final verified = _asBool(record['verified']);
        final active = _asBool(record['valid']);
        return FahesSourceResult(
          source: 'PhishTank',
          verdict: verified && active
              ? FahesVerdict.listed
              : FahesVerdict.unverified,
          detail: verified && active
              ? 'The URL is present and verified as an active phish report.'
              : 'The URL appears in the database, but its report is not confirmed active.',
          recordCount: 1,
        );
      }
      if (record.isEmpty) {
        return const FahesSourceResult(
          source: 'PhishTank',
          verdict: FahesVerdict.unavailable,
          detail: 'PhishTank returned an unrecognized response.',
        );
      }
      return const FahesSourceResult(
        source: 'PhishTank',
        verdict: FahesVerdict.notListed,
        detail: 'No matching phishing record was returned.',
      );
    } on TimeoutException {
      return const FahesSourceResult(
        source: 'PhishTank',
        verdict: FahesVerdict.unavailable,
        detail: 'PhishTank request timed out.',
      );
    } catch (_) {
      return const FahesSourceResult(
        source: 'PhishTank',
        verdict: FahesVerdict.unavailable,
        detail: 'PhishTank could not be checked.',
      );
    }
  }

  Future<FahesSourceResult> _checkUrlhaus(String url, String authKey) async {
    if (authKey.isEmpty) {
      return const FahesSourceResult(
        source: 'URLhaus',
        verdict: FahesVerdict.keyRequired,
        detail: 'A free abuse.ch Auth-Key is required for this source.',
      );
    }
    try {
      final response = await _client
          .post(
            _urlhausEndpoint,
            headers: {'accept': 'application/json', 'Auth-Key': authKey},
            body: {'url': url},
          )
          .timeout(const Duration(seconds: 20));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        return const FahesSourceResult(
          source: 'URLhaus',
          verdict: FahesVerdict.unavailable,
          detail: 'URLhaus rejected the request or is temporarily unavailable.',
        );
      }
      final body = _decode(response.body);
      switch (body['query_status']?.toString()) {
        case 'ok':
          final status = body['url_status']?.toString() ?? 'unknown';
          final threat = body['threat']?.toString() ?? 'malware URL';
          return FahesSourceResult(
            source: 'URLhaus',
            verdict: FahesVerdict.listed,
            detail: 'Listed as $threat; URL status: $status.',
            recordCount: 1,
          );
        case 'no_results':
          return const FahesSourceResult(
            source: 'URLhaus',
            verdict: FahesVerdict.notListed,
            detail: 'No matching malware-distribution URL was returned.',
          );
        default:
          return const FahesSourceResult(
            source: 'URLhaus',
            verdict: FahesVerdict.unavailable,
            detail: 'URLhaus returned an unrecognized query status.',
          );
      }
    } on TimeoutException {
      return const FahesSourceResult(
        source: 'URLhaus',
        verdict: FahesVerdict.unavailable,
        detail: 'URLhaus request timed out.',
      );
    } catch (_) {
      return const FahesSourceResult(
        source: 'URLhaus',
        verdict: FahesVerdict.unavailable,
        detail: 'URLhaus could not be checked.',
      );
    }
  }

  Future<FahesSourceResult> _checkThreatFox(
    String url,
    String host,
    String authKey,
  ) async {
    if (authKey.isEmpty) {
      return const FahesSourceResult(
        source: 'ThreatFox',
        verdict: FahesVerdict.keyRequired,
        detail: 'A free abuse.ch Auth-Key is required for this source.',
      );
    }
    try {
      var body = await _queryThreatFox(url, authKey);
      var data = body['data'];
      var records = data is List ? data : const [];
      if (records.isEmpty && host.toLowerCase() != url.toLowerCase()) {
        body = await _queryThreatFox(host, authKey);
        data = body['data'];
        records = data is List ? data : const [];
      }
      if (records.isNotEmpty) {
        final details = records
            .whereType<Map>()
            .take(3)
            .map((item) {
              final malware = item['malware_printable'] ?? item['malware'];
              final kind = item['ioc_type_desc'] ?? item['ioc_type'];
              final confidence = item['confidence_level'];
              return [
                if (malware != null) 'Malware: $malware',
                if (kind != null) 'Indicator: $kind',
                if (confidence != null) 'Confidence: $confidence%',
              ].join('; ');
            })
            .where((item) => item.isNotEmpty)
            .toList();
        return FahesSourceResult(
          source: 'ThreatFox',
          verdict: FahesVerdict.listed,
          detail: details.isEmpty
              ? 'Matching indicator found.'
              : details.join('\n'),
          recordCount: records.length,
        );
      }
      if (body['query_status']?.toString() == 'ok' ||
          body['query_status']?.toString() == 'no_result') {
        return const FahesSourceResult(
          source: 'ThreatFox',
          verdict: FahesVerdict.notListed,
          detail: 'No matching active indicator was returned.',
        );
      }
      return const FahesSourceResult(
        source: 'ThreatFox',
        verdict: FahesVerdict.unavailable,
        detail: 'ThreatFox returned an unrecognized query status.',
      );
    } on TimeoutException {
      return const FahesSourceResult(
        source: 'ThreatFox',
        verdict: FahesVerdict.unavailable,
        detail: 'ThreatFox request timed out.',
      );
    } catch (_) {
      return const FahesSourceResult(
        source: 'ThreatFox',
        verdict: FahesVerdict.unavailable,
        detail: 'ThreatFox could not be checked.',
      );
    }
  }

  Future<Map<String, dynamic>> _queryThreatFox(
    String searchTerm,
    String authKey,
  ) async {
    final response = await _client
        .post(
          _threatFoxEndpoint,
          headers: {'accept': 'application/json', 'Auth-Key': authKey},
          body: {
            'query': 'search_ioc',
            'search_term': searchTerm,
            'exact_match': 'true',
          },
        )
        .timeout(const Duration(seconds: 20));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw const FormatException('ThreatFox returned an unsuccessful status.');
    }
    return _decode(response.body);
  }

  static Map<String, dynamic> _decode(String text) {
    final value = jsonDecode(text);
    if (value is Map) return Map<String, dynamic>.from(value);
    throw const FormatException('Expected a JSON object.');
  }

  static bool _asBool(Object? value) {
    if (value == true || value == 1) return true;
    final normalized = value?.toString().toLowerCase();
    return normalized == 'true' || normalized == '1' || normalized == 'y';
  }

  void dispose() => _client.close();
}
