import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/learning_content.dart';

class LearningProgress {
  final Set<String> completedLessons;
  final Map<String, int> quizBestScores;
  final Map<String, int> flashcardRatings;
  final String updatedAt;

  const LearningProgress({this.completedLessons = const {}, this.quizBestScores = const {}, this.flashcardRatings = const {}, this.updatedAt = ''});

  LearningProgress copyWith({Set<String>? completedLessons, Map<String, int>? quizBestScores, Map<String, int>? flashcardRatings}) => LearningProgress(
    completedLessons: completedLessons ?? this.completedLessons,
    quizBestScores: quizBestScores ?? this.quizBestScores,
    flashcardRatings: flashcardRatings ?? this.flashcardRatings,
    updatedAt: DateTime.now().toUtc().toIso8601String(),
  );

  Map<String, Object?> toJson() => {
    'completedLessons': completedLessons.toList()..sort(),
    'quizBestScores': quizBestScores,
    'flashcardRatings': flashcardRatings,
    'updatedAt': updatedAt,
  };

  factory LearningProgress.fromJson(Map<String, dynamic> json) => LearningProgress(
    completedLessons: ((json['completedLessons'] as List?) ?? const []).map((e) => e.toString()).toSet(),
    quizBestScores: ((json['quizBestScores'] as Map?) ?? const {}).map((key, value) => MapEntry(key.toString(), int.tryParse(value.toString()) ?? 0)),
    flashcardRatings: ((json['flashcardRatings'] as Map?) ?? const {}).map((key, value) => MapEntry(key.toString(), int.tryParse(value.toString()) ?? 0)),
    updatedAt: json['updatedAt']?.toString() ?? '',
  );
}

class LearningProgressService {
  static const _key = 'learning_progress_v2';
  static const _schema = 2;
  LearningProgress _progress = const LearningProgress();
  LearningProgress get progress => _progress;

  Future<LearningProgress> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw != null) {
      try {
        _progress = LearningProgress.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
        return _progress;
      } catch (_) {}
    }
    // Migration is intentionally additive: old bookmarks/settings remain untouched.
    final legacyLessons = prefs.getStringList('learning_completed_v1') ?? const <String>[];
    _progress = LearningProgress(completedLessons: legacyLessons.toSet());
    await _save();
    return _progress;
  }

  Future<LearningProgress> completeLesson(String id) async {
    final lessons = {..._progress.completedLessons, id};
    _progress = _progress.copyWith(completedLessons: lessons);
    await _save();
    return _progress;
  }

  Future<LearningProgress> recordQuiz(String pathId, int score) async {
    final scores = {..._progress.quizBestScores};
    if (score > (scores[pathId] ?? -1)) scores[pathId] = score;
    _progress = _progress.copyWith(quizBestScores: scores);
    await _save();
    return _progress;
  }

  Future<LearningProgress> rateCard(String id, int rating) async {
    final ratings = {..._progress.flashcardRatings, id: rating.clamp(0, 2).toInt()};
    _progress = _progress.copyWith(flashcardRatings: ratings);
    await _save();
    return _progress;
  }

  int pathCompleted(LearningPath path) => path.lessonIds.where(_progress.completedLessons.contains).length;

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(_progress.toJson()));
  }

  Future<String> exportJson() async {
    await _save();
    final payload = {
      'app': 'ZaherCyber',
      'schema': _schema,
      'exportedAt': DateTime.now().toUtc().toIso8601String(),
      'learning': _progress.toJson(),
    };
    return jsonEncode(payload);
  }

  Future<bool> importJson(String raw) async {
    final decoded = jsonDecode(raw);
    if (decoded is! Map) throw const FormatException('Invalid learning backup.');
    final schema = int.tryParse(decoded['schema']?.toString() ?? '') ?? 0;
    if (schema < 1 || decoded['learning'] is! Map) throw const FormatException('Unsupported learning backup.');
    final incoming = LearningProgress.fromJson(Map<String, dynamic>.from(decoded['learning'] as Map));
    // Merge instead of replacing, so an import can never erase current progress.
    _progress = LearningProgress(
      completedLessons: {..._progress.completedLessons, ...incoming.completedLessons},
      quizBestScores: {..._progress.quizBestScores}..addAll(incoming.quizBestScores.map((key, value) => MapEntry(key, value > (_progress.quizBestScores[key] ?? -1) ? value : (_progress.quizBestScores[key] ?? value)))),
      flashcardRatings: {..._progress.flashcardRatings}..addAll(incoming.flashcardRatings),
      updatedAt: DateTime.now().toUtc().toIso8601String(),
    );
    await _save();
    return true;
  }

  Future<File> writeLocalBackup() async {
    final directory = await getApplicationDocumentsDirectory();
    final file = File('${directory.path}/zahercyber-learning-backup.json');
    await file.writeAsString(await exportJson(), flush: true);
    return file;
  }
}
