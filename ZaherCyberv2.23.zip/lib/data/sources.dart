class NewsSource {
  final String name;
  final String url;
  final String category;
  final String language;
  const NewsSource(this.name, this.url, this.category, this.language);
}

/// Publisher RSS/Atom feeds plus live Arabic Google News search feeds.
/// A feed can be disabled by the user when its publisher temporarily blocks access.
const newsSources = <NewsSource>[
  NewsSource(
    'The Hacker News',
    'https://feeds.feedburner.com/TheHackersNews',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'Krebs on Security',
    'https://krebsonsecurity.com/feed/',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'BleepingComputer',
    'https://www.bleepingcomputer.com/feed/',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'Dark Reading',
    'https://www.darkreading.com/rss.xml',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'SecurityWeek',
    'https://www.securityweek.com/feed/',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'Help Net Security',
    'https://www.helpnetsecurity.com/feed/',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'CyberScoop',
    'https://cyberscoop.com/feed/',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'The Record',
    'https://therecord.media/feed',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'WeLiveSecurity',
    'https://www.welivesecurity.com/en/rss/feed/',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'Malwarebytes Labs',
    'https://www.malwarebytes.com/blog/feed/index.xml',
    'Malware',
    'EN',
  ),
  NewsSource(
    'SANS Internet Storm Center',
    'https://isc.sans.edu/rssfeed.xml',
    'Threat Intelligence',
    'EN',
  ),
  NewsSource(
    'SANS ISC Daily Diary',
    'https://isc.sans.edu/rssfeed_full.xml',
    'Threat Intelligence',
    'EN',
  ),
  NewsSource(
    'CISA Cybersecurity Advisories',
    'https://www.cisa.gov/cybersecurity-advisories/all.xml',
    'Alerts',
    'EN',
  ),
  NewsSource(
    'NIST News',
    'https://www.nist.gov/news-events/news/rss.xml',
    'Standards',
    'EN',
  ),
  NewsSource(
    'Google Security Blog',
    'https://security.googleblog.com/feeds/posts/default',
    'Technology',
    'EN',
  ),
  NewsSource(
    'Cloudflare Blog',
    'https://blog.cloudflare.com/rss/',
    'Cloud Security',
    'EN',
  ),
  NewsSource(
    'Cisco Talos',
    'https://blog.talosintelligence.com/rss/',
    'Threat Intelligence',
    'EN',
  ),
  NewsSource(
    'Unit 42',
    'https://unit42.paloaltonetworks.com/feed/',
    'Threat Intelligence',
    'EN',
  ),
  NewsSource(
    'Rapid7 Blog',
    'https://www.rapid7.com/blog/rss/',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'Wired Security',
    'https://www.wired.com/feed/category/security/latest/rss',
    'Technology',
    'EN',
  ),
  NewsSource(
    'TechCrunch Security',
    'https://techcrunch.com/category/security/feed/',
    'Technology',
    'EN',
  ),
  NewsSource(
    'Project Zero',
    'https://googleprojectzero.blogspot.com/feeds/posts/default',
    'Vulnerabilities',
    'EN',
  ),
  NewsSource(
    'Schneier on Security',
    'https://www.schneier.com/feed/atom/',
    'Analysis',
    'EN',
  ),
  NewsSource(
    'Exploit-DB',
    'https://www.exploit-db.com/rss.xml',
    'Exploits',
    'EN',
  ),
  NewsSource(
    'GitHub Security Lab',
    'https://github.blog/tag/security/feed/',
    'AppSec',
    'EN',
  ),
  NewsSource(
    'Android Developers Blog',
    'https://android-developers.googleblog.com/feeds/posts/default',
    'Android',
    'EN',
  ),
  NewsSource(
    'XDA Developers',
    'https://www.xda-developers.com/feed/',
    'Android',
    'EN',
  ),
  NewsSource(
    'Arabhardware',
    'https://arabhardware.net/feed',
    'Technology',
    'AR',
  ),
  NewsSource(
    'عالم التقنية',
    'https://www.tech-wd.com/wd/feed/',
    'Technology',
    'AR',
  ),
  NewsSource(
    'البوابة العربية للأخبار التقنية',
    'https://aitnews.com/feed/',
    'Technology',
    'AR',
  ),
  NewsSource(
    'The Verge',
    'https://www.theverge.com/rss/index.xml',
    'Technology',
    'EN',
  ),
  NewsSource(
    'BBC Technology',
    'https://feeds.bbci.co.uk/news/technology/rss.xml',
    'Technology',
    'EN',
  ),
  NewsSource(
    'Security Affairs',
    'https://securityaffairs.com/feed',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'Infosecurity Magazine',
    'https://www.infosecurity-magazine.com/rss/news/',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'The Register Security',
    'https://www.theregister.com/security/headlines.atom',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'Mozilla Security Blog',
    'https://blog.mozilla.org/security/feed/',
    'AppSec',
    'EN',
  ),
  NewsSource(
    'AWS Security Blog',
    'https://aws.amazon.com/blogs/security/feed/',
    'Cloud Security',
    'EN',
  ),
  NewsSource(
    'SentinelOne Labs',
    'https://www.sentinelone.com/labs/feed/',
    'Threat Intelligence',
    'EN',
  ),
  NewsSource(
    'UK National Cyber Security Centre',
    'https://www.ncsc.gov.uk/api/1/services/v1/all-rss-feed.xml',
    'Alerts',
    'EN',
  ),
  NewsSource(
    'Ars Technica',
    'https://feeds.arstechnica.com/arstechnica/index',
    'Technology',
    'EN',
  ),
  NewsSource(
    'TechRadar Security',
    'https://www.techradar.com/feeds/tag/security',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'ZDNET Security',
    'https://www.zdnet.com/topic/security/rss.xml',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'TechRepublic Security',
    'https://www.techrepublic.com/rssfeeds/topic/security/',
    'Technology',
    'EN',
  ),
  NewsSource('Cybernews', 'https://cybernews.com/feed/', 'Cybersecurity', 'EN'),
  NewsSource(
    'Zero Day Initiative',
    'https://www.zerodayinitiative.com/blog?format=rss',
    'Vulnerabilities',
    'EN',
  ),
  NewsSource(
    'CERT Polska',
    'https://www.cert.pl/en/feed/',
    'Threat Intelligence',
    'EN',
  ),
  NewsSource(
    'Google News — الأمن السيبراني',
    'https://news.google.com/rss/search?q=%D8%A7%D9%84%D8%A3%D9%85%D9%86%20%D8%A7%D9%84%D8%B3%D9%8A%D8%A8%D8%B1%D8%A7%D9%86%D9%8A&hl=ar&gl=SA&ceid=SA:ar',
    'Cybersecurity',
    'AR',
  ),
  NewsSource(
    'Google News — أخبار التقنية',
    'https://news.google.com/rss/search?q=%D8%A3%D8%AE%D8%A8%D8%A7%D8%B1%20%D8%A7%D9%84%D8%AA%D9%82%D9%86%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar',
    'Technology',
    'AR',
  ),
  NewsSource(
    'Google News — ثغرات أمنية',
    'https://news.google.com/rss/search?q=%D8%AB%D8%BA%D8%B1%D8%A7%D8%AA%20%D8%A3%D9%85%D9%86%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar',
    'Exploits',
    'AR',
  ),
  NewsSource(
    'Google News — Android مفتوح المصدر',
    'https://news.google.com/rss/search?q=%D8%A3%D9%86%D8%AF%D8%B1%D9%88%D9%8A%D8%AF%20%D8%AA%D8%B7%D8%A8%D9%8A%D9%82%D8%A7%D8%AA%20%D9%85%D9%81%D8%AA%D9%88%D8%AD%D8%A9%20%D8%A7%D9%84%D9%85%D8%B5%D8%AF%D8%B1&hl=ar&gl=SA&ceid=SA:ar',
    'Android',
    'AR',
  ),
  NewsSource(
    'Google News — هجمات سيبرانية',
    'https://news.google.com/rss/search?q=%D9%87%D8%AC%D9%85%D8%A7%D8%AA%20%D8%B3%D9%8A%D8%A8%D8%B1%D8%A7%D9%86%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar',
    'Threat Intelligence',
    'AR',
  ),
  NewsSource(
    'Google News — برمجيات مفتوحة المصدر',
    'https://news.google.com/rss/search?q=%D8%A8%D8%B1%D9%85%D8%AC%D9%8A%D8%A7%D8%AA%20%D9%85%D9%81%D8%AA%D9%88%D8%AD%D8%A9%20%D8%A7%D9%84%D9%85%D8%B5%D8%AF%D8%B1&hl=ar&gl=SA&ceid=SA:ar',
    'Open Source',
    'AR',
  ),
  NewsSource(
    'Google News — الخصوصية الرقمية',
    'https://news.google.com/rss/search?q=%D8%A7%D9%84%D8%AE%D8%B5%D9%88%D8%B5%D9%8A%D8%A9%20%D8%A7%D9%84%D8%B1%D9%82%D9%85%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar',
    'Privacy',
    'AR',
  ),
  NewsSource(
    'Google News — الأمن والبرمجيات',
    'https://news.google.com/rss/search?q=%D8%A8%D8%B1%D9%85%D8%AC%D9%8A%D8%A7%D8%AA%20%D8%A3%D9%85%D9%86%20%D8%B3%D9%8A%D8%A8%D8%B1%D8%A7%D9%86%D9%8A&hl=ar&gl=SA&ceid=SA:ar',
    'Cybersecurity',
    'AR',
  ),
  // Verified official feeds added for the 2.3.0 content expansion.
  NewsSource(
    'CERT-EU Security Advisories',
    'https://cert.europa.eu/publications/security-advisories-rss',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'FortiGuard Labs Threat Signal Report',
    'https://filestore.fortinet.com/fortiguard/rss/threatsignal.xml',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'SonicWall PSIRT Advisories',
    'https://psirtapi.global.sonicwall.com/api/v1/feed/rss.xml',
    'Cybersecurity',
    'EN',
  ),
  NewsSource(
    'Hugging Face Blog',
    'https://huggingface.co/blog/feed.xml',
    'AI',
    'EN',
  ),
  NewsSource(
    'Google Research Blog',
    'https://research.google/blog/rss/',
    'AI',
    'EN',
  ),
  NewsSource(
    'Microsoft Research',
    'https://www.microsoft.com/en-us/research/feed/',
    'AI',
    'EN',
  ),
  NewsSource(
    'Google Testing Blog',
    'https://testing.googleblog.com/feeds/posts/default',
    'Programming',
    'EN',
  ),
  NewsSource(
    'Kotlin Blog',
    'https://blog.jetbrains.com/kotlin/feed/',
    'Programming',
    'EN',
  ),
  NewsSource(
    'Linux Kernel Archives – Distribution RSS',
    'https://www.kernel.org/feeds/kdist.xml',
    'Linux',
    'EN',
  ),
  NewsSource('openSUSE News', 'https://news.opensuse.org/feed/', 'Linux', 'EN'),
  NewsSource(
    'Fedora Magazine',
    'https://fedoramagazine.org/feed/',
    'Linux',
    'EN',
  ),
  NewsSource(
    'The Crossplane Blog',
    'https://blog.crossplane.io/rss/',
    'Cloud',
    'EN',
  ),
  NewsSource(
    'OpenTofu Blog',
    'https://opentofu.org/blog/rss.xml',
    'Cloud',
    'EN',
  ),
  NewsSource('Cilium Blog', 'https://cilium.io/blog/rss.xml', 'Cloud', 'EN'),
  // Verified official feeds added for the 2.3.0 content expansion.
  NewsSource('F-Droid Blog', 'https://f-droid.org/feed.xml', 'Android', 'EN'),
  NewsSource(
    'LineageOS News',
    'https://lineageos.org/feed.xml',
    'Android',
    'EN',
  ),
  // Verified official feeds added for the 2.3.0 content expansion.
  NewsSource(
    'Internet Society',
    'https://www.internetsociety.org/feed/',
    'Privacy',
    'EN',
  ),
  NewsSource(
    'GrapheneOS Releases',
    'https://grapheneos.org/releases.atom',
    'Privacy',
    'EN',
  ),

  // Verified official feeds added for the 2.3.0 content expansion.
  NewsSource(
    'التقنية السورية Syrian Tech',
    'https://syriantech.com/feed/',
    'Technology',
    'AR',
  ),
  // Official feeds validated on 2026-10-18 (HTTP 200 + XML/RSS).
  NewsSource('CISA News', 'https://www.cisa.gov/news.xml', 'Alerts', 'EN'),
  NewsSource('CISA Blog', 'https://www.cisa.gov/cisa/blog.xml', 'Alerts', 'EN'),
  NewsSource(
    'CISA ICS Advisories',
    'https://www.cisa.gov/cybersecurity-advisories/ics-advisories.xml',
    'Industrial Security',
    'EN',
  ),
  NewsSource(
    'CISA ICS Medical Advisories',
    'https://www.cisa.gov/cybersecurity-advisories/ics-medical-advisories.xml',
    'Healthcare Security',
    'EN',
  ),
  NewsSource(
    'Cisco PSIRT Security Advisories',
    'https://sec.cloudapps.cisco.com/security/center/psirtrss20/CiscoSecurityAdvisory.xml',
    'Vendor Advisories',
    'EN',
  ),
  NewsSource(
    'Cisco Event Responses',
    'https://sec.cloudapps.cisco.com/security/center/eventResponses_20.xml',
    'Incident Response',
    'EN',
  ),
  NewsSource(
    'FortiGuard PSIRT Advisories',
    'https://filestore.fortinet.com/fortiguard/rss/ir.xml',
    'Vendor Advisories',
    'EN',
  ),
  NewsSource(
    'Debian Security Advisories',
    'https://www.debian.org/security/dsa.rdf',
    'Linux Security',
    'EN',
  ),
  // RSS/Atom verified on 2026-10-20 (HTTP 200, parseable XML with entries).
  NewsSource('Ubuntu Security Notices', 'https://ubuntu.com/security/notices/rss.xml', 'Linux Security', 'EN'),
  NewsSource('Kubernetes Security & Releases', 'https://kubernetes.io/feed.xml', 'Cloud Security', 'EN'),
  NewsSource('OpenSSF Blog', 'https://openssf.org/feed/', 'Supply Chain Security', 'EN'),
  NewsSource('CERT/CC Vulnerability Notes', 'https://kb.cert.org/vuls/atomfeed/', 'Vulnerability Advisories', 'EN'),
  NewsSource('Australian Cyber Security Centre Alerts', 'https://www.cyber.gov.au/rss/alerts', 'Alerts', 'EN'),
];

/// Publisher RSS/Atom feeds for longer-form learning and practical guides.
/// Keep these separate from breaking news while sharing source management.
const tutorialSources = <NewsSource>[
  NewsSource(
    'PortSwigger Research & Tutorials',
    'https://portswigger.net/blog/rss',
    'Tutorial · Web Security',
    'EN',
  ),
  NewsSource(
    'freeCodeCamp News',
    'https://www.freecodecamp.org/news/rss/',
    'Tutorial · Programming',
    'EN',
  ),
  NewsSource(
    'GitHub Tutorials',
    'https://github.blog/tag/tutorial/feed/',
    'Tutorial · Developer Tools',
    'EN',
  ),
  NewsSource(
    'DigitalOcean Community Tutorials',
    'https://www.digitalocean.com/community/tutorials/feed',
    'Tutorial · Cloud & Linux',
    'EN',
  ),
  NewsSource(
    'Google Developers',
    'https://developers.googleblog.com/feeds/posts/default',
    'Tutorial · Android & AI',
    'EN',
  ),
  NewsSource(
    'Linux Foundation Blog',
    'https://www.linuxfoundation.org/blog/rss.xml',
    'Tutorial · Open Source',
    'EN',
  ),
  NewsSource(
    'Linux.com',
    'https://www.linux.com/feed/',
    'Tutorial · Linux',
    'EN',
  ),
];

const allFeedSources = <NewsSource>[...newsSources, ...tutorialSources];

/// Live upcoming CTF events. CTFtime permits this API/feed for analysis and mobile apps.
const ctfSource = NewsSource(
  'CTFtime — Upcoming Events',
  'https://ctftime.org/event/list/upcoming/rss/',
  'CTF',
  'EN',
);
