import '../models/protection_content.dart';

// Defensive checklists based on linked official platform and agency guidance.
const List<ProtectionCheck> protectionChecks = <ProtectionCheck>[
  ProtectionCheck(
    id: "android-hardening-01",
    platform: "Android",
    groupAr: "تقوية Android",
    groupEn: "Android hardening",
    titleAr: "ثبّت تحديثات Android وتصحيحات الأمان",
    titleEn: "Install Android system and security updates",
    detailAr:
        "افتح الإعدادات > حول الهاتف/الجهاز اللوحي > إصدار Android لمراجعة إصدار Android وتاريخ تصحيح الأمان وتحديث Google Play، ثم افتح الإعدادات > النظام > تحديثات البرامج واتبع التعليمات. التحديثات الكبيرة قد تحتاج Wi‑Fi وشحناً كافياً. يختلف موعد الدعم والتحديث حسب الشركة المصنّعة والطراز وشركة الاتصالات؛ إذا لم يعد جهازك مدعوماً، راجع الشركة المصنّعة أو مزوّد الاتصالات.",
    detailEn:
        "Open Settings > About phone/tablet > Android version to review the Android version, security-update status, and Google Play system update; then open Settings > System > Software updates and follow the prompts. Large updates may need Wi‑Fi and sufficient charge. Update availability varies by device, manufacturer, and carrier; if the device is no longer supported, contact the manufacturer or carrier.",
    risk: "high",
    officialUrl: "https://support.google.com/android/answer/7680439?hl=en",
    sourceTitle: "Check & update your Android version",
  ),
  ProtectionCheck(
    id: "android-hardening-02",
    platform: "Android",
    groupAr: "تقوية Android",
    groupEn: "Android hardening",
    titleAr: "أبقِ Google Play Protect مفعّلاً",
    titleEn: "Keep Google Play Protect enabled",
    detailAr:
        "في متجر Google Play، افتح صورة الملف الشخصي > Play Protect > الإعدادات، وتأكد من تشغيل فحص التطبيقات مع Play Protect. يفحص Play Protect التطبيقات قبل تنزيلها من Google Play ويفحص التطبيقات من مصادر أخرى، وقد يحذّر من التطبيق الضار أو يعطّله أو يزيله. راجع أيضاً حالة اعتماد الجهاز من متجر Play > صورة الملف الشخصي > الإعدادات > لمحة/حول. لا تفترض أن الفحص ضمان كامل للأمان.",
    detailEn:
        "In Google Play, open the profile icon > Play Protect > Settings and ensure Scan apps with Play Protect is on. Play Protect checks apps before download from Google Play and scans apps from other sources; it may warn about, disable, or remove harmful apps. Also review certification under Play Store > profile icon > Settings > About. Do not treat scanning as a guarantee of safety.",
    risk: "high",
    officialUrl: "https://support.google.com/android/answer/2812853?hl=en",
    sourceTitle:
        "Use Google Play Protect to help keep your apps safe & your data private",
  ),
  ProtectionCheck(
    id: "android-hardening-03",
    platform: "Android",
    groupAr: "تقوية Android",
    groupEn: "Android hardening",
    titleAr: "تجنّب التطبيقات من المصادر غير المعروفة",
    titleEn: "Avoid apps from unknown sources",
    detailAr:
        "نزّل التطبيقات من متجر رسمي موثوق، ولا تثبّت ملفات APK أو شهادات مؤسسية غير موثوقة. يحظر Android تثبيت التطبيقات من خارج Google Play حتى تمنح مصدراً معيناً إذناً صريحاً؛ لا تمنح هذا الإذن إلا لحاجة موثقة ومن مصدر تثق به، وألغِه بعد الانتهاء إذا كان جهازك يتيح ذلك. تختلف الإعدادات حسب إصدار Android؛ وبعض مزوّدي الشبكة قد يمنعون التثبيت من المصادر غير المعروفة.",
    detailEn:
        "Install apps from a trusted official app store and avoid APKs or untrusted enterprise certificates. Android blocks installs from outside Google Play until you explicitly opt in a particular source; grant that permission only for a verified need and trusted source, and revoke it afterward if your device allows. Settings vary by Android version, and some network providers may restrict unknown-source installs.",
    risk: "high",
    officialUrl:
        "https://developer.android.com/distribute/marketing-tools/alternative-distribution",
    sourceTitle: "Alternative distribution options",
  ),
  ProtectionCheck(
    id: "android-hardening-04",
    platform: "Android",
    groupAr: "تقوية Android",
    groupEn: "Android hardening",
    titleAr: "راجع أذونات التطبيقات وأوقف غير الضروري",
    titleEn: "Review and reduce app permissions",
    detailAr:
        "من الإعدادات > التطبيقات > اختر التطبيق > الأذونات، أو الإعدادات > الأمان والخصوصية > الخصوصية > مدير الأذونات، امنح كل تطبيق ما يحتاجه فقط. للموقع والكاميرا والميكروفون استخدم السماح أثناء الاستخدام أو السؤال في كل مرة عندما يتوفر، وارفض غير الضروري. فعّل إيقاف نشاط التطبيق مؤقتاً عند عدم استخدامه للتطبيقات المناسبة، وراجع التطبيقات التي لا تحتاجها واحذفها.",
    detailEn:
        "Go to Settings > Apps > select an app > Permissions, or Settings > Security & Privacy > Privacy > Permission manager, and grant only what the app needs. For location, camera, and microphone, choose while-in-use or ask every time where available, and deny unnecessary access. Enable Pause app activity if unused for suitable apps, and uninstall apps you no longer need.",
    risk: "medium",
    officialUrl: "https://support.google.com/android/answer/9431959?hl=en",
    sourceTitle: "Change app permissions on your Android phone",
  ),
  ProtectionCheck(
    id: "android-hardening-05",
    platform: "Android",
    groupAr: "تقوية Android",
    groupEn: "Android hardening",
    titleAr: "استخدم قفل شاشة قويّاً",
    titleEn: "Use a strong screen lock",
    detailAr:
        "افتح الإعدادات > الأمان > قفل الشاشة واختر PIN أو نمطاً أو كلمة مرور، ولا تترك الجهاز بلا قفل. توضح Google أن استخدام PIN أو نمط أو كلمة مرور يساعد على تشفير النسخ الاحتياطية التلقائية واليدوية بقفل الشاشة؛ وقد تختلف القوائم حسب الجهاز. إذا استخدمت Auto-confirm، فاعلم أن Google تحذّر من أنه قد يقلل أمان الجهاز.",
    detailEn:
        "Open Settings > Security > Screen lock and choose a PIN, pattern, or password; do not leave the device with no lock. Google states that using a PIN, pattern, or password helps encrypt automatic and manual backups with the screen lock; menus vary by device. If you use Auto-confirm unlock, note Google’s warning that it may reduce device security.",
    risk: "high",
    officialUrl: "https://support.google.com/android/answer/9079129?hl=en",
    sourceTitle: "Set screen lock on an Android device",
  ),
  ProtectionCheck(
    id: "android-hardening-06",
    platform: "Android",
    groupAr: "تقوية Android",
    groupEn: "Android hardening",
    titleAr: "فعّل حماية السرقة عند توفرها",
    titleEn: "Turn on Theft protection when available",
    detailAr:
        "بعد ضبط قفل الشاشة، افتح الإعدادات > Google > جميع الخدمات > الأمان الشخصي والجهاز > حماية من السرقة، وفعّل Theft Detection Lock وOffline Device Lock وFailed Authentication Lock وRemote Lock، وIdentity Check إن ظهر. تتطلب بعض الميزات Android 10 أو 15 فأحدث، ولا تعمل على Android Go أو الأجهزة اللوحية أو الساعات، وقد يختلف الدعم حسب الطراز؛ استخدم فقط الخيارات التي يعرضها جهازك.",
    detailEn:
        "After setting a screen lock, open Settings > Google > All services > Personal & device safety > Theft protection and enable Theft Detection Lock, Offline Device Lock, Failed Authentication Lock, and Remote Lock; enable Identity Check if shown. Some features require Android 10 or 15 and later, are unavailable on Android Go, tablets, and wearables, and vary by model; use only options your device exposes.",
    risk: "high",
    officialUrl: "https://support.google.com/android/answer/15146908?hl=en",
    sourceTitle: "Protect your personal data against theft",
  ),
  ProtectionCheck(
    id: "android-hardening-07",
    platform: "Android",
    groupAr: "تقوية Android",
    groupEn: "Android hardening",
    titleAr: "جهّز Find Hub للقفل أو المسح عن بُعد",
    titleEn: "Prepare Find Hub for remote lock or erase",
    detailAr:
        "أضف حساب Google إلى الجهاز وتحقق من تشغيل Find Hub. يجب أن يكون الجهاز مشحوناً، متصلاً ببيانات الهاتف أو Wi‑Fi، مسجلاً بحساب Google، ومرئياً على Google Play لاستخدام إجراءات التأمين أو المسح عن بُعد. اختبر الوصول إلى Find Hub مسبقاً، واحفظ كلمة مرور حساب Google؛ بعد المسح ستحتاج إليها لإعادة استخدام الجهاز.",
    detailEn:
        "Add a Google Account to the device and confirm Find Hub is on. For remote securing or erasing, the device needs power, mobile data or Wi‑Fi, a signed-in Google Account, Find Hub enabled, and visibility on Google Play. Verify access to Find Hub in advance and keep the Google Account password available; after an erase, it is required to use the device again.",
    risk: "high",
    officialUrl: "https://support.google.com/android/answer/6160491?hl=en",
    sourceTitle: "Find, secure, or erase a lost Android device",
  ),
  ProtectionCheck(
    id: "android-hardening-08",
    platform: "Android",
    groupAr: "تقوية Android",
    groupEn: "Android hardening",
    titleAr: "فعّل Advanced Protection للمستخدمين ذوي المخاطر الأعلى",
    titleEn: "Enable Advanced Protection for higher-risk users",
    detailAr:
        "إذا كان جهازك يدعمها وتحتاج حماية إضافية، افتح الإعدادات > الأمان والخصوصية > Advanced Protection، أو الإعدادات > Google > جميع الخدمات > الأمان الشخصي والجهاز > Advanced Protection، ثم راجع Device protection. عند تفعيلها لا يمكن إيقاف Play Protect، وتُحظر تطبيقات المصادر غير المعروفة وتُقيّد خدمات تسهيل الاستخدام إلى الأدوات الموثقة. قد تختلف الإتاحة، وقد يسبب MTE المدعوم بطئاً، وقد يمنع الجهاز الاتصال بشبكات 2G؛ راجع أثرها على احتياجاتك قبل التفعيل.",
    detailEn:
        "If your device supports it and you need stronger protection, open Settings > Security & Privacy > Advanced Protection, or Settings > Google > All services > Personal and device safety > Advanced Protection, then review Device protection. When enabled, Play Protect cannot be turned off, unknown-source apps are blocked, and accessibility services are restricted to verified tools. Availability varies; supported MTE may reduce performance and 2G protection may prevent connection where only 2G is available.",
    risk: "medium",
    officialUrl: "https://support.google.com/android/answer/16339980?hl=en",
    sourceTitle: "Improve device security with Advanced Protection for Android",
  ),
  ProtectionCheck(
    id: "win-01",
    platform: "Windows",
    groupAr: "تقوية Windows",
    groupEn: "Windows hardening",
    titleAr: "ثبّت تحديثات Windows والتطبيقات من القنوات الرسمية",
    titleEn: "Install Windows and app updates from official channels",
    detailAr:
        "افتح Start > Settings > Windows Update، اختر Check for Windows updates، ثم Download & install وأعد التشغيل عند الطلب. فعّل التحديثات التلقائية حيثما كانت متاحة، وحدد وقتًا دوريًا لتحديث التطبيقات، ولا تثبّت تحديثًا من نافذة منبثقة أو رسالة بريد؛ استخدم Windows Update أو متجرًا موثوقًا فقط. إذا كان إصدار Windows أو التطبيق خارج الدعم، فاستبدله أو رقّه إلى إصدار مدعوم.",
    detailEn:
        "Open Start > Settings > Windows Update, select Check for Windows updates, then Download & install and restart when prompted. Enable automatic updates when available, set a regular time to update apps, and use Windows Update or a trusted app store—not a browser pop-up or email—to install updates. If Windows or an app is no longer supported, upgrade or replace it with a supported version.",
    risk: "high",
    officialUrl:
        "https://support.microsoft.com/en-us/windows/deployment/updates-lifecycle/install-windows-updates",
    sourceTitle: "Install Windows Updates",
  ),
  ProtectionCheck(
    id: "win-02",
    platform: "Windows",
    groupAr: "تقوية Windows",
    groupEn: "Windows hardening",
    titleAr: "أبقِ Microsoft Defender والحماية الفورية مفعّلين",
    titleEn: "Keep Microsoft Defender and real-time protection enabled",
    detailAr:
        "افتح Windows Security > Virus & threat protection، تأكد من تشغيل Real-time protection، وشغّل Quick scan عند الاشتباه. افحص Protection updates > Check for updates، ولا تضف استثناءات للملفات أو المجلدات إلا عند الضرورة وبعد التحقق منها؛ فالاستثناء قد يزيد قابلية الجهاز أو البيانات للخطر.",
    detailEn:
        "Open Windows Security > Virus & threat protection, verify that Real-time protection is on, and run Quick scan when you suspect a problem. Check Protection updates > Check for updates, and add antivirus exclusions only when necessary and after validating the item; exclusions can make the device or data more vulnerable.",
    risk: "high",
    officialUrl:
        "https://support.microsoft.com/en-us/windows/security/threat-malware-protection/virus-and-threat-protection-in-the-windows-security-app",
    sourceTitle: "Virus and threat protection in the Windows Security app",
  ),
  ProtectionCheck(
    id: "win-03",
    platform: "Windows",
    groupAr: "تقوية Windows",
    groupEn: "Windows hardening",
    titleAr: "اترك Windows Firewall مفعّلًا",
    titleEn: "Leave Windows Firewall enabled",
    detailAr:
        "في Windows Security > Firewall & network protection، تحقق من أن جدار الحماية مفعّل لملف تعريف الشبكة النشط. استخدم ملف Public للشبكات غير الموثوقة مثل نقاط اتصال المقاهي، ولا تعطل الجدار لمجرد حل مشكلة تطبيق؛ راجع إعداد التطبيق أو اطلب مساعدة المسؤول بدلًا من إيقاف الحماية.",
    detailEn:
        "In Windows Security > Firewall & network protection, verify that the firewall is enabled for the active network profile. Use the Public profile for untrusted networks such as café hotspots, and do not disable the firewall merely to fix an app; review the app’s access or ask an administrator instead.",
    risk: "high",
    officialUrl:
        "https://learn.microsoft.com/en-us/windows/security/operating-system-security/network-security/windows-firewall/",
    sourceTitle: "Windows Firewall overview",
  ),
  ProtectionCheck(
    id: "win-04",
    platform: "Windows",
    groupAr: "تقوية Windows",
    groupEn: "Windows hardening",
    titleAr: "فعّل Controlled folder access للحماية من برمجيات الفدية",
    titleEn: "Enable Controlled folder access against ransomware",
    detailAr:
        "افتح Windows Security > Virus & threat protection > Manage ransomware protection، ثم فعّل Controlled folder access لحماية مجلدات مثل Documents وPictures وDesktop من التغييرات غير المصرح بها. إذا حُظر تطبيق موثوق، تحقّق من هويته ووظيفته قبل السماح له، ولا تسمح بتطبيقات مجهولة استجابةً لرسالة.",
    detailEn:
        "Open Windows Security > Virus & threat protection > Manage ransomware protection and enable Controlled folder access to protect folders such as Documents, Pictures, and Desktop from unauthorized changes. If a trusted app is blocked, verify its identity and purpose before allowing it; never allow an unknown app in response to a prompt.",
    risk: "medium",
    officialUrl:
        "https://support.microsoft.com/en-us/windows/security/threat-malware-protection/virus-and-threat-protection-in-the-windows-security-app",
    sourceTitle: "Virus and threat protection in the Windows Security app",
  ),
  ProtectionCheck(
    id: "win-05",
    platform: "Windows",
    groupAr: "تقوية Windows",
    groupEn: "Windows hardening",
    titleAr: "فعّل تشفير الجهاز وتحقق من مفتاح الاسترداد",
    titleEn: "Enable device encryption and verify the recovery key",
    detailAr:
        "بعد التأكد من وجود نسخة احتياطية، افتح Settings > Privacy & security > Device encryption وشغّل التشفير، ثم تحقّق من إمكانية الوصول إلى مفتاح الاسترداد. التشفير يحمي البيانات عند فقدان الجهاز أو سرقته، لكنه لا يعوض النسخ الاحتياطي.",
    detailEn:
        "After confirming that your data is backed up, open Settings > Privacy & security > Device encryption and turn encryption on, then verify that the recovery key is accessible. Encryption protects data if the device is lost or stolen, but it does not replace backups.",
    risk: "high",
    officialUrl:
        "https://support.microsoft.com/en-us/windows/security/encryption/device-encryption-in-windows",
    sourceTitle: "Device Encryption in Windows",
  ),
  ProtectionCheck(
    id: "win-06",
    platform: "Windows",
    groupAr: "تقوية Windows",
    groupEn: "Windows hardening",
    titleAr: "احفظ نسخة منفصلة وآمنة من مفتاح BitLocker",
    titleEn: "Keep a separate, safe backup of the BitLocker recovery key",
    detailAr:
        "اكتب BitLocker في Start وافتح Manage BitLocker، ثم اختر Back up your recovery key. احفظه في حساب Microsoft أو حساب العمل/الدراسة أو على USB منفصل أو مطبوعًا، ولا تخزن USB أو النسخة المطبوعة مع الكمبيوتر؛ فمن يملك الجهاز والمفتاح قد يتجاوز حماية البيانات. اختبر وجود النسخة قبل الحاجة إليها.",
    detailEn:
        "Type BitLocker in Start and open Manage BitLocker, then select Back up your recovery key. Save it to your Microsoft or work/school account, a separate USB drive, or a printout; do not keep the USB or printout with the computer, because possession of both could bypass data protection. Verify that the backup exists before it is needed.",
    risk: "high",
    officialUrl:
        "https://support.microsoft.com/en-us/windows/security/encryption/back-up-your-bitlocker-recovery-key",
    sourceTitle: "Back Up Your BitLocker Recovery Key",
  ),
  ProtectionCheck(
    id: "win-07",
    platform: "Windows",
    groupAr: "تقوية Windows",
    groupEn: "Windows hardening",
    titleAr: "فعّل التحقق بخطوتين لحساب Microsoft",
    titleEn: "Turn on two-step verification for your Microsoft account",
    detailAr:
        "من إعدادات أمان حساب Microsoft افتح Manage how I sign in، ثم Additional security > Two-step verification > Turn on. أضف ثلاث وسائل أمان إن أمكن لتقليل خطر فقدان الوصول، ولا توافق على طلب تحقق لم تبدأه أنت. هذه الخطوة تخص حساب Microsoft الشخصي؛ حسابات العمل أو الدراسة قد تخضع لسياسة المسؤول.",
    detailEn:
        "In your Microsoft account security settings, open Manage how I sign in, then Additional security > Two-step verification > Turn on. Add three security methods when possible to reduce lockout risk, and never approve a verification request you did not initiate. This applies to personal Microsoft accounts; work or school accounts may be governed by an administrator’s policy.",
    risk: "high",
    officialUrl:
        "https://support.microsoft.com/en-us/accounts-billing/security/how-to-use-two-step-verification-with-your-microsoft-account",
    sourceTitle: "How to use two-step verification with your Microsoft account",
  ),
  ProtectionCheck(
    id: "win-08",
    platform: "Windows",
    groupAr: "تقوية Windows",
    groupEn: "Windows hardening",
    titleAr: "أنشئ نسخًا احتياطية متكررة وافصل القرص الخارجي",
    titleEn: "Make frequent backups and disconnect the external drive",
    detailAr:
        "انسخ الملفات المهمة بانتظام إلى قرص خارجي آمن أو خدمة سحابية موثوقة، واحتفظ بالقرص الخارجي مفصولًا عندما لا تكون عملية النسخ جارية لتقليل خطر تلف النسخ ببرمجيات الفدية. تحقق دوريًا من إمكانية قراءة النسخ. تفاصيل الاستعادة والاحتفاظ تعتمد على خدمة النسخ أو جهازك، وهذه ليست بديلًا عن خطة استعادة كاملة.",
    detailEn:
        "Back up important files regularly to a secure external drive or a properly vetted cloud service, and disconnect the external drive when it is not actively being used for backup to reduce ransomware exposure. Periodically verify that backups can be read. Restore and retention details depend on the backup provider and device, and this is not a substitute for a full disaster-recovery plan.",
    risk: "high",
    officialUrl:
        "https://www.cisa.gov/resources-tools/training/how-protect-data-stored-your-devices",
    sourceTitle: "How to Protect the Data that is Stored on Your Devices",
  ),
  ProtectionCheck(
    id: "linux-01",
    platform: "Linux",
    groupAr: "تقوية Linux",
    groupEn: "Linux hardening",
    titleAr: "ثبّت تحديثات الأمان تلقائياً وراجع نجاحها",
    titleEn: "Install security updates automatically and verify them",
    detailAr:
        "حدّث النظام دورياً عبر مدير الحزم، وثبّت unattended-upgrades على Ubuntu لتثبيت تحديثات الأمان وإصلاحات الأخطاء تلقائياً (الإعداد الافتراضي يومي، ويمكن مراجعته). احذف الحزم غير اللازمة وفضّل مستودعات التوزيعة الرسمية. هذا الإجراء خاص بتوزيعات/مديري حزم مزودك؛ قد تحتاج إصدارات قديمة أو حزم Universe إلى تغطية Ubuntu Pro/ESM، ولا تفترض أن التحديث نجح من دون فحص السجلات أو حالة الحزمة.",
    detailEn:
        "Update regularly through the distribution package manager and, on Ubuntu, install unattended-upgrades so security updates and bug fixes are installed automatically (the default schedule is daily and can be reviewed). Remove packages you do not need and prefer the distribution's official repositories. This is distribution/package-manager dependent; older releases or Universe packages may require Ubuntu Pro/ESM coverage, and you should verify logs/package status rather than assuming an update succeeded.",
    risk: "high",
    officialUrl:
        "https://ubuntu.com/server/docs/explanation/security/security_suggestions/",
    sourceTitle: "Security suggestions",
  ),
  ProtectionCheck(
    id: "linux-02",
    platform: "Linux",
    groupAr: "تقوية Linux",
    groupEn: "Linux hardening",
    titleAr: "فعّل جداراً نارياً واسمح فقط بالمنافذ المطلوبة",
    titleEn: "Enable a firewall and allow only required ports",
    detailAr:
        "على Ubuntu استخدم ufw، فعّله، اعرض حالته، وراجِع القواعد قبل فتح أي منفذ؛ استخدم ملفات تعريف التطبيقات أو قيّد الإدارة إلى عناوين/شبكات موثوقة عند الإمكان. لا تنفّذ ذلك عبر اتصال وحيد قبل التأكد من أن منفذ الإدارة مسموح، ونسّق مع جدار مزود السحابة أو جهاز الشبكة لأن ufw لا يحل محل ضوابطهم ولا ينطبق بالضرورة على كل توزيعة.",
    detailEn:
        "On Ubuntu use ufw, enable it, inspect its status, and review rules before opening a port; use application profiles or restrict administration to trusted hosts/networks where feasible. Do not do this over your only connection until the management path is allowed. Coordinate with a cloud-provider security group or network appliance: ufw does not replace those controls and is not the default tool on every distribution.",
    risk: "high",
    officialUrl: "https://ubuntu.com/server/docs/how-to/security/firewalls/",
    sourceTitle: "Firewall",
  ),
  ProtectionCheck(
    id: "linux-03",
    platform: "Linux",
    groupAr: "تقوية Linux",
    groupEn: "Linux hardening",
    titleAr: "أمّن SSH بمفاتيح واختبر الإعداد قبل إعادة التشغيل",
    titleEn: "Harden SSH with keys and test configuration before restart",
    detailAr:
        "إذا كان OpenSSH server مستخدماً، أنشئ مفتاحاً حديثاً محمياً بعبارة مرور (توصي وثائق Ubuntu بـ Ed25519)، ثبّت المفتاح العام في authorized_keys، وتحقق من صلاحيات الملف. بعد أي تعديل استخدم sshd -t قبل إعادة تشغيل الخدمة، واحتفظ بجلسة/وصول وحدة تحكم احتياطي لتجنب الإقفال؛ تعطيل كلمة مرور أو دخول root يتطلب التأكد أولاً من عمل مسار المفتاح وسياسة مزودك.",
    detailEn:
        "If OpenSSH server is in use, create a modern key protected by a passphrase (Ubuntu documents Ed25519), install only the public key in authorized_keys, and verify file permissions. After every change run sshd -t before restarting the service, and keep a separate session or console path so a mistake does not lock you out. Disabling password or root login must wait until key access and the provider's recovery path are confirmed.",
    risk: "high",
    officialUrl:
        "https://ubuntu.com/server/docs/how-to/security/openssh-server/",
    sourceTitle: "OpenSSH server",
  ),
  ProtectionCheck(
    id: "linux-04",
    platform: "Linux",
    groupAr: "تقوية Linux",
    groupEn: "Linux hardening",
    titleAr: "استخدم حساباً عادياً وقيّد امتيازات sudo",
    titleEn: "Use a regular account and limit sudo privileges",
    detailAr:
        "طبّق مبدأ أقلّ امتياز: استخدم حساباً غير root للعمل اليومي، ولا تستخدم sudo إلا لمهام الإدارة، وراجع عضوية مجموعة sudo والحسابات المحلية دورياً. Ubuntu يعطّل تسجيل دخول root الإداري افتراضياً ويستخدم sudo للمساءلة؛ لا تفعّل كلمة مرور root كحل سريع، ولا تطبق هذه التفاصيل حرفياً على LDAP/Active Directory أو توزيعة أخرى من دون الرجوع إلى موفر الهوية/التوزيعة.",
    detailEn:
        "Apply least privilege: use a non-root account for daily work, use sudo only for administration, and periodically review sudo-group membership and local accounts. Ubuntu disables direct administrative root login by default and uses sudo for accountability; do not enable a root password as a shortcut. These details do not automatically cover LDAP/Active Directory or another distribution; follow that identity provider/distribution's guidance.",
    risk: "high",
    officialUrl:
        "https://ubuntu.com/server/docs/how-to/security/user-management/",
    sourceTitle: "User management",
  ),
  ProtectionCheck(
    id: "linux-05",
    platform: "Linux",
    groupAr: "تقوية Linux",
    groupEn: "Linux hardening",
    titleAr: "تحقق من AppArmor واترك الملفات الناضجة في وضع الإنفاذ",
    titleEn: "Check AppArmor and keep mature profiles enforced",
    detailAr:
        "على Ubuntu افحص الحالة عبر apparmor_status؛ فـ AppArmor مثبت ومحمّل افتراضياً، ويمكن تثبيت apparmor-profiles. استخدم الملفات المورّدة في وضع Enforce، وابدأ الملفات التجريبية في Complain وراقب السجلات قبل فرضها. لا تنشئ أو تعدّل سياسة لتطبيق من دون اختبار وظائفه وخطة تراجع؛ AppArmor خاص بالتوزيعات التي توفره وقد تحتاج أجهزة/تطبيقات أخرى إلى SELinux أو آلية مختلفة.",
    detailEn:
        "On Ubuntu check status with apparmor_status; AppArmor is installed and loaded by default, and apparmor-profiles is available. Keep mature vendor profiles in Enforce mode; use Complain for experimental profiles and review logs before enforcing them. Do not create or change a policy without testing the application's normal functions and having a rollback plan. AppArmor is distribution-dependent; other systems may use SELinux or another mechanism.",
    risk: "medium",
    officialUrl: "https://ubuntu.com/server/docs/how-to/security/apparmor/",
    sourceTitle: "AppArmor",
  ),
  ProtectionCheck(
    id: "linux-06",
    platform: "Linux",
    groupAr: "تقوية Linux",
    groupEn: "Linux hardening",
    titleAr: "أضف مصادقة FIDO/‏U2F لـ SSH عند توفر العتاد",
    titleEn: "Add FIDO/U2F authentication to SSH when hardware is available",
    detailAr:
        "للوصول البعيد عالي القيمة، أضف مفتاحاً عتادياً FIDO/U2F إلى المصادقة المعتمدة على المفاتيح؛ توثق Ubuntu نوعي ecdsa-sk وed25519-sk، ويتطلب الاستخدام وجود الجهاز ولمسه، وقد يتطلب الجهاز الأحدث نوع ed25519-sk. ضع PIN للجهاز، وسجّل مفتاحاً احتياطياً ومسار استرداد قبل فرضه؛ هذا يعتمد على إصدار OpenSSH (الدعم أضيف في 8.2) وعلى توفر العتاد وتوافقه، ولا تتخلص من طريقة الدخول الوحيدة قبل اختبارها.",
    detailEn:
        "For high-value remote access, add a FIDO/U2F hardware key to key-based authentication; Ubuntu documents ecdsa-sk and ed25519-sk. Use requires the device to be present and touched, and ed25519-sk may need newer hardware. Set a device PIN and enroll a backup key/recovery path before enforcing it. This depends on OpenSSH version (support was added in 8.2), hardware availability/compatibility, and provider access; do not remove the only working login method before testing.",
    risk: "medium",
    officialUrl:
        "https://ubuntu.com/server/docs/how-to/security/two-factor-authentication-with-u2f-or-fido/",
    sourceTitle: "Two factor authentication with U2F/FIDO",
  ),
  ProtectionCheck(
    id: "linux-07",
    platform: "Linux",
    groupAr: "تقوية Linux",
    groupEn: "Linux hardening",
    titleAr: "احمِ أدلة المستخدم من القراءة العامة",
    titleEn: "Protect user home directories from public read access",
    detailAr:
        "راجع صلاحيات /home لكل مستخدم، واجعل الدليل غير قابل للقراءة العامة (توثق Ubuntu مثال 0750) عند ملاءمته لاحتياج المشاركة. عدّل الدليل الأب فقط ولا تستخدم chmod -R عشوائياً، ثم اختبر التطبيقات والنسخ الاحتياطية. هذا مناسب للتثبيتات المحلية في Ubuntu؛ قد تكسر مشاركة ملفات أو حسابات خدمة، وقد تفرض سياسة الدليل المركزي/الحاوية صلاحيات مختلفة.",
    detailEn:
        "Review each user's /home permissions and remove public read access (Ubuntu documents 0750 as an example) where it fits the sharing requirement. Change only the parent directory; do not use chmod -R indiscriminately, then test applications and backups. This is most applicable to local Ubuntu installations; it can break file sharing or service accounts, and centralized-directory or container policies may require different permissions.",
    risk: "low",
    officialUrl:
        "https://ubuntu.com/server/docs/how-to/security/user-management/",
    sourceTitle: "User management",
  ),
  ProtectionCheck(id: "android-hardening-09", platform: "Android", groupAr: "تقوية Android", groupEn: "Android hardening", titleAr: "راجع التطبيقات ذات الوصول الخاص", titleEn: "Review special app access", detailAr: "افتح الإعدادات > التطبيقات > وصول خاص للتطبيقات وراجع الظهور فوق التطبيقات، وتثبيت تطبيقات غير معروفة، والوصول إلى الإشعارات، وخدمات تسهيل الاستخدام. عطّل ما لا تحتاجه ولا تمنح هذه الصلاحيات لتطبيق غير موثوق.", detailEn: "Open Settings > Apps > Special app access and review draw-over-other-apps, install-unknown-apps, notification access, and accessibility services. Disable what you do not need and do not grant these privileges to untrusted apps.", risk: "high", officialUrl: "https://support.google.com/android/answer/9455138?hl=en", sourceTitle: "Change app permissions on your Android phone"),
  ProtectionCheck(id: "android-hardening-10", platform: "Android", groupAr: "تقوية Android", groupEn: "Android hardening", titleAr: "أوقف معاينات الرسائل الحساسة على شاشة القفل", titleEn: "Hide sensitive lock-screen previews", detailAr: "راجع إعدادات الإشعارات وشاشة القفل لإخفاء محتوى الرسائل والرموز عندما يكون الهاتف مقفلاً، خصوصاً لتطبيقات المصادقة والبريد والحسابات المالية.", detailEn: "Review notification and lock-screen settings to hide message and code content while the phone is locked, especially for authenticators, email, and financial accounts.", risk: "medium", officialUrl: "https://support.google.com/android/answer/9079661?hl=en", sourceTitle: "Control notifications on Android"),
  ProtectionCheck(id: "android-hardening-11", platform: "Android", groupAr: "تقوية Android", groupEn: "Android hardening", titleAr: "تحقق من النسخ الاحتياطية قبل إعادة الضبط", titleEn: "Verify backups before a reset", detailAr: "قبل إعادة ضبط الجهاز، حدد ما تحتاجه فعلاً، وتأكد من أن النسخة الاحتياطية لا تحتوي ملفات أو تطبيقات مشتبه بها، واختبر استعادة البيانات غير الحساسة مسبقاً.", detailEn: "Before resetting a device, identify what you actually need, ensure the backup does not contain suspicious apps or files, and test restoration of non-sensitive data in advance.", risk: "medium", officialUrl: "https://support.google.com/android/answer/2819582?hl=en", sourceTitle: "Back up or restore data on your Android device"),
  ProtectionCheck(id: "win-09", platform: "Windows", groupAr: "تقوية Windows", groupEn: "Windows hardening", titleAr: "استخدم حساباً عادياً للعمل اليومي", titleEn: "Use a standard account for daily work", detailAr: "استخدم حساباً عادياً للمهام اليومية واطلب صلاحيات المسؤول فقط عند الحاجة. راجع أعضاء مجموعة Administrators وأزل الحسابات غير اللازمة.", detailEn: "Use a standard account for daily work and request administrator privileges only when needed. Review Administrators group membership and remove unnecessary accounts.", risk: "high", officialUrl: "https://learn.microsoft.com/en-us/windows/security/identity-protection/user-account-control/user-account-control-overview", sourceTitle: "User Account Control overview"),
  ProtectionCheck(id: "win-10", platform: "Windows", groupAr: "تقوية Windows", groupEn: "Windows hardening", titleAr: "فعّل BitLocker أو تشفير الجهاز", titleEn: "Enable BitLocker or device encryption", detailAr: "تحقق من دعم جهازك لتشفير الجهاز أو BitLocker، واحفظ مفتاح الاسترداد في مكان آمن منفصل ولا تضعه بجوار الجهاز.", detailEn: "Check whether your device supports device encryption or BitLocker, and store the recovery key safely in a separate location rather than beside the device.", risk: "high", officialUrl: "https://learn.microsoft.com/en-us/windows/security/operating-system-security/data-protection/bitlocker/", sourceTitle: "Device encryption in Windows"),
  ProtectionCheck(id: "win-11", platform: "Windows", groupAr: "تقوية Windows", groupEn: "Windows hardening", titleAr: "راجع التطبيقات التي تبدأ مع النظام", titleEn: "Review startup applications", detailAr: "من إعدادات التطبيقات أو Task Manager راجع عناصر بدء التشغيل وعطّل ما لا تحتاجه بعد التحقق من اسم الناشر ومسار الملف، ولا تحذف عنصراً نظامياً لمجرد أن اسمه غير مألوف.", detailEn: "Review startup items in Settings or Task Manager and disable what you do not need after checking publisher and path; do not remove a system item merely because its name is unfamiliar.", risk: "medium", officialUrl: "https://learn.microsoft.com/en-us/windows/configuration/startup-apps/", sourceTitle: "Configure startup applications in Windows"),
  ProtectionCheck(id: "linux-09", platform: "Linux", groupAr: "تقوية Linux", groupEn: "Linux hardening", titleAr: "فعّل التحديثات الأمنية التلقائية حيث تناسبك", titleEn: "Enable automatic security updates where appropriate", detailAr: "فعّل التحديثات الأمنية التلقائية وفق سياسة توزيعتك، وراقب الإخفاقات وإعادة التشغيل المطلوبة. لا تخلط بين التحديث التلقائي وترقية إصدار رئيسي دون اختبار.", detailEn: "Enable automatic security updates according to your distribution policy and monitor failures and required restarts. Do not confuse automatic security updates with an untested major-version upgrade.", risk: "high", officialUrl: "https://ubuntu.com/security", sourceTitle: "Ubuntu security maintenance"),
  ProtectionCheck(id: "linux-10", platform: "Linux", groupAr: "تقوية Linux", groupEn: "Linux hardening", titleAr: "راجع الخدمات والمنافذ المستمعة", titleEn: "Review listening services and ports", detailAr: "اجرد الخدمات والمنافذ المستمعة دورياً، أوقف ما لا تحتاجه، وقيّد الوصول بجدار ناري أو شبكة إدارة موثوقة. لا تغلق منفذ إدارتك الوحيد قبل اختبار المسار البديل.", detailEn: "Periodically inventory listening services and ports, stop what you do not need, and restrict access with a firewall or trusted management network. Do not close your only management path before testing an alternative.", risk: "high", officialUrl: "https://www.cisecurity.org/controls", sourceTitle: "CIS Critical Security Controls"),
  ProtectionCheck(id: "privacy-01", platform: "All", groupAr: "الخصوصية والحسابات", groupEn: "Privacy & accounts", titleAr: "راجع جلسات تسجيل الدخول والأجهزة", titleEn: "Review sign-in sessions and devices", detailAr: "افتح صفحة الأمان الرسمية لكل حساب، راجع الأجهزة والجلسات والتطبيقات المرتبطة، وأنهِ الجلسة غير المعروفة من قناة موثوقة ثم غيّر كلمة المرور عند الشك.", detailEn: "Open each account's official security page, review devices, sessions, and connected apps, end unknown sessions through a trusted channel, and change the password when in doubt.", risk: "high", officialUrl: "https://support.google.com/accounts/answer/46526?hl=en", sourceTitle: "Secure a hacked or compromised Google Account"),
  ProtectionCheck(id: "identity-02", platform: "All", groupAr: "الهوية والوصول", groupEn: "Identity & access", titleAr: "افصل حساب الإدارة عن الحساب اليومي", titleEn: "Separate admin and daily-use accounts", detailAr: "استخدم حساباً يومياً محدود الصلاحيات، وحساباً إدارياً منفصلاً للمهام الحساسة. لا تستخدم حساب الإدارة للتصفح والبريد، وراجع أعضاء مجموعات الإدارة دورياً.", detailEn: "Use a least-privileged daily account and a separate administrative account for sensitive tasks. Do not use the admin account for browsing or email, and review admin-group membership regularly.", risk: "high", officialUrl: "https://www.cisecurity.org/controls/cis-controls-list", sourceTitle: "CIS Critical Security Controls"),
  ProtectionCheck(id: "identity-03", platform: "All", groupAr: "الهوية والوصول", groupEn: "Identity & access", titleAr: "طبّق MFA مقاومًا للتصيد للحسابات الحساسة", titleEn: "Use phishing-resistant MFA for sensitive accounts", detailAr: "ابدأ بالحسابات الإدارية والبريد والسحابة. فضّل مفاتيح الأمان أو passkeys عندما يدعمها المزود، ولا تعتمد على رمز يصل عبر قناة ضعيفة للحسابات الأعلى خطراً.", detailEn: "Start with administrator, email, and cloud accounts. Prefer security keys or passkeys when supported, and avoid weak out-of-band codes for the highest-risk accounts.", risk: "high", officialUrl: "https://www.cisa.gov/MFA", sourceTitle: "CISA Multi-Factor Authentication"),
  ProtectionCheck(id: "logging-01", platform: "All", groupAr: "الرؤية والسجلات", groupEn: "Visibility & logging", titleAr: "اجمع سجلات الدخول والتغييرات في مكان مركزي", titleEn: "Centralize sign-in and change logs", detailAr: "اجمع سجلات المصادقة وتغييرات الإعدادات والامتيازات من الأجهزة والخدمات المهمة. احمِ النقل والتخزين، وحدد من يقرأ السجلات ومن يستطيع حذفها.", detailEn: "Centralize authentication, configuration-change, and privilege-change logs from critical devices and services. Protect transport and storage, and restrict who can read or delete them.", risk: "high", officialUrl: "https://www.cisecurity.org/controls/cis-controls-list", sourceTitle: "CIS Control 8: Audit Log Management"),
  ProtectionCheck(id: "logging-02", platform: "All", groupAr: "الرؤية والسجلات", groupEn: "Visibility & logging", titleAr: "اضبط احتفاظ السجلات واختبر التنبيه", titleEn: "Set retention and test alerting", detailAr: "حدد مدة الاحتفاظ بحسب المخاطر والالتزامات، وأنشئ تنبيهات لتسجيلات الدخول غير المعتادة وتعطيل الحماية وتغيير الحسابات. اختبر التنبيه بسيناريو آمن موثق.", detailEn: "Set retention based on risk and obligations, and alert on unusual sign-ins, disabled protections, and account changes. Test alerts with a documented safe scenario.", risk: "medium", officialUrl: "https://www.cisa.gov/resources-tools/resources/enhanced-visibility-and-hardening-guidance-communications-infrastructure", sourceTitle: "CISA Enhanced Visibility and Hardening Guidance"),
  ProtectionCheck(id: "network-visibility-01", platform: "Network", groupAr: "الشبكة", groupEn: "Network", titleAr: "راقب تغييرات إعدادات أجهزة الشبكة", titleEn: "Monitor network-device configuration changes", detailAr: "احتفظ بنسخة مركزية من الإعدادات، وسجّل تغييرات ACL والمستخدمين والبروتوكولات والمسارات خارج عملية إدارة التغيير. لا تجعل الجهاز نفسه المصدر الوحيد الموثوق لإعداده.", detailEn: "Keep configurations centrally and log changes to ACLs, users, protocols, and routes outside the change-management process. Do not let the device be the only source of truth for its configuration.", risk: "high", officialUrl: "https://www.cisa.gov/resources-tools/resources/enhanced-visibility-and-hardening-guidance-communications-infrastructure", sourceTitle: "CISA Enhanced Visibility and Hardening Guidance"),
  ProtectionCheck(id: "network-visibility-02", platform: "Network", groupAr: "الشبكة", groupEn: "Network", titleAr: "اعزل إدارة الشبكة عن الإنترنت", titleEn: "Isolate network management from the Internet", detailAr: "استخدم شبكة إدارة مخصصة أو مساراً خارجياً مع ضوابط وصول قوية ومحطات إدارية مخصصة. لا تسمح بإدارة أجهزة الشبكة مباشرة من الإنترنت.", detailEn: "Use a dedicated management network or out-of-band path with strong access controls and dedicated admin workstations. Do not manage network devices directly from the Internet.", risk: "high", officialUrl: "https://www.cisa.gov/resources-tools/resources/enhanced-visibility-and-hardening-guidance-communications-infrastructure", sourceTitle: "CISA Enhanced Visibility and Hardening Guidance"),
  ProtectionCheck(id: "backup-02", platform: "All", groupAr: "الاستعادة", groupEn: "Recovery", titleAr: "اختبر استعادة نسخة احتياطية معزولة", titleEn: "Test restoration from an isolated backup", detailAr: "لا تكتفِ بوجود نسخة احتياطية. اختبر استعادة ملفات وخدمة أساسية في بيئة منفصلة، وسجّل الزمن والاعتماديات، وتأكد من أن النسخة لا يمكن تعديلها من الحساب اليومي.", detailEn: "Do not rely on backup existence alone. Test restoring a critical file and service in an isolated environment, record timing and dependencies, and ensure the daily-use account cannot alter the backup.", risk: "high", officialUrl: "https://www.cisecurity.org/controls/cis-controls-list", sourceTitle: "CIS Control 11: Data Recovery"),
  ProtectionCheck(id: "supply-chain-02", platform: "All", groupAr: "سلسلة التوريد", groupEn: "Supply chain", titleAr: "ولّد SBOM لكل إصدار مهم", titleEn: "Generate an SBOM for important releases", detailAr: "أنشئ قائمة مكونات برمجية لكل إصدار، اربطها برقم الإصدار، وافحصها ضد الثغرات قبل النشر. لا تعتبر SBOM بديلاً عن الاختبار أو المراجعة.", detailEn: "Generate a software bill of materials for each important release, tie it to the version, and scan it for vulnerabilities before publishing. An SBOM does not replace testing or review.", risk: "medium", officialUrl: "https://www.cisa.gov/sbom", sourceTitle: "CISA Software Bill of Materials"),
  ProtectionCheck(id: "cloud-01", platform: "Cloud", groupAr: "السحابة", groupEn: "Cloud", titleAr: "راجع الموارد المكشوفة خارجياً", titleEn: "Review externally exposed cloud resources", detailAr: "اجرد عناوين التخزين وقواعد البيانات وواجهات الإدارة والخدمات العامة، وأزل التعرض غير الضروري. اختبر من خارج الشبكة الداخلية وتحقق من السجلات بعد التغيير.", detailEn: "Inventory public storage, databases, management APIs, and services, then remove unnecessary exposure. Test from outside the internal network and verify logs after changes.", risk: "high", officialUrl: "https://www.cisecurity.org/controls/cis-controls-list", sourceTitle: "CIS Critical Security Controls"),
  ProtectionCheck(id: "container-01", platform: "Cloud", groupAr: "الحاويات", groupEn: "Containers", titleAr: "شغّل الحاويات بأقل صلاحيات", titleEn: "Run containers with least privilege", detailAr: "تجنب التشغيل كـ root عندما لا يلزم، قلل Linux capabilities، اجعل نظام الملفات للقراءة فقط حيث يمكن، وثبت الصور بإصدار أو digest بدلاً من latest.", detailEn: "Avoid running as root when unnecessary, reduce Linux capabilities, use a read-only filesystem where possible, and pin images to a version or digest instead of latest.", risk: "high", officialUrl: "https://www.cisecurity.org/controls/cis-controls-list", sourceTitle: "CIS Critical Security Controls"),

];

const List<IncidentPlaybook> incidentPlaybooks = <IncidentPlaybook>[
  IncidentPlaybook(
    id: "account-takeover-response-01",
    titleAr: "استجابة الاستيلاء على الحساب واستعادة السيطرة",
    titleEn: "Account Takeover Response and Recovery",
    summaryAr:
        "دليل متسلسل وآمن لاستعادة حساب يُشتبه في الاستيلاء عليه، وتقليل الضرر، والتحقق من الأجهزة والإعدادات والحسابات المرتبطة. استخدم فقط مواقع الدعم الرسمية التي تكتب عنوانها مباشرة أو تصل إليها من موقع المزود الرسمي؛ تختلف أسماء القوائم وخيارات الاسترداد حسب المزود والجهاز.",
    summaryEn:
        "A sequential, safety-focused playbook to regain control of a suspected taken-over account, reduce harm, and check devices, settings, and linked accounts. Use only official support sites reached by typing the provider address directly or navigating from its official site; menu names and recovery options vary by provider and device.",
    whenExpertAr:
        "صعّد فوراً إلى دعم المزود الرسمي إذا تغيّرت كلمة المرور أو وسائل الاسترداد أو تعذر تسجيل الدخول، وإلى البنك/جهة الدفع عند وجود معاملة غير مصرح بها. اتصل بشركة الاتصالات إذا اشتُبه في تحويل رسائل SMS أو السيطرة على الرقم، وبمسؤول تقنية المعلومات إذا كان الحساب للعمل أو المدرسة. أبلغ الشرطة/الجهة الوطنية المختصة عند سرقة أموال أو هوية أو وجود تهديد، واتصل بخدمات الطوارئ المحلية عند وجود خطر فوري على الحياة أو السلامة. لا تعتمد على جهات خارجية تعدك باسترداد الحساب أو المال.",
    whenExpertEn:
        "Escalate immediately to the provider’s official support if the password or recovery methods were changed or sign-in is unavailable, and to the bank/payment provider for any unauthorized transaction. Contact the mobile carrier if SMS forwarding or number takeover is suspected, and workplace/school IT for an organizational account. Report to police or the relevant national cybercrime authority for stolen money, identity theft, or threats; call local emergency services for an immediate threat to life or safety. Do not trust third parties promising to recover the account or money.",
    steps: <ResponseStep>[
      ResponseStep(
        titleAr: "1. احتوِ الوصول المشتبه به",
        titleEn: "1. Contain the suspected access",
        detailAr:
            "إذا كان جهاز متصل بالحساب متأثراً أو يتصرف بشكل غير معتاد، افصل الجهاز المتأثر عن الإنترنت مؤقتاً. أوقف أي استخدام مالي أو حساس من جهاز يُشتبه في إصابته، ونبّه جهات الاتصال إلى تجاهل الروابط أو المرفقات غير المعتادة. على الهاتف قد تختلف أدوات العزل حسب نظام التشغيل؛ اتبع خيارات النظام أو إرشادات الشركة المصنعة المتاحة.",
        detailEn:
            "If a device connected to the account is affected or behaving unusually, temporarily disconnect the affected device from the internet. Stop financial or sensitive activity from a device you suspect is compromised, and warn contacts to ignore unusual links or attachments. On phones, isolation controls vary by operating system; use the available OS or manufacturer guidance.",
        risk: "high",
        officialUrl: "https://www.cyber.gov.au/guidance/recover-from-email-and-online-account-compromise",
        sourceTitle:
            "Recover from hacking — Australian Signals Directorate’s Australian Cyber Security Centre (ASD’s ACSC)",
      ),
      ResponseStep(
        titleAr: "2. افحص الجهاز قبل تغيير كلمة المرور",
        titleEn: "2. Scan the device before changing the password",
        detailAr:
            "حدّث برنامج الحماية وشغّل فحصاً كاملاً بحثاً عن برمجيات ضارة قبل تغيير كلمة المرور، خصوصاً على جهاز Windows. احذف البرمجيات المشبوهة فقط وفق أداة الحماية أو تعليمات المزود الرسمية، ثم أعد التشغيل عند طلبها. لا تفترض أن خطوات فحص الحاسوب تنطبق حرفياً على كل هاتف؛ استخدم أداة الأمان الرسمية لنظامك.",
        detailEn:
            "Update security software and run a full malware scan before changing the password, especially on a Windows PC. Remove suspicious software only through the security tool or the provider’s official instructions, then restart if instructed. Do not assume PC scanning steps apply identically to every phone; use the official security controls for your OS.",
        risk: "high",
        officialUrl:
            "https://support.microsoft.com/en-us/accounts-billing/manage/how-to-recover-a-hacked-or-compromised-microsoft-account",
        sourceTitle:
            "How to recover a hacked or compromised Microsoft account — Microsoft Support",
      ),
      ResponseStep(
        titleAr: "3. استعد الحساب وغيّر كلمة المرور",
        titleEn: "3. Recover the account and change the password",
        detailAr:
            "افتح صفحة المساعدة أو الاسترداد الرسمية للمزود مباشرة واتبع عملية إثبات الملكية؛ إذا كان الحساب ما زال متاحاً، غيّر كلمة المرور إلى كلمة قوية وفريدة. غيّر أيضاً كلمات مرور الحسابات الأخرى التي أعادت استخدام كلمة المرور نفسها، ولا تستخدم كلمة مرور الحساب المخترق في أي خدمة أخرى. إذا غُيّرت معلومات الاسترداد أو تعذر الدخول، استخدم مسار الاسترداد الرسمي؛ قد يفرض المزود فترة انتظار أو يطلب معلومات تحقق إضافية.",
        detailEn:
            "Open the provider’s official help or recovery page directly and follow its ownership-verification process; if you still have access, change the password to a strong, unique one. Also change passwords on other accounts where the same password was reused, and never reuse the compromised password. If recovery information was changed or sign-in is unavailable, use the provider’s official recovery path; the provider may impose a waiting period or require additional verification.",
        risk: "high",
        officialUrl:
            "https://www.ncsc.gov.uk/guidance/recovering-a-hacked-account",
        sourceTitle:
            "Recovering a hacked account — UK National Cyber Security Centre (NCSC)",
      ),
      ResponseStep(
        titleAr: "4. أنهِ الجلسات وافحص النشاط",
        titleEn: "4. Sign out sessions and review activity",
        detailAr:
            "بعد تغيير كلمة المرور، سجّل الخروج من جميع الأجهزة والتطبيقات من إعدادات الحساب إن كان الخيار متاحاً، ثم راجع الأجهزة أو المواقع أو عمليات الدخول غير المعروفة. افحص البريد المرسل والمحذوف، وقواعد إعادة توجيه البريد، والمنشورات أو الرسائل التي لم تنشئها؛ احذف قواعد التوجيه غير المعروفة وسجّل ما وجدته. قد لا يوفر كل مزود زر تسجيل خروج شامل أو نفس سجل النشاط.",
        detailEn:
            "After changing the password, sign out of all devices and apps from account settings if the option is available, then review unfamiliar devices, locations, or sign-ins. Check sent and deleted mail, email-forwarding rules, and posts or messages you did not create; remove forwarding rules you did not set and record what you found. Not every provider offers a global sign-out control or the same activity history.",
        risk: "high",
        officialUrl:
            "https://consumer.ftc.gov/consumer-alerts/2024/10/email-or-social-media-hacked-heres-what-do",
        sourceTitle:
            "How To Recover Your Hacked Email or Social Media Account — U.S. Federal Trade Commission (FTC)",
      ),
      ResponseStep(
        titleAr: "5. صحّح وسائل الاسترداد والأجهزة الموثوقة",
        titleEn: "5. Correct recovery methods and trusted devices",
        detailAr:
            "تحقق من أن بريد الاسترداد وأرقام الهاتف ووسائل الأمان تخصك ويمكنك الوصول إليها، وأزل الأجهزة غير المعروفة من صفحة الحساب إذا كان المزود يتيح ذلك. بالنسبة للحسابات المرتبطة بالهاتف، تحقق مع شركة الاتصالات من عدم إعداد تحويل SMS غير مصرح به. في Apple، قد يلزم استخدام iforgot.apple.com ومرور فترة استرداد إذا تعذر تغيير كلمة المرور؛ هذه التفاصيل خاصة بالمزود.",
        detailEn:
            "Verify that recovery email addresses, phone numbers, and security methods belong to you and are accessible, and remove unrecognized devices from the account page if the provider supports it. For phone-linked accounts, check with the carrier that unauthorized SMS forwarding has not been set up. For Apple Accounts, if the password cannot be changed, Apple may require iforgot.apple.com and an account-recovery waiting period; these details are provider-specific.",
        risk: "high",
        officialUrl: "https://support.apple.com/en-us/102560",
        sourceTitle:
            "If you think your Apple Account has been compromised — Apple Support",
      ),
      ResponseStep(
        titleAr: "6. فعّل التحقق متعدد العوامل وحدّث الجهاز",
        titleEn: "6. Enable multi-factor authentication and update the device",
        detailAr:
            "فعّل التحقق بخطوتين أو المصادقة متعددة العوامل للحساب، خصوصاً البريد والحسابات المالية، إذا كان المزود يدعمها. ثبّت تحديثات نظام التشغيل والتطبيقات وشغّل التحديث التلقائي عند توفره. طريقة المصادقة (تطبيق، مفتاح أمان، SMS أو غير ذلك) وتوافرها يحددهما المزود والجهاز؛ لا تشارك رموز التحقق مع أي شخص.",
        detailEn:
            "Enable two-step verification or multi-factor authentication for the account, especially email and financial accounts, if the provider supports it. Install operating-system and app updates and enable automatic updates when available. The authentication method (app, security key, SMS, or another option) and its availability are provider- and device-dependent; never share verification codes.",
        risk: "medium",
        officialUrl:
            "https://www.ncsc.gov.uk/guidance/recovering-a-hacked-account",
        sourceTitle:
            "Recovering a hacked account — UK National Cyber Security Centre (NCSC)",
      ),
      ResponseStep(
        titleAr: "7. افحص الأثر وصعّد وأبلغ",
        titleEn: "7. Check impact, escalate, and report",
        detailAr:
            "راجع المعاملات والمشتريات والحسابات المرتبطة بحثاً عن نشاط غير مصرح به. اتصل بالبنك أو جهة الدفع فوراً عبر رقم أو موقع رسمي لطلب المساعدة أو إيقاف المعاملات عند الحاجة. أخبر جهات الاتصال بما حدث كي لا يثقوا برسائل الحساب، وسجّل ماذا حدث ومتى وعلى أي منصة وما الإجراءات التي اتخذتها. أبلغ الجهة الوطنية المختصة أو الشرطة وفق بلدك عند فقدان المال أو سرقة المعلومات أو التهديد؛ في أستراليا يوجه ACSC إلى نموذج الإبلاغ، وفي المملكة المتحدة إلى Report Fraud. إذا لم يمكن استرداد الحساب، اتبع تعليمات المزود بشأن حساب بديل وأخبر جهات الاتصال بتعطيل الحساب القديم.",
        detailEn:
            "Review transactions, purchases, and linked accounts for unauthorized activity. Contact the bank or payment provider immediately through an official number or website for help or to stop transactions when appropriate. Tell contacts what happened so they do not trust messages from the account, and record what happened, when, on which platform, and what actions you took. Report to the relevant national authority or police for lost money, stolen information, or threats; ACSC directs Australian users to its reporting form, while the UK NCSC directs users to Report Fraud. If the account cannot be recovered, follow the provider’s instructions for a replacement account and tell contacts the old account is abandoned.",
        risk: "medium",
        officialUrl: "https://www.cyber.gov.au/guidance/recover-from-email-and-online-account-compromise",
        sourceTitle:
            "Recover from hacking — Australian Signals Directorate’s Australian Cyber Security Centre (ASD’s ACSC)",
      ),
    ],
  ),
  IncidentPlaybook(
    id: "phishing-incident-response",
    titleAr: "الاستجابة لرسالة تصيد أو مرفق مشبوه",
    titleEn: "Phishing or Suspicious Attachment Response",
    summaryAr:
        "خطة تعافٍ متسلسلة وآمنة بعد استلام رسالة تصيد أو فتح رابط/مرفق مشبوه، مع تكييف أسماء الأزرار حسب مزود البريد والجهاز.",
    summaryEn:
        "A sequential, safety-first recovery plan after receiving phishing or opening a suspicious link/attachment; button names vary by mail provider and device.",
    whenExpertAr:
        "صعّد فوراً إلى قسم تقنية المعلومات/الأمن إذا كان الجهاز أو الحساب للعمل/الدراسة، أو إذا فُتح مرفق/ثُبّت برنامج على جهاز مُدار. اتصل بالبنك أو جهة إصدار البطاقة فوراً عند مشاركة بيانات مالية أو ظهور معاملة غير معروفة. اطلب مساعدة مزود الحساب عند فقدان الوصول أو الاشتباه في اختراق، وأبلغ الشرطة/جهة مكافحة الاحتيال عند خسارة مال أو سرقة هوية. لا تستخدم هذه الخطة بدلاً من تعليمات مزود الجهاز أو الحساب.",
    whenExpertEn:
        "Escalate immediately to work/school IT or security if a work/school device or account was involved, or if an attachment was opened/software installed on a managed device. Contact the bank or card issuer immediately if financial details were shared or an unknown transaction appears. Ask the account provider for help if access is lost or takeover is suspected, and report to law enforcement/fraud authorities after money loss or identity theft. Do not substitute this playbook for provider- or device-specific instructions.",
    steps: <ResponseStep>[
      ResponseStep(
        titleAr: "1. أوقف التفاعل واعزل الخطر",
        titleEn: "1. Stop interacting and contain the risk",
        detailAr:
            "لا ترد، ولا تضغط أي رابط، ولا تفتح أو تعاين المرفق، ولا تستخدم رابط إلغاء الاشتراك في الرسالة. إذا بدا أن الرسالة قد تكون حقيقية، افتح موقع الجهة أو تطبيقها بكتابة العنوان/استخدام إشارة محفوظة، أو تحقّق من المرسل عبر قناة أخرى. على Android يمكن الضغط المطوّل على الرابط لرؤية وجهته، وعلى iOS استخدم الضغط المطوّل الخفيف؛ لا تفتح الوجهة. هذه الخطوات تمنع تفاعلاً إضافياً لكنها لا تثبت أن الجهاز سليم إذا سبق فتح الرابط أو المرفق.",
        detailEn:
            "Do not reply, click any link, open or preview the attachment, or use the message’s unsubscribe link. If it might be legitimate, open the organization’s site or app by typing the address or using a trusted saved favorite, or verify the sender through another channel. On Android, long-press a link to view its destination; on iOS use a light long-press—do not open the destination. This limits further interaction but does not establish that a device is clean if the link or attachment was already opened.",
        risk: "high",
        officialUrl:
            "https://www.cisa.gov/secure-our-world/recognize-and-report-phishing",
        sourceTitle: "CISA — Recognize and Report Phishing",
      ),
      ResponseStep(
        titleAr: "2. أبلغ الرسالة ثم احذفها",
        titleEn: "2. Report the message, then delete it",
        detailAr:
            "استخدم خيار الإبلاغ عن التصيد/الرسائل المزعجة في تطبيق البريد، ثم احذف الرسالة. في Gmail: افتح الرسالة > المزيد > الإبلاغ عن تصيد. في Outlook/Microsoft 365: حدّد الرسالة > Report > Report phishing. في تطبيقات أخرى تختلف الأزرار؛ اتبع تعليمات مزود البريد، ولا تعِد توجيه الرسالة إلى شخص قد يفتحها. إذا كانت الرسالة تخص العمل، أبلغ قناة الأمن/الدعم الداخلية وفق السياسة.",
        detailEn:
            "Use the mail app’s phishing/spam reporting control, then delete the message. In Gmail: open the message > More > Report phishing. In Outlook/Microsoft 365: select the message > Report > Report phishing. Other apps use different controls; follow the provider’s instructions and do not forward the message to someone who might open it. For work mail, also notify the organization’s security/support channel according to policy.",
        risk: "low",
        officialUrl: "https://support.google.com/mail/answer/8253?hl=en",
        sourceTitle: "Google Gmail Help — Avoid & report phishing emails",
      ),
      ResponseStep(
        titleAr: "3. وثّق ما حدث قبل زوال التفاصيل",
        titleEn: "3. Record what happened while details are fresh",
        detailAr:
            "دوّن وقت الحادثة، التطبيق/الجهاز، عنوان المرسل أو رقم الهاتف، اسم المرفق، الرابط كما ظهر دون فتحه، وما إذا نقرت أو فتحت أو أدخلت بيانات، وأي اسم مستخدم/رقم حساب/كلمة مرور شاركتها. احتفظ بلقطة شاشة آمنة إن أمكن من دون إعادة فتح المرفق. لا تسجّل كلمات المرور في ملاحظات غير محمية ولا تشاركها مع أي جهة.",
        detailEn:
            "Write down the time, app/device, sender address or phone number, attachment name, the link as displayed without opening it, whether you clicked/opened/entered data, and any username, account number, or password you shared. Keep a safe screenshot if possible without reopening the attachment. Do not store passwords in unprotected notes or disclose them to anyone.",
        risk: "medium",
        officialUrl:
            "https://support.microsoft.com/en-us/security/protect-yourself-from-phishing",
        sourceTitle: "Microsoft Support — Protect yourself from phishing",
      ),
      ResponseStep(
        titleAr: "4. غيّر بيانات الدخول وفعّل التحقق متعدد العوامل",
        titleEn: "4. Change credentials and enable multifactor authentication",
        detailAr:
            "إذا أُدخلت كلمة مرور أو رمز دخول، غيّر كلمة مرور الحساب المتأثر فوراً من تطبيق/موقع رسمي مستقل، ثم غيّرها في كل حساب آخر استخدم كلمة المرور نفسها؛ استخدم كلمات فريدة. فعّل التحقق متعدد العوامل لكل حساب يتيحه. إذا فقدت الوصول، استخدم استرداد الحساب الرسمي لمزود الخدمة. لا تستخدم رابط الاسترداد الموجود في الرسالة. لا تكفي هذه الخطوة وحدها إذا كان الجهاز قد ثُبّت عليه برنامج ضار.",
        detailEn:
            "If a password or sign-in code was entered, change the affected account’s password immediately through the provider’s independent official app/site, then change it anywhere the same password was reused; use unique passwords. Enable multifactor authentication wherever available. If locked out, use the provider’s official account-recovery process. Do not use a recovery link from the message. This step alone is not sufficient if malware may have been installed on the device.",
        risk: "high",
        officialUrl:
            "https://www.ncsc.gov.uk/collection/phishing-scams/what-to-do",
        sourceTitle:
            "UK National Cyber Security Centre — Phishing scams: If you've shared sensitive information",
      ),
      ResponseStep(
        titleAr: "5. احمِ المال والهوية إذا كُشفت بياناتها",
        titleEn: "5. Protect money and identity if those details were exposed",
        detailAr:
            "إذا شاركت بيانات البنك أو البطاقة أو ظهرت معاملة غير معروفة، اتصل بالبنك/جهة إصدار البطاقة فوراً باستخدام رقم رسمي من البطاقة أو كشف الحساب، واطلب إيقاف/مراجعة المعاملات وفق ما يتيحه البنك. إذا كُشفت بيانات هوية أو رقم حكومي، استخدم بوابة الجهة الحكومية الرسمية الخاصة بسرقة الهوية؛ إذا خَسرت مالاً، أبلغ جهة مكافحة الاحتيال أو الشرطة المحلية. الإجراءات والجهات تختلف حسب البلد والبنك.",
        detailEn:
            "If banking/card details were shared or an unknown transaction appears, contact the bank/card issuer immediately using a trusted number from the card or statement and ask about blocking/reviewing transactions as the bank permits. If identity or government-ID data was exposed, use the relevant government identity-theft portal; after money loss, report to the appropriate fraud authority or local police. Procedures and authorities vary by country and bank.",
        risk: "high",
        officialUrl:
            "https://www.ncsc.gov.uk/collection/phishing-scams/what-to-do",
        sourceTitle:
            "UK National Cyber Security Centre — Phishing scams: If you've shared sensitive information",
      ),
      ResponseStep(
        titleAr: "6. افحص الجهاز إذا فُتح الرابط أو المرفق",
        titleEn: "6. Scan the device if a link or attachment was opened",
        detailAr:
            "إذا فُتح رابط، أو مرفق، أو ثُبّت برنامج بناءً على الرسالة، حدّث برنامج الحماية/الأمان ثم شغّل فحصاً كاملاً واتركه ينظف ما يجده. على جهاز العمل أو الدراسة لا تثبّت أدوات فحص من الرسالة ولا تحاول إصلاحه ذاتياً قبل إبلاغ تقنية المعلومات. توفر الفحص الكامل والتنظيف وخيارات العزل يختلف حسب نظام التشغيل، الجهاز، وتطبيق الحماية؛ اتبع تعليمات المورد.",
        detailEn:
            "If you opened a link or attachment, or installed software because of the message, update the device’s security software, run a full scan, and allow it to clean problems it finds. On a work or school device, do not install a scanner from the message or attempt self-remediation before notifying IT. Full-scan, cleanup, and isolation features vary by operating system, device, and security product; follow the vendor’s instructions.",
        risk: "high",
        officialUrl:
            "https://www.ncsc.gov.uk/collection/phishing-scams/what-to-do",
        sourceTitle:
            "UK National Cyber Security Centre — Phishing scams: If you've shared sensitive information",
      ),
      ResponseStep(
        titleAr: "7. صعّد الحادثة وتابع مؤشرات الاختراق",
        titleEn: "7. Escalate and monitor for signs of compromise",
        detailAr:
            "أبلغ تقنية المعلومات/الأمن إذا كان الحساب أو الجهاز للعمل/الدراسة، أو إذا أُرسلت رسائل غير معروفة من حسابك أو تعذر تسجيل الدخول. راقب تنبيهات تسجيل الدخول، تغيّر بيانات الاسترداد، والعمليات المالية غير المعروفة، واستخدم مسار استرداد مزود الحساب عند الحاجة. صعّد إلى البنك فوراً عند مؤشرات احتيال، وإلى الشرطة/جهة مكافحة الاحتيال عند خسارة مال أو سرقة هوية. لا تفترض أن حذف الرسالة أنهى الاختراق.",
        detailEn:
            "Notify work/school IT or security if the account/device was organizational, if unrecognized messages were sent from your account, or if you cannot sign in. Monitor sign-in alerts, changed recovery details, and unknown financial activity, and use the provider’s account-recovery path when needed. Escalate to the bank immediately for fraud indicators, and to police/fraud authorities after money loss or identity theft. Do not assume deleting the message ended a compromise.",
        risk: "high",
        officialUrl:
            "https://support.microsoft.com/en-us/security/protect-yourself-from-phishing",
        sourceTitle: "Microsoft Support — Protect yourself from phishing",
      ),
    ],
  ),
  IncidentPlaybook(
    id: "ransomware-mobile-incident-response",
    titleAr: "خطة الاستجابة والتعافي من برمجية الفدية للأجهزة المحمولة",
    titleEn: "Mobile-device ransomware response and recovery playbook",
    summaryAr:
        "اتبع الخطوات بالترتيب: اعزل الجهاز، احفظ الأدلة، أبلغ وصعّد، أمّن الحسابات من جهاز نظيف، ثم استخدم مسار التنظيف المناسب لنظام Android أو iPhone/iPad، واستعد فقط من نسخة احتياطية موثوقة، ثم راقب قبل إعادة الاتصال الكامل. لا تدفع الفدية منفرداً؛ لا تضمن إتاحة البيانات وقد يبقى الجهاز مصاباً.",
    summaryEn:
        "Follow the steps in order: isolate the device, preserve evidence, report and escalate, secure accounts from a clean device, use the appropriate Android or iPhone/iPad cleanup path, restore only from a trusted backup, then monitor before full reconnection. Do not pay a ransom on your own: payment does not guarantee data access and the device may remain infected.",
    whenExpertAr:
        "اطلب فوراً مساعدة فريق تقنية المعلومات/الاستجابة للحوادث أو الشركة المصنّعة/مزود الخدمة إذا كان الجهاز تابعاً للعمل، أو أصيبت عدة أجهزة/حسابات، أو كانت بيانات حساسة قد سُرّبت، أو لا يمكن عزل الجهاز، أو استمرت الأعراض بعد إعادة الضبط، أو تم دفع المال/إدخال بيانات مالية. لا تُجرِ إعادة ضبط أو تستعيد نسخة احتياطية قبل حفظ الأدلة إذا كان التحقيق أو الإبلاغ مطلوباً.",
    whenExpertEn:
        "Immediately involve IT/incident-response staff or the device maker/service provider if the device is work-managed, multiple devices or accounts are affected, sensitive data may have been exfiltrated, the device cannot be isolated, symptoms persist after reset, or money/financial credentials were provided. Do not reset or restore a backup before evidence preservation when investigation or reporting is required.",
    steps: <ResponseStep>[
      ResponseStep(
        titleAr: "1. اعزل الجهاز فوراً عن الشبكات",
        titleEn: "1. Immediately isolate the device from networks",
        detailAr:
            "أوقف Wi‑Fi وبيانات الهاتف وافصل كابل الشبكة إن وُجد، واعزل أي جهاز متأثر عن كل الاتصالات. إذا كانت عدة أجهزة أو شبكة مؤسسة متأثرة، لا تُطفئ معدات الشبكة بنفسك إلا وفق تعليمات مسؤول تقنية المعلومات. لا تطفئ الجهاز إذا أمكن فصله عن الشبكة؛ توصي CISA بإيقاف التشغيل فقط عندما يتعذر العزل، لأن الإيقاف قد يفقد أدلة موجودة في الذاكرة.",
        detailEn:
            "Turn off Wi‑Fi and mobile data and unplug any Ethernet cable; isolate every affected device from all network connections. If multiple devices or an organisational network are affected, do not shut down network equipment unless directed by IT. Do not power off when network isolation is possible; CISA says to power down only when disconnection cannot be achieved because shutdown can lose volatile evidence.",
        risk: "high",
        officialUrl:
            "https://www.cisa.gov/stopransomware/ive-been-hit-ransomware",
        sourceTitle: "CISA — I've Been Hit By Ransomware!",
      ),
      ResponseStep(
        titleAr: "2. احفظ الأدلة قبل المسح أو إعادة الضبط",
        titleEn: "2. Preserve evidence before wiping or resetting",
        detailAr:
            "لا تحذف رسالة الفدية أو الملفات والسجلات ذات الصلة، ولا تبدأ المسح أو إعادة الضبط قبل توثيق ما ظهر (الوقت، الجهاز، الحسابات والملفات المتأثرة) وطلب المشورة. قد يحتاج المختص إلى صورة للنظام أو التقاط للذاكرة والسجلات؛ إذا تعذر أي إجراء احتواء آخر، اتبع تعليمات المختص لأن إيقاف التشغيل قد يزيل أدلة متطايرة.",
        detailEn:
            "Do not delete the ransom note or relevant files/logs, and do not start wiping or resetting before recording what happened (time, device, accounts, and affected files) and obtaining advice. An expert may need a system image, memory capture, and logs; if no other containment is possible, follow expert instructions because powering down can destroy volatile evidence.",
        risk: "high",
        officialUrl:
            "https://www.cisa.gov/stopransomware/ive-been-hit-ransomware",
        sourceTitle: "CISA — I've Been Hit By Ransomware!",
      ),
      ResponseStep(
        titleAr: "3. أبلغ وصعّد ولا تتخذ قرار الدفع منفرداً",
        titleEn: "3. Report and escalate; do not decide on payment alone",
        detailAr:
            "أبلغ جهة العمل/مسؤول الأمن أو مزود الخدمة، وشركة التأمين السيبراني إن وُجدت. في الولايات المتحدة تذكر CISA قنوات CISA وFBI/IC3؛ وفي المملكة المتحدة توجّه NCSC إلى Report Fraud؛ استخدم القناة الحكومية الرسمية في بلدك خارج ذلك. لا تشجع NCSC دفع الفدية أو تضمنه: لا يضمن الدفع استعادة البيانات وقد يبقى الجهاز مصاباً ويزيد الاستهداف لاحقاً. لا تتواصل مع المهاجم أو تدفع قبل استشارة مختص والجهات المختصة.",
        detailEn:
            "Notify your employer/security contact or service provider and any cyber-insurer. In the United States, CISA lists CISA and FBI/IC3 reporting routes; in the UK, NCSC directs victims to Report Fraud; elsewhere use your national government cyber-reporting channel. The NCSC does not encourage, endorse, or condone ransom payment: payment does not guarantee recovery, the device may remain infected, and future targeting may become more likely. Do not contact the attacker or pay before expert and authority advice.",
        risk: "medium",
        officialUrl:
            "https://www.ncsc.gov.uk/section/respond-recover/sole-ransomware-attack",
        sourceTitle: "NCSC — Ransomware attack",
      ),
      ResponseStep(
        titleAr: "4. أوقف تسجيل الدخول وأمّن الحسابات من جهاز نظيف",
        titleEn: "4. Stop logins and secure accounts from a clean device",
        detailAr:
            "لا تسجّل الدخول إلى الخدمات المصرفية أو التسوق أو الحسابات الحساسة من الجهاز المصاب. من جهاز موثوق ونظيف، غيّر كلمات المرور المتأثرة أو المعاد استخدامها، فعّل المصادقة الثنائية، وراجع نشاط الحساب. لا تستخدم كلمات مرور أو رموز استرداد مخزنة على الجهاز المصاب. قد تختلف خطوات الاسترداد حسب مزود الحساب؛ لا تغيّر حساباً إدارياً بطريقة قد تمنع الوصول إلى أنظمة التعافي دون تنسيق مع المختص.",
        detailEn:
            "Do not log in to banking, shopping, or other sensitive services from the infected device. From a trusted, clean device, change affected or reused passwords, enable two-factor authentication, and review account activity. Do not use passwords or recovery codes stored on the infected device. Recovery steps vary by account provider; do not change an administrator account in a way that locks responders out of recovery systems without coordination.",
        risk: "medium",
        officialUrl:
            "https://www.ftc.gov/media/79889",
        sourceTitle:
            "FTC — Malware: How To Protect Against, Detect, and Remove It",
      ),
      ResponseStep(
        titleAr: "5. إذا كان الجهاز Android: افحصه ونظّفه وفق تعليمات Google",
        titleEn:
            "5. If it is Android: scan and clean it using Google's guidance",
        detailAr:
            "بعد العزل، فعّل Google Play Protect، ثبّت تحديثات Android وتحديثات الأمان، وأزل التطبيقات غير الموثوقة أو التي لم تحصل عليها من Google Play. راجع Security Checkup للحساب. إذا استمرت علامات البرمجية الخبيثة، تقول Google إنك قد تحتاج إلى إعادة ضبط الجهاز أو مساعدة الشركة المصنّعة. تختلف أسماء القوائم والخطوات حسب إصدار Android والشركة المصنّعة؛ استخدم تعليمات الدعم الرسمية لجهازك.",
        detailEn:
            "After isolation, turn on Google Play Protect, install Android and security updates, and remove apps you do not trust or did not get from Google Play. Run the account Security Checkup. If malware signs continue, Google says you may need to reset the Android device or ask the device maker for help. Menu names and exact steps vary by Android version and manufacturer; use the device maker's official support instructions.",
        risk: "high",
        officialUrl:
            "https://support.google.com/accounts/answer/9924802?hl=en&co=GENIE.Platform%3DAndroid",
        sourceTitle:
            "Google Account Help — Remove malware or unsafe software (Android phone & tablet)",
      ),
      ResponseStep(
        titleAr: "6. إذا كان الجهاز iPhone أو iPad: استخدم المسح الرسمي بحذر",
        titleEn:
            "6. If it is an iPhone or iPad: use the official erase path carefully",
        detailAr:
            "إذا كان الاشتباه ببرمجية خبيثة أو عبث بالجهاز قوياً، توضح Apple أن إعادة ضبط المصنع تمسح كل المحتوى والإعدادات والتطبيقات. راجع Safety Check أولاً عند ملاءمته، وتأكد من رمز الجهاز وكلمة مرور Apple Account والاتصال بالإنترنت. تحذّر Apple من استعادة نسخة احتياطية إذا كان سبب المسح هو إزالة برمجية خبيثة، لأن النسخة قد تعيدها. لا تبدأ المسح قبل حفظ الأدلة والتأكد من النسخ المطلوبة؛ تفاصيل المسار تعتمد على إصدار الجهاز والنظام.",
        detailEn:
            "When malware or tampering is a serious concern, Apple says a factory restore erases all content, settings, and apps. Use Safety Check first where appropriate, and ensure you have the device passcode, Apple Account password, and internet access. Apple warns not to restore from a backup when erasing to remove malicious software because the backup may reinstall it. Preserve evidence and verify what data is needed before erasing; the exact path depends on the device and OS version.",
        risk: "high",
        officialUrl:
            "https://support.apple.com/guide/personal-safety/restore-device-to-factory-settings-ips4603248a8/web",
        sourceTitle:
            "Apple Personal Safety User Guide — Restore device to factory settings",
      ),
      ResponseStep(
        titleAr: "7. استعد فقط من نسخة احتياطية سليمة وعلى شبكة نظيفة",
        titleEn: "7. Restore only from a known-clean backup on a clean network",
        detailAr:
            "بعد إزالة العدوى أو إعادة تثبيت النظام، لا تستعد إلا من آخر نسخة احتياطية معروفة السلامة؛ افحص النسخة أو اطلب من المختص تأكيد سلامتها. توصي CISA بالاستعادة من نسخ احتياطية غير متصلة ومشفّرة عند توفرها، وعلى شبكة استرداد نظيفة، مع ترتيب الخدمات الحرجة أولاً. لا تعِد نسخة احتياطية مشتبه بها إلى جهاز أعيد ضبطه، ولا تعِد توصيل أجهزة أخرى قبل التأكد من نظافتها.",
        detailEn:
            "After malware removal or OS reinstallation, restore only from the last known-good backup; have its integrity checked or confirmed by an expert. CISA recommends offline, encrypted backups where available and recovery on a clean network, prioritising critical services. Do not restore a suspected backup to a reset device, and do not reconnect other devices until they are considered clean.",
        risk: "high",
        officialUrl:
            "https://www.cisa.gov/stopransomware/ive-been-hit-ransomware",
        sourceTitle: "CISA — I've Been Hit By Ransomware!",
      ),
      ResponseStep(
        titleAr: "8. حدّث وراقب قبل إعادة الاتصال الكامل",
        titleEn: "8. Update and monitor before full reconnection",
        detailAr:
            "على الشبكة النظيفة، حدّث نظام التشغيل والتطبيقات وأدوات الحماية، وشغّل الفحص المتاح للجهاز، ثم أعد الاتصال تدريجياً. راقب سلوك الجهاز والحسابات وأي تشفير أو نوافذ فدية جديدة. إذا عاد العرض، أو ظهرت إصابات على أجهزة أخرى، أو ظهرت مؤشرات دخول غير مصرح به أو تسريب بيانات، افصل الجهاز مجدداً وصعّد فوراً إلى المختص/مزود الخدمة والجهة الحكومية المختصة. لا تفترض أن إعادة التشغيل وحدها أزالت العدوى.",
        detailEn:
            "On the clean network, update the OS, apps, and available security tools, run the device's available scan, and reconnect gradually. Monitor the device and accounts for renewed encryption or ransom messages. If symptoms return, other devices become affected, or there are signs of unauthorised access or data leakage, isolate again and immediately escalate to an expert/device provider and the relevant government authority. Do not assume a reboot alone removed the infection.",
        risk: "medium",
        officialUrl:
            "https://www.ncsc.gov.uk/section/respond-recover/sole-ransomware-attack",
        sourceTitle: "NCSC — Ransomware attack",
      ),
    ],
  ),
  IncidentPlaybook(
    id: "lost-phone-response-android",
    titleAr: "خطة الاستجابة لهاتف Android مفقود أو مسروق",
    titleEn: "Lost or stolen Android phone response playbook",
    summaryAr:
        "نفّذ الخطوات بالترتيب من جهاز آمن: حاول تحديد الهاتف، اقفله، أوقف الشريحة، أمّن الحسابات، احمِ الحسابات المالية، ثم امسح الهاتف أو أبلغ الجهات المختصة عند الحاجة. تختلف النتائج حسب طاقة الهاتف واتصاله وإعدادات Find Hub ودعم شركة الاتصالات.",
    summaryEn:
        "From a safe, trusted device, work in order: try to locate the phone, lock it, suspend the SIM, secure accounts, protect financial accounts, then erase it or report/escalate as needed. Results depend on phone power/connectivity, Find Hub settings, and carrier support.",
    whenExpertAr:
        "صعّد فوراً إلى الشرطة/الجهة المحلية المختصة إذا كان هناك سرقة أو تهديد أو خطر جسدي، وإلى قسم تقنية المعلومات إذا كان الهاتف تابعاً للعمل أو يحتوي بيانات مؤسسية. اتصل بشركة الاتصالات فوراً إذا ظهرت مؤشرات تبديل SIM أو فقدت السيطرة على الرقم. اتصل بالبنك/مزود الدفع عند وجود عملية غير مصرح بها. استخدم استرداد حساب Google أو دعم مسؤول المؤسسة إذا تعذر تسجيل الدخول أو رموز التحقق.",
    whenExpertEn:
        "Escalate immediately to local law enforcement if there was theft, a threat, or physical danger, and to IT if the phone is work-issued or held organizational data. Contact the carrier immediately if there are signs of a SIM swap or loss of number control. Contact the bank/payment provider for unauthorized activity. Use Google Account recovery or an organization administrator if sign-in or verification codes fail.",
    steps: <ResponseStep>[
      ResponseStep(
        titleAr: "1. افتح Find Hub من جهاز موثوق وحاول تحديد الهاتف",
        titleEn:
            "1. Open Find Hub from a trusted device and try to locate the phone",
        detailAr:
            "من متصفح آمن افتح https://android.com/find أو تطبيق Find Hub وسجّل الدخول بالحساب المرتبط بالهاتف. راجع الموقع/آخر موقع معروف، وشغّل الرنين فقط إذا كان الهاتف قريباً ويمكن استرجاعه بأمان. تقول Google إن إجراءات التأمين والمسح تتطلب عادةً طاقة، واتصال Wi‑Fi أو بيانات، وتسجيل الدخول إلى حساب Google، وتفعيل Find Hub وظهور الجهاز في Google Play؛ لذلك قد يفشل التحديد أو يعرض موقعاً قديماً بحسب الجهاز والاتصال.",
        detailEn:
            "From a trusted browser open https://android.com/find or the Find Hub app and sign in to the account on the phone. Review the location/last known location and use Play sound only when the phone is nearby and retrieval is safe. Google says securing or erasing generally requires power, Wi‑Fi or mobile data, a Google Account, Find Hub enabled, and the device visible on Google Play; location or actions may therefore be unavailable or stale depending on the device and connection.",
        risk: "low",
        officialUrl: "https://support.google.com/accounts/answer/6160491?hl=en",
        sourceTitle:
            "Find, secure, or erase a lost Android device — Google Account Help",
      ),
      ResponseStep(
        titleAr: "2. اقفل الهاتف عن بُعد",
        titleEn: "2. Lock the phone remotely",
        detailAr:
            "في Find Hub اختر تأمين الجهاز/قفل الجهاز، أو استخدم Remote Lock إذا كان مفعّلاً وأدخل رقم الهاتف. يوضح Android أن Remote Lock لا ينفذ إلا إذا كان مفعّلاً؛ وإذا كان الهاتف غير متصل فسيُقفل تلقائياً عند عودته إلى الاتصال. لا تحاول مواجهة السارق أو الذهاب إلى موقع غير آمن لاستعادته.",
        detailEn:
            "In Find Hub choose Secure device/Lock device, or use Remote Lock if it was enabled and enter the phone number. Android states that Remote Lock works only when enabled; if the phone is offline, its screen locks when it comes online. Do not confront a thief or travel to an unsafe location to retrieve it.",
        risk: "low",
        officialUrl: "https://www.android.com/lock",
        sourceTitle:
            "Lock your lost or stolen Android device — Android/Google Find Hub Remote Lock",
      ),
      ResponseStep(
        titleAr: "3. أوقف الشريحة واطلب شريحة بديلة من شركة الاتصالات",
        titleEn:
            "3. Suspend the SIM and request a replacement from the carrier",
        detailAr:
            "اتصل بشركة الاتصالات من قناة رسمية واطلب إيقاف الشريحة/الخدمة، ثم اسأل عن شريحة بديلة أو تحويل المكالمات وعن رقم IMEI إن كان متاحاً. تؤكد Google أن شركة الاتصالات قد توقف الشريحة أو تصدر شريحة جديدة، لكن الخيارات والإجراءات تختلف حسب المزود والبلد. ضع PIN أو كلمة مرور لحساب الاتصالات إذا كان المزود يدعم ذلك.",
        detailEn:
            "Contact the carrier through a known official channel and ask it to turn off the SIM/service; request a replacement SIM and ask about call forwarding and the IMEI if available. Google says a carrier may turn off the SIM or order a new one, but options and procedures vary by provider and country. Set a PIN or password on the cellular account if the carrier supports it.",
        risk: "medium",
        officialUrl: "https://support.google.com/accounts/answer/7177579?hl=en",
        sourceTitle:
            "Lock or erase your lost phone or computer — Google Account Help",
      ),
      ResponseStep(
        titleAr: "4. سجّل الخروج من الهاتف وغيّر كلمات المرور",
        titleEn: "4. Sign out the phone and change passwords",
        detailAr:
            "من Google Account > الأمان > أجهزتك > إدارة الأجهزة، اختر الهاتف المفقود ثم سجّل الخروج لإزالة وصول حساب Google والتطبيقات المتصلة. غيّر كلمة مرور Google، ثم غيّر كلمات مرور المواقع/التطبيقات المحفوظة أو المعاد استخدامها. إذا ظهرت أجهزة أو نشاطات غير مألوفة، استخدم صفحة تأمين الحساب المخترق وفعّل التحقق بخطوتين من جهاز موثوق. قد تحتاج حسابات العمل/الدراسة إلى مسؤول المؤسسة.",
        detailEn:
            "In Google Account > Security > Your devices > Manage devices, select the lost phone and sign out to remove access to Google and connected apps. Change the Google password, then change passwords saved on or reused from the account. If unfamiliar devices or activity appear, use Google’s compromised-account flow and turn on 2-Step Verification from a trusted device. Work or school accounts may require an administrator.",
        risk: "high",
        officialUrl: "https://support.google.com/accounts/answer/7177579?hl=en",
        sourceTitle:
            "Lock or erase your lost phone or computer — Google Account Help",
      ),
      ResponseStep(
        titleAr: "5. احمِ الحسابات المالية وراقب النشاط",
        titleEn: "5. Protect financial accounts and monitor activity",
        detailAr:
            "راجع البنوك والبطاقات والمحافظ وتطبيقات الدفع من جهاز موثوق؛ جمّد البطاقة أو أبلغ الجهة المصدرة فوراً عن أي عملية غير مصرح بها. بعد استعادة الرقم، غيّر كلمات المرور وراجع الحسابات. تحذر FTC من أن تبديل SIM قد يمنح المهاجم الرسائل والمكالمات، وتوصي بـ PIN لحساب الاتصالات وبمصادقة أقوى من الرسائل النصية مثل تطبيق مصادقة أو مفتاح أمان عندما يكون ذلك متاحاً.",
        detailEn:
            "From a trusted device, review banks, cards, wallets, and payment apps; freeze a card or report unauthorized transactions to the issuer immediately. After regaining control of the number, change passwords and review accounts. The FTC warns that a SIM swap can give an attacker calls and texts, and recommends a carrier-account PIN plus stronger-than-SMS authentication such as an authenticator app or security key where available.",
        risk: "high",
        officialUrl:
            "https://www.ctia.org/protecting-against-sim-swap-fraud",
        sourceTitle:
            "SIM Swap Scams: How to Protect Yourself — Federal Trade Commission",
      ),
      ResponseStep(
        titleAr: "6. امسح بيانات الهاتف عن بُعد فقط بعد اتخاذ قرار نهائي",
        titleEn:
            "6. Remotely erase the phone only after making a final decision",
        detailAr:
            "إذا تعذر استرجاع الهاتف وكان خطر البيانات أعلى من قيمة محاولة تحديده، استخدم خيار Erase/Factory reset في Find Hub. هذا إجراء نهائي؛ تذكر Google أنه بعد المسح ستحتاج إلى كلمة مرور حساب Google لاستخدام الجهاز مجدداً. تنفيذ المسح يعتمد على أن يكون الهاتف قادراً على استقبال الأمر (طاقة واتصال وإعدادات Find Hub المطلوبة)، وقد لا ينجح على كل جهاز أو في كل حالة.",
        detailEn:
            "If recovery is unlikely and data exposure is more serious than preserving a chance to locate the phone, use Erase/Factory reset in Find Hub. This is a final action; Google says that after erasing, you need the Google Account password to use the device again. Execution depends on the phone being able to receive the command (power, connectivity, and required Find Hub settings), so it may not work for every device or situation.",
        risk: "high",
        officialUrl: "https://support.google.com/accounts/answer/6160491?hl=en",
        sourceTitle:
            "Find, secure, or erase a lost Android device — Google Account Help",
      ),
      ResponseStep(
        titleAr: "7. أبلغ الشرطة أو جهة العمل واحتفظ بسجل الحادث",
        titleEn:
            "7. Report to police or your organization and document the incident",
        detailAr:
            "إذا كان الهاتف مسروقاً، أبلغ الشرطة/الجهة المحلية المختصة ولا تحاول استعادته بنفسك من موقع غير آمن. إذا كان الهاتف تابعاً للعمل أو وصل إلى بيانات مؤسسية، أبلغ المؤسسة فوراً كي تلغي الاعتمادات أو الشهادات. احتفظ بوقت ومكان الفقد، رقم الهاتف/IMEI إن توفر، ولقطات من نشاط الحساب والمعاملات غير المصرح بها.",
        detailEn:
            "If the phone was stolen, report it to local law enforcement or the appropriate authority and do not attempt an unsafe self-recovery. If it was organization-issued or accessed private/corporate data, notify the organization immediately so it can revoke credentials or certificates. Record the time and place of loss, phone number/IMEI if available, and screenshots of account activity or unauthorized transactions.",
        risk: "medium",
        officialUrl:
            "https://www.cisa.gov/sites/default/files/publications/cyber_threats_to_mobile_phones.pdf",
        sourceTitle:
            "Cyber Threats to Mobile Phones — Cybersecurity and Infrastructure Security Agency (CISA)",
      ),
    ],
  ),
  IncidentPlaybook(
    id: "github-secret-leak-recovery",
    titleAr: "خطة الاستجابة لتسرّب رمز أو سر GitHub",
    titleEn: "Leaked GitHub Token or Secret: Incident-Response Playbook",
    summaryAr:
        "اعتبر السر مكشوفًا ومخترقًا فورًا، ثم احتوِ الوصول، استبدل السر، افحص النشاط، ونظّف المستودع بحذر. لا يكفي حذف السطر أو إنشاء commit جديد؛ وتختلف بعض الإجراءات بحسب مزوّد السر، نوع الرمز، صلاحيات GitHub وخطة الحساب.",
    summaryEn:
        "Treat the secret as exposed and compromised immediately. Contain access, replace the secret, check activity, and clean the repository carefully. Deleting a line or adding a new commit is not enough; some actions depend on the secret provider, token type, GitHub permissions, and account plan.",
    whenExpertAr:
        "صعّد فورًا إلى مالك الرمز/مسؤول المستودع وفريق الأمن إذا كان الرمز نشطًا أو عامًا أو إنتاجيًا أو إداريًا، أو ظهرت سجلات وصول غير مألوف/تغييرات غير مصرّح بها، أو كان الوصول إلى المزوّد مفقودًا، أو تعذّر تحديد النطاق، أو شمل الحادث بيانات شخصية/منظّمة أو عدة مستودعات/حسابات. يحتاج تغيير تاريخ Git إلى مسؤول المستودع وتنسيق مع جميع النسخ المستنسخة والفروع والشُعب؛ وقد يتطلب طلب دعم GitHub. لا تُبلغ جهة حكومية إلا وفق متطلبات مؤسستك أو ولايتك القضائية.",
    whenExpertEn:
        "Escalate immediately to the token owner/repository administrator and security team if the token is active, public, production, or administrative; if logs show unusual access or unauthorized changes; if provider access is unavailable; if scope cannot be determined; or if personal/regulated data or multiple repositories/accounts may be involved. History rewriting requires repository-admin ownership and coordination with all clones, forks, and branches, and may require GitHub Support. Contact a government agency only when required by your organization or jurisdiction.",
    steps: <ResponseStep>[
      ResponseStep(
        titleAr: "1. ثبّت الدليل وحدّد السر والنطاق",
        titleEn: "1. Preserve evidence and identify the secret and scope",
        detailAr:
            "اعتبر السر مخترقًا فورًا. قبل التنظيف، التقط لقطات شاشة واحفظ تنبيهات Secret scanning، وصدّر السجلات أو نتائج البحث المتاحة، وسجّل نوع السر ومزوّده ومالكه والمستودع/الملف/السطر ووقت الاكتشاف وما إذا كان المستودع عامًا. افحص حالة الصلاحية والظهور العام والتسريبات المتعددة إن كانت متاحة؛ ومزوّد السر هو المرجع الأوثق لصلاحية السر. لا تطبع قيمة السر أو ترسلها في الدردشة.",
        detailEn:
            "Treat the secret as compromised immediately. Before cleanup, capture screenshots and preserve Secret scanning alerts, export available logs or query results, and record the secret type, provider, owner, repository/file/line, discovery time, and whether the repository is public. Check validity, public-exposure, and multiple-leak indicators when available; the secret provider is the authoritative source for validity. Do not paste the secret value into chat or tickets.",
        risk: "high",
        officialUrl:
            "https://docs.github.com/en/enterprise-cloud@latest/code-security/tutorials/secure-your-organization/respond-to-a-security-incident",
        sourceTitle: "Responding to a security incident",
      ),
      ResponseStep(
        titleAr: "2. أوقف الرمز المكشوف فورًا",
        titleEn: "2. Revoke the exposed credential immediately",
        detailAr:
            "ألغِ الرمز من جهة المزوّد قبل الاكتفاء بحذف الكود. لرمز GitHub، يمكن أن يكون الإلغاء عبر إعدادات الحساب/التطبيق أو آلية الإلغاء الرسمية؛ والرمز الملصق في مستودع عام قد يُلغى تلقائيًا. إذا كان GitHub PAT نشطًا أو غير مؤكّد في مستودع خاص، فقد يتيح تنبيه Secret scanning خيار Report leak؛ هذه الميزة مخصّصة حاليًا لأنواع GitHub PAT المحددة وقد تتغير. للرموز غير التابعة لـ GitHub، اتبع تعليمات المزوّد؛ وإذا لم تملك صلاحية البوابة، اتصل بالمالك أو مسؤول المستودع.",
        detailEn:
            "Revoke the credential at its provider before relying on code deletion. For a GitHub token, use the account/app settings or the official revocation mechanism; a token pushed to a public repository may be revoked automatically. For an active or unconfirmed GitHub PAT in a private repository, a Secret scanning alert may offer Report leak; this is currently limited to specified GitHub PAT types and may change. For non-GitHub secrets, follow the provider's instructions; if you lack portal access, contact the owner or repository administrator.",
        risk: "high",
        officialUrl:
            "https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/token-expiration-and-revocation",
        sourceTitle: "Token expiration and revocation",
      ),
      ResponseStep(
        titleAr: "3. أنشئ بديلًا آمنًا وحدّث الخدمات",
        titleEn: "3. Create a replacement and update dependent services",
        detailAr:
            "أنشئ سرًا جديدًا بصلاحيات أقل ما يلزم، وبتاريخ انتهاء إن كان المزوّد يدعم ذلك. حدّث كل تطبيق أو workflow أو تكامل يستخدم السر القديم، ثم اختبره. خزّن البديل في مخزن أسرار/Secrets and variables أو أداة إدارة أسرار، وليس في الكود. إذا كان الإلغاء الفوري قد يسبب توقفًا، توصي GitHub بإمكان إنشاء البديل أولًا، تحويل الخدمة إليه، ثم إلغاء القديم؛ لا تفعل ذلك إلا إذا كان الاحتواء ما زال كافيًا.",
        detailEn:
            "Create a new secret with least-privilege permissions and an expiration when the provider supports it. Update every application, workflow, or integration that used the old secret, then test it. Store the replacement in a secrets manager or GitHub Secrets and variables, not in source code. If immediate revocation could cause downtime, GitHub says you may create the replacement first, switch the service, and then revoke the old secret—but only when containment remains adequate.",
        risk: "high",
        officialUrl:
            "https://docs.github.com/en/code-security/tutorials/remediate-leaked-secrets/remediating-a-leaked-secret",
        sourceTitle: "Remediating a leaked secret in your repository",
      ),
      ResponseStep(
        titleAr: "4. افحص الوصول غير المصرّح به وسجّل النطاق",
        titleEn: "4. Check for unauthorized access and document scope",
        detailAr:
            "بعد استعادة الخدمات، راجع سجل الأمان لحسابك وسجل التدقيق للمؤسسة/المؤسسة التجارية، بما في ذلك أحداث استخدام الرمز أو إنشاءه، وراجع سجلات مزوّد السر. ابحث عن تسجيلات دخول أو طلبات API أو تغييرات مستودعات أو سير عمل غير مألوفة، وسجّل الخط الزمني والمؤشرات والقرارات. قد تتطلب سجلات المؤسسة صلاحية مالك المؤسسة أو مسؤول المؤسسة؛ لا تفترض أن غياب السجل يثبت عدم الاستخدام.",
        detailEn:
            "After services are restored, review your account security log and the organization/enterprise audit log, including token-use or token-creation events, and review the secret provider's logs. Look for unusual logins, API requests, repository changes, or workflow runs, and record the timeline, indicators, and decisions. Organization or enterprise logs may require an owner or administrator; absence of a visible event is not proof that the secret was not used.",
        risk: "high",
        officialUrl:
            "https://docs.github.com/en/code-security/tutorials/remediate-leaked-secrets/remediating-a-leaked-secret",
        sourceTitle: "Remediating a leaked secret in your repository",
      ),
      ResponseStep(
        titleAr: "5. أزل النسخ من المستودع بحذر بعد الإلغاء",
        titleEn: "5. Remove repository copies carefully after revocation",
        detailAr:
            "احذف السر من الملفات الحالية، ثم قيّم مع مسؤول الأمن ما إذا كان يلزم تنظيف تاريخ Git. لا تبدأ إعادة كتابة التاريخ قبل الإلغاء/التدوير؛ وقد يكون الإلغاء كافيًا. إعادة كتابة التاريخ عملية مدمّرة: تغيّر commit hashes وقد تؤثر في طلبات السحب والتوقيعات وحماية الفروع، ويمكن أن تعيد النسخ القديمة أو الفروع أو forks نشر السر. نسّق مع جميع المتعاونين ونظّف النسخ المستنسخة، واطلب من GitHub Support إزالة التخزين المؤقت/مراجع طلبات السحب فقط عندما ينطبق ذلك. لا تعرض قيمة السر أثناء التنظيف.",
        detailEn:
            "Remove the secret from current files, then decide with the security/repository owner whether Git history must be cleaned. Do not rewrite history before revocation/rotation; revocation may be sufficient. History rewriting is disruptive: it changes commit hashes and can affect pull requests, signatures, and branch protection, while old clones, branches, or forks can reintroduce or retain the secret. Coordinate with collaborators, clean other clones, and contact GitHub Support for cached views or pull-request references only where applicable. Do not expose the secret value during cleanup.",
        risk: "medium",
        officialUrl:
            "https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/removing-sensitive-data-from-a-repository",
        sourceTitle: "Removing sensitive data from a repository",
      ),
      ResponseStep(
        titleAr: "6. امنع تكرار التسريب",
        titleEn: "6. Prevent a repeat leak",
        detailAr:
            "فعّل Secret scanning وPush protection إذا كانت الخطة والصلاحيات تدعمانهما، واضبط ضوابط التجاوز بحيث لا يتجاوزها إلا الموثوقون. استخدم متغيرات البيئة أو GitHub Secrets بدل hardcoding، وقلّل الصلاحيات، واضبط انتهاء الصلاحية والتدوير الدوري، وامنع تسجيل الأسرار في السجلات. قد لا تتوفر بعض الميزات في كل خطة أو نوع مستودع، وقد يحتاج التفعيل إلى مسؤول مستودع/مؤسسة.",
        detailEn:
            "Enable Secret scanning and push protection when the plan and permissions support them, and restrict bypass controls to trusted users. Use environment variables or GitHub Secrets instead of hardcoding, apply least privilege, set expiration and regular rotation, and prevent secrets from being written to logs. Some features are not available on every plan or repository type and may require a repository or organization administrator.",
        risk: "low",
        officialUrl:
            "https://docs.github.com/en/code-security/concepts/secret-security/push-protection",
        sourceTitle: "Push protection",
      ),
      ResponseStep(
        titleAr: "7. أغلق التنبيه ووثّق وصعّد عند الحاجة",
        titleEn:
            "7. Close the alert, document the incident, and escalate when required",
        detailAr:
            "بعد الإلغاء والاستبدال والتحقق والتنظيف المناسب، أغلق تنبيه Secret scanning بسبب Revoked، ووثّق ما حدث وما عولج والدروس المستفادة في نظام الحوادث. أخطر مالك الرمز ومسؤول المستودع وفريق الأمن، وأشرك القانوني/الخصوصية إذا كانت بيانات حساسة معرضة للخطر. إذا كان هناك وصول غير مصرّح به أو تأثير تشغيلي أو نطاق غير معروف، أبقِ الحادث مفتوحًا وصعّده بدل إغلاقه لمجرد إزالة الرمز.",
        detailEn:
            "After revocation, replacement, verification, and appropriate cleanup, close the Secret scanning alert as Revoked and document what happened, what was remediated, and lessons learned in the incident system. Notify the token owner, repository administrator, and security team; involve legal/privacy teams if sensitive data may be at risk. If there is unauthorized access, operational impact, or unknown scope, keep the incident open and escalate it rather than closing it merely because the token was removed.",
        risk: "medium",
        officialUrl:
            "https://docs.github.com/en/enterprise-cloud@latest/code-security/tutorials/secure-your-organization/respond-to-a-security-incident",
        sourceTitle: "Responding to a security incident",
      ),
    ],
  ),
  IncidentPlaybook(id: "account-takeover-recovery", titleAr: "استعادة حساب بعد تسجيل دخول غير معروف", titleEn: "Recover an account after an unknown sign-in", summaryAr: "مسار احتواء واستعادة لحساب ظهرت فيه جلسة أو جهاز غير معروف.", summaryEn: "Containment and recovery path for an account showing an unknown session or device.", whenExpertAr: "اطلب مساعدة مختص إذا كان الحساب مؤسسياً أو مالياً، أو تعذر استرداده، أو ظهرت معاملات أو بيانات حساسة غير مصرح بها.", whenExpertEn: "Escalate if the account is organizational or financial, recovery fails, or unauthorized transactions or sensitive data are involved.", steps: <ResponseStep>[ResponseStep(titleAr: "1. أوقف الجلسات غير المعروفة", titleEn: "1. End unknown sessions", detailAr: "من صفحة الأمان الرسمية، سجّل الخروج من الأجهزة والجلسات التي لا تتعرف عليها. لا تستخدم رابطاً وصلك في رسالة لاستعادة الحساب.", detailEn: "From the official security page, sign out unknown devices and sessions. Do not use a recovery link delivered in a message.", risk: "high", officialUrl: "https://support.google.com/accounts/answer/6294825?hl=en", sourceTitle: "Secure a hacked or compromised Google Account"), ResponseStep(titleAr: "2. غيّر كلمة المرور من جهاز موثوق", titleEn: "2. Change the password from a trusted device", detailAr: "أنشئ كلمة مرور فريدة، وغيّرها في الحسابات التي أعادت استخدامها، ولا تحفظها في رسالة أو ملف مكشوف.", detailEn: "Create a unique password, change it anywhere it was reused, and do not place it in a message or exposed file.", risk: "high", officialUrl: "https://www.ncsc.gov.uk/collection/top-tips-for-staying-secure-online/password-managers", sourceTitle: "NCSC password guidance"), ResponseStep(titleAr: "3. فعّل MFA وراجع وسائل الاسترداد", titleEn: "3. Enable MFA and review recovery methods", detailAr: "احذف رقم أو بريد الاسترداد غير المعروف، وأعد إنشاء رموز الاسترداد، وفضّل مفتاح أمان أو تطبيق مصادقة عند توفره.", detailEn: "Remove unknown recovery details, regenerate recovery codes, and prefer a security key or authenticator app where available.", risk: "high", officialUrl: "https://www.cisa.gov/MFA", sourceTitle: "CISA Multi-Factor Authentication"), ResponseStep(titleAr: "4. وثّق الأثر وصعّد عند الحاجة", titleEn: "4. Document impact and escalate", detailAr: "سجّل الزمن والأجهزة والتنبيهات وأي تغيير أو معاملة. اتصل بمزوّد الخدمة أو البنك من قناة رسمية إذا كان هناك خطر مالي.", detailEn: "Record times, devices, alerts, and changes or transactions. Contact the provider or bank through an official channel if money is at risk.", risk: "high", officialUrl: "https://www.cisa.gov/stopransomware/ive-been-hit-ransomware", sourceTitle: "CISA incident guidance")]),
  IncidentPlaybook(id: "suspicious-attachment", titleAr: "مرفق أو ملف مشبوه", titleEn: "Suspicious attachment or file", summaryAr: "خطوات آمنة للتوقف والعزل والتحقق دون تشغيل الملف مرة أخرى.", summaryEn: "Safe steps to stop, isolate, and verify without reopening the file.", whenExpertAr: "اطلب مساعدة مختص إذا فُتح الملف، أو ظهرت عمليات غريبة، أو كان الجهاز تابعاً لمؤسسة.", whenExpertEn: "Escalate if the file was opened, unusual activity appeared, or the device is organization-managed.", steps: <ResponseStep>[ResponseStep(titleAr: "1. لا تفتح الملف ولا تعِد إرساله", titleEn: "1. Do not open or forward the file", detailAr: "لا تضغط Enable Content ولا تشغّل سكربتاً ولا ترفع الملف إلى خدمة عامة إذا كان يحتوي بيانات خاصة.", detailEn: "Do not click Enable Content, run scripts, or upload the file to a public service if it may contain private data.", risk: "high", officialUrl: "https://www.ncsc.gov.uk/guidance/phishing", sourceTitle: "CISA phishing guidance"), ResponseStep(titleAr: "2. أبلغ القناة الرسمية", titleEn: "2. Report through the official channel", detailAr: "استخدم زر الإبلاغ في البريد أو أرسل التفاصيل إلى فريق الأمن، ولا تتواصل مع المرسل المشبوه للمتابعة.", detailEn: "Use the mail report control or send details to security; do not engage the suspicious sender.", risk: "medium", officialUrl: "https://support.google.com/mail/answer/8253?hl=en", sourceTitle: "Report phishing"), ResponseStep(titleAr: "3. افحص الجهاز وراجع الجلسات", titleEn: "3. Scan the device and review sessions", detailAr: "إذا تم فتح الملف، افصل الاتصال عند استمرار الأعراض، شغّل أدوات الحماية الرسمية، وراجع الجلسات من جهاز موثوق.", detailEn: "If it was opened, disconnect if symptoms persist, run official protection tools, and review sessions from a trusted device.", risk: "high", officialUrl: "https://learn.microsoft.com/en-us/windows/security/", sourceTitle: "Windows Security")]),

  IncidentPlaybook(
    id: "critical-security-update-response",
    titleAr: "إدارة تحديث أمني حرج قبل التطبيق وأثناءه وبعده",
    titleEn: "Critical security update: before, during, and after deployment",
    summaryAr: "قائمة عمل للمسؤولين عن أنظمة يملكونها أو يديرونها بتفويض. تحقّق من النشرة الأصلية والنطاق المتأثر، ثم قيّم التعرض والنسخ الاحتياطي وخطة الرجوع والتحقق بعد التحديث. لا تؤجل إجراء الاحتواء عند وجود استغلال نشط.",
    summaryEn: "A checklist for administrators of systems they own or are authorized to manage. Verify the original advisory and affected scope, assess exposure, backups, rollback, and post-update validation. Do not delay containment when active exploitation is reported.",
    whenExpertAr: "صعّد فوراً إلى فريق الاستجابة أو مالك الخدمة عند الاشتباه باستغلال نشط، أو تعذر تطبيق تصحيح على نظام مكشوف، أو وجود أثر على بيانات حساسة أو خدمات حرجة. لا تطبق تغييرات غير معتمدة على أنظمة طبية أو صناعية أو إنتاجية؛ اتبع خطة التغيير والطوارئ المؤسسية.",
    whenExpertEn: "Escalate immediately to incident response or the service owner if active exploitation is suspected, an exposed system cannot be patched, or sensitive data or critical services may be affected. Do not make unapproved changes to medical, industrial, or production systems; follow organizational change and emergency procedures.",
    steps: <ResponseStep>[
      ResponseStep(titleAr: "1. تحقق من النشرة والمنتج والإصدار", titleEn: "1. Verify the advisory, product, and version", detailAr: "افتح نشرة المورد الرسمية من عنوان معروف، وتحقق من اسم المنتج والإصدارات المتأثرة والإصلاحات المتاحة والمتطلبات. لا تعتمد على عنوان رسالة أو رابط مختصر. سجّل وقت النشر ومصدره والأنظمة التي قد تتأثر.", detailEn: "Open the vendor’s official advisory from a known address and confirm the product, affected versions, available fixes, and requirements. Do not rely on an email subject or shortened link. Record the publication time, source, and potentially affected systems.", risk: "high", officialUrl: "https://csrc.nist.gov/pubs/sp/800/40/r4/final", sourceTitle: "NIST SP 800-40 Rev. 4, Guide to Enterprise Patch Management Planning"),
      ResponseStep(titleAr: "2. قيّم التعرض والاستغلال والأولوية", titleEn: "2. Assess exposure, exploitation, and priority", detailAr: "حدد الأنظمة المكشوفة للإنترنت والأصول الحساسة والاعتماديات. راجع تحذيرات المورد والجهات الرسمية حول الاستغلال النشط. إذا تعذر التصحيح فوراً، قلل التعرض وفق ضوابط معتمدة واطلب قراراً من مالك النظام؛ غياب سجل أو تطابق لا يثبت السلامة.", detailEn: "Identify internet-exposed systems, sensitive assets, and dependencies. Review vendor and official-agency alerts for active exploitation. If immediate patching is not possible, reduce exposure using approved controls and get the system owner’s decision; absence of a listing or match does not prove safety.", risk: "high", officialUrl: "https://www.cisa.gov/known-exploited-vulnerabilities-catalog", sourceTitle: "CISA Known Exploited Vulnerabilities Catalog"),
      ResponseStep(titleAr: "3. جهّز نسخة احتياطية وخطة رجوع", titleEn: "3. Prepare a backup and rollback plan", detailAr: "تحقق من وجود نسخة احتياطية حديثة قابلة للاستعادة، وحدد مسؤول التغيير ونافذته والاعتماديات واختبار النجاح وخطة الرجوع. في الأنظمة عالية الأثر، اختبر التغيير على بيئة مماثلة إن أمكن، وأبلغ أصحاب الخدمة والمستخدمين المعنيين.", detailEn: "Confirm a recent restorable backup, change owner, maintenance window, dependencies, success checks, and rollback plan. For high-impact systems, test in a representative environment where feasible and notify service owners and affected users.", risk: "high", officialUrl: "https://csrc.nist.gov/pubs/sp/800/40/r4/final", sourceTitle: "NIST Enterprise Patch Management Planning"),
      ResponseStep(titleAr: "4. طبّق الإصلاح من قناة موثوقة", titleEn: "4. Apply the fix from a trusted channel", detailAr: "نزّل التحديث من قناة المورد الرسمية أو آلية الإدارة المعتمدة، واتبع الترتيب والمتطلبات المنشورة. راقب الخدمات والسجلات أثناء التنفيذ. إذا ظهرت مؤشرات استغلال أو تعطّل واسع، أوقف التغيير وفق الخطة وصعّد إلى الفريق المختص بدلاً من التجربة العشوائية.", detailEn: "Obtain the update through the vendor’s official channel or approved management system and follow published sequencing and prerequisites. Monitor services and logs during deployment. If exploitation indicators or widespread disruption appear, stop according to the plan and escalate rather than improvising.", risk: "high", officialUrl: "https://csrc.nist.gov/pubs/sp/800/40/r4/final", sourceTitle: "NIST Enterprise Patch Management Planning"),
      ResponseStep(titleAr: "5. تحقق ووثّق وصعّد المتبقي", titleEn: "5. Validate, document, and escalate residual risk", detailAr: "تحقق من الإصدار المصحح وعمل الخدمة والضوابط والسجلات، ثم وثق الأصول والوقت والنتيجة والاستثناءات. راقب التنبيهات اللاحقة. إذا بقي نظام معرض دون إصلاح أو كان هناك اشتباه باختراق سابق، احتفظ بالسجلات واتبع خطة الاستجابة المؤسسية واستعن بمختص.", detailEn: "Verify the patched version, service operation, controls, and logs, then document assets, timing, outcome, and exceptions. Monitor follow-up advisories. If an exposed system remains unpatched or prior compromise is suspected, preserve logs, follow the incident-response plan, and involve a specialist.", risk: "medium", officialUrl: "https://csrc.nist.gov/pubs/sp/800/40/r4/final", sourceTitle: "NIST Enterprise Patch Management Planning"),
    ],
  ),

];
