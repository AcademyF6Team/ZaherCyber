/// Official public-facing links for the ZaherCyber project.
const String zaherCyberProjectTelegramUrl = 'https://t.me/+nRjn9nPpbzliMTIy';
