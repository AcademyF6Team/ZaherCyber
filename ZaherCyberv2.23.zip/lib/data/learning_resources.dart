import 'package:flutter/material.dart';

class LearningResource {
  final String name;
  final String descriptionAr;
  final String descriptionEn;
  final String url;
  final IconData icon;

  const LearningResource({
    required this.name,
    required this.descriptionAr,
    required this.descriptionEn,
    required this.url,
    required this.icon,
  });
}

class LearningResourceSection {
  final String titleAr;
  final String titleEn;
  final List<LearningResource> items;

  const LearningResourceSection(this.titleAr, this.titleEn, this.items);
}

/// Carefully curated starting points. Always follow each publisher's terms,
/// and use testing labs only where you have explicit authorization.
const learningResourceSections = <LearningResourceSection>[
  LearningResourceSection(
    'الدفاع الأزرق والاستجابة للحوادث',
    'Blue team & incident response',
    [
      LearningResource(
        name: 'CISA Cybersecurity Advisories',
        descriptionAr: 'تنبيهات وإرشادات أمنية حكومية للجهات والأفراد.',
        descriptionEn: 'Government cybersecurity advisories and guidance.',
        url: 'https://www.cisa.gov/news-events/cybersecurity-advisories',
        icon: Icons.campaign_outlined,
      ),
      LearningResource(
        name: 'CISA Secure by Design',
        descriptionAr: 'مبادئ عملية لبناء منتجات آمنة وتقليل المخاطر.',
        descriptionEn: 'Practical principles for building safer products.',
        url: 'https://www.cisa.gov/securebydesign',
        icon: Icons.verified_user_outlined,
      ),
      LearningResource(
        name: 'MITRE ATT&CK',
        descriptionAr: 'قاعدة معرفة لتكتيكات وتقنيات الخصوم ومصفوفات المنصات.',
        descriptionEn: 'Knowledge base of adversary tactics and techniques.',
        url: 'https://attack.mitre.org/',
        icon: Icons.account_tree_outlined,
      ),
      LearningResource(
        name: 'MITRE D3FEND',
        descriptionAr: 'مرجع دفاعي يربط التدابير المضادة بالتقنيات الهجومية.',
        descriptionEn: 'A knowledge graph of defensive countermeasures.',
        url: 'https://d3fend.mitre.org/',
        icon: Icons.shield_outlined,
      ),
      LearningResource(
        name: 'SigmaHQ Rules',
        descriptionAr: 'قواعد كشف مفتوحة قابلة للتحويل بين منصات SIEM.',
        descriptionEn: 'Portable open detection rules for SIEM platforms.',
        url: 'https://github.com/SigmaHQ/sigma',
        icon: Icons.rule_folder_outlined,
      ),
      LearningResource(
        name: 'Atomic Red Team',
        descriptionAr: 'اختبارات محاكاة دفاعية تعمل داخل مختبر تملكه فقط.',
        descriptionEn: 'Small adversary simulation tests for your own lab.',
        url: 'https://atomicredteam.io/',
        icon: Icons.science_outlined,
      ),
      LearningResource(
        name: 'NIST Incident Response',
        descriptionAr: 'مرجع NIST للتخطيط والاستجابة للحوادث السيبرانية.',
        descriptionEn: 'NIST guidance for cybersecurity incident response.',
        url: 'https://csrc.nist.gov/projects/incident-response',
        icon: Icons.emergency_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'أمن التطبيقات وواجهات API',
    'Application & API security',
    [
      LearningResource(
        name: 'OWASP ASVS',
        descriptionAr: 'معيار متدرج لمتطلبات التحقق من أمن التطبيقات.',
        descriptionEn:
            'A framework of application security verification requirements.',
        url: 'https://owasp.org/www-project-application-security-verification-standard/',
        icon: Icons.checklist_rounded,
      ),
      LearningResource(
        name: 'OWASP API Security Top 10',
        descriptionAr: 'أهم مخاطر أمن واجهات API وإرشادات الحد منها.',
        descriptionEn: 'Key API security risks and mitigation guidance.',
        url: 'https://owasp.org/projects/api-security-project',
        icon: Icons.api_outlined,
      ),
      LearningResource(
        name: 'OWASP SAMM',
        descriptionAr: 'نموذج نضج يساعد المؤسسات على تحسين أمن البرمجيات.',
        descriptionEn: 'A maturity model for improving software assurance.',
        url: 'https://owaspsamm.org/',
        icon: Icons.trending_up_rounded,
      ),
      LearningResource(
        name: 'OWASP Cheat Sheet Series',
        descriptionAr: 'إرشادات مختصرة للمطورين والمهندسين الأمنيين.',
        descriptionEn:
            'Concise guidance for developers and security engineers.',
        url: 'https://cheatsheetseries.owasp.org/',
        icon: Icons.menu_book_outlined,
      ),
      LearningResource(
        name: 'PortSwigger Web Security Academy',
        descriptionAr: 'دروس ومختبرات ويب تعليمية مخصصة للتدريب.',
        descriptionEn:
            'Free web security lessons and purpose-built training labs.',
        url: 'https://portswigger.net/web-security',
        icon: Icons.language_rounded,
      ),
      LearningResource(
        name: 'OWASP Juice Shop',
        descriptionAr: 'تطبيق تدريبي متعمد الضعف شغّله محلياً داخل مختبر.',
        descriptionEn:
            'Intentionally vulnerable training app; run in a local lab.',
        url: 'https://owasp.org/www-project-juice-shop/',
        icon: Icons.local_drink_outlined,
      ),
      LearningResource(
        name: 'OWASP Threat Dragon',
        descriptionAr: 'نمذجة تهديدات مفتوحة المصدر لتصميم الأنظمة.',
        descriptionEn: 'Open-source threat modeling for system design.',
        url: 'https://owasp.org/www-project-threat-dragon/',
        icon: Icons.account_tree_outlined,
      ),
      LearningResource(
        name: 'SEI CERT Secure Coding',
        descriptionAr: 'قواعد ومراجع البرمجة الآمنة من معهد SEI.',
        descriptionEn: 'Secure coding standards and references from SEI.',
        url: 'https://www.sei.cmu.edu/library/sei-cert-coding-standards-wiki/',
        icon: Icons.code_rounded,
      ),
    ],
  ),
  LearningResourceSection(
    'السحابة والحاويات وسلسلة التوريد',
    'Cloud, containers & supply chain',
    [
      LearningResource(
        name: 'CIS Benchmarks',
        descriptionAr: 'خطوط أساس لتقوية إعداد الأنظمة والخدمات.',
        descriptionEn:
            'Configuration baselines for hardening systems and services.',
        url: 'https://www.cisecurity.org/cis-benchmarks',
        icon: Icons.cloud_outlined,
      ),
      LearningResource(
        name: 'Kubernetes Security',
        descriptionAr: 'دليل Kubernetes الرسمي لأمن العناقيد وأفضل الممارسات.',
        descriptionEn: 'Official Kubernetes guidance for cluster security.',
        url: 'https://kubernetes.io/docs/concepts/security/',
        icon: Icons.view_in_ar_outlined,
      ),
      LearningResource(
        name: 'OWASP Kubernetes Top 10',
        descriptionAr: 'مخاطر شائعة لتأمين Kubernetes وطرق الحد منها.',
        descriptionEn: 'Common Kubernetes risks and mitigation guidance.',
        url: 'https://owasp.org/www-project-kubernetes-top-ten/',
        icon: Icons.grid_view_rounded,
      ),
      LearningResource(
        name: 'AWS Well-Architected Security Pillar',
        descriptionAr: 'ممارسات مرجعية لتصميم أحمال AWS بأمان.',
        descriptionEn: 'Reference practices for securing AWS workloads.',
        url: 'https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/welcome.html',
        icon: Icons.cloud_done_outlined,
      ),
      LearningResource(
        name: 'Microsoft Cloud Security',
        descriptionAr: 'مركز توثيق ومراجع أمن خدمات Microsoft السحابية.',
        descriptionEn: 'Security documentation for Microsoft cloud services.',
        url: 'https://learn.microsoft.com/security/',
        icon: Icons.cloud_outlined,
      ),
      LearningResource(
        name: 'Google Cloud Security Foundations',
        descriptionAr: 'إطار مرجعي لتصميم بيئات Google Cloud الآمنة.',
        descriptionEn:
            'Blueprint for designing secure Google Cloud environments.',
        url: 'https://cloud.google.com/architecture/security-foundations',
        icon: Icons.foundation_outlined,
      ),
      LearningResource(
        name: 'OpenSSF',
        descriptionAr:
            'مبادرات وأدوات لحماية النظام البيئي للبرمجيات مفتوحة المصدر.',
        descriptionEn:
            'Initiatives and tools for open-source software security.',
        url: 'https://openssf.org/',
        icon: Icons.lock_outline_rounded,
      ),
      LearningResource(
        name: 'SLSA Framework',
        descriptionAr: 'إطار مستويات لضمان سلامة سلسلة بناء البرمجيات.',
        descriptionEn: 'A framework for improving software build provenance.',
        url: 'https://slsa.dev/',
        icon: Icons.integration_instructions_outlined,
      ),
      LearningResource(
        name: 'OWASP Dependency-Check',
        descriptionAr: 'فحص الاعتماديات بحثاً عن مكونات ذات ثغرات معروفة.',
        descriptionEn:
            'Identify project dependencies with known vulnerabilities.',
        url: 'https://owasp.org/www-project-dependency-check/',
        icon: Icons.device_hub_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'التحقيق الجنائي الرقمي وDFIR',
    'Digital forensics & DFIR',
    [
      LearningResource(
        name: 'The DFIR Report',
        descriptionAr: 'تحليلات لحوادث منشورة مع تسلسل زمني ومؤشرات.',
        descriptionEn: 'Incident analyses with timelines and indicators.',
        url: 'https://thedfirreport.com/',
        icon: Icons.description_outlined,
      ),
      LearningResource(
        name: 'Volatility Foundation',
        descriptionAr: 'توثيق ومراجع لتحليل الذاكرة الجنائي.',
        descriptionEn: 'Documentation and references for memory forensics.',
        url: 'https://volatilityfoundation.org/',
        icon: Icons.memory_outlined,
      ),
      LearningResource(
        name: 'Autopsy Digital Forensics',
        descriptionAr: 'منصة مفتوحة للتحقيق الجنائي الرقمي وتحليل الأدلة.',
        descriptionEn: 'Open digital forensics platform and evidence analysis.',
        url: 'https://www.autopsy.com/',
        icon: Icons.find_in_page_outlined,
      ),
      LearningResource(
        name: 'Plaso / log2timeline',
        descriptionAr: 'مشروع بناء خطوط زمنية من مصادر الأدلة الرقمية.',
        descriptionEn:
            'Create timelines from digital forensic evidence sources.',
        url: 'https://plaso.readthedocs.io/',
        icon: Icons.timeline_rounded,
      ),
      LearningResource(
        name: 'Velociraptor Documentation',
        descriptionAr: 'توثيق جمع الأدلة والتحقيق على نقاط النهاية.',
        descriptionEn: 'Endpoint collection and investigation documentation.',
        url: 'https://docs.velociraptor.app/',
        icon: Icons.devices_other_rounded,
      ),
      LearningResource(
        name: 'REMnux',
        descriptionAr:
            'بيئة Linux متخصصة لتحليل البرمجيات الضارة داخل مختبر معزول.',
        descriptionEn: 'Linux toolkit for malware analysis in an isolated lab.',
        url: 'https://remnux.org/',
        icon: Icons.biotech_outlined,
      ),
      LearningResource(
        name: 'CyberChef',
        descriptionAr:
            'أداة متصفح لتحويل وفك ترميزات البيانات وتحليلها محلياً.',
        descriptionEn:
            'Browser-based data transformations and decoding utility.',
        url: 'https://gchq.github.io/CyberChef/',
        icon: Icons.science_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'استخبارات التهديدات وOSINT',
    'Threat intelligence & OSINT',
    [
      LearningResource(
        name: 'MISP Project',
        descriptionAr: 'منصة مفتوحة لمشاركة وإدارة مؤشرات التهديد.',
        descriptionEn:
            'Open platform for sharing and managing threat indicators.',
        url: 'https://www.misp-project.org/',
        icon: Icons.hub_outlined,
      ),
      LearningResource(
        name: 'OpenCTI',
        descriptionAr: 'منصة لإدارة وربط معلومات استخبارات التهديدات.',
        descriptionEn:
            'Platform for managing and relating threat intelligence.',
        url: 'https://www.opencti.io/',
        icon: Icons.hub_outlined,
      ),
      LearningResource(
        name: 'abuse.ch ThreatFox',
        descriptionAr: 'قاعدة مجتمعية لمؤشرات البرمجيات الضارة.',
        descriptionEn: 'Community database of malware indicators.',
        url: 'https://threatfox.abuse.ch/',
        icon: Icons.travel_explore_rounded,
      ),
      LearningResource(
        name: 'URLhaus',
        descriptionAr: 'مشاركة عناوين URL المرتبطة بتوزيع البرمجيات الضارة.',
        descriptionEn: 'Share URLs associated with malware distribution.',
        url: 'https://urlhaus.abuse.ch/',
        icon: Icons.link_rounded,
      ),
      LearningResource(
        name: 'AlienVault OTX',
        descriptionAr: 'مجتمع وموجزات لمؤشرات التهديد المفتوحة.',
        descriptionEn:
            'Community threat intelligence and open indicator feeds.',
        url: 'https://otx.alienvault.com/',
        icon: Icons.public_rounded,
      ),
      LearningResource(
        name: 'OSINT Framework',
        descriptionAr: 'دليل مصنف لأدوات ومصادر المعلومات المفتوحة.',
        descriptionEn:
            'Categorized directory of open-source intelligence resources.',
        url: 'https://osintframework.com/',
        icon: Icons.account_tree_outlined,
      ),
      LearningResource(
        name: 'Bellingcat Online Investigation Toolkit',
        descriptionAr: 'أدوات ومنهجيات التحقيق بالمصادر المفتوحة.',
        descriptionEn: 'Tools and methods for open-source investigations.',
        url: 'https://bellingcat.gitbook.io/toolkit/',
        icon: Icons.search_rounded,
      ),
      LearningResource(
        name: 'urlscan.io',
        descriptionAr:
            'خدمة فحص صفحات الويب؛ تذكر أن الإرسال قد يجعل URL مرئياً للآخرين.',
        descriptionEn: 'Website scanning service; submitted URLs may become visible to others.',
        url: 'https://urlscan.io/',
        icon: Icons.travel_explore_outlined,
      ),
      LearningResource(
        name: 'Censys Search',
        descriptionAr: 'محرك بحث للأصول والخدمات المكشوفة على الإنترنت.',
        descriptionEn:
            'Search engine for internet-exposed assets and services.',
        url: 'https://docs.censys.com/',
        icon: Icons.radar_rounded,
      ),
    ],
  ),
  LearningResourceSection(
    'الثغرات والمعايير والخصوصية',
    'Vulnerabilities, standards & privacy',
    [
      LearningResource(
        name: 'NIST National Vulnerability Database',
        descriptionAr: 'مصدر NIST لبيانات CVE ومعلومات الثغرات.',
        descriptionEn: 'NIST source for CVE and vulnerability information.',
        url: 'https://nvd.nist.gov/',
        icon: Icons.warning_amber_rounded,
      ),
      LearningResource(
        name: 'MITRE CWE',
        descriptionAr: 'تصنيف لأنماط الضعف البرمجي الشائعة.',
        descriptionEn: 'Catalog of common software weakness types.',
        url: 'https://cwe.mitre.org/',
        icon: Icons.category_outlined,
      ),
      LearningResource(
        name: 'FIRST CVSS',
        descriptionAr: 'المعيار المفتوح لتقدير شدة الثغرات الأمنية.',
        descriptionEn: 'Open standard for rating vulnerability severity.',
        url: 'https://www.first.org/cvss/',
        icon: Icons.speed_rounded,
      ),
      LearningResource(
        name: 'FIRST EPSS',
        descriptionAr: 'تقدير احتمالية استغلال الثغرات وفق بيانات عامة.',
        descriptionEn: 'Estimate exploitation probability from public data.',
        url: 'https://www.first.org/epss/',
        icon: Icons.query_stats_rounded,
      ),
      LearningResource(
        name: 'Privacy Guides',
        descriptionAr: 'إرشادات عملية لتحسين الخصوصية الرقمية.',
        descriptionEn:
            'Practical recommendations for improving digital privacy.',
        url: 'https://www.privacyguides.org/',
        icon: Icons.privacy_tip_outlined,
      ),
      LearningResource(
        name: 'EFF Surveillance Self-Defense',
        descriptionAr: 'دليل دفاع رقمي وإدارة مخاطر الخصوصية.',
        descriptionEn: 'Digital self-defense and privacy risk guidance.',
        url: 'https://ssd.eff.org/',
        icon: Icons.security_outlined,
      ),
      LearningResource(
        name: 'Have I Been Pwned',
        descriptionAr:
            'تحقق يدوي من ظهور البريد ضمن تسريبات؛ لا تشارك كلمات المرور.',
        descriptionEn: 'Check whether an email appears in breaches; never enter passwords.',
        url: 'https://haveibeenpwned.com/',
        icon: Icons.mail_lock_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'مصادر ومراكز عربية رسمية',
    'Arabic official cyber resources',
    [
      LearningResource(
        name: 'الهيئة الوطنية للأمن السيبراني — السعودية',
        descriptionAr: 'أطر وضوابط وإرشادات الجهة الوطنية للأمن السيبراني.',
        descriptionEn:
            'Saudi National Cybersecurity Authority frameworks and guidance.',
        url: 'https://nca.gov.sa/',
        icon: Icons.account_balance_outlined,
      ),
      LearningResource(
        name: 'المركز الوطني الإرشادي للأمن السيبراني',
        descriptionAr: 'تنبيهات وتوعية وإرشادات أمن سيبراني باللغة العربية.',
        descriptionEn: 'Arabic cybersecurity awareness and advisories.',
        url: 'https://cert.gov.sa/',
        icon: Icons.campaign_outlined,
      ),
      LearningResource(
        name: 'قطر — NCSA',
        descriptionAr: 'الجهة الوطنية للأمن السيبراني في دولة قطر.',
        descriptionEn: 'Qatar National Cyber Security Agency.',
        url: 'https://www.ncsa.gov.qa/',
        icon: Icons.account_balance_outlined,
      ),
      LearningResource(
        name: 'المركز الوطني للأمن السيبراني — الأردن',
        descriptionAr: 'مواد توعوية وإعلانات ومراجع وطنية للأمن السيبراني.',
        descriptionEn:
            'Jordanian national cybersecurity awareness and guidance.',
        url: 'https://ncsc.jo/',
        icon: Icons.account_balance_outlined,
      ),
      LearningResource(
        name: 'Oman CERT',
        descriptionAr: 'مركز الاستجابة لطوارئ الحاسوب في سلطنة عُمان.',
        descriptionEn: 'Oman Computer Emergency Readiness Team.',
        url: 'https://cert.gov.om/',
        icon: Icons.account_balance_outlined,
      ),
      LearningResource(
        name: 'الأكاديمية الوطنية للأمن السيبراني',
        descriptionAr: 'مسارات وبرامج لتنمية المهارات السيبرانية في السعودية.',
        descriptionEn:
            'Cybersecurity learning programmes and skills development.',
        url: 'https://nca.gov.sa/en/initiatives/academy/',
        icon: Icons.school_outlined,
      ),
      LearningResource(
        name: 'مجلس الأمن السيبراني الإماراتي',
        descriptionAr: 'تنبيهات تهديدات وإرشادات وسياسات وطنية ومعلومات للإبلاغ عن الحوادث.',
        descriptionEn: 'UAE threat alerts, national cybersecurity guidance and incident reporting.',
        url: 'https://www.cisa.gov/resources-tools',
        icon: Icons.account_balance_outlined,
      ),
      LearningResource(
        name: 'EG-CERT — مصر',
        descriptionAr:
            'استجابة للحوادث السيبرانية وتحليل وإنذار مبكر للتهديدات.',
        descriptionEn: 'Egyptian cyber incident response, analysis and early threat warnings.',
        url: 'https://www.cisa.gov/report',
        icon: Icons.emergency_outlined,
      ),
      LearningResource(
        name: 'DGSSI وmaCERT — المغرب',
        descriptionAr: 'المديرية العامة لأمن نظم المعلومات وخدمة المساعدة في الاستجابة للحوادث.',
        descriptionEn: 'Morocco’s information-systems security directorate and maCERT incident-response support.',
        url: 'https://www.ncsc.gov.uk/collection/incident-management',
        icon: Icons.shield_outlined,
      ),
      LearningResource(
        name: 'الوكالة الوطنية للأمن السيبراني — تونس',
        descriptionAr:
            'تنبيهات وثغرات وخدمات إرشاد ومساعدة وطنية في الأمن السيبراني.',
        descriptionEn: 'Tunisian cybersecurity alerts, vulnerability information and guidance.',
        url: 'https://www.ancs.tn/',
        icon: Icons.campaign_outlined,
      ),
      LearningResource(
        name: 'المركز الوطني للأمن السيبراني — البحرين',
        descriptionAr:
            'الاستراتيجية الوطنية والمعايير ومبادرات التوعية السيبرانية.',
        descriptionEn: 'Bahrain’s national cybersecurity strategy, standards and awareness initiatives.',
        url: 'https://www.ncsc.gov.bh/en/about/who-are-we.html',
        icon: Icons.account_balance_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'مشهد التهديدات والبحث في الثغرات',
    'Threat landscape & vulnerability research',
    [
      LearningResource(
        name: 'ENISA Threat Landscape',
        descriptionAr: 'تحليلات وتقارير عن مشهد التهديدات والحوادث والقطاعات المستهدفة في أوروبا.',
        descriptionEn: 'European threat-landscape reports analyzing incidents, trends and targeted sectors.',
        url:
            'https://www.enisa.europa.eu/topics/cyber-threats/threat-landscape',
        icon: Icons.public_outlined,
      ),
      LearningResource(
        name: 'CERT/CC Vulnerability Notes',
        descriptionAr:
            'ملاحظات ثغرات تقنية تتضمن الجهات المتأثرة ومعلومات المعالجة.',
        descriptionEn: 'Technical vulnerability notes with affected vendors and mitigation information.',
        url: 'https://www.kb.cert.org/vuls/',
        icon: Icons.warning_amber_rounded,
      ),
      LearningResource(
        name: 'Google Project Zero',
        descriptionAr: 'أبحاث أمنية متخصصة في اكتشاف الثغرات والإفصاح عنها، ومنها ثغرات اليوم الصفري.',
        descriptionEn: 'Security research on vulnerability discovery and disclosure, including zero-days.',
        url: 'https://projectzero.google/',
        icon: Icons.search_rounded,
      ),
      LearningResource(
        name: 'Microsoft Security Response Center',
        descriptionAr: 'بلاغات الثغرات والتحقيق فيها وتحديثات ومنشورات أمن منتجات Microsoft.',
        descriptionEn: 'Microsoft vulnerability reporting, investigation and security update guidance.',
        url: 'https://msrc.microsoft.com/',
        icon: Icons.security_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'اكتشاف البرمجيات مفتوحة المصدر',
    'Discover open-source software',
    [
      LearningResource(
        name: 'Open Source Alternative',
        descriptionAr: 'دليل ويب لاكتشاف بدائل مفتوحة المصدر حسب المنتج والفئة؛ ليس موجز أخبار.',
        descriptionEn: 'A web directory for finding open-source alternatives by product and category; not a news feed.',
        url: 'https://www.opensourcealternative.to/',
        icon: Icons.travel_explore_rounded,
      ),
    ],
  ),
  LearningResourceSection(
    'الأمن السيبراني والتهديدات',
    'Cybersecurity & threat intelligence',
    [
      LearningResource(
        name: 'NIST NICE: Free and Low Cost Online Cybersecurity Learning Content',
        descriptionAr: 'دليل رسمي من NIST لمحتوى تعلّم إلكتروني مجاني أو منخفض التكلفة، مع مسارات للتطوير المهني والتوعية والتدريب التعليمي.',
        descriptionEn: 'NIST NICE\'s maintained directory of free and low-cost online cybersecurity education, grouped by career development, awareness, educator, and K-12 content.',
        url: 'https://www.nist.gov/itl/applied-cybersecurity/nice/resources/online-learning-content',
        icon: Icons.security_rounded,
      ),
      LearningResource(
        name: 'MITRE ATT&CK CTI Training and Learning Resources',
        descriptionAr: 'صفحة MITRE الرسمية للتعلّم العملي حول ATT&CK، وتتضمن تدريب استخبارات التهديدات وموادًا عن تطبيق الإطار.',
        descriptionEn: 'MITRE\'s official ATT&CK learning page with CTI training modules, presentations, and reading materials explaining practical use and framework design.',
        url: 'https://attack.mitre.org/resources/learn-more-about-attack/',
        icon: Icons.security_rounded,
      ),
    ],
  ),
  LearningResourceSection(
    'الذكاء الاصطناعي وتعلم الآلة',
    'AI & machine learning',
    [
      LearningResource(
        name: 'Machine Learning Systems (MLSysBook)',
        descriptionAr: 'كتاب ومنهج مفتوح الوصول لهندسة أنظمة التعلم الآلي، مع مختبرات تفاعلية وTinyTorch ونمذجة أداء ونشر على العتاد.',
        descriptionEn: 'An open-access, actively maintained textbook and curriculum for engineering intelligent systems, with interactive labs, TinyTorch, performance modeling, and hardware deployment.',
        url: 'https://www.mlsysbook.ai/',
        icon: Icons.memory_rounded,
      ),
      LearningResource(
        name: 'Full Stack Deep Learning',
        descriptionAr: 'دورات ومواد عملية لبناء منتجات مدعومة بالذكاء الاصطناعي عبر دورة الحياة كاملة، من اختيار النموذج ووحدة GPU إلى النشر والتعلم المستمر.',
        descriptionEn: 'Practical courses and guidance for building AI-powered products across the lifecycle, from model/GPU selection and LLMOps to deployment, UX, and continual learning.',
        url: 'https://fullstackdeeplearning.com/',
        icon: Icons.memory_rounded,
      ),
    ],
  ),
  LearningResourceSection(
    'البرمجة وهندسة البرمجيات',
    'Programming & software engineering',
    [
      LearningResource(
        name: 'Google Engineering Practices Documentation',
        descriptionAr: 'مرجع عملي لمراجعة الكود، يتضمن أدلة المراجع ومؤلف التغيير وممارسات هندسية عامة.',
        descriptionEn: 'Practical engineering guidance centered on code review, with separate reviewer and change-author guides applicable across languages and projects.',
        url: 'https://google.github.io/eng-practices/',
        icon: Icons.code_rounded,
      ),
      LearningResource(
        name: 'C4 Model',
        descriptionAr: 'منهج سهل التعلم وصديق للمطورين لرسم وتوثيق معمارية البرمجيات باستخدام تجريدات ومخططات هرمية.',
        descriptionEn: 'A developer-friendly, easy-to-learn reference for visualizing software architecture through hierarchical abstractions and diagrams.',
        url: 'https://c4model.com/',
        icon: Icons.code_rounded,
      ),
    ],
  ),
  LearningResourceSection(
    'Linux والأنظمة مفتوحة المصدر',
    'Linux & open systems',
    [
      LearningResource(
        name: 'ArchWiki',
        descriptionAr: 'مرجع Arch Linux الرسمي العملي؛ يضم دليل التثبيت، توصيات ما بعد التثبيت، إدارة الحزم، استكشاف الأعطال وفئات واسعة من توثيق Linux.',
        descriptionEn: 'The Arch Linux documentation reference with installation, post-install recommendations, package/system administration, troubleshooting, and broad Linux how-to coverage.',
        url: 'https://wiki.archlinux.org/',
        icon: Icons.terminal_rounded,
      ),
      LearningResource(
        name: 'Linux From Scratch (LFS)',
        descriptionAr: 'دروس عملية خطوة بخطوة لبناء نظام Linux مخصص من الشفرة المصدرية، مع كتب BLFS وALFS وMLFS وSLFS للتوسعة والأتمتة.',
        descriptionEn: 'Step-by-step practical instructions for building a custom Linux system entirely from source, with related books for beyond-LFS configuration, automation, multilib, and supplemental systems.',
        url: 'https://www.linuxfromscratch.org/',
        icon: Icons.terminal_rounded,
      ),
    ],
  ),

  LearningResourceSection('السحابة وDevOps', 'Cloud & DevOps', [
    LearningResource(
      name: 'Platform Engineering University: Kubernetes Cluster Lifecycle Management',
      descriptionAr: 'دورة مجانية عند الطلب لمدة ساعتين حول إدارة دورة حياة عناقيد Kubernetes، وعمليات Day 2، والأتمتة وGitOps والحوكمة والأمن متعدد العناقيد.',
      descriptionEn: 'A free, two-hour on-demand course covering declarative Kubernetes cluster lifecycle management, Day 2 operations, automation/GitOps, multi-cluster governance, and security.',
      url: 'https://university.platformengineering.org/kubernetes-cluster-lifecycle-management-in-platform-engineering',
      icon: Icons.cloud_rounded,
    ),
    LearningResource(
      name: 'OpenTofu Documentation: Introduction',
      descriptionAr: 'مرجع عملي رسمي يشرح تعريف موارد السحابة والمحلية، وسير عمل Write/Plan/Apply، والمزوّدين والوحدات وحالة البنية التحتية.',
      descriptionEn: 'Official practical documentation explaining cloud and on-premises resource definitions, the Write/Plan/Apply workflow, providers, modules, state, and automation.',
      url: 'https://opentofu.org/docs/intro/',
      icon: Icons.cloud_rounded,
    ),
  ]),
  LearningResourceSection('Android والهواتف المحمولة', 'Android & mobile', [
    LearningResource(
      name: 'Android Developers Training',
      descriptionAr: 'دورات ومسارات عملية رسمية لتعلم تطوير Android باستخدام Kotlin وJetpack Compose، مع بنية التطبيقات والتخزين والشبكات والاختبار.',
      descriptionEn: 'Official hands-on Android training courses and pathways covering Kotlin, Jetpack Compose, app architecture, storage, networking, testing, and accessibility.',
      url: 'https://developer.android.com/courses',
      icon: Icons.phone_android_rounded,
    ),
    LearningResource(
      name: 'AOSP Android Security documentation',
      descriptionAr: 'مرجع عملي رسمي لأمن منصة Android يتناول نظرة عامة، ميزات الأمان، النشرات الأمنية، الاختبار، وأفضل ممارسات الخصوصية.',
      descriptionEn: 'Official AOSP security reference covering the Android security model, device security features, bulletins, security testing, and privacy best practices.',
      url: 'https://source.android.com/docs/security',
      icon: Icons.phone_android_rounded,
    ),
  ]),
  LearningResourceSection(
    'الخصوصية والأجهزة والتقنية الاستهلاكية',
    'Privacy & consumer technology',
    [
      LearningResource(
        name: 'Internet Society: Privacy Course',
        descriptionAr: 'دورة ذاتية التعلم تشرح الخصوصية على الإنترنت، التهديدات، أطر الخصوصية، حقوق الأفراد، ومبادئ جمع البيانات الأخلاقي.',
        descriptionEn: 'A self-paced course covering online privacy, threats, privacy frameworks, individual rights, and ethical data collection.',
        url: 'https://www.internetsociety.org/learning/privacy/',
        icon: Icons.privacy_tip_rounded,
      ),
      LearningResource(
        name: 'Privacy Guides: Why Privacy Matters',
        descriptionAr: 'مرجع عملي يميز بين الخصوصية والأمن وإخفاء الهوية، ويقدم مدخلاً إلى نمذجة التهديدات واختيار أدوات وتقنيات أكثر حماية.',
        descriptionEn: 'A practical reference distinguishing privacy, security, and anonymity, with links into threat modeling and safer technology choices.',
        url: 'https://www.privacyguides.org/en/basics/why-privacy-matters/',
        icon: Icons.privacy_tip_rounded,
      ),
    ],
  ),

  LearningResourceSection(
    'مصادر عربية ومسارات تعليمية',
    'Arabic resources & learning paths',
    [
      LearningResource(
        name: 'مركز التعلم — أكاديمية سينباي',
        descriptionAr: 'مركز عربي عملي يجمع قنوات ومنصات ومختبرات CTF وشهادات، إضافة إلى مكتبات payloads وسيناريوهات هجوم وCheat Sheets؛ الروابط مباشرة ومحدّثة وموسومة مجانية.',
        descriptionEn: 'An Arabic practical learning hub aggregating channels, hands-on CTF platforms/labs, certifications, payload references, attack scenarios, and cheat sheets.',
        url: 'https://academysenpai.com/learning',
        icon: Icons.menu_book_rounded,
      ),
      LearningResource(
        name: 'الأدلة الإرشادية — سايبرنس',
        descriptionAr: 'مكتبة عربية مجانية وتفاعلية للتوعية العملية بالأمن السيبراني، تشمل التصيد وكلمات المرور والمصادقة والجرائم السيبرانية وحماية الشركات الصغيرة والطلاب.',
        descriptionEn: 'A free Arabic interactive cybersecurity guidance library covering phishing, passwords/MFA, cybercrime, small-business security, student safety, and social-media protection.',
        url: 'https://www.nist.gov/cyberframework',
        icon: Icons.menu_book_rounded,
      ),
    ],
  ),
  LearningResourceSection(
    'مصادر بيانات وأبحاث محدثة',
    'Data sources & security research',
    [
      LearningResource(
        name: 'OSV.dev API',
        descriptionAr: 'قاعدة مفتوحة للاستعلام عن الثغرات حسب الحزمة والإصدار؛ النتائج تحتاج تفسيراً وتغطيتها ليست شاملة.',
        descriptionEn: 'Open vulnerability queries by package and version; interpret results and do not treat coverage as complete.',
        url: 'https://google.github.io/osv.dev/api/',
        icon: Icons.data_object_outlined,
      ),
      LearningResource(
        name: 'GitHub Advisory Database',
        descriptionAr: 'قاعدة استشارات للمشاريع مفتوحة المصدر مع تصفية حسب النظام البيئي والشدة.',
        descriptionEn: 'Advisory database for open-source projects with ecosystem and severity filters.',
        url: 'https://docs.github.com/en/code-security/security-advisories/working-with-global-security-advisories-from-the-github-advisory-database',
        icon: Icons.storage_outlined,
      ),
      LearningResource(
        name: 'ENISA Publications',
        descriptionAr: 'تقارير أوروبية رسمية عن التهديدات والهوية والقطاعات الحرجة والمهارات.',
        descriptionEn: 'Official European reports on threats, identity, critical sectors, and skills.',
        url: 'https://www.enisa.europa.eu/publications',
        icon: Icons.public_outlined,
      ),
      LearningResource(
        name: 'NIST CSRC Publications',
        descriptionAr: 'فهرس المنشورات والمعايير والمسودات التقنية؛ المسودة ليست معياراً نهائياً.',
        descriptionEn: 'Index of technical publications, standards, and drafts; drafts are not final standards.',
        url: 'https://csrc.nist.gov/publications',
        icon: Icons.menu_book_outlined,
      ),
      LearningResource(
        name: 'arXiv cs.CR',
        descriptionAr:
            'فهرس أبحاث في التشفير والأمن؛ الأوراق المسبقة قد لا تكون محكمة.',
        descriptionEn: 'Cryptography and security preprints; papers may not be peer reviewed.',
        url: 'https://arxiv.org/list/cs.CR/recent',
        icon: Icons.science_outlined,
      ),
      LearningResource(
        name: 'USENIX Security Proceedings',
        descriptionAr:
            'أبحاث ومداولات مؤتمر أمني متقدمة مع روابط النص الأصلي والمؤلفين.',
        descriptionEn: 'Advanced security research proceedings with original paper and author links.',
        url: 'https://www.usenix.org/conferences/byname/685',
        icon: Icons.school_outlined,
      ),
      LearningResource(
        name: 'CyLab Security Academy / picoCTF',
        descriptionAr:
            'تدريب عملي ومسابقات تعليمية من Carnegie Mellon بمستويات متعددة.',
        descriptionEn: 'Practical training and educational challenges from Carnegie Mellon at multiple levels.',
        url: 'https://picoctf.org/',
        icon: Icons.emoji_events_outlined,
      ),
      LearningResource(
        name: 'OverTheWire Wargames',
        descriptionAr: 'تمارين متدرجة في Linux والشبكات والويب والتشفير داخل مختبرات تعليمية.',
        descriptionEn: 'Progressive Linux, networking, web, and cryptography exercises in educational labs.',
        url: 'https://overthewire.org/wargames/',
        icon: Icons.games_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'إدارة الحوادث والاستجابة للتسريب',
    'Incident response & leak recovery',
    [
      LearningResource(
        name: 'CISA: I’ve Been Hit By Ransomware',
        descriptionAr: 'إرشادات رسمية للاستجابة للفدية تشمل العزل، حفظ الأدلة، الإبلاغ، والاستعادة من نسخ سليمة؛ استخدمها مع مختصي الاستجابة عند تأثر مؤسسة.',
        descriptionEn: 'Official ransomware-response guidance covering isolation, evidence, reporting, and recovery from clean backups; involve incident responders for organizational incidents.',
        url: 'https://www.cisa.gov/stopransomware/ive-been-hit-ransomware',
        icon: Icons.emergency_outlined,
      ),
      LearningResource(
        name: 'UK NCSC: Recovering a hacked account',
        descriptionAr: 'دليل عملي لاستعادة حساب مخترق والتحقق من كلمات المرور والأجهزة وإعدادات الأمان.',
        descriptionEn: 'Practical guidance for recovering a hacked account and reviewing passwords, devices, and security settings.',
        url: 'https://www.ncsc.gov.uk/guidance/recovering-a-hacked-account',
        icon: Icons.manage_accounts_outlined,
      ),
      LearningResource(
        name: 'GitHub Docs: Remediating a leaked secret',
        descriptionAr: 'خطوات لإبطال الرمز المكشوف، استبداله، التحقق من الاستخدام، وتنظيف المستودع بحذر.',
        descriptionEn: 'Steps to revoke and replace exposed credentials, investigate use, and carefully clean repository history.',
        url: 'https://docs.github.com/en/code-security/tutorials/remediate-leaked-secrets/remediating-a-leaked-secret',
        icon: Icons.key_off_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'الهوية والخصوصية والثقة الرقمية',
    'Identity, privacy & digital trust',
    [
      LearningResource(
        name: 'NIST Privacy Framework',
        descriptionAr:
            'إطار عملي لإدارة مخاطر الخصوصية داخل المنتجات والخدمات.',
        descriptionEn: 'Practical framework for managing privacy risk in products and services.',
        url: 'https://www.nist.gov/privacy-framework',
        icon: Icons.privacy_tip_outlined,
      ),
      LearningResource(
        name: 'NIST Digital Identity Guidelines',
        descriptionAr:
            'إرشادات رسمية لإثبات الهوية والمصادقة وإدارة دورة حياة الحساب.',
        descriptionEn: 'Official guidance for identity proofing, authentication, and account lifecycle.',
        url: 'https://pages.nist.gov/800-63-4/',
        icon: Icons.badge_outlined,
      ),
      LearningResource(
        name: 'Mozilla Privacy Not Included',
        descriptionAr: 'مورد توعوي لفهم مخاطر الخصوصية في المنتجات المتصلة.',
        descriptionEn: 'Consumer resource for understanding privacy risks in connected products.',
        url: 'https://foundation.mozilla.org/privacynotincluded/',
        icon: Icons.devices_other_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'أمن البيانات والتشفير',
    'Data security & cryptography',
    [
      LearningResource(
        name: 'NIST Cryptographic Standards',
        descriptionAr:
            'صفحة معايير NIST في التشفير وإدارة المفاتيح والخوارزميات.',
        descriptionEn:
            'NIST standards and guidance for cryptography and key management.',
        url: 'https://csrc.nist.gov/projects/cryptographic-standards-and-guidelines',
        icon: Icons.lock_outline_rounded,
      ),
      LearningResource(
        name: 'OWASP Cryptographic Storage Cheat Sheet',
        descriptionAr:
            'إرشادات للمطورين حول تخزين البيانات الحساسة واختيار التشفير.',
        descriptionEn: 'Developer guidance for sensitive-data storage and cryptographic choices.',
        url: 'https://cheatsheetseries.owasp.org/cheatsheets/Cryptographic_Storage_Cheat_Sheet.html',
        icon: Icons.enhanced_encryption_outlined,
      ),
      LearningResource(
        name: 'Google Security Engineering',
        descriptionAr:
            'كتاب ومراجع هندسة أمنية حول تصميم الأنظمة القابلة للتوسع بأمان.',
        descriptionEn: 'Security engineering material on designing secure scalable systems.',
        url: 'https://google.github.io/security-research/',
        icon: Icons.architecture_outlined,
      ),
    ],
  ),
  LearningResourceSection('أمن الذكاء الاصطناعي', 'AI security', [
    LearningResource(
      name: 'NIST AI Risk Management Framework',
      descriptionAr:
          'إطار لإدارة مخاطر الذكاء الاصطناعي وقياس الثقة والمسؤولية.',
      descriptionEn:
          'Framework for managing AI risks and measuring trustworthy AI.',
      url: 'https://www.nist.gov/itl/ai-risk-management-framework',
      icon: Icons.smart_toy_outlined,
    ),
    LearningResource(
      name: 'OWASP Top 10 for LLM Applications',
      descriptionAr: 'مخاطر تطبيقات النماذج اللغوية الكبيرة وضوابط الحد منها.',
      descriptionEn: 'Risks and mitigations for applications built with large language models.',
      url: 'https://owasp.org/www-project-top-10-for-large-language-model-applications/',
      icon: Icons.psychology_outlined,
    ),
    LearningResource(
      name: 'Google Secure AI Framework',
      descriptionAr: 'مبادئ أمنية لبناء ونشر أنظمة الذكاء الاصطناعي.',
      descriptionEn:
          'Security principles for building and deploying AI systems.',
      url: 'https://safety.google/cybersecurity-advancements/saif/',
      icon: Icons.auto_awesome_outlined,
    ),
  ]),

  LearningResourceSection(
    'هندسة الكشف وMITRE ATT&CK',
    'Detection engineering & MITRE ATT&CK',
    [
      LearningResource(
        name: 'استراتيجيات الكشف في MITRE ATT&CK',
        descriptionAr: 'مرجع رسمي يشرح تحويل تقنيات الخصم إلى استراتيجيات كشف وتحليلات دفاعية قابلة للاختبار.',
        descriptionEn: 'Official reference for turning adversary techniques into testable defensive detection strategies.',
        url: 'https://attack.mitre.org/detectionstrategies/',
        icon: Icons.security_outlined,
      ),
      LearningResource(
        name: 'العثور على التهديدات باستخدام ATT&CK',
        descriptionAr: 'منهجية MITRE لاختيار الحساسات وبناء واختبار التحليلات السلوكية وتحليل فجوات الكشف.',
        descriptionEn: 'MITRE methodology for selecting sensors, building and testing behavioral analytics, and analyzing detection gaps.',
        url: 'https://www.mitre.org/sites/default/files/2023-08/16-3713-finding-cyber-threats-with-attack-based-analytics.pdf',
        icon: Icons.analytics_outlined,
      ),
      LearningResource(
        name: 'أفضل الممارسات لربط ATT&CK',
        descriptionAr: 'دليل CISA وHSSEDI لربط السلوكيات بتقنيات ATT&CK بدقة وسياق تقني كافٍ.',
        descriptionEn: 'CISA and HSSEDI guidance for accurate, context-rich mapping of behaviors to ATT&CK techniques.',
        url: 'https://www.cisa.gov/sites/default/files/2023-01/Best%20Practices%20for%20MITRE%20ATTCK%20Mapping.pdf',
        icon: Icons.policy_outlined,
      ),
      LearningResource(
        name: 'مستودع التحليلات السيبرانية من MITRE',
        descriptionAr: 'قاعدة تحليلات دفاعية تتضمن الفرضية ومصادر البيانات ونموذج البيانات واختبارات التحقق.',
        descriptionEn: 'Defensive analytics documenting hypotheses, data sources, data models, and validation tests.',
        url: 'https://car.mitre.org/',
        icon: Icons.fact_check_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'الاستجابة للحوادث والتحقيق الرقمي',
    'Incident response & digital forensics',
    [
      LearningResource(
        name: 'توصيات الاستجابة للحوادث — NIST SP 800-61r3',
        descriptionAr: 'إطار NIST الأحدث لدمج الاستعداد والكشف والاستجابة والتعافي في إدارة المخاطر.',
        descriptionEn: 'NIST guidance for integrating preparation, detection, response, and recovery into risk management.',
        url: 'https://csrc.nist.gov/pubs/sp/800/61/r3/final',
        icon: Icons.policy_outlined,
      ),
      LearningResource(
        name: 'دمج التحقيق الجنائي في الاستجابة للحوادث',
        descriptionAr: 'دليل NIST لمصادر الأدلة من الملفات وأنظمة التشغيل والشبكات والتطبيقات ضمن استخدام مصرح.',
        descriptionEn: 'NIST guide to collecting and using evidence from files, operating systems, networks, and applications.',
        url: 'https://csrc.nist.gov/pubs/sp/800/86/final',
        icon: Icons.security_outlined,
      ),
      LearningResource(
        name: 'أدلة CISA للاستجابة للحوادث والثغرات',
        descriptionAr: 'قوائم تحقق لتحديد الحوادث واحتوائها ومعالجتها والتعافي منها مع توثيق مصدر الدليل.',
        descriptionEn: 'CISA playbooks for identifying, containing, remediating, and recovering from incidents with evidence provenance.',
        url: 'https://www.cisa.gov/sites/default/files/2024-08/Federal_Government_Cybersecurity_Incident_and_Vulnerability_Response_Playbooks_508C.pdf',
        icon: Icons.fact_check_outlined,
      ),
      LearningResource(
        name: 'موثوقية الأدلة الرقمية ومصدرها',
        descriptionAr: 'ورقة بحثية عن تتبع منشأ الأدلة وتحولاتها أثناء الاستجابة وسلامتها وقابليتها للتدقيق.',
        descriptionEn: 'Research on tracking evidence provenance and transformations during response for integrity and auditability.',
        url: 'https://csrc.nist.gov/pubs/journal/2017/09/advancing-coordinated-cyberinvestigations/final',
        icon: Icons.verified_user_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'أمن السحابة وKubernetes',
    'Cloud & Kubernetes security',
    [
      LearningResource(
        name: 'دليل أمن حاويات التطبيقات — NIST SP 800-190',
        descriptionAr: 'مخاطر الصور والسجلات والمنسّقات وبيئات التشغيل مع ضوابط التحقق والعزل وأقل امتياز.',
        descriptionEn: 'Risks and controls for container images, registries, orchestrators, runtimes, validation, and isolation.',
        url: 'https://nvlpubs.nist.gov/nistpubs/specialpublications/nist.sp.800-190.pdf',
        icon: Icons.security_outlined,
      ),
      LearningResource(
        name: 'إرشادات تقوية Kubernetes',
        descriptionAr: 'تقرير NSA وCISA حول سلسلة التوريد وسوء الإعداد والامتيازات والسجلات في العناقيد.',
        descriptionEn: 'NSA and CISA guidance on supply chains, misconfiguration, privileges, and logging in clusters.',
        url: 'https://www.cisa.gov/news-events/alerts/2022/03/15/updated-kubernetes-hardening-guide',
        icon: Icons.cloud_outlined,
      ),
      LearningResource(
        name: 'معايير أمن Pods',
        descriptionAr: 'مستويات Privileged وBaseline وRestricted لتقليل تصعيد الصلاحيات وعزل الأحمال.',
        descriptionEn: 'Privileged, Baseline, and Restricted levels for reducing privilege escalation and isolating workloads.',
        url: 'https://kubernetes.io/docs/concepts/security/pod-security-standards/',
        icon: Icons.policy_outlined,
      ),
    ],
  ),
  LearningResourceSection('الهوية وZero Trust', 'Identity & Zero Trust', [
    LearningResource(
      name: 'هندسة انعدام الثقة — NIST SP 800-207',
      descriptionAr: 'المرجع الأساسي لفهم الوصول القائم على هوية المستخدم والجهاز والسياسة بدلاً من موقع الشبكة.',
      descriptionEn: 'Foundational reference for user, device, and policy-based access instead of network-location trust.',
      url: 'https://csrc.nist.gov/pubs/sp/800/207/final',
      icon: Icons.security_outlined,
    ),
    LearningResource(
      name: 'نموذج نضج انعدام الثقة — CISA 2.0',
      descriptionAr: 'خارطة طريق بخمس ركائز ومستويات نضج للانتقال التدريجي إلى Zero Trust.',
      descriptionEn: 'Roadmap with five pillars and maturity levels for progressive Zero Trust adoption.',
      url: 'https://www.cisa.gov/resources-tools/resources/zero-trust-maturity-model',
      icon: Icons.policy_outlined,
    ),
    LearningResource(
      name: 'إرشادات الهوية الرقمية — NIST SP 800-63-4',
      descriptionAr: 'مرجع لإثبات الهوية والتسجيل والمصادقات والمصادقة والاتحاد بين الهويات.',
      descriptionEn: 'Reference for identity proofing, enrollment, authenticators, authentication, and federation.',
      url: 'https://csrc.nist.gov/pubs/sp/800/63/4/final',
      icon: Icons.verified_user_outlined,
    ),
    LearningResource(
      name: 'BeyondCorp: أمن المؤسسات',
      descriptionAr: 'دراسة USENIX عن الوصول المعتمد على هوية المستخدم والجهاز والاعتماديات قصيرة الأجل.',
      descriptionEn: 'USENIX case study on user and device identity, single sign-on, and short-lived credentials.',
      url: 'https://www.usenix.org/system/files/login/articles/login_dec14_02_ward.pdf',
      icon: Icons.devices_outlined,
    ),
  ]),
  LearningResourceSection(
    'سلسلة توريد البرمجيات وSBOM',
    'Software supply chain & SBOM',
    [
      LearningResource(
        name: 'فاتورة مواد البرمجيات — CISA',
        descriptionAr:
            'مدخل رسمي إلى SBOM والشفافية وإدارة مخاطر سلسلة التوريد وVEX.',
        descriptionEn: 'Official introduction to SBOM, transparency, supply-chain risk, and VEX.',
        url: 'https://www.cisa.gov/topics/information-communications-technology-supply-chain-security/sbom',
        icon: Icons.security_outlined,
      ),
      LearningResource(
        name: 'أمن سلسلة التوريد البرمجية — NIST',
        descriptionAr:
            'إرشادات حكومية لربط SBOM بالشفافية وإثبات المصدر واكتشاف الثغرات.',
        descriptionEn: 'Government guidance connecting SBOM to transparency, provenance, and vulnerability remediation.',
        url: 'https://www.nist.gov/itl/executive-order-14028-improving-nations-cybersecurity/software-supply-chain-security-guidance-20',
        icon: Icons.policy_outlined,
      ),
      LearningResource(
        name: 'العناصر الدنيا لـ SBOM — NTIA',
        descriptionAr: 'تقرير يحدد حقول البيانات وقابلية القراءة الآلية والممارسات اللازمة لتبني SBOM.',
        descriptionEn: 'Report defining SBOM data fields, machine readability, practices, and adoption processes.',
        url: 'https://www.ntia.doc.gov/files/ntia/publications/sbom_minimum_elements_report.pdf',
        icon: Icons.description_outlined,
      ),
      LearningResource(
        name: 'مراجعة منهجية لـ SBOM',
        descriptionAr: 'مراجعة أكاديمية لأدلة استخدام SBOM في الثغرات والشفافية وسلامة سلسلة التوريد.',
        descriptionEn: 'Academic review of SBOM evidence for vulnerability management, transparency, and supply-chain integrity.',
        url: 'https://arxiv.org/html/2506.03507v1',
        icon: Icons.menu_book_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'أمن الذكاء الاصطناعي والتعلم الآلي',
    'AI & machine-learning security',
    [
      LearningResource(
        name: 'التعلم الآلي الخصومي',
        descriptionAr: 'تصنيف NIST لمفاهيم الهجمات الخصومية وأهدافها ووسائل التخفيف من منظور دفاعي.',
        descriptionEn: 'NIST taxonomy of adversarial-machine-learning attacks, goals, and mitigations from a defensive perspective.',
        url: 'https://csrc.nist.gov/pubs/ai/100/2/e2025/final',
        icon: Icons.security_outlined,
      ),
      LearningResource(
        name: 'تحديات الأمن السيبراني للذكاء الاصطناعي',
        descriptionAr: 'تقرير ENISA عن الأصول والتهديدات ونقاط الضعف عبر دورة حياة الذكاء الاصطناعي.',
        descriptionEn: 'ENISA report on assets, threats, and vulnerabilities across the AI lifecycle.',
        url: 'https://www.enisa.europa.eu/publications/artificial-intelligence-cybersecurity-challenges',
        icon: Icons.account_tree_outlined,
      ),
    ],
  ),
  LearningResourceSection('أمن تطبيقات الهاتف', 'Mobile application security', [
    LearningResource(
      name: 'معيار OWASP للتحقق من أمن تطبيقات الهاتف',
      descriptionAr: 'ضوابط التحقق من التخزين والتشفير والمصادقة والشبكات والخصوصية في تطبيقات الهاتف.',
      descriptionEn: 'Verification controls for storage, cryptography, authentication, networking, and privacy in mobile apps.',
      url: 'https://mas.owasp.org/MASVS/',
      icon: Icons.security_outlined,
    ),
    LearningResource(
      name: 'فحص أمن تطبيقات الهاتف — NIST SP 800-163r1',
      descriptionAr:
          'عملية مؤسسية لفحص التطبيقات قبل اعتمادها وتقليل العيوب والثغرات.',
      descriptionEn: 'Organizational process for vetting apps before adoption and reducing defects and vulnerabilities.',
      url: 'https://csrc.nist.gov/pubs/sp/800/163/r1/final',
      icon: Icons.policy_outlined,
    ),
    LearningResource(
      name: 'قائمة التحقق لأمن Android',
      descriptionAr: 'ممارسات Android الرسمية للمصادقة وسلامة التطبيق والأذونات والشبكات والتشفير.',
      descriptionEn: 'Official Android practices for authentication, app integrity, permissions, networking, and cryptography.',
      url: 'https://developer.android.com/privacy-and-security/security-tips',
      icon: Icons.android_outlined,
    ),
    LearningResource(
      name: 'ورقة OWASP لأمن تطبيقات الهاتف',
      descriptionAr: 'ورقة عملية للتصميم الآمن والهوية والتخزين والخصوصية والاختبار وما بعد الإطلاق.',
      descriptionEn: 'Practical guidance for secure design, identity, storage, privacy, testing, and post-deployment.',
      url: 'https://cheatsheetseries.owasp.org/cheatsheets/Mobile_Application_Security_Cheat_Sheet.html',
      icon: Icons.verified_user_outlined,
    ),
  ]),
  LearningResourceSection(
    'تنبيهات الأنظمة ومعايير الأمن',
    'Platform advisories & security frameworks',
    [
      LearningResource(
        name: 'Ubuntu Security Notices',
        descriptionAr: 'صفحة مرجعية رسمية لنشرات أمن Ubuntu؛ موجز التحديث الحي مضاف في قسم الأخبار.',
        descriptionEn: 'Official Ubuntu security-notice reference; its live feed is listed separately in News.',
        url: 'https://ubuntu.com/security/notices',
        icon: Icons.computer_rounded,
      ),
      LearningResource(
        name: 'Android Security Bulletins',
        descriptionAr:
            'نشرات Android الشهرية وملاحظات معالجة الثغرات من المصدر الرسمي.',
        descriptionEn: 'Official monthly Android security bulletins and vulnerability-fix notes.',
        url: 'https://source.android.com/docs/security/bulletin',
        icon: Icons.android_outlined,
      ),
      LearningResource(
        name: 'Apple Security Releases',
        descriptionAr:
            'صفحة Apple المرجعية لتحديثات الأمن المنشورة لأنظمة ومنتجات Apple.',
        descriptionEn: 'Apple reference page for published security updates across Apple products.',
        url: 'https://support.apple.com/en-us/100100',
        icon: Icons.security_outlined,
      ),
      LearningResource(
        name: 'Australian ACSC Essential Eight',
        descriptionAr:
            'إطار إرشادي أسترالي لتدابير تخفيف مخاطر سيبرانية ذات أولوية.',
        descriptionEn: 'Australian guidance framework for prioritized cyber-risk mitigation strategies.',
        url: 'https://www.cyber.gov.au/essential-eight',
        icon: Icons.checklist_outlined,
      ),
      LearningResource(
        name: 'NIST CSF Online Learning',
        descriptionAr: 'مواد تعليمية رسمية للتعرف إلى إطار NIST للأمن السيبراني؛ صفحة مرجعية لا موجز حي.',
        descriptionEn: 'Official learning materials for the NIST Cybersecurity Framework; a reference page, not a live feed.',
        url: 'https://www.nist.gov/cyberframework/csf-11-online-learning',
        icon: Icons.account_tree_outlined,
      ),
      LearningResource(
        name: 'CIS Critical Security Controls',
        descriptionAr:
            'ضوابط دفاعية مرتبة الأولوية للمساعدة في بناء برنامج تحسين أمني.',
        descriptionEn: 'Prioritized defensive safeguards for building and improving a security program.',
        url: 'https://www.cisecurity.org/controls',
        icon: Icons.shield_outlined,
      ),
      LearningResource(
        name: 'OpenSSF Scorecard',
        descriptionAr:
            'أداة ومواصفات مفتوحة لتقييم ممارسات أمان المشاريع والاعتماديات.',
        descriptionEn: 'Open tool and guidance for assessing project and dependency security practices.',
        url: 'https://scorecard.dev/',
        icon: Icons.rule_folder_outlined,
      ),
      LearningResource(
        name: 'NIST CSF 2.0 Resources',
        descriptionAr: 'مواد تنزيل وأدوات وموارد داعمة لتطبيق إطار NIST CSF 2.0؛ صفحة مرجعية وليست موجز تحديث.',
        descriptionEn: 'Downloadable materials, tools, and resources supporting NIST CSF 2.0 implementation; a reference page, not a live feed.',
        url: 'https://www.nist.gov/cyberframework/resources',
        icon: Icons.query_stats_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'الخصوصية والتشفير وحماية البيانات',
    'Privacy, cryptography & data protection',
    [
      LearningResource(
        name: 'إرشادات إدارة مفاتيح التشفير من NIST',
        descriptionAr:
            'أفضل ممارسات حماية المفاتيح ووظائف دورة حياتها وسياسات إدارتها.',
        descriptionEn: 'Best practices for key protection, lifecycle functions, and cryptographic-key policy.',
        url: 'https://csrc.nist.gov/projects/key-management/key-management-guidelines',
        icon: Icons.key_outlined,
      ),
      LearningResource(
        name: 'اللائحة العامة لحماية البيانات GDPR',
        descriptionAr: 'مرجع لفهم تقليل البيانات والحماية حسب التصميم والافتراض والمسؤولية التنظيمية.',
        descriptionEn: 'Reference for data minimization, privacy by design and default, and accountability.',
        url: 'https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng',
        icon: Icons.policy_outlined,
      ),
      LearningResource(
        name: 'بروتوكول TLS 1.3 — RFC 8446',
        descriptionAr: 'المواصفة الرسمية للمصادقة والسرية والسلامة وتأسيس مفاتيح الجلسة في الاتصالات الآمنة.',
        descriptionEn: 'IETF specification for authentication, confidentiality, integrity, and session-key establishment.',
        url: 'https://www.rfc-editor.org/rfc/rfc8446',
        icon: Icons.lock_outlined,
      ),
    ],
  ),

  LearningResourceSection(
    'تنبيهات ومصادر عربية رسمية',
    'Arabic official advisories & learning',
    [
      LearningResource(
        name: 'Saudi CERT — التنبيهات الأمنية',
        descriptionAr: 'تنبيهات رسمية تتضمن الشدة والمنتجات والقطاعات المتأثرة وتوصيات المعالجة؛ صفحة مرجعية وليست موجز RSS.',
        descriptionEn: 'Official alerts with severity, affected products/sectors, and remediation guidance; a reference page, not an RSS feed.',
        url: 'https://nca.gov.sa/ar/cert/',
        icon: Icons.account_balance_outlined,
      ),
      LearningResource(
        name: 'Cisco Networking Academy — محلل الأمن السيبراني المبتدئ',
        descriptionAr: 'مسار تمهيدي عربي في أمن الشبكات ونقاط النهاية وإدارة التهديدات؛ تذكر الصفحة أن الدورات والموارد مجانية، وقد تكون الشهادة منفصلة.',
        descriptionEn: 'Arabic beginner pathway for network and endpoint defense and threat management. The page describes courses/resources as free; certification may be separate.',
        url: 'https://www.netacad.com/career-paths/cybersecurity?courseLang=ar-SA',
        icon: Icons.school_outlined,
      ),
      LearningResource(
        name: 'Google — الحماية من الهجمات الرقمية (Coursera)',
        descriptionAr: 'دورة عربية تمهيدية عن التهديدات والتشفير والمصادقة وأمن الشبكات؛ خيار التسجيل المجاني لا يضمن مجانية كل التقييمات أو الشهادة.',
        descriptionEn: 'Arabic introductory course on threats, cryptography, authentication, and network security. Free enrollment does not necessarily include all assessments or a certificate.',
        url: 'https://www.coursera.org/learn/it-security-ar',
        icon: Icons.school_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'أمن المنصات والسحابة والحاويات',
    'Platform, cloud & container security',
    [
      LearningResource(
        name: 'Microsoft Security Update Guide Notifications',
        descriptionAr: 'خدمة Microsoft الرسمية لإشعارات تحديثات الأمان وإعادة إصدارها عبر البريد؛ تتطلب اشتراكاً من صفحة الخدمة وليست موجز RSS.',
        descriptionEn: 'Microsoft’s official email notifications for security updates and re-releases. Sign-up is required; this is not an RSS feed.',
        url: 'https://www.microsoft.com/en-us/msrc/technical-security-notifications',
        icon: Icons.notifications_active_outlined,
      ),
      LearningResource(
        name: 'Microsoft Defender for Containers — documentation',
        descriptionAr: 'توثيق رسمي لمفاهيم تقييم المخاطر والثغرات وحماية وقت التشغيل وسلسلة توريد صور الحاويات؛ تحقق من الترخيص والتكلفة قبل تفعيل خدمة سحابية.',
        descriptionEn: 'Official guidance on container risk/vulnerability assessment, runtime protection, and image supply chains. Check licensing and costs before enabling cloud services.',
        url: 'https://learn.microsoft.com/en-us/azure/defender-for-cloud/defender-for-containers-introduction',
        icon: Icons.cloud_outlined,
      ),
      LearningResource(
        name: 'Docker Engine security',
        descriptionAr: 'توثيق Docker الرسمي عن العزل والصلاحيات وقيود الموارد؛ التحكم في Docker daemon يمنح امتيازات قوية على المضيف، لذلك استخدم مختبراً.',
        descriptionEn: 'Docker’s official reference on isolation, privileges, and resource controls. Docker-daemon access can grant powerful host privileges; use a lab.',
        url: 'https://docs.docker.com/engine/security/',
        icon: Icons.cloud_outlined,
      ),
      LearningResource(
        name: 'HashiCorp Vault — حماية أسرار GitLab CI/CD',
        descriptionAr: 'إرشادات رسمية لاستخدام JWT/OIDC وتقييد أدوار Vault في CI/CD؛ اختبر بأسرار وهمية، ولا تنسخ بيانات إنتاجية إلى سجلات التدريب.',
        descriptionEn: 'Official guidance for JWT/OIDC and claim-bound Vault roles in CI/CD. Use dummy secrets and never copy production credentials into training logs.',
        url: 'https://developer.hashicorp.com/well-architected-framework/secure-systems/secure-applications/ci-cd-secrets/gitlab',
        icon: Icons.key_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'خصوصية وسلامة الهواتف',
    'Mobile privacy & personal safety',
    [
      LearningResource(
        name: 'Android Help — إعدادات الأمان والخصوصية',
        descriptionAr: 'دليل Android الرسمي لمراجعة حالة الجهاز والأذونات والتحديثات وحماية التطبيقات؛ تختلف أسماء الإعدادات بحسب الشركة وإصدار النظام.',
        descriptionEn: 'Official Android guide to device status, permissions, updates, and app protection. Settings vary by device maker and OS version.',
        url: 'https://support.google.com/android/answer/13985942?hl=en',
        icon: Icons.phone_android_rounded,
      ),
      LearningResource(
        name: 'Apple Personal Safety User Guide',
        descriptionAr: 'دليل Apple لإدارة وصول الحساب والجهاز ومشاركة الموقع وأدوات Safety Check؛ راعِ تنبيه السلامة قبل إيقاف المشاركة أو حذف معلومات.',
        descriptionEn: 'Apple guide to account/device access, location sharing, and Safety Check. Consider the safety implications before stopping sharing or deleting information.',
        url: 'https://support.apple.com/guide/personal-safety/welcome/web',
        icon: Icons.privacy_tip_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'أمن تطبيقات الذكاء الاصطناعي',
    'AI application security',
    [
      LearningResource(
        name: 'OWASP Top 10 for LLM Applications — 2025',
        descriptionAr: 'قائمة OWASP بمخاطر تطبيقات النماذج اللغوية مثل حقن المطالبات وكشف المعلومات والصلاحيات المفرطة؛ استخدمها لتصميم الضوابط واختبر أنظمة تملكها أو لديك إذن بها فقط.',
        descriptionEn: 'OWASP’s 2025 list of LLM-application risks such as prompt injection, information disclosure, and excessive agency. Use for defensive controls and test only authorized systems.',
        url: 'https://genai.owasp.org/llm-top-10/',
        icon: Icons.security_outlined,
      ),
      LearningResource(
        name: 'MITRE ATLAS — تهديدات أنظمة الذكاء الاصطناعي',
        descriptionAr: 'قاعدة معرفة حية لأساليب الخصوم ضد أنظمة الذكاء الاصطناعي، مع تقنيات وتخفيفات ودراسات حالة؛ مرجع لنمذجة التهديد والدفاع وليس تصريحاً للاختبار على أهداف حقيقية.',
        descriptionEn: 'A living knowledge base of adversary techniques against AI systems, with mitigations and case studies. Use for threat modeling and defense, not unauthorized testing.',
        url: 'https://atlas.mitre.org/',
        icon: Icons.account_tree_outlined,
      ),
    ],
  ),
  LearningResourceSection(
    'التحليل الجنائي والاستجابة للحوادث',
    'Digital forensics & incident response',
    [
      LearningResource(
        name: 'Blue Team Labs Online',
        descriptionAr: 'تحديات دفاعية وسيناريوهات للتحليل الجنائي والاستجابة وصيد التهديدات؛ تختلف الإتاحة بين التحديات المجانية والتحقيقات المدفوعة، وتطبق شروط التسجيل.',
        descriptionEn: 'Defensive forensics, incident-response, and threat-hunting scenarios. Free challenges and paid investigations differ; registration terms apply.',
        url: 'https://blueteamlabs.online/',
        icon: Icons.manage_search_rounded,
      ),
      LearningResource(
        name: 'SANS Digital Forensics & Incident Response',
        descriptionAr: 'فهرس مهني لدورات التحقيق الجنائي والاستجابة والمختبرات العملية؛ راجع الرسوم وشروط التسجيل، واستخدم بيانات أدلة مصرحاً بها.',
        descriptionEn: 'Professional directory of digital-forensics and incident-response courses with hands-on labs. Check fees and enrollment requirements; use authorized evidence.',
        url: 'https://www.sans.org/cybersecurity-focus-areas/digital-forensics-incident-response',
        icon: Icons.manage_search_rounded,
      ),
    ],
  ),
];
