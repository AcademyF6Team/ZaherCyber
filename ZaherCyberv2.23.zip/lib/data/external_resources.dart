import 'package:flutter/material.dart';

import '../models/external_resource.dart';

const externalResources = <ExternalResource>[
  ExternalResource(
    id: 'kc7', nameAr: 'KC7 — محقق التهديدات', nameEn: 'KC7 — threat investigation',
    descriptionAr: 'سيناريوهات تحقيق في سجلات وبيانات تهديد لتعلّم التحليل الدفاعي.', descriptionEn: 'Threat-investigation scenarios using logs and data for defensive analysis.',
    url: 'https://kc7cyber.com/', categoryAr: 'تحقيق ودفاع', categoryEn: 'Investigation & defense', accessAr: 'الوصول إلى المحتوى التدريبي متاح عبر الموقع؛ راجع التسجيل والشروط.', accessEn: 'Training access is provided on the site; check its registration and terms.', icon: Icons.manage_search_rounded,
  ),
  ExternalResource(
    id: 'cyberdefenders', nameAr: 'CyberDefenders', nameEn: 'CyberDefenders',
    descriptionAr: 'مختبرات وتحديات دفاعية للتحقيق الجنائي والاستجابة وصيد التهديدات.', descriptionEn: 'Blue-team labs and challenges for forensics, response, and threat hunting.',
    url: 'https://cyberdefenders.org/blue-team-labs/', categoryAr: 'تحقيق ودفاع', categoryEn: 'Investigation & defense', accessAr: 'يتطلب حساباً؛ تختلف إتاحة المختبرات وشروطها، فلا يُفترض أنها مجانية بالكامل.', accessEn: 'An account is required; lab availability and terms vary, so do not assume all content is free.', icon: Icons.security_rounded,
  ),
  ExternalResource(
    id: 'crapi', nameAr: 'OWASP crAPI', nameEn: 'OWASP crAPI',
    descriptionAr: 'تطبيق API متعمد الضعف للتدريب على مخاطر API. شغّله محلياً أو داخل VM معزولة فقط.', descriptionEn: 'Intentionally vulnerable API app for training. Run locally or in an isolated VM only.',
    url: 'https://owasp.org/www-project-crapi/', categoryAr: 'مختبر محلي', categoryEn: 'Local lab', accessAr: 'مشروع مفتوح المصدر؛ لا يحتاج حساباً لتشغيله محلياً، لكنه ليس خدمة عامة للتجربة.', accessEn: 'Open-source project; no account is needed for local setup, but it is not a public target.', icon: Icons.api_rounded, requiresIsolation: true,
  ),
  ExternalResource(
    id: 'internetnl', nameAr: 'Internet.nl', nameEn: 'Internet.nl',
    descriptionAr: 'يفحص معايير النطاقات والبريد والاتصال مثل IPv6 وDNSSEC وTLS.', descriptionEn: 'Checks internet standards for domains, mail, and connections including IPv6, DNSSEC, and TLS.',
    url: 'https://internet.nl/', categoryAr: 'فحص خارجي', categoryEn: 'External check', accessAr: 'الخدمة متاحة عبر الويب؛ قد ترسل النطاق أو البريد الذي تدخله إلى الخدمة.', accessEn: 'Web service; the domain or email you submit may be processed by the service.', icon: Icons.public_rounded, processesSubmittedData: true,
  ),
  ExternalResource(
    id: 'dnsviz', nameAr: 'DNSViz', nameEn: 'DNSViz',
    descriptionAr: 'تشخيص رسومي لسلسلة DNS وDNSSEC لنطاق تملكه أو تملك تصريحاً بفحصه.', descriptionEn: 'Visual DNS and DNSSEC diagnostics for a domain you own or are authorized to assess.',
    url: 'https://dnsviz.net/', categoryAr: 'فحص خارجي', categoryEn: 'External check', accessAr: 'الوصول عبر الويب؛ النطاق المرسل يصبح مرئياً للخدمة ويُستعلم عنه.', accessEn: 'Web access; the submitted domain is visible to and queried by the service.', icon: Icons.hub_outlined, processesSubmittedData: true,
  ),
  ExternalResource(
    id: 'tor', nameAr: 'دليل Tor Browser الرسمي', nameEn: 'Tor Browser official guide',
    descriptionAr: 'دليل التثبيت والاستخدام الرسمي. لا يجعل Tor كل نشاط مجهولاً تلقائياً.', descriptionEn: 'Official installation and use guide. Tor does not automatically make all activity anonymous.',
    url: 'https://support.torproject.org/tor-browser/getting-started/installing/', categoryAr: 'خصوصية', categoryEn: 'Privacy', accessAr: 'قراءة عامة؛ تنزيل البرنامج والحصول على بعض الخدمات قد يتطلب اتصالاً مناسباً.', accessEn: 'Public reading; downloading and some services may require suitable connectivity.', icon: Icons.privacy_tip_outlined,
  ),
  ExternalResource(
    id: 'ooni', nameAr: 'OONI — وثائق المخاطر', nameEn: 'OONI — risk documentation',
    descriptionAr: 'وثائق المخاطر والآثار المحتملة قبل تشغيل OONI Probe؛ التطبيق لا يشغّل أي اختبار.', descriptionEn: 'Risk and impact documentation before using OONI Probe; ZaherCyber runs no test.',
    url: 'https://ooni.org/about/risks/', categoryAr: 'خصوصية وقياس', categoryEn: 'Privacy & measurement', accessAr: 'قراءة عامة؛ تشغيل Probe اختياري وقد يرسل قياسات وينشرها حسب الإعدادات والبلد.', accessEn: 'Public reading; Probe use is optional and may send or publish measurements depending on settings and location.', icon: Icons.warning_amber_rounded, processesSubmittedData: true,
  ),
  ExternalResource(
    id: 'tryhackme', nameAr: 'TryHackMe', nameEn: 'TryHackMe',
    descriptionAr: 'مسارات ودروس ومختبرات عملية للمبتدئين والمتقدمين في الأمن السيبراني.', descriptionEn: 'Hands-on paths, lessons, and labs for beginner to advanced learners.',
    url: 'https://tryhackme.com/', categoryAr: 'تعلم ومختبرات', categoryEn: 'Learning & labs', accessAr: 'يوجد حساب مجاني ومحتوى متاح، مع وجود محتوى أو مزايا مدفوعة؛ ليس مجانياً بالكامل.', accessEn: 'A free account and content are available, with paid content or features; not fully free.', icon: Icons.school_outlined,
  ),
  ExternalResource(
    id: 'htb-academy', nameAr: 'HTB Academy', nameEn: 'HTB Academy',
    descriptionAr: 'دورات ومسارات تفاعلية وتمارين عملية وشهادات من Hack The Box.', descriptionEn: 'Interactive courses, paths, practical exercises, and certifications from Hack The Box.',
    url: 'https://academy.hackthebox.com/', categoryAr: 'تعلم ومختبرات', categoryEn: 'Learning & labs', accessAr: 'التسجيل متاح والصفحة تعرض بدءاً مجانياً، بينما تتطلب وحدات أو شهادات أخرى اشتراكاً أو دفعاً.', accessEn: 'Registration and a free start are offered; other modules or certifications require subscription or payment.', icon: Icons.school_rounded,
  ),
  ExternalResource(
    id: 'portswigger', nameAr: 'PortSwigger Web Security Academy', nameEn: 'PortSwigger Web Security Academy',
    descriptionAr: 'تدريب ويب تفاعلي مجاني مع مختبرات وتتبع تقدم؛ بعض التمارين تستفيد من Burp Suite Community.', descriptionEn: 'Free interactive web-security training with labs and progress tracking; some exercises use Burp Suite Community.',
    url: 'https://portswigger.net/web-security', categoryAr: 'أمن الويب', categoryEn: 'Web security', accessAr: 'المحتوى والمختبرات مجانية حسب المصدر الرسمي؛ إنشاء حساب اختياري لتتبع التقدم.', accessEn: 'The source states the content and labs are free; an account enables progress tracking.', icon: Icons.language_rounded,
  ),
  ExternalResource(
    id: 'overthewire', nameAr: 'OverTheWire', nameEn: 'OverTheWire',
    descriptionAr: 'ألعاب Wargames لتعلم Linux والشبكات والويب والتشفير والهندسة العكسية عبر SSH.', descriptionEn: 'Wargames for Linux, networking, web, cryptography, and reverse engineering via SSH.',
    url: 'https://overthewire.org/wargames/', categoryAr: 'ألعاب أمنية', categoryEn: 'Security games', accessAr: 'الوصول إلى الألعاب متاح عبر الموقع؛ يلزم اتصال SSH وقد توجد تكاليف اتصال المستخدم فقط.', accessEn: 'Games are accessible from the site; SSH connectivity is required and user network costs may apply.', icon: Icons.sports_esports_outlined,
  ),
  ExternalResource(
    id: 'picocylab', nameAr: 'picoCTF / CyLab Security Academy', nameEn: 'picoCTF / CyLab Security Academy',
    descriptionAr: 'تعلم ومسابقات أمنية من Carnegie Mellon؛ ينقل الموقع الحالي المستخدمين إلى CyLab Security Academy.', descriptionEn: 'Carnegie Mellon security learning and competitions; the current site points learners to CyLab Security Academy.',
    url: 'https://picoctf.org/', categoryAr: 'CTF وتعليم', categoryEn: 'CTF & learning', accessAr: 'تذكر الصفحة الرسمية أن CyLab منصة تعلم مجانية؛ الحساب مطلوب للوصول والتقدم.', accessEn: 'The official page describes CyLab as free; an account is needed for access and progress.', icon: Icons.flag_outlined,
  ),
  ExternalResource(
    id: 'root-me', nameAr: 'Root-Me', nameEn: 'Root-Me',
    descriptionAr: 'منصة تحديات في الويب والشبكات والتشفير والهندسة العكسية والتحليل.', descriptionEn: 'Challenges in web, networking, cryptography, reverse engineering, and analysis.',
    url: 'https://www.root-me.org/', categoryAr: 'تحديات', categoryEn: 'Challenges', accessAr: 'يتطلب التسجيل لبعض الميزات؛ لم تؤكد الصفحة المقروءة أن كل المحتوى مجاني، لذا راجع شروط المنصة.', accessEn: 'Registration is needed for some features; the reviewed page did not confirm all content is free, so check the platform terms.', icon: Icons.account_tree_outlined,
  ),
  ExternalResource(
    id: 'letsdefend', nameAr: 'LetsDefend', nameEn: 'LetsDefend',
    descriptionAr: 'تدريب Blue Team داخل SOC محاكى مع مسارات للحوادث والتحقيق والاستجابة.', descriptionEn: 'Blue-team training in a simulated SOC with incident, investigation, and response paths.',
    url: 'https://letsdefend.io/', categoryAr: 'دفاع وSOC', categoryEn: 'Defense & SOC', accessAr: 'حساب Basic مجاني دائماً حسب صفحة الأسعار، مع خطط VIP وVIP+ مدفوعة ومحتوى إضافي.', accessEn: 'The pricing page lists an always-free Basic account plus paid VIP and VIP+ plans with more content.', icon: Icons.monitor_heart_outlined,
  ),
  ExternalResource(
    id: 'btlo', nameAr: 'Blue Team Labs Online', nameEn: 'Blue Team Labs Online',
    descriptionAr: 'تحقيقات وتحديات في الاستجابة والتحليل الجنائي والعمليات الأمنية وصيد التهديدات.', descriptionEn: 'Investigations and challenges in response, forensics, security operations, and threat hunting.',
    url: 'https://blueteamlabs.online/', categoryAr: 'دفاع وتحقيق', categoryEn: 'Defense & forensics', accessAr: 'التسجيل المجاني متاح؛ توجد طبقات مجانية ومدفوعة، والاشتراك Pro يفتح تحقيقات إضافية.', accessEn: 'Free registration is available; free and paid tiers exist, and Pro unlocks additional investigations.', icon: Icons.fact_check_outlined,
  ),
  ExternalResource(
    id: 'juice-shop', nameAr: 'OWASP Juice Shop', nameEn: 'OWASP Juice Shop',
    descriptionAr: 'تطبيق ويب متعمد الضعف للتدريب على OWASP Top 10. شغّله محلياً أو داخل VM معزولة.', descriptionEn: 'Intentionally vulnerable web app for OWASP Top 10 training. Run locally or in an isolated VM.',
    url: 'https://owasp.org/www-project-juice-shop/', categoryAr: 'مختبر محلي', categoryEn: 'Local lab', accessAr: 'مشروع مفتوح المصدر للتشغيل المحلي؛ لا يحتاج حساباً، لكنه ضعيف عمداً ولا يجب تعريضه للإنترنت.', accessEn: 'Open-source local project; no account is needed, but it is intentionally vulnerable and must not be exposed online.', icon: Icons.local_drink_outlined, requiresIsolation: true,
  ),
  ExternalResource(
    id: 'webgoat', nameAr: 'OWASP WebGoat', nameEn: 'OWASP WebGoat',
    descriptionAr: 'تطبيق Java تعليمي متعمد الضعف؛ تحذر OWASP من فصله عن الإنترنت أثناء التشغيل.', descriptionEn: 'Deliberately insecure Java training app; OWASP warns to disconnect it from the Internet while running.',
    url: 'https://owasp.org/www-project-webgoat/', categoryAr: 'مختبر محلي', categoryEn: 'Local lab', accessAr: 'مشروع OWASP مفتوح المصدر؛ لا يحتاج حساباً للتشغيل المحلي، ويجب عزله.', accessEn: 'Open-source OWASP project; no account is needed for local use, and isolation is required.', icon: Icons.bug_report_outlined, requiresIsolation: true,
  ),
  ExternalResource(
    id: 'dvwa', nameAr: 'DVWA', nameEn: 'Damn Vulnerable Web Application',
    descriptionAr: 'تطبيق PHP/MySQL متعمد الضعف للتدريب على أمن الويب؛ استخدمه محلياً فقط.', descriptionEn: 'Intentionally vulnerable PHP/MySQL web app for training; use locally only.',
    url: 'https://github.com/digininja/DVWA', categoryAr: 'مختبر محلي', categoryEn: 'Local lab', accessAr: 'المستودع الرسمي مفتوح المصدر ولا يحتاج حساباً للتشغيل، لكن GitHub قد يتطلب حساباً لبعض التفاعلات.', accessEn: 'The official repository is open source and needs no account to run; GitHub may require one for some interactions.', icon: Icons.web_asset_off_outlined, requiresIsolation: true,
  ),
  ExternalResource(
    id: 'vulnhub', nameAr: 'VulnHub', nameEn: 'VulnHub',
    descriptionAr: 'أجهزة افتراضية ضعيفة عمداً للتدريب على الاختبار والاختراق؛ شغّلها في شبكة معزولة.', descriptionEn: 'Intentionally vulnerable virtual machines for practice; run them on an isolated network.',
    url: 'https://www.vulnhub.com/', categoryAr: 'أجهزة افتراضية', categoryEn: 'Virtual machines', accessAr: 'التنزيلات متاحة من الموقع بحسب كل جهاز؛ لا يُفترض وجود دعم أو ضمان موحد لكل صورة.', accessEn: 'Downloads are listed per machine; do not assume uniform support or guarantees for every image.', icon: Icons.computer_outlined, requiresIsolation: true,
  ),
];
