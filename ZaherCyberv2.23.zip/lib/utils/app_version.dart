/// Single display source for the app release shown in user-facing surfaces.
/// Keep this aligned with the version in pubspec.yaml and BUILD_INFO.md.
const appVersion = '2.23.0';
const appBuild = '42';
const appVersionLabel = '$appVersion+$appBuild';
