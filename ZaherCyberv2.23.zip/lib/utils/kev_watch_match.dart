import '../models/kev_item.dart';

bool matchesWatchTermsInText(String text, Iterable<String> terms) {
  final searchable = text.toLowerCase();
  return terms.any((rawTerm) {
    final term = rawTerm.trim().toLowerCase();
    return term.length >= 2 && searchable.contains(term);
  });
}

bool matchesKevWatchTerms(
  KevItem item,
  Iterable<String> terms,
) => matchesWatchTermsInText(
  '${item.vendor} ${item.product} ${item.name} ${item.description} ${item.cveId}',
  terms,
);
