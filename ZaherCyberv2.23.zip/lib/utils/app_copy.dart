import 'package:flutter/widgets.dart';

String copy(BuildContext context, String arabic, String english) =>
    Localizations.localeOf(context).languageCode == 'en' ? english : arabic;

TextDirection appTextDirection(BuildContext context) =>
    Localizations.localeOf(context).languageCode == 'en'
    ? TextDirection.ltr
    : TextDirection.rtl;
