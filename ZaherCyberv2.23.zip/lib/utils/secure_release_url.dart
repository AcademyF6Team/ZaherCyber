/// Returns a usable absolute HTTPS download URL, or null for unsupported input.
/// Handles legacy/cache variations seen in release metadata without ever
/// fetching over plain HTTP. HTTP is upgraded only for known release hosts.
String? secureReleaseUrl(String input) {
  var value = input
      .trim()
      .replaceAll(RegExp(r'[\u0000-\u001f\u007f\u200B-\u200F\uFEFF]'), '')
      .replaceAll('&amp;', '&');
  if (value.isEmpty) return null;
  if (value.length >= 2 &&
      ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'")))) {
    value = value.substring(1, value.length - 1).trim();
  }
  // Some legacy cached records persisted a percent-encoded URL instead of a URL.
  if (value.toLowerCase().startsWith('https%3a%2f%2f') ||
      value.toLowerCase().startsWith('http%3a%2f%2f')) {
    try {
      value = Uri.decodeComponent(value);
    } on FormatException {
      return null;
    }
  }
  if (value.startsWith('//')) value = 'https:$value';
  // Repair missing/doubled separators from old hand-entered catalog records.
  final malformedScheme = RegExp(
    r'^(https?):/+(?!/)(.+)$',
    caseSensitive: false,
  );
  final malformedMatch = malformedScheme.firstMatch(value);
  if (malformedMatch != null) {
    value = '${malformedMatch.group(1)}://${malformedMatch.group(2)}';
  }

  var uri = Uri.tryParse(value);
  if (uri == null || uri.host.isEmpty) {
    final withoutScheme = value.replaceFirst(
      RegExp(r'^https?:/*', caseSensitive: false),
      '',
    );
    final likelyHost = withoutScheme.split('/').first.toLowerCase();
    const knownHosts = <String>{
      'github.com',
      'www.github.com',
      'objects.githubusercontent.com',
      'release-assets.githubusercontent.com',
      'f-droid.org',
      'www.f-droid.org',
      'gitlab.com',
      'codeberg.org',
      'downloads.sourceforge.net',
      'sourceforge.net',
    };
    if (knownHosts.contains(likelyHost) ||
        likelyHost.endsWith('.githubusercontent.com') ||
        likelyHost.endsWith('.gitlab.com')) {
      value = 'https://$withoutScheme';
      uri = Uri.tryParse(value);
    }
  }
  if (uri == null || uri.host.isEmpty || uri.userInfo.isNotEmpty) return null;

  final scheme = uri.scheme.toLowerCase();
  final host = uri.host.toLowerCase();
  if (scheme == 'https') {
    return uri.replace(scheme: 'https', host: host).toString();
  }
  const trustedHttpHosts = <String>{
    'github.com',
    'www.github.com',
    'objects.githubusercontent.com',
    'release-assets.githubusercontent.com',
    'githubusercontent.com',
    'f-droid.org',
    'www.f-droid.org',
    'downloads.sourceforge.net',
    'sourceforge.net',
    'gitlab.com',
    'codeberg.org',
  };
  final isTrusted =
      trustedHttpHosts.contains(host) ||
      host.endsWith('.githubusercontent.com') ||
      host.endsWith('.gitlab.com') ||
      host.endsWith('.f-droid.org');
  if (scheme == 'http' && isTrusted) {
    return uri.replace(scheme: 'https', host: host).toString();
  }
  return null;
}
