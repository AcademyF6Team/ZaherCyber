import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

/// Firebase configuration for the Android application.
///
/// This file contains client configuration only. No server key or service
/// account credential belongs in a Flutter application.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (defaultTargetPlatform == TargetPlatform.android) {
      return android;
    }
    throw UnsupportedError(
      'DefaultFirebaseOptions are not configured for this platform.',
    );
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCrjPHvXisu0uzpWTTn_sG7-EixEPvKw2E',
    appId: '1:574521473108:android:64b33ec76adfa1bdd355c1',
    messagingSenderId: '574521473108',
    projectId: 'zahercyber-project',
    storageBucket: 'zahercyber-project.firebasestorage.app',
  );
}
