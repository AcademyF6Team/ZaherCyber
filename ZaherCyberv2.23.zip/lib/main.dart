import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'firebase_options.dart';
import 'screens/app_entry_screens.dart';
import 'screens/home_screen.dart';
import 'services/notification_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const ZaherCyberApp());
}

class ZaherCyberApp extends StatefulWidget {
  const ZaherCyberApp({super.key});

  @override
  State<ZaherCyberApp> createState() => _ZaherCyberAppState();
}

class _ZaherCyberAppState extends State<ZaherCyberApp> {
  final _navigatorKey = GlobalKey<NavigatorState>();
  Locale _locale = const Locale('ar');
  int _themeIndex = 0;
  bool _preferencesReady = false;
  bool _onboardingComplete = false;
  bool _bootActive = false;
  bool _notificationsStarted = false;

  @override
  void initState() {
    super.initState();
    _restorePreferences();
  }

  Future<void> _restorePreferences() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        _locale = Locale(preferences.getString('app_locale') ?? 'ar');
        _themeIndex = preferences.getInt('app_theme') ?? 0;
        _onboardingComplete = preferences.getBool('onboarding_complete_v1') ?? false;
        _bootActive = _onboardingComplete;
        if (_themeIndex < 0 || _themeIndex >= AppThemes.presets.length)
          _themeIndex = 0;
        _preferencesReady = true;
      });
      if (_onboardingComplete) _startNotificationsWhenReady();
    } catch (_) {
      if (mounted) {
        setState(() => _preferencesReady = true);
        if (_onboardingComplete) _startNotificationsWhenReady();
      }
    }
  }

  Future<void> _startNotificationsWhenReady() async {
    if (_notificationsStarted || !mounted) return;
    _notificationsStarted = true;
    await NotificationService.initialize(
      onMessageOpened: _handleNotificationOpened,
    );
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final dialogContext = _navigatorKey.currentContext;
      if (dialogContext != null) {
        await NotificationService.requestPermission(dialogContext);
      }
    });
  }

  void _handleNotificationOpened(RemoteMessage message) {
    // The open callback is intentionally safe and does not trust arbitrary
    // deep links. Future notification actions can be added here explicitly.
  }

  Future<void> _finishOnboarding() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      await preferences.setBool('onboarding_complete_v1', true);
    } catch (_) {
      // The user can still enter the app if local preference storage is unavailable.
    }
    if (!mounted) return;
    setState(() {
      _onboardingComplete = true;
      _bootActive = false;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startNotificationsWhenReady();
    });
  }

  Future<void> _setLocale(Locale value) async {
    setState(() => _locale = value);
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString('app_locale', value.languageCode);
  }

  Future<void> _setTheme(int value) async {
    setState(() => _themeIndex = value);
    final preferences = await SharedPreferences.getInstance();
    await preferences.setInt('app_theme', value);
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    navigatorKey: _navigatorKey,
    title: 'ZaherCyber',
    debugShowCheckedModeBanner: false,
    locale: _locale,
    supportedLocales: const [Locale('ar'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: AppThemes.build(_themeIndex),
    home: !_preferencesReady
        ? const _StartupLoadingScreen()
        : !_onboardingComplete
            ? OnboardingScreen(onFinished: _finishOnboarding)
            : _bootActive
                ? CyberBootScreen(onFinished: () => setState(() => _bootActive = false))
                : HomeScreen(
                    locale: _locale,
                    onLocaleChanged: _setLocale,
                    onThemeChanged: _setTheme,
                  ),
  );
}

class _StartupLoadingScreen extends StatelessWidget {
  const _StartupLoadingScreen();

  @override
  Widget build(BuildContext context) => const Scaffold(
    body: Center(child: CircularProgressIndicator()),
  );
}
