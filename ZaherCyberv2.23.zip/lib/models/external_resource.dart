import 'package:flutter/material.dart';

class ExternalResource {
  const ExternalResource({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.descriptionAr,
    required this.descriptionEn,
    required this.url,
    required this.categoryAr,
    required this.categoryEn,
    required this.accessAr,
    required this.accessEn,
    required this.icon,
    this.requiresIsolation = false,
    this.processesSubmittedData = false,
    this.downloadUrl,
    this.trustAr = 'مصدر خارجي؛ تحقق من التوقيع والصلاحيات قبل التثبيت.',
    this.trustEn = 'External source; verify the signature and permissions before installing.',
  });

  final String id;
  final String nameAr;
  final String nameEn;
  final String descriptionAr;
  final String descriptionEn;
  final String url;
  final String categoryAr;
  final String categoryEn;
  final String accessAr;
  final String accessEn;
  final IconData icon;
  final bool requiresIsolation;
  final bool processesSubmittedData;
  final String? downloadUrl;
  final String trustAr;
  final String trustEn;
}
