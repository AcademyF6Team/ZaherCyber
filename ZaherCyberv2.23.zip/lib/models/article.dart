class Article {
  final String title;
  final String link;
  final String summary;
  final String source;
  final String category;
  final String language;
  final DateTime? publishedAt;

  bool get isEnglish => isLikelyEnglish(language, '$title $summary');

  const Article({
    required this.title,
    required this.link,
    required this.summary,
    required this.source,
    required this.category,
    this.language = 'EN',
    this.publishedAt,
  });

  Map<String, Object?> toJson() => {
    'title': title,
    'link': link,
    'summary': summary,
    'source': source,
    'category': category,
    'language': language,
    'publishedAt': publishedAt?.toIso8601String(),
  };

  factory Article.fromJson(Map<String, dynamic> json) => Article(
    title: json['title']?.toString() ?? '',
    link: json['link']?.toString() ?? '',
    summary: json['summary']?.toString() ?? '',
    source: json['source']?.toString() ?? '',
    category: json['category']?.toString() ?? '',
    language: json['language']?.toString() ?? 'EN',
    publishedAt: DateTime.tryParse(json['publishedAt']?.toString() ?? ''),
  );
}

bool isLikelyEnglish(String language, String text) {
  final code = language.trim().toLowerCase().replaceAll('_', '-');
  if (code == 'en' || code.startsWith('en-')) return true;
  final latinCount = RegExp(r'[A-Za-z]').allMatches(text).length;
  final arabicCount = RegExp(r'[\u0600-\u06FF]').allMatches(text).length;
  return latinCount >= 12 && latinCount > arabicCount;
}
