class ProtectionCheck {
  final String id;
  final String platform;
  final String groupAr;
  final String groupEn;
  final String titleAr;
  final String titleEn;
  final String detailAr;
  final String detailEn;
  final String risk;
  final String officialUrl;
  final String sourceTitle;

  const ProtectionCheck({
    required this.id,
    required this.platform,
    required this.groupAr,
    required this.groupEn,
    required this.titleAr,
    required this.titleEn,
    required this.detailAr,
    required this.detailEn,
    required this.risk,
    required this.officialUrl,
    required this.sourceTitle,
  });
}

class ResponseStep {
  final String titleAr;
  final String titleEn;
  final String detailAr;
  final String detailEn;
  final String risk;
  final String officialUrl;
  final String sourceTitle;

  const ResponseStep({
    required this.titleAr,
    required this.titleEn,
    required this.detailAr,
    required this.detailEn,
    required this.risk,
    required this.officialUrl,
    required this.sourceTitle,
  });
}

class IncidentPlaybook {
  final String id;
  final String titleAr;
  final String titleEn;
  final String summaryAr;
  final String summaryEn;
  final String whenExpertAr;
  final String whenExpertEn;
  final List<ResponseStep> steps;

  const IncidentPlaybook({
    required this.id,
    required this.titleAr,
    required this.titleEn,
    required this.summaryAr,
    required this.summaryEn,
    required this.whenExpertAr,
    required this.whenExpertEn,
    required this.steps,
  });
}
