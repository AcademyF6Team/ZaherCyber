class KevItem {
  final String cveId;
  final String vendor;
  final String product;
  final String name;
  final String dateAdded;
  final String description;
  final String requiredAction;
  final bool knownRansomwareUse;

  const KevItem({
    required this.cveId,
    required this.vendor,
    required this.product,
    required this.name,
    required this.dateAdded,
    required this.description,
    required this.requiredAction,
    required this.knownRansomwareUse,
  });

  factory KevItem.fromJson(Map<String, dynamic> json) => KevItem(
    cveId: json['cveID']?.toString() ?? '',
    vendor: json['vendorProject']?.toString() ?? '',
    product: json['product']?.toString() ?? '',
    name: json['vulnerabilityName']?.toString() ?? '',
    dateAdded: json['dateAdded']?.toString() ?? '',
    description: json['shortDescription']?.toString() ?? '',
    requiredAction: json['requiredAction']?.toString() ?? '',
    knownRansomwareUse:
        json['knownRansomwareCampaignUse']?.toString().toLowerCase() == 'known',
  );

  Map<String, Object?> toJson() => {
    'cveID': cveId,
    'vendorProject': vendor,
    'product': product,
    'vulnerabilityName': name,
    'dateAdded': dateAdded,
    'shortDescription': description,
    'requiredAction': requiredAction,
    'knownRansomwareCampaignUse': knownRansomwareUse ? 'Known' : 'Unknown',
  };
}
