import '../utils/secure_release_url.dart';

class ReleaseAsset {
  final String name;
  final String url;
  final int size;
  final String? sha256;
  const ReleaseAsset({
    required this.name,
    required this.url,
    required this.size,
    this.sha256,
  });

  factory ReleaseAsset.fromJson(Map<String, dynamic> json) {
    final rawDigest = json['digest']?.toString();
    final sha256 =
        json['sha256']?.toString() ??
        (rawDigest != null && rawDigest.toLowerCase().startsWith('sha256:')
            ? rawDigest.substring(7)
            : null);
    final rawUrl =
        (json['browser_download_url'] ?? json['url'])?.toString() ?? '';
    return ReleaseAsset(
      name: json['name']?.toString() ?? 'download.bin',
      url: secureReleaseUrl(rawUrl) ?? rawUrl,
      size: (json['size'] as num?)?.toInt() ?? 0,
      sha256: sha256,
    );
  }

  Map<String, Object?> toJson() => {
    'name': name,
    'url': url,
    'size': size,
    'sha256': sha256,
  };
}

class ToolRelease {
  final String repo;
  final String tag;
  final String title;
  final String notes;
  final String releaseUrl;
  final DateTime? publishedAt;
  final List<ReleaseAsset> assets;
  final String? license;
  final bool cached;

  const ToolRelease({
    required this.repo,
    required this.tag,
    required this.title,
    required this.notes,
    required this.releaseUrl,
    required this.publishedAt,
    required this.assets,
    this.license,
    this.cached = false,
  });

  factory ToolRelease.fromGitHub(
    String repo,
    Map<String, dynamic> json, {
    String? license,
  }) => ToolRelease(
    repo: repo,
    tag: json['tag_name']?.toString() ?? '',
    title: json['name']?.toString() ?? json['tag_name']?.toString() ?? '',
    notes: json['body']?.toString() ?? '',
    releaseUrl:
        json['html_url']?.toString() ?? 'https://github.com/$repo/releases',
    publishedAt: DateTime.tryParse(json['published_at']?.toString() ?? ''),
    assets: ((json['assets'] as List?) ?? const [])
        .whereType<Map>()
        .map((e) => ReleaseAsset.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => secureReleaseUrl(e.url) != null)
        .toList(),
    license: license,
  );

  factory ToolRelease.fromJson(
    Map<String, dynamic> json, {
    bool cached = false,
  }) => ToolRelease(
    repo: json['repo']?.toString() ?? '',
    tag: json['tag']?.toString() ?? '',
    title: json['title']?.toString() ?? '',
    notes: json['notes']?.toString() ?? '',
    releaseUrl: json['releaseUrl']?.toString() ?? '',
    publishedAt: DateTime.tryParse(json['publishedAt']?.toString() ?? ''),
    assets: ((json['assets'] as List?) ?? const [])
        .whereType<Map>()
        .map((e) => ReleaseAsset.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => secureReleaseUrl(e.url) != null)
        .toList(),
    license: json['license']?.toString(),
    cached: cached,
  );

  Map<String, Object?> toJson() => {
    'repo': repo,
    'tag': tag,
    'title': title,
    'notes': notes,
    'releaseUrl': releaseUrl,
    'publishedAt': publishedAt?.toIso8601String(),
    'assets': assets.map((e) => e.toJson()).toList(),
    'license': license,
  };
}
