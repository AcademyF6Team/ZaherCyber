class ToolProject {
  final String id;
  final String name;
  final String descriptionAr;
  final String descriptionEn;
  final String category;
  final String? githubRepo;
  final String sourceUrl;
  final String? fdroidPackageId;
  final String? licenseHint;
  final Set<String> platforms;
  final bool discovered;
  /// Indicative learning curve: beginner, intermediate, or advanced.
  final String? difficulty;
  /// Repository state at the last verification; does not imply active maintenance.
  final String? repositoryStatus;

  const ToolProject({
    required this.id,
    required this.name,
    required this.descriptionAr,
    required this.descriptionEn,
    required this.category,
    required this.githubRepo,
    required this.sourceUrl,
    required this.platforms,
    this.fdroidPackageId,
    this.licenseHint,
    this.discovered = false,
    this.difficulty,
    this.repositoryStatus,
  });

  factory ToolProject.fromGitHubSearch(
    Map<String, dynamic> json,
    String platformHint,
  ) {
    final fullName = json['full_name']?.toString() ?? '';
    final repoUrl = json['html_url']?.toString() ?? '';
    final license = (json['license'] as Map?)?['spdx_id']?.toString();
    final topics =
        (json['topics'] as List?)?.map((e) => e.toString()).toSet() ??
        <String>{};
    final platforms = <String>{};
    if (const {
      'android',
      'windows',
      'linux',
      'macos',
      'web',
    }.contains(platformHint)) {
      platforms.add(platformHint);
    }
    if (topics.any((t) => t.contains('linux') || t.contains('unix')))
      platforms.add('linux');
    if (topics.any((t) => t.contains('android'))) platforms.add('android');
    if (topics.any((t) => t.contains('windows'))) platforms.add('windows');
    if (topics.any((t) => t.contains('macos') || t.contains('darwin')))
      platforms.add('macos');
    if (topics.any((t) => t.contains('web'))) platforms.add('web');
    final category = switch (platformHint) {
      'ai' => 'Artificial Intelligence',
      'dev' => 'Developer tools',
      'cloud' => 'Cloud security',
      'privacy' => 'Privacy',
      _ => 'Discovered',
    };
    return ToolProject(
      id: fullName.toLowerCase().replaceAll('/', '__'),
      name: fullName,
      descriptionAr:
          json['description']?.toString() ?? 'مشروع مفتوح المصدر من GitHub',
      descriptionEn:
          json['description']?.toString() ??
          'Open-source project discovered from GitHub',
      category: category,
      githubRepo: fullName.isEmpty ? null : fullName,
      sourceUrl: repoUrl,
      platforms: platforms,
      licenseHint: license == null || license == 'NOASSERTION' ? null : license,
      discovered: true,
    );
  }
}
