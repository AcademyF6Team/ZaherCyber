import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/external_resources.dart';
import '../models/external_resource.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../widgets/page_navigation_controls.dart';

class ExternalResourcesScreen extends StatefulWidget {
  const ExternalResourcesScreen({super.key});

  @override
  State<ExternalResourcesScreen> createState() => _ExternalResourcesScreenState();
}

class _ExternalResourcesScreenState extends State<ExternalResourcesScreen> {
  final _search = TextEditingController();
  String _category = 'all';

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  bool get _en => Localizations.localeOf(context).languageCode == 'en';
  String _t(String ar, String en) => copy(context, ar, en);

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<String> get _categories => [
    'all',
    ...externalResources.map((item) => _en ? item.categoryEn : item.categoryAr).toSet(),
  ];

  List<ExternalResource> get _filtered {
    final query = _search.text.trim().toLowerCase();
    return externalResources.where((item) {
      final category = _en ? item.categoryEn : item.categoryAr;
      final text = '${item.nameAr} ${item.nameEn} ${item.descriptionAr} ${item.descriptionEn}'.toLowerCase();
      return (_category == 'all' || category == _category) && (query.isEmpty || text.contains(query));
    }).toList();
  }

  Future<void> _open(ExternalResource item) async {
    final warning = [
      _t('سيغادر التطبيق إلى موقع خارجي: ${item.nameAr}.', 'This will leave the app for: ${item.nameEn}.'),
      _t('قد يسجل الموقع عنوان IP وبيانات الطلب وفق سياسة الجهة المشغلة. لا ترسل بيانات شخصية أو أسراراً، واستخدم نطاقاً تملكه أو لديك تصريح بفحصه.', 'The site may log your IP address and request data under its policy. Do not send personal data or secrets, and use only authorized targets.'),
      if (item.requiresIsolation) _t('هذا المورد ضعيف عمداً أو مخصص للتدريب. شغّله في بيئة محلية/افتراضية معزولة ولا تعرّضه للإنترنت.', 'This resource is intentionally vulnerable or made for training. Run it in an isolated local/virtual environment and never expose it to the Internet.'),
      if (item.processesSubmittedData) _t('أي نطاق أو بريد تدخله هناك قد تعالجه الخدمة الخارجية.', 'Any domain or email you enter there may be processed by the external service.'),
    ].join('\n\n');
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(_t('موافقة قبل فتح موقع خارجي', 'Consent before opening an external site')),
        content: SingleChildScrollView(child: Text(warning)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: Text(_t('إلغاء', 'Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(_t('فتح الموقع', 'Open site'))),
        ],
      ),
    );
    if (accepted != true || !mounted) return;
    final uri = Uri.tryParse(item.url);
    if (uri == null || uri.scheme != 'https') {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_t('الرابط غير صالح.', 'Invalid link.'))));
      return;
    }
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_t('تعذر فتح الموقع.', 'Could not open the site.'))));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_t('تعذر فتح الموقع الآن.', 'Could not open the site right now.'))));
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = _filtered;
    return Scaffold(
      backgroundColor: _p.background,
      appBar: AppBar(
        leading: pageBackButton(context),
        title: Text(_t('مختبرات وخدمات خارجية', 'External labs and services')),
        actions: [pageHomeButton(context)],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
            child: TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                labelText: _t('بحث في المختبرات والخدمات', 'Search labs and services'),
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _search.text.isEmpty ? null : IconButton(onPressed: () { _search.clear(); setState(() {}); }, icon: const Icon(Icons.clear)),
                border: const OutlineInputBorder(),
              ),
            ),
          ),
          SizedBox(
            height: 50,
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              scrollDirection: Axis.horizontal,
              children: [
                for (final category in _categories)
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 6),
                    child: ChoiceChip(
                      label: Text(category == 'all' ? _t('الكل', 'All') : category),
                      selected: _category == category,
                      onSelected: (_) => setState(() => _category = category),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 3),
            child: Align(alignment: AlignmentDirectional.centerStart, child: Text('${items.length} ${_t('مصدر', 'resources')}', style: TextStyle(color: _p.muted, fontSize: 12))),
          ),
          Expanded(
            child: items.isEmpty
                ? Center(child: Text(_t('لا توجد نتائج مطابقة.', 'No matching resources.')))
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(14, 4, 14, 24),
                    itemCount: items.length,
                    itemBuilder: (_, index) => _card(items[index]),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _card(ExternalResource item) {
    final category = _en ? item.categoryEn : item.categoryAr;
    return Card(
      color: _p.surface,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Icon(item.icon, color: _p.accent), const SizedBox(width: 10), Expanded(child: Text(_en ? item.nameEn : item.nameAr, style: TextStyle(color: _p.text, fontWeight: FontWeight.w900))), Chip(label: Text(category, style: const TextStyle(fontSize: 10))) ]),
          const SizedBox(height: 7),
          Text(_en ? item.descriptionEn : item.descriptionAr, style: TextStyle(color: _p.muted, height: 1.4)),
          const SizedBox(height: 7),
          Text(_en ? item.accessEn : item.accessAr, style: TextStyle(color: _p.text, fontSize: 12, height: 1.35)),
          if (item.requiresIsolation) Padding(padding: const EdgeInsets.only(top: 7), child: Text(_t('تحذير: تدريب ضعيف عمداً — عزل محلي/افتراضي مطلوب.', 'Warning: intentionally vulnerable training — local/virtual isolation required.'), style: TextStyle(color: _p.accent2, fontWeight: FontWeight.w800, fontSize: 11))),
          const SizedBox(height: 8),
          Align(alignment: AlignmentDirectional.centerEnd, child: FilledButton.icon(onPressed: () => _open(item), icon: const Icon(Icons.open_in_new, size: 17), label: Text(_t('عرض الموقع الرسمي', 'Open official site')))),
        ]),
      ),
    );
  }
}
