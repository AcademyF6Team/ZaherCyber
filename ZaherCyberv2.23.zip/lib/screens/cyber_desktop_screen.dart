import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/learning_content.dart';
import '../models/article.dart';
import '../services/learning_progress_service.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import 'fahes_screen.dart';

class CyberDesktopScreen extends StatefulWidget {
  const CyberDesktopScreen({
    super.key,
    this.resetToken = 0,
    this.onOpenLearning,
    required this.articles,
    required this.lastUpdated,
    required this.isUpdating,
    required this.updateFailed,
    required this.updatedSources,
    required this.failedSources,
    required this.onRefresh,
    required this.onGlobalSearch,
    required this.onOpenSection,
    required this.onOpenAcademy,
    required this.onOpenCtf,
    this.onOpenExternalResources,
    this.onOpenSecurityTools,
    this.onOpenWorkbench,
    this.onOpenAssistant,
    required this.onOpenArticle,
  });

  final int resetToken;
  final void Function(String? lessonId)? onOpenLearning;
  final List<Article> articles;
  final DateTime? lastUpdated;
  final bool isUpdating;
  final bool updateFailed;
  final int updatedSources;
  final int failedSources;
  final Future<void> Function() onRefresh;
  final ValueChanged<String> onGlobalSearch;
  final ValueChanged<String> onOpenSection;
  final VoidCallback onOpenAcademy;
  final VoidCallback onOpenCtf;
  final VoidCallback? onOpenExternalResources;
  final VoidCallback? onOpenSecurityTools;
  final VoidCallback? onOpenWorkbench;
  final VoidCallback? onOpenAssistant;
  final ValueChanged<Article> onOpenArticle;

  @override
  State<CyberDesktopScreen> createState() => _CyberDesktopScreenState();
}

class _CyberDesktopApp {
  const _CyberDesktopApp(
    this.id,
    this.ar,
    this.en,
    this.icon,
    this.group, {
    this.section,
    this.academy = false,
    this.ctf = false,
    this.fahes = false,
    this.workbench = false,
  });
  final String id;
  final String ar;
  final String en;
  final IconData icon;
  final String group;
  final String? section;
  final bool academy;
  final bool ctf;
  final bool fahes;
  final bool workbench;
}

class _CyberDesktopScreenState extends State<CyberDesktopScreen> {
  static const _hiddenKey = 'desktop_hidden_widgets_v1';
  static const _favoritesKey = 'desktop_favorite_apps_v1';
  static const _orderKey = 'desktop_app_order_v1';
  static const _readinessKey = 'desktop_readiness_v1';
  static const _defenseKey = 'desktop_defense_plan_v1';
  static const _dailyKey = 'desktop_daily_question_v1';
  static const _recentKey = 'desktop_recent_apps_v1';
  static const _readinessLabels = <(String, String, String)>[
    (
      'mfa',
      'راجعت حماية الحسابات والمصادقة متعددة العوامل',
      'Reviewed account protection and MFA',
    ),
    (
      'backup',
      'أعرف أين توجد نسخة احتياطية وكيف أستعيدها',
      'Know where a backup is and how to restore it',
    ),
    (
      'recovery',
      'أعرف قنوات استرداد الحساب الرسمية',
      'Know the official account recovery channels',
    ),
  ];

  final TextEditingController _search = TextEditingController();
  final LearningProgressService _progressService = LearningProgressService();
  final Set<String> _hiddenWidgets = {};
  final Set<String> _favoriteApps = {};
  List<String> _appOrder = _apps.map((app) => app.id).toList();
  List<String> _recentApps = [];
  final Set<String> _readiness = {};
  final Set<String> _defensePlan = {};
  String _query = '';
  String _workspace = 'all';
  bool _editing = false;
  bool _focusMode = false;
  String _focusGroup = 'learn';
  bool _loadingProgress = true;
  int _completedLessons = 0;
  bool _dailyComplete = false;

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  bool get _en => Localizations.localeOf(context).languageCode == 'en';
  String _t(String ar, String en) => copy(context, ar, en);

  static const _apps = <_CyberDesktopApp>[
    _CyberDesktopApp(
      'news',
      'الأخبار',
      'News',
      Icons.newspaper_rounded,
      'watch',
      section: 'news',
    ),
    _CyberDesktopApp(
      'arsenal',
      'الترسانة',
      'Arsenal',
      Icons.shield_rounded,
      'watch',
      section: 'arsenal',
    ),
    _CyberDesktopApp(
      'learn',
      'المعرفة',
      'Knowledge',
      Icons.menu_book_rounded,
      'learn',
      section: 'learn',
    ),
    _CyberDesktopApp(
      'protect',
      'مركز الحماية',
      'Protection',
      Icons.health_and_safety_rounded,
      'respond',
      section: 'protect',
    ),
    _CyberDesktopApp(
      'academy',
      'أكاديمية F6-Team',
      'F6-Team Academy',
      Icons.school_rounded,
      'learn',
      academy: true,
    ),
    _CyberDesktopApp(
      'ctf',
      'مختبر CTF',
      'CTF Lab',
      Icons.science_rounded,
      'learn',
      ctf: true,
    ),
    _CyberDesktopApp(
      'external-resources',
      'مختبرات وخدمات خارجية',
      'External labs',
      Icons.open_in_new_rounded,
      'tools',
    ),
    _CyberDesktopApp(
      'f6-security-tools',
      'أدوات F6 Security Tools',
      'F6 Security Tools',
      Icons.security_update_good_rounded,
      'tools',
    ),
    _CyberDesktopApp(
      'security-workbench',
      'مركز العمل الأمني',
      'Security Workbench',
      Icons.hub_rounded,
      'tools',
      workbench: true,
    ),
    _CyberDesktopApp(
      'zaher-assistant',
      'المساعد المحلي',
      'Zaher Assistant',
      Icons.auto_awesome_rounded,
      'tools',
    ),
    _CyberDesktopApp(
      'saved',
      'المحفوظات',
      'Saved',
      Icons.bookmark_rounded,
      'watch',
      section: 'saved',
    ),
    _CyberDesktopApp(
      'downloads',
      'التنزيلات',
      'Downloads',
      Icons.download_rounded,
      'tools',
      section: 'downloads',
    ),
    _CyberDesktopApp(
      'settings',
      'الإعدادات',
      'Settings',
      Icons.tune_rounded,
      'tools',
      section: 'settings',
    ),
    _CyberDesktopApp(
      'fahes',
      'فاحص | FAHES',
      'FAHES | URL Checker',
      Icons.travel_explore_rounded,
      'tools',
      fahes: true,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _loadLocalState();
    _loadProgress();
  }

  @override
  void didUpdateWidget(covariant CyberDesktopScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.resetToken != widget.resetToken) {
      _hiddenWidgets.clear();
      _favoriteApps.clear();
      _appOrder = _apps.map((app) => app.id).toList();
      _recentApps.clear();
      _readiness.clear();
      _defensePlan.clear();
      _workspace = 'all';
      _focusMode = false;
      _focusGroup = 'learn';
      _editing = false;
      _query = '';
      _dailyComplete = false;
      _loadLocalState();
    }
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _loadLocalState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        _hiddenWidgets.addAll(prefs.getStringList(_hiddenKey) ?? const []);
        _favoriteApps.addAll(prefs.getStringList(_favoritesKey) ?? const []);
        _recentApps = (prefs.getStringList(_recentKey) ?? const [])
            .where((id) => _apps.any((app) => app.id == id))
            .take(5)
            .toList();
        final savedOrder = prefs.getStringList(_orderKey);
        if (savedOrder != null) {
          _appOrder = [
            ...savedOrder.where((id) => _apps.any((app) => app.id == id)),
            ..._apps
                .map((app) => app.id)
                .where((id) => !savedOrder.contains(id)),
          ];
        }
        _readiness.addAll(prefs.getStringList(_readinessKey) ?? const []);
        _defensePlan.addAll(prefs.getStringList(_defenseKey) ?? const []);
        _dailyComplete = prefs.getString(_dailyKey) == _todayKey;
      });
    } catch (_) {
      // The desktop remains usable even if local preferences cannot be read.
    }
  }

  Future<void> _loadProgress() async {
    try {
      final progress = await _progressService.load();
      if (!mounted) return;
      setState(() {
        _completedLessons = progress.completedLessons.length;
        _loadingProgress = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loadingProgress = false);
    }
  }

  String get _todayKey {
    final now = DateTime.now();
    return '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  Future<void> _saveSet(String key, Set<String> values) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(key, values.toList()..sort());
    } catch (_) {
      if (mounted)
        _notice(
          _t('تعذر حفظ التغيير محلياً.', 'Could not save this change locally.'),
        );
    }
  }

  void _toggleWidget(String id) {
    setState(() {
      if (!_hiddenWidgets.add(id)) _hiddenWidgets.remove(id);
    });
    _saveSet(_hiddenKey, _hiddenWidgets);
  }

  void _toggleFavorite(String id) {
    setState(() {
      if (!_favoriteApps.add(id)) _favoriteApps.remove(id);
    });
    _saveSet(_favoritesKey, _favoriteApps);
  }

  void _notice(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<bool> _confirm({
    required String title,
    required String body,
    required String confirmLabel,
  }) async {
    return await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: Text(title),
            content: SingleChildScrollView(child: Text(body)),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: Text(_t('إلغاء', 'Cancel')),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                child: Text(confirmLabel),
              ),
            ],
          ),
        ) ??
        false;
  }

  Future<void> _openExternal(
    String label,
    String url, {
    String? warning,
  }) async {
    if (warning != null &&
        !await _confirm(
          title: label,
          body: warning,
          confirmLabel: _t('متابعة إلى الموقع', 'Continue to website'),
        ))
      return;
    final uri = Uri.tryParse(url);
    if (uri == null || uri.scheme != 'https') {
      _notice(_t('الرابط غير صالح.', 'This link is invalid.'));
      return;
    }
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted)
        _notice(
          _t(
            'تعذر فتح الموقع. تحقق من اتصال الإنترنت.',
            'Could not open the site. Check your internet connection.',
          ),
        );
    } catch (_) {
      if (mounted)
        _notice(
          _t(
            'تعذر فتح الموقع. يمكنك المحاولة لاحقاً.',
            'Could not open the site. Try again later.',
          ),
        );
    }
  }

  List<_CyberDesktopApp> get _visibleApps {
    var apps = _apps
        .where(
          (app) =>
              _query.trim().isEmpty ||
              '${app.ar} ${app.en}'.toLowerCase().contains(
                _query.trim().toLowerCase(),
              ),
        )
        .toList();
    if (_workspace != 'all')
      apps = apps.where((app) => app.group == _workspace).toList();
    apps.sort((a, b) {
      final aFav = _favoriteApps.contains(a.id);
      final bFav = _favoriteApps.contains(b.id);
      if (aFav != bFav) return aFav ? -1 : 1;
      return _appOrder.indexOf(a.id).compareTo(_appOrder.indexOf(b.id));
    });
    return apps;
  }

  void _launch(_CyberDesktopApp app) {
    _recordRecentApp(app);
    if (app.fahes) {
      _openFahes();
      return;
    }
    if (app.academy) {
      widget.onOpenAcademy();
      return;
    }
    if (app.ctf) {
      widget.onOpenCtf();
      return;
    }
    if (app.id == 'external-resources') {
      widget.onOpenExternalResources?.call();
      return;
    }
    if (app.id == 'f6-security-tools') {
      widget.onOpenSecurityTools?.call();
      return;
    }
    if (app.workbench) {
      widget.onOpenWorkbench?.call();
      return;
    }
    if (app.id == 'zaher-assistant') {
      widget.onOpenAssistant?.call();
      return;
    }
    if (app.section != null) widget.onOpenSection(app.section!);
  }

  Future<void> _openFahes() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 22),
        clipBehavior: Clip.antiAlias,
        child: SizedBox(
          width: 560,
          height: MediaQuery.sizeOf(dialogContext).height * .88,
          child: const FahesScreen(),
        ),
      ),
    );
  }

  Future<void> _recordRecentApp(_CyberDesktopApp app) async {
    setState(() {
      _recentApps.remove(app.id);
      _recentApps.insert(0, app.id);
      if (_recentApps.length > 5) _recentApps.removeLast();
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_recentKey, _recentApps);
    } catch (_) {
      if (mounted) {
        _notice(
          _t(
            'تعذر حفظ التطبيقات الأخيرة محلياً.',
            'Could not save recent apps locally.',
          ),
        );
      }
    }
  }

  Widget _recentAppsWidget() {
    final recent = <_CyberDesktopApp>[];
    for (final id in _recentApps) {
      final matches = _apps.where((app) => app.id == id);
      if (matches.isNotEmpty) recent.add(matches.first);
    }
    if (recent.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: _panel(
        'recent-apps',
        Icons.history_rounded,
        _t('المستخدمة مؤخراً', 'Recently opened'),
        _p,
        child: Wrap(
          spacing: 7,
          runSpacing: 4,
          children: [
            for (final app in recent)
              ActionChip(
                avatar: Icon(app.icon, size: 16),
                label: Text(_en ? app.en : app.ar),
                onPressed: () => _launch(app),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _answerQuestion(int selected) async {
    final question = _dailyQuestion;
    final correct = selected == question.correctIndex;
    if (correct) {
      setState(() => _dailyComplete = true);
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_dailyKey, _todayKey);
      } catch (_) {}
    }
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(
          correct
              ? _t('إجابة صحيحة', 'Correct')
              : _t('ليست الإجابة الصحيحة بعد', 'Not quite yet'),
        ),
        content: Text(
          '${_en ? question.explanationEn : question.explanationAr}${correct ? '' : '\n\n${_t('يمكنك المحاولة مجدداً من سؤال اليوم.', 'You can try again from the daily question.')}'}',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(_t('حسناً', 'OK')),
          ),
        ],
      ),
    );
  }

  LearningQuestion get _dailyQuestion {
    final now = DateTime.now();
    final dayKey = now.year * 10000 + now.month * 100 + now.day;
    return learningQuestions[dayKey % learningQuestions.length];
  }

  Future<void> _showDailyQuestion() async {
    final q = _dailyQuestion;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(_t('سؤال اليوم', 'Question of the day')),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _en ? q.promptEn : q.promptAr,
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 12),
              for (var i = 0; i < q.optionsAr.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 7),
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.pop(dialogContext);
                      _answerQuestion(i);
                    },
                    child: Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Text(_en ? q.optionsEn[i] : q.optionsAr[i]),
                    ),
                  ),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(_t('إغلاق', 'Close')),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleReadiness(String id) async {
    setState(() {
      if (!_readiness.add(id)) _readiness.remove(id);
    });
    await _saveSet(_readinessKey, _readiness);
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    final apps = _visibleApps;
    final width = MediaQuery.sizeOf(context).width;
    final columns = width >= 900
        ? 4
        : width >= 600
        ? 3
        : 2;
    final widgets = <Widget>[
      if (_showWidget('status')) _statusWidget(),
      if (_showWidget('news')) _newsWidget(),
      if (_showWidget('learning')) _learningWidget(),
      if (_showWidget('response')) _responseWidget(),
      if (_showWidget('flow')) _threatWidget(),
      if (_showWidget('challenge')) _challengeWidget(),
      if (_showWidget('readiness')) _readinessWidget(),
      if (_showWidget('defense')) _defenseWidget(),
      if (_showWidget('external')) _externalWidget(),
    ];
    return ColoredBox(
      color: p.background,
      child: CustomScrollView(
        key: const PageStorageKey<String>('cyber-desktop-scroll'),
        slivers: [
          SliverToBoxAdapter(child: _topHeader()),
          SliverToBoxAdapter(child: _searchAndWorkspaces()),
          SliverToBoxAdapter(
            child: _sectionHeader(
              _t('تطبيقاتي', 'My applications'),
              trailing: _editing
                  ? _t(
                      'اسحب للترتيب واضغط النجمة للتثبيت',
                      'Drag to reorder; tap star to pin',
                    )
                  : null,
              onToggleEdit: () => setState(() => _editing = !_editing),
            ),
          ),
          if (!_editing && _recentApps.isNotEmpty)
            SliverToBoxAdapter(child: _recentAppsWidget()),
          if (_editing) SliverToBoxAdapter(child: _customizationPanel()),
          if (_editing)
            SliverToBoxAdapter(child: _appReorderList(apps, p))
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
              sliver: SliverGrid(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: columns,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: width < 400 ? 1.23 : 1.34,
                ),
                delegate: SliverChildBuilderDelegate((context, index) {
                  final app = apps[index];
                  return _appTile(app, p);
                }, childCount: apps.length),
              ),
            ),
          if (apps.isEmpty) SliverToBoxAdapter(child: _emptySearch()),
          for (final widget in widgets) SliverToBoxAdapter(child: widget),
          const SliverToBoxAdapter(child: SizedBox(height: 24)),
        ],
      ),
    );
  }

  bool _showWidget(String id) {
    if (_hiddenWidgets.contains(id)) return false;
    if (!_focusMode) return true;
    final focusIds = switch (_focusGroup) {
      'watch' => const {'status', 'news'},
      'respond' => const {'response', 'flow', 'readiness', 'defense'},
      'tools' => const {'external'},
      _ => const {'learning', 'challenge'},
    };
    return focusIds.contains(id);
  }

  void _toggleFocusMode() {
    setState(() {
      _focusMode = !_focusMode;
      _workspace = _focusMode ? _focusGroup : 'all';
    });
  }

  Widget _topHeader() {
    final p = _p;
    final now = DateTime.now();
    final date =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 7),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: AlignmentDirectional.topStart,
            end: AlignmentDirectional.bottomEnd,
            colors: [p.heroStart, p.surface, p.background],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: p.accent.withValues(alpha: .42)),
          boxShadow: [
            BoxShadow(
              color: p.accent.withValues(alpha: .07),
              blurRadius: 22,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Stack(
          children: [
            PositionedDirectional(
              end: -32,
              top: -42,
              child: Icon(
                Icons.radar_rounded,
                size: 172,
                color: p.accent.withValues(alpha: .045),
              ),
            ),
            Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(15, 14, 13, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: p.accent.withValues(alpha: .12),
                          borderRadius: BorderRadius.circular(17),
                          border: Border.all(
                            color: p.accent.withValues(alpha: .38),
                          ),
                        ),
                        child: Icon(
                          Icons.memory_rounded,
                          color: p.accent,
                          size: 29,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'F6-OS',
                              style: TextStyle(
                                color: p.text,
                                fontSize: 23,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                              ),
                            ),
                            Text(
                              'CYBER OPERATING ENVIRONMENT',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: p.accent,
                                fontSize: 8,
                                fontWeight: FontWeight.w900,
                                letterSpacing: .9,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: _t('وضع التركيز', 'Focus mode'),
                        onPressed: _toggleFocusMode,
                        icon: Icon(
                          _focusMode
                              ? Icons.center_focus_strong_rounded
                              : Icons.center_focus_weak_rounded,
                          color: _focusMode ? p.accent : p.muted,
                        ),
                      ),
                      IconButton(
                        tooltip: _t(
                          'تخصيص تطبيقات F6-OS',
                          'Customize F6-OS apps',
                        ),
                        onPressed: () => setState(() => _editing = !_editing),
                        icon: Icon(
                          _editing
                              ? Icons.done_rounded
                              : Icons.dashboard_customize_outlined,
                          color: p.accent,
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsetsDirectional.only(
                      start: 62,
                      top: 4,
                    ),
                    child: Text(
                      _t(
                        'بوابة خدماتك السيبرانية في مساحة واحدة',
                        'Your cyber services in one workspace',
                      ),
                      style: TextStyle(color: p.muted, fontSize: 10),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(height: 1, color: p.accent.withValues(alpha: .18)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.terminal_rounded, color: p.accent, size: 14),
                      const SizedBox(width: 5),
                      Expanded(
                        child: Text(
                          _editing
                              ? _t('وضع تخصيص التطبيقات', 'APP CUSTOMIZATION')
                              : _t('مساحة عمل محلية', 'LOCAL APP WORKSPACE'),
                          style: TextStyle(
                            color: p.accent,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            letterSpacing: .6,
                          ),
                        ),
                      ),
                      Text(
                        date,
                        style: TextStyle(color: p.muted, fontSize: 10),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _searchAndWorkspaces() {
    final p = _p;
    final workspaces = <(String, String, String)>[
      ('all', 'الكل', 'All'),
      ('learn', 'تعلّم', 'Learn'),
      ('watch', 'تابع', 'Monitor'),
      ('respond', 'استجب', 'Respond'),
      ('tools', 'أدواتي', 'Tools'),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 9, 16, 2),
      child: Column(
        children: [
          TextField(
            controller: _search,
            onChanged: (value) => setState(() => _query = value),
            onSubmitted: widget.onGlobalSearch,
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search_rounded),
              hintText: _t(
                'ابحث عن تطبيق أو خبر أو أداة',
                'Search apps, news, and tools',
              ),
              suffixIcon: _query.isEmpty
                  ? null
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          tooltip: _t('بحث شامل', 'Search content'),
                          onPressed: () => widget.onGlobalSearch(_query),
                          icon: const Icon(Icons.search_rounded),
                        ),
                        IconButton(
                          tooltip: _t('مسح البحث', 'Clear search'),
                          onPressed: () {
                            _search.clear();
                            setState(() => _query = '');
                          },
                          icon: const Icon(Icons.close_rounded),
                        ),
                      ],
                    ),
              contentPadding: const EdgeInsets.symmetric(vertical: 11),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 38,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                for (final item in workspaces)
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 7),
                    child: ChoiceChip(
                      label: Text(_en ? item.$3 : item.$2),
                      selected: _workspace == item.$1,
                      onSelected: (_) => setState(() {
                        _workspace = item.$1;
                        if (item.$1 == 'all') {
                          _focusMode = false;
                        } else {
                          _focusGroup = item.$1;
                        }
                      }),
                      showCheckmark: false,
                      selectedColor: p.accent.withValues(alpha: .18),
                      side: BorderSide(
                        color: _workspace == item.$1 ? p.accent : p.border,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          if (_focusMode)
            Padding(
              padding: const EdgeInsets.only(top: 5),
              child: Align(
                alignment: AlignmentDirectional.centerStart,
                child: Text(
                  _t(
                    'وضع التركيز مفعّل — اختر مساحة، ويمكنك إيقافه من رمز التركيز.',
                    'Focus mode is on—choose a workspace or turn it off from the focus icon.',
                  ),
                  style: TextStyle(color: p.accent, fontSize: 9),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _sectionHeader(
    String title, {
    String? trailing,
    VoidCallback? onToggleEdit,
  }) {
    final p = _p;
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 9),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                color: p.text,
                fontSize: 16,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          if (trailing != null)
            Text(trailing, style: TextStyle(color: p.muted, fontSize: 10)),
          if (onToggleEdit != null)
            IconButton(
              visualDensity: VisualDensity.compact,
              tooltip: _t(
                'تخصيص التطبيقات والودجتس',
                'Customize apps and widgets',
              ),
              onPressed: onToggleEdit,
              icon: Icon(Icons.tune_rounded, color: p.accent, size: 19),
            ),
        ],
      ),
    );
  }

  Widget _appTile(_CyberDesktopApp app, AppPalette p) {
    final favorite = _favoriteApps.contains(app.id);
    final appNumber = (_apps.indexOf(app) + 1).toString().padLeft(2, '0');
    return Semantics(
      button: true,
      label: _en ? app.en : app.ar,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          key: ValueKey<String>('desktop-app-${app.id}'),
          borderRadius: BorderRadius.circular(17),
          onTap: () => _launch(app),
          child: Ink(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: AlignmentDirectional.topStart,
                end: AlignmentDirectional.bottomEnd,
                colors: [p.surface, p.surface.withValues(alpha: .84)],
              ),
              borderRadius: BorderRadius.circular(17),
              border: Border.all(
                color: favorite ? p.accent.withValues(alpha: .78) : p.border,
              ),
            ),
            child: Stack(
              children: [
                PositionedDirectional(
                  start: 9,
                  top: 8,
                  child: Text(
                    'APP-$appNumber',
                    style: TextStyle(
                      color: p.muted.withValues(alpha: .8),
                      fontSize: 7,
                      fontWeight: FontWeight.w900,
                      letterSpacing: .5,
                    ),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(8, 16, 8, 7),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 47,
                          height: 47,
                          decoration: BoxDecoration(
                            color: p.accent.withValues(alpha: .11),
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(
                              color: p.accent.withValues(alpha: .22),
                            ),
                          ),
                          child: Icon(app.icon, color: p.accent, size: 25),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _en ? app.en : app.ar,
                          maxLines: 2,
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: p.text,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          _t('فتح التطبيق  ›', 'OPEN APP  ›'),
                          style: TextStyle(
                            color: p.accent.withValues(alpha: .86),
                            fontSize: 8,
                            fontWeight: FontWeight.w800,
                            letterSpacing: .4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (_editing)
                  PositionedDirectional(
                    top: 0,
                    end: 0,
                    child: IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () => _toggleFavorite(app.id),
                      tooltip: favorite
                          ? _t('إزالة من المثبتة', 'Unpin')
                          : _t('تثبيت', 'Pin'),
                      icon: Icon(
                        favorite
                            ? Icons.star_rounded
                            : Icons.star_border_rounded,
                        color: favorite ? p.accent : p.muted,
                        size: 18,
                      ),
                    ),
                  )
                else if (favorite)
                  PositionedDirectional(
                    top: 7,
                    end: 7,
                    child: Icon(Icons.star_rounded, color: p.accent, size: 14),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _appReorderList(List<_CyberDesktopApp> apps, AppPalette p) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(15, 0, 15, 10),
      child: ReorderableListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        buildDefaultDragHandles: false,
        itemCount: apps.length,
        onReorderItem: (oldIndex, newIndex) async {
          final changed = [...apps];
          final moved = changed.removeAt(oldIndex);
          changed.insert(newIndex, moved);
          final visibleIds = apps.map((app) => app.id).toSet();
          final slots = <int>[
            for (var i = 0; i < _appOrder.length; i++)
              if (visibleIds.contains(_appOrder[i])) i,
          ];
          setState(() {
            for (var i = 0; i < slots.length && i < changed.length; i++) {
              _appOrder[slots[i]] = changed[i].id;
            }
          });
          try {
            final prefs = await SharedPreferences.getInstance();
            await prefs.setStringList(_orderKey, _appOrder);
          } catch (_) {
            if (mounted) {
              _notice(
                _t('تعذر حفظ ترتيب التطبيقات.', 'Could not save app order.'),
              );
            }
          }
        },
        itemBuilder: (context, index) {
          final app = apps[index];
          final favorite = _favoriteApps.contains(app.id);
          return Container(
            key: ValueKey<String>('desktop-reorder-${app.id}'),
            margin: const EdgeInsets.only(bottom: 5),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: p.border),
            ),
            child: ListTile(
              dense: true,
              leading: Icon(app.icon, color: p.accent),
              title: Text(
                _en ? app.en : app.ar,
                style: TextStyle(
                  color: p.text,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    tooltip: favorite
                        ? _t('إزالة من المثبتة', 'Unpin')
                        : _t('تثبيت', 'Pin'),
                    onPressed: () => _toggleFavorite(app.id),
                    icon: Icon(
                      favorite ? Icons.star_rounded : Icons.star_border_rounded,
                      color: favorite ? p.accent : p.muted,
                    ),
                  ),
                  ReorderableDragStartListener(
                    index: index,
                    child: Icon(Icons.drag_handle_rounded, color: p.muted),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _customizationPanel() {
    final p = _p;
    const options = <(String, String, String)>[
      ('status', 'حالة التحديث', 'Update status'),
      ('news', 'موجز الأخبار', 'News feed'),
      ('learning', 'متابعة التعلّم', 'Learning progress'),
      ('response', 'الاستجابة السريعة', 'Quick response'),
      ('challenge', 'سؤال اليوم', 'Daily question'),
      ('readiness', 'قائمة الاستعداد', 'Preparedness checklist'),
      ('defense', 'ابنِ خطة دفاع', 'Build a defense plan'),
      ('external', 'الخدمات الخارجية', 'External services'),
    ];
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _t(
              'إظهار الودجتس المطلوبة. التغييرات محفوظة على هذا الجهاز.',
              'Choose visible widgets. Changes stay on this device.',
            ),
            style: TextStyle(color: p.muted, fontSize: 10),
          ),
          Wrap(
            spacing: 4,
            children: [
              for (final item in options)
                FilterChip(
                  label: Text(_en ? item.$3 : item.$2),
                  selected: !_hiddenWidgets.contains(item.$1),
                  onSelected: (_) => _toggleWidget(item.$1),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statusWidget() {
    final p = _p;
    final state = widget.isUpdating
        ? _t('جارٍ التحديث', 'Updating')
        : widget.updateFailed
        ? _t('تعذر تحديث بعض المصادر', 'Some sources failed')
        : widget.lastUpdated == null
        ? _t('لم يكتمل تحديث بعد', 'No successful refresh yet')
        : _t('آخر تحديث ناجح', 'Last successful update');
    final timestamp = widget.lastUpdated?.toLocal().toString();
    return _panel(
      'status',
      Icons.sync_rounded,
      _t('حالة المصادر', 'Source status'),
      p,
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  state,
                  style: TextStyle(
                    color: p.text,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
                if (timestamp != null)
                  Text(
                    timestamp.length > 16
                        ? timestamp.substring(0, 16)
                        : timestamp,
                    style: TextStyle(color: p.muted, fontSize: 10),
                  ),
                Text(
                  _t(
                    'نجح ${widget.updatedSources} · تعذر ${widget.failedSources}',
                    '${widget.updatedSources} updated · ${widget.failedSources} failed',
                  ),
                  style: TextStyle(color: p.muted, fontSize: 10),
                ),
                Text(
                  _t(
                    'المحتوى المحفوظ يبقى متاحاً دون اتصال.',
                    'Cached content remains available offline.',
                  ),
                  style: TextStyle(color: p.muted, fontSize: 10),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: _t('تحديث الأخبار', 'Refresh news'),
            onPressed: widget.isUpdating ? null : () => widget.onRefresh(),
            icon: widget.isUpdating
                ? SizedBox(
                    width: 19,
                    height: 19,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: p.accent,
                    ),
                  )
                : Icon(Icons.refresh_rounded, color: p.accent),
          ),
        ],
      ),
    );
  }

  Widget _newsWidget() {
    final p = _p;
    final items = widget.articles.take(3).toList();
    return _panel(
      'news',
      Icons.newspaper_rounded,
      _t('آخر المستجدات', 'Latest updates'),
      p,
      trailing: TextButton(
        onPressed: () => widget.onOpenSection('news'),
        child: Text(_t('كل الأخبار', 'All news')),
      ),
      child: items.isEmpty
          ? Text(
              _t(
                'لا توجد أخبار مخزنة حالياً. افتح الأخبار للتحديث عند توفر الإنترنت.',
                'No cached stories yet. Open News to refresh when online.',
              ),
              style: TextStyle(color: p.muted, fontSize: 11),
            )
          : Column(
              children: [
                for (final item in items)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text(
                      item.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: p.text,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    subtitle: Text(
                      '${item.source} · ${item.publishedAt?.toLocal().toString().substring(0, 10) ?? '—'}',
                      style: TextStyle(color: p.muted, fontSize: 9),
                    ),
                    onTap: () => widget.onOpenArticle(item),
                  ),
              ],
            ),
    );
  }

  Widget _learningWidget() {
    final p = _p;
    final total = learningLessons.length;
    final ratio = total == 0
        ? 0.0
        : (_completedLessons / total).clamp(0.0, 1.0).toDouble();
    LearningLesson? next;
    for (final lesson in learningLessons) {
      if (!_progressService.progress.completedLessons.contains(lesson.id)) {
        next = lesson;
        break;
      }
    }
    return _panel(
      'learning',
      Icons.route_rounded,
      _t('تابع تعلّمك', 'Continue learning'),
      p,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _loadingProgress
                ? _t('جارٍ قراءة تقدمك المحلي…', 'Loading local progress…')
                : _t(
                    '$_completedLessons من $total درساً مكتملاً',
                    '$_completedLessons of $total lessons complete',
                  ),
            style: TextStyle(
              color: p.text,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: ratio,
            color: p.accent,
            backgroundColor: p.raised,
            minHeight: 5,
          ),
          if (next != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                _t('الدرس التالي: ${next.titleAr}', 'Next: ${next.titleEn}'),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: p.muted, fontSize: 10),
              ),
            ),
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: TextButton.icon(
              onPressed: () {
                if (widget.onOpenLearning != null) {
                  widget.onOpenLearning!(next?.id);
                } else {
                  widget.onOpenSection('learn');
                }
              },
              icon: const Icon(Icons.play_arrow_rounded),
              label: Text(_t('متابعة المسارات', 'Continue paths')),
            ),
          ),
        ],
      ),
    );
  }

  Widget _responseWidget() {
    final p = _p;
    const cases = <(String, String, IconData)>[
      ('account', 'حساب مخترق', Icons.account_circle_outlined),
      ('phishing', 'تصيّد أو مرفق', Icons.mail_lock_outlined),
      ('phone', 'هاتف مفقود', Icons.phone_android_rounded),
      ('ransomware', 'فدية', Icons.lock_outline_rounded),
    ];
    return _panel(
      'response',
      Icons.emergency_outlined,
      _t('ماذا حدث؟ ابدأ من هنا', 'What happened? Start here'),
      p,
      child: Wrap(
        spacing: 7,
        runSpacing: 4,
        children: [
          for (final item in cases)
            ActionChip(
              avatar: Icon(item.$3, size: 16),
              label: Text(
                _en
                    ? switch (item.$1) {
                        'account' => 'Account',
                        'phishing' => 'Phishing',
                        'phone' => 'Lost phone',
                        _ => 'Ransomware',
                      }
                    : item.$2,
              ),
              onPressed: () => _showScenario(item.$1),
            ),
        ],
      ),
    );
  }

  Widget _threatWidget() {
    final p = _p;
    final stages = <(String, String, IconData, String)>[
      (
        'phish',
        _t('رسالة مشبوهة', 'Suspicious message'),
        Icons.mark_email_unread_outlined,
        _t(
          'تحقق من المرسل عبر قناة مستقلة ولا تفتح الرابط قبل التأكد.',
          'Verify the sender independently; do not open the link until verified.',
        ),
      ),
      (
        'account',
        _t('محاولة دخول', 'Sign-in attempt'),
        Icons.account_circle_outlined,
        _t(
          'المصادقة متعددة العوامل ومراجعة الجلسات تقللان أثر سرقة كلمة المرور.',
          'MFA and session review reduce the impact of stolen credentials.',
        ),
      ),
      (
        'data',
        _t('بيانات أو خدمة', 'Data or service'),
        Icons.storage_rounded,
        _t(
          'أقل صلاحية ونسخ احتياطي مجرّب يساعدان على الحد من الأثر والتعافي.',
          'Least privilege and tested backups help limit impact and recover.',
        ),
      ),
    ];
    return _panel(
      'flow',
      Icons.account_tree_outlined,
      _t('مسرح التهديد — نموذج توضيحي', 'Threat theater — illustrative model'),
      p,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _t(
              'المسار افتراضي للتعلّم؛ لا يقرأ حركة جهازك أو شبكتك.',
              'Illustrative learning path only; it does not inspect your device or network traffic.',
            ),
            style: TextStyle(color: p.muted, fontSize: 9),
          ),
          const SizedBox(height: 8),
          Wrap(
            alignment: WrapAlignment.center,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 4,
            runSpacing: 5,
            children: [
              for (var i = 0; i < stages.length; i++) ...[
                ActionChip(
                  avatar: Icon(stages[i].$3, size: 16, color: p.accent),
                  label: Text(
                    stages[i].$2,
                    style: TextStyle(fontSize: 9, color: p.text),
                  ),
                  onPressed: () => showDialog<void>(
                    context: context,
                    builder: (dialogContext) => AlertDialog(
                      title: Text(stages[i].$2),
                      content: Text(stages[i].$4),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(dialogContext),
                          child: Text(_t('إغلاق', 'Close')),
                        ),
                      ],
                    ),
                  ),
                ),
                if (i < stages.length - 1)
                  Icon(Icons.arrow_forward_rounded, size: 16, color: p.muted),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _challengeWidget() {
    final p = _p;
    final q = _dailyQuestion;
    return _panel(
      'challenge',
      Icons.quiz_outlined,
      _t('سؤال اليوم', 'Daily question'),
      p,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _en ? q.promptEn : q.promptAr,
            style: TextStyle(
              color: p.text,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: _dailyComplete ? null : _showDailyQuestion,
            icon: Icon(
              _dailyComplete
                  ? Icons.check_circle_outline
                  : Icons.play_arrow_rounded,
            ),
            label: Text(
              _dailyComplete
                  ? _t('أُنجز سؤال اليوم', 'Completed today')
                  : _t('جرّب السؤال', 'Try question'),
            ),
          ),
          Text(
            _t(
              'تدريب تعليمي فقط؛ لا يفحص الجهاز.',
              'Educational practice only; it does not scan your device.',
            ),
            style: TextStyle(color: p.muted, fontSize: 9),
          ),
        ],
      ),
    );
  }

  Widget _readinessWidget() {
    final p = _p;
    return _panel(
      'readiness',
      Icons.fact_check_outlined,
      _t('قائمة استعداد شخصية', 'Personal preparedness checklist'),
      p,
      child: Column(
        children: [
          for (final item in _readinessLabels)
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              value: _readiness.contains(item.$1),
              onChanged: (_) => _toggleReadiness(item.$1),
              title: Text(
                _en ? item.$3 : item.$2,
                style: TextStyle(color: p.text, fontSize: 10),
              ),
              controlAffinity: ListTileControlAffinity.leading,
            ),
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: Text(
              _t(
                'تقييم ذاتي محلي فقط، وليس درجة أمان أو فحصاً للجهاز.',
                'Local self-check only—not a security score or device scan.',
              ),
              style: TextStyle(color: p.muted, fontSize: 9),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showScenario(String id) async {
    final scenario = switch (id) {
      'account' => (
        _t(
          'تنبيه: دخول غير مألوف إلى حسابك',
          'Alert: unfamiliar sign-in to your account',
        ),
        _t('ما أول تصرف آمن؟', 'What is the safest first step?'),
        <String>[
          _t('فتح رابط في رسالة التنبيه', 'Open a link in the alert message'),
          _t(
            'فتح التطبيق أو الموقع الرسمي مباشرة والتحقق من الجلسات',
            'Open the official app/site directly and review sessions',
          ),
          _t(
            'إرسال رمز التحقق لمن طلبه',
            'Send the verification code to whoever asks',
          ),
        ],
        1,
        _t(
          'ادخل عبر التطبيق أو العنوان الرسمي، أنهِ الجلسات غير المعروفة، ثم غيّر بيانات الدخول وفعّل المصادقة متعددة العوامل.',
          'Use the official app/site, end unknown sessions, then change credentials and enable MFA.',
        ),
      ),
      'phishing' => (
        _t(
          'وصلتك رسالة بمرفق غير متوقع',
          'You received an unexpected attachment',
        ),
        _t('كيف تتصرف؟', 'What do you do?'),
        <String>[
          _t(
            'فتح المرفق لمعرفة محتواه',
            'Open the attachment to see what it is',
          ),
          _t(
            'التحقق من المرسل عبر قناة مستقلة والإبلاغ عن الرسالة',
            'Verify the sender through another channel and report the message',
          ),
          _t('إعادة توجيهها إلى زملائك', 'Forward it to colleagues'),
        ],
        1,
        _t(
          'تحقق من المرسل عبر وسيلة تعرفها مسبقاً، ولا تفتح المرفق، واتبع قناة الإبلاغ في جهتك.',
          'Verify the sender through a channel you already know, do not open the attachment, and use your organization’s reporting path.',
        ),
      ),
      'phone' => (
        _t('فُقد هاتفك', 'Your phone is missing'),
        _t('ما الخطوة الأولى الأكثر أماناً؟', 'What is the safest first step?'),
        <String>[
          _t(
            'استخدام خدمة العثور الرسمية وقفل الجهاز إن أمكن',
            'Use the official find service and lock the device if possible',
          ),
          _t(
            'نشر كلمة المرور على وسائل التواصل',
            'Post the password on social media',
          ),
          _t('تثبيت أداة من رابط عشوائي', 'Install an app from a random link'),
        ],
        0,
        _t(
          'استخدم خدمة الشركة الرسمية لقفل الجهاز، ثم تواصل مع مزود الخدمة وراجع جلسات الحسابات من جهاز موثوق.',
          'Use the vendor’s official service to lock it, contact your carrier, and review account sessions from a trusted device.',
        ),
      ),
      _ => (
        _t(
          'ظهرت ملاحظة فدية على جهاز عمل',
          'A ransomware note appeared on a work device',
        ),
        _t('ما التصرف الأكثر أماناً؟', 'What is the safest response?'),
        <String>[
          _t(
            'اتباع خطة الاستجابة وإبلاغ فريق الأمن فوراً',
            'Follow the response plan and alert security immediately',
          ),
          _t(
            'حذف السجلات وإعادة تشغيل كل الأجهزة',
            'Delete logs and reboot every device',
          ),
          _t('توصيل أقراص النسخ الاحتياطي', 'Connect backup drives'),
        ],
        0,
        _t(
          'أبلغ فريق الأمن فوراً، واتبع الإجراء المؤسسي. لا توصل نسخاً احتياطية ولا تعبث بالأدلة من دون توجيه.',
          'Alert security immediately and follow the organization’s response plan. Do not connect backups or alter evidence without guidance.',
        ),
      ),
    };
    final answer = await showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(scenario.$1),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(scenario.$2),
            const SizedBox(height: 10),
            for (var i = 0; i < scenario.$3.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(dialogContext, i),
                  child: Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Text(scenario.$3[i]),
                  ),
                ),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(_t('إغلاق', 'Close')),
          ),
        ],
      ),
    );
    if (answer == null || !mounted) return;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(
          answer == scenario.$4
              ? _t('اختيار مناسب', 'Good choice')
              : _t('تدرّب على الإجراء الآمن', 'Practice the safer response'),
        ),
        content: Text(
          '${scenario.$5}\n\n${_t('هذا سيناريو تدريبي افتراضي، ولا يتصل بجهازك أو ينفذ إجراءً فعلياً.', 'This is a fictional training scenario. It does not connect to your device or perform real actions.')}',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(_t('فهمت', 'Got it')),
          ),
        ],
      ),
    );
  }

  Widget _defenseWidget() {
    final p = _p;
    const steps = <(String, String, String)>[
      (
        'account-layer',
        'طبقة الحسابات: مصادقة متعددة العوامل واسترداد آمن',
        'Accounts: MFA and secure recovery',
      ),
      (
        'device-layer',
        'طبقة الأجهزة: تحديثات رسمية وقفل شاشة قوي',
        'Devices: official updates and a strong screen lock',
      ),
      (
        'recovery-layer',
        'طبقة التعافي: نسخة احتياطية مجرّبة وخطة استرداد',
        'Recovery: tested backup and recovery plan',
      ),
    ];
    return _panel(
      'defense',
      Icons.layers_outlined,
      _t('ابنِ خطة دفاعك', 'Build your defense plan'),
      p,
      child: Column(
        children: [
          Text(
            _t(
              'اختر ضوابط تريد مراجعتها؛ الاختيار لا يطبق إعداداً على جهازك.',
              'Select controls you want to review; selecting does not change device settings.',
            ),
            style: TextStyle(color: p.muted, fontSize: 10),
          ),
          for (final step in steps)
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              value: _defensePlan.contains(step.$1),
              onChanged: (_) async {
                setState(() {
                  if (!_defensePlan.add(step.$1)) _defensePlan.remove(step.$1);
                });
                await _saveSet(_defenseKey, _defensePlan);
              },
              title: Text(
                _en ? step.$3 : step.$2,
                style: TextStyle(color: p.text, fontSize: 10),
              ),
              controlAffinity: ListTileControlAffinity.leading,
            ),
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: Text(
              _t(
                'محفوظة محلياً على هذا الجهاز فقط.',
                'Saved locally on this device only.',
              ),
              style: TextStyle(color: p.muted, fontSize: 9),
            ),
          ),
        ],
      ),
    );
  }

  Widget _externalWidget() {
    final p = _p;
    final entries = <(String, String, String, IconData, String?)>[
      (
        'kc7',
        'KC7 — محقق التهديدات',
        'KC7 — Threat investigation',
        Icons.manage_search_rounded,
        null,
      ),
      (
        'cyberdefenders',
        'مختبرات CyberDefenders',
        'CyberDefenders labs',
        Icons.security_rounded,
        null,
      ),
      (
        'crapi',
        'مختبر OWASP crAPI',
        'OWASP crAPI lab',
        Icons.api_rounded,
        _t(
          'تطبيق تدريبي مقصود الضعف؛ اقرأ طريقة الإعداد وشغّله في مختبر محلي معزول فقط، وليس على خدمة عامة.',
          'Intentionally vulnerable training app. Read setup guidance and run only in an isolated local lab, never as a public service.',
        ),
      ),
      (
        'internetnl',
        'Internet.nl — معايير الإنترنت',
        'Internet.nl — internet standards',
        Icons.public_rounded,
        _t(
          'يفتح خدمة خارجية. إذا أدخلت نطاقاً أو بريداً هناك، فستعالجه الخدمة لفحصه. أدخل نطاقاً تملكه أو لديك إذن بفحصه.',
          'Opens an external service. Any domain or email you enter there is processed by that service. Use only a domain you own or are authorized to assess.',
        ),
      ),
      (
        'dnsviz',
        'DNSViz — تشخيص DNS',
        'DNSViz — DNS diagnostics',
        Icons.hub_outlined,
        _t(
          'يفتح خدمة DNS خارجية. إذا أرسلت نطاقاً للتحليل، ستراه الخدمة وتنفذ استعلامات DNS عنه. استخدم نطاقاً تملكه أو لديك إذن بفحصه.',
          'Opens an external DNS service. A domain you submit is visible to that service and queried. Use only a domain you own or are authorized to assess.',
        ),
      ),
      (
        'tor',
        'دليل Tor Browser الرسمي',
        'Tor Browser official guide',
        Icons.privacy_tip_outlined,
        _t(
          'يفتح دليل التثبيت الرسمي. Tor Browser لا يجعل كل نشاطك مجهولاً تلقائياً؛ نزّله من المصدر الرسمي فقط.',
          'Opens the official installation guide. Tor Browser does not automatically make all activity anonymous; download only from the official source.',
        ),
      ),
      (
        'ooni',
        'OONI Probe: اقرأ المخاطر أولاً',
        'OONI Probe: read risks first',
        Icons.warning_amber_rounded,
        _t(
          'لا يشغّل ZaherCyber أي اختبار. تشغيل OONI قد يرسل قياسات إلى OONI وينشرها علناً حسب الإعدادات، وقد يحمل مخاطر قانونية أو شخصية بحسب البلد. افتح وثائق المخاطر فقط قبل اتخاذ قرارك.',
          'ZaherCyber will not run any test. OONI may send and publicly publish measurements depending on settings, and use may carry legal or personal risk depending on location. This opens risk documentation only.',
        ),
      ),
    ];
    return _panel(
      'external',
      Icons.open_in_new_rounded,
      _t('مختبرات وخدمات خارجية', 'External labs and services'),
      p,
      child: Column(
        children: [
          for (final item in entries)
            ListTile(
              key: ValueKey<String>('desktop-external-${item.$1}'),
              contentPadding: EdgeInsets.zero,
              dense: true,
              leading: Icon(item.$4, color: p.accent, size: 21),
              title: Text(
                _en ? item.$3 : item.$2,
                style: TextStyle(
                  color: p.text,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
              trailing: Icon(
                Icons.arrow_outward_rounded,
                color: p.muted,
                size: 16,
              ),
              onTap: () {
                final url = switch (item.$1) {
                  'kc7' => 'https://kc7cyber.com/',
                  'cyberdefenders' =>
                    'https://cyberdefenders.org/blue-team-labs/',
                  'crapi' => 'https://owasp.org/projects/crapi',
                  'internetnl' => 'https://internet.nl/',
                  'dnsviz' => 'https://dnsviz.net/',
                  'tor' =>
                    'https://support.torproject.org/tor-browser/getting-started/installing/',
                  _ => 'https://ooni.org/about/risks/',
                };
                _openExternal(_en ? item.$3 : item.$2, url, warning: item.$5);
              },
            ),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              _t(
                'الخدمات الخارجية تتطلب الإنترنت وتخضع لسياسات الجهات المشغلة. ZaherCyber لا يرسل بيانات إليها تلقائياً.',
                'External services require internet and follow their operators’ policies. ZaherCyber does not send data to them automatically.',
              ),
              style: TextStyle(color: p.muted, fontSize: 9),
            ),
          ),
        ],
      ),
    );
  }

  Widget _panel(
    String id,
    IconData icon,
    String title,
    AppPalette p, {
    required Widget child,
    Widget? trailing,
  }) {
    return Container(
      key: ValueKey<String>('desktop-widget-$id'),
      margin: const EdgeInsets.fromLTRB(15, 5, 15, 8),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: p.border),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(17),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: p.accent, size: 19),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: TextStyle(
                      color: p.text,
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                    ),
                  ),
                ),
                if (trailing != null) trailing,
              ],
            ),
            const SizedBox(height: 8),
            child,
          ],
        ),
      ),
    );
  }

  Widget _emptySearch() => Padding(
    padding: const EdgeInsets.all(26),
    child: Center(
      child: Text(
        _t(
          'لا توجد تطبيقات مطابقة. امسح البحث أو غيّر مساحة العمل.',
          'No matching apps. Clear the search or change workspace.',
        ),
        textAlign: TextAlign.center,
      ),
    ),
  );
}
