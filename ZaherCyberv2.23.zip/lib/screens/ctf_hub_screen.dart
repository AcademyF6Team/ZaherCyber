import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/sources.dart';
import '../models/article.dart';
import '../services/feed_service.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../widgets/page_navigation_controls.dart';

class CtfHubScreen extends StatefulWidget {
  const CtfHubScreen({super.key});

  @override
  State<CtfHubScreen> createState() => _CtfHubScreenState();
}

class _CtfHubScreenState extends State<CtfHubScreen> {
  final FeedService _feeds = FeedService();
  final ScrollController _scrollController = ScrollController();
  List<Article> _events = const [];
  bool _loading = true;
  String? _error;
  Timer? _pollTimer;
  final Set<String> _knownEventLinks = {};

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  String _t(String ar, String en) => copy(context, ar, en);

  static const _labCommands = <Map<String, String>>[
    {
      'titleAr': 'بصمة ملف قبل تحليله',
      'titleEn': 'Hash a file before analysis',
      'command': 'sha256sum sample.bin',
      'purposeAr':
          'سجّل البصمة أولاً حتى تستطيع التحقق من أن الملف لم يتغير أثناء المختبر.',
      'purposeEn':
          'Record the hash first so you can verify that the sample did not change during the lab.',
    },
    {
      'titleAr': 'التعرف على نوع الملف',
      'titleEn': 'Identify a file type',
      'command': 'file sample.bin',
      'purposeAr': 'تحقق من النوع الفعلي للملف بدلاً من الاعتماد على امتداده.',
      'purposeEn':
          'Check the actual file type instead of trusting its filename extension.',
    },
    {
      'titleAr': 'استخراج النصوص الواضحة',
      'titleEn': 'Extract readable strings',
      'command': 'strings -n 8 sample.bin | less',
      'purposeAr':
          'استخرج النصوص الظاهرة من عينة CTF محلية للبحث عن تلميحات دون تشغيلها.',
      'purposeEn':
          'Extract readable text from a local CTF sample to look for clues without executing it.',
    },
    {
      'titleAr': 'البحث عن نمط العلم',
      'titleEn': 'Search for a flag pattern',
      'command': r'''grep -RIn --binary-files=text 'FLAG{' ./challenge''',
      'purposeAr':
          'ابحث داخل ملفات تحدٍّ محلية فقط عن نمط العلم الذي يحدده منظمو المسابقة.',
      'purposeEn':
          'Search only local challenge files for the flag pattern defined by the event organizers.',
    },
    {
      'titleAr': 'سجل الملفات الموجودة',
      'titleEn': 'Inventory local challenge files',
      'command': 'find ./challenge -type f -maxdepth 2 -print',
      'purposeAr': 'أنشئ جرداً للملفات داخل مجلد المختبر قبل بدء التحليل.',
      'purposeEn':
          'Inventory files inside the lab folder before beginning analysis.',
    },
    {
      'titleAr': 'فحص بيانات الصورة الوصفية',
      'titleEn': 'Inspect image metadata',
      'command': 'exiftool challenge.jpg',
      'purposeAr':
          'اعرض البيانات الوصفية لصورة محلية ضمن تحدي معلومات مخفية أو تحقيق رقمي.',
      'purposeEn':
          'Inspect metadata from a local image in a forensics or hidden-information challenge.',
    },
  ];

  @override
  void initState() {
    super.initState();
    _refresh();
    _pollTimer = Timer.periodic(
      const Duration(minutes: 15),
      (_) => _refresh(silent: true),
    );
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _scrollController.dispose();
    _feeds.dispose();
    super.dispose();
  }

  Future<void> _refresh({bool silent = false}) async {
    if (!silent) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final items = await _feeds.fetchAll(sources: [ctfSource]);
      if (!mounted) return;
      final incoming = items
          .map((item) => item.link)
          .where((link) => link.isNotEmpty)
          .toSet();
      final hasNew =
          _knownEventLinks.isNotEmpty &&
          incoming.difference(_knownEventLinks).isNotEmpty;
      _knownEventLinks.addAll(incoming);
      setState(() {
        _events = items;
        _loading = false;
        if (items.isEmpty)
          _error = _t(
            'لم يصل أي حدث من المصدر حالياً.',
            'The source returned no events right now.',
          );
      });
      if (silent && hasNew && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'أُعلنت فعالية CTF جديدة — افتح القائمة للتفاصيل.',
                'A new CTF event was announced — open the list for details.',
              ),
            ),
          ),
        );
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = _t(
          'تعذر تحديث فعاليات CTF. تحقق من الاتصال وحاول لاحقاً.',
          'Could not refresh CTF events. Check connectivity and try again.',
        );
      });
    }
  }

  Future<void> _open(String url) async {
    final uri = Uri.tryParse(url);
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _copy(String command) async {
    await Clipboard.setData(ClipboardData(text: command));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _t('تم نسخ الأمر للمختبر فقط', 'Copied for lab use only'),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _p.background,
      appBar: AppBar(
        title: Text(_t('مختبر CTF', 'CTF Lab')),
        backgroundColor: _p.background,
        foregroundColor: _p.text,
        leading: pageBackButton(context),
        actions: [
          pageHomeButton(context),
          IconButton(
            onPressed: _loading ? null : _refresh,
            tooltip: _t('تحديث الفعاليات', 'Refresh events'),
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(
          controller: _scrollController,
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
          children: [
            _introCard(),
            const SizedBox(height: 14),
            _sectionTitle(
              Icons.manage_search_outlined,
              _t('مسارات مهام تدريبية', 'Training challenge tracks'),
            ),
            const SizedBox(height: 8),
            _trackCard(
              icon: Icons.image_search_outlined,
              titleAr: 'Forensics — التحقيق وتحليل الملفات',
              titleEn: 'Forensics — file and evidence analysis',
              taskAr:
                  'المهمة: احسب بصمة العينة واقرأ ترويسة الملف وحدد ما إذا كان الامتداد يطابق المحتوى. استخدم نسخة من ملف التحدي، لا الملف الأصلي.',
              taskEn:
                  'Task: hash the sample, inspect its header, and compare the extension with its content. Use a copy of the challenge file, never the original.',
              code: '''from pathlib import Path
import hashlib

p = Path("sample.bin")
data = p.read_bytes()
print("bytes:", len(data))
print("sha256:", hashlib.sha256(data).hexdigest())
print("header:", data[:16].hex(" "))''',
            ),
            _trackCard(
              icon: Icons.account_tree_outlined,
              titleAr: 'Reverse Engineering — تحليل ساكن',
              titleEn: 'Reverse Engineering — static analysis',
              taskAr:
                  'المهمة: افهم تدفق دالة تدريبية صغيرة عبر bytecode دون تشغيل ملف مجهول. قارن التعليمات بالمخرجات المتوقعة ووثّق الفرضية.',
              taskEn:
                  'Task: understand a small training function through bytecode without executing an unknown file. Compare instructions with expected output and document the hypothesis.',
              code: '''import dis

def check_token(value):
    return value.strip().lower() == "training-flag"

dis.dis(check_token)''',
            ),
            const SizedBox(height: 14),
            _sectionTitle(
              Icons.event_available_outlined,
              _t('فعاليات حية من CTFtime', 'Live events from CTFtime'),
            ),
            const SizedBox(height: 8),
            if (_loading)
              const Padding(
                padding: EdgeInsets.all(28),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_error != null)
              _errorCard()
            else if (_events.isEmpty)
              _emptyCard()
            else
              ..._events.map(_eventCard),
            const SizedBox(height: 18),
            _sectionTitle(
              Icons.terminal_rounded,
              _t('أوامر مختبر قابلة للنسخ', 'Copyable lab commands'),
            ),
            const SizedBox(height: 8),
            _safetyCard(),
            const SizedBox(height: 8),
            ..._labCommands.map(_commandCard),
          ],
        ),
      ),
    );
  }

  Widget _introCard() => Card(
    color: _p.surface,
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.flag_circle_outlined, color: _p.accent, size: 30),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _t(
                'مساحة تعليمية للتحديات القانونية. الفعاليات تُجلب من CTFtime عبر الإنترنت، والأوامر أدناه للملفات المحلية داخل مختبرك فقط ولا ينفذها التطبيق.',
                'A legal learning space for challenges. Events are fetched from CTFtime, while the commands below target local lab files only and are never executed by the app.',
              ),
              style: TextStyle(color: _p.text, height: 1.55),
            ),
          ),
        ],
      ),
    ),
  );

  Widget _sectionTitle(IconData icon, String title) => Row(
    children: [
      Icon(icon, color: _p.accent),
      const SizedBox(width: 8),
      Expanded(
        child: Text(
          title,
          style: TextStyle(color: _p.text, fontWeight: FontWeight.w800),
        ),
      ),
    ],
  );

  Widget _eventCard(Article article) => Card(
    color: _p.surface,
    margin: const EdgeInsets.only(bottom: 8),
    child: ListTile(
      title: Text(
        article.title,
        style: TextStyle(color: _p.text, fontWeight: FontWeight.w700),
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 6),
        child: Text(
          article.summary,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: _p.muted, height: 1.4),
        ),
      ),
      trailing: Icon(Icons.open_in_new_rounded, color: _p.accent),
      onTap: () => _open(article.link),
    ),
  );

  Widget _trackCard({
    required IconData icon,
    required String titleAr,
    required String titleEn,
    required String taskAr,
    required String taskEn,
    required String code,
  }) => Card(
    color: _p.surface,
    margin: const EdgeInsets.only(bottom: 8),
    child: ExpansionTile(
      leading: Icon(icon, color: _p.accent),
      title: Text(
        _t(titleAr, titleEn),
        style: TextStyle(color: _p.text, fontWeight: FontWeight.w800),
      ),
      subtitle: Text(
        _t(taskAr, taskEn),
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(color: _p.muted, height: 1.35, fontSize: 11),
      ),
      childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      iconColor: _p.accent,
      collapsedIconColor: _p.muted,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _p.background,
            borderRadius: BorderRadius.circular(12),
          ),
          child: SelectableText(
            code,
            style: TextStyle(
              color: _p.accent,
              fontFamily: 'monospace',
              fontSize: 11,
              height: 1.45,
            ),
          ),
        ),
        Align(
          alignment: AlignmentDirectional.centerEnd,
          child: TextButton.icon(
            onPressed: () => _copy(code),
            icon: const Icon(Icons.copy_rounded, size: 17),
            label: Text(_t('نسخ الكود', 'Copy code')),
          ),
        ),
      ],
    ),
  );

  Widget _commandCard(Map<String, String> item) => Card(
    color: _p.surface,
    margin: const EdgeInsets.only(bottom: 8),
    child: Padding(
      padding: const EdgeInsets.all(13),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _t(item['titleAr']!, item['titleEn']!),
            style: TextStyle(color: _p.text, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          SelectableText(
            item['command']!,
            style: TextStyle(
              color: _p.accent,
              fontFamily: 'monospace',
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            _t(item['purposeAr']!, item['purposeEn']!),
            style: TextStyle(color: _p.muted, height: 1.4, fontSize: 12),
          ),
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: TextButton.icon(
              onPressed: () => _copy(item['command']!),
              icon: const Icon(Icons.copy_rounded, size: 17),
              label: Text(_t('نسخ', 'Copy')),
            ),
          ),
        ],
      ),
    ),
  );

  Widget _safetyCard() => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: _p.accent.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: _p.accent.withValues(alpha: .22)),
    ),
    child: Text(
      _t(
        'تنبيه: لا تشغّل هذه الأوامر على أهداف أو ملفات لا تملكها أو لا تملك تصريحاً لتحليلها. التطبيق ينسخ النص فقط ولا ينفذ أوامر على الهاتف أو الإنترنت.',
        'Safety: never run these commands against targets or files you do not own or lack permission to analyze. The app only copies text and never executes commands on the device or Internet.',
      ),
      style: TextStyle(color: _p.text, height: 1.45, fontSize: 12),
    ),
  );

  Widget _errorCard() => Card(
    color: _p.surface,
    child: ListTile(
      leading: Icon(Icons.cloud_off_rounded, color: _p.accent2),
      title: Text(_error!, style: TextStyle(color: _p.text)),
      trailing: IconButton(
        onPressed: _refresh,
        icon: Icon(Icons.refresh_rounded, color: _p.accent),
      ),
    ),
  );

  Widget _emptyCard() => Card(
    color: _p.surface,
    child: ListTile(
      leading: Icon(Icons.event_busy_outlined, color: _p.muted),
      title: Text(
        _t('لا توجد فعاليات حالياً', 'No events right now'),
        style: TextStyle(color: _p.text),
      ),
    ),
  );
}
