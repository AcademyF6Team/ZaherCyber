import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/learning_content.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../services/learning_progress_service.dart';
import '../widgets/page_navigation_controls.dart';

class LearningCenterScreen extends StatefulWidget {
  const LearningCenterScreen({super.key, this.initialLessonId});

  final String? initialLessonId;

  @override
  State<LearningCenterScreen> createState() => _LearningCenterScreenState();
}

class _LearningCenterScreenState extends State<LearningCenterScreen>
    with SingleTickerProviderStateMixin {
  static const _native = MethodChannel('com.zahercyber/native');
  final LearningProgressService _service = LearningProgressService();
  LearningProgress _progress = const LearningProgress();
  bool _loading = true;
  bool _busy = false;
  bool _initialLessonOpened = false;
  int _quizIndex = 0;
  int? _selectedOption;
  bool _answered = false;
  int _quizScore = 0;
  int _flashIndex = 0;
  bool _flipped = false;
  late final TabController _tabController;
  String? _loadError;

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  String _t(String ar, String en) => copy(context, ar, en);
  bool get _en => Localizations.localeOf(context).languageCode == 'en';
  String _level(String value) => _t(
    {
          'Beginner': 'مبتدئ',
          'Intermediate': 'متوسط',
          'Advanced': 'متقدم',
        }[value] ??
        value,
    value,
  );

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _load();
  }

  Future<void> _load() async {
    try {
      final value = await _service.load();
      if (!mounted) return;
      setState(() {
        _progress = value;
        _loading = false;
        _loadError = null;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _loadError = _t('تعذر قراءة التقدم المحلي؛ يمكنك متابعة المحتوى ثم المحاولة لاحقاً.', 'Local progress could not be read; you can still use the content and retry later.');
      });
    }
    final lessonId = widget.initialLessonId;
    if (lessonId != null && !_initialLessonOpened) {
      _initialLessonOpened = true;
      final matches = learningLessons.where((lesson) => lesson.id == lessonId);
      if (matches.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _showLesson(matches.first);
        });
      }
    }
  }

  Future<void> _complete(LearningLesson lesson) async {
    try {
      final value = await _service.completeLesson(lesson.id);
      if (mounted) setState(() { _progress = value; _loadError = null; });
    } catch (_) {
      if (mounted) setState(() => _loadError = _t('تعذر حفظ التقدم محلياً، لكن بقي الدرس مفتوحاً.', 'Progress could not be saved locally, but the lesson remains available.'));
    }
  }

  Future<void> _export() async {
    setState(() => _busy = true);
    try {
      final file = await _service.writeLocalBackup();
      await _native
          .invokeMethod<String>('saveToDownloads', {
            'path': file.path,
            'fileName': 'zahercyber-learning-backup.json',
            'mimeType': 'application/json',
          });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _t(
              'تم حفظ نسخة التقدم في Downloads/ZaherCyber',
              'Progress backup saved to Downloads/ZaherCyber',
            ),
          ),
        ),
      );
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'تعذر تصدير التقدم: $error',
                'Could not export progress: $error',
              ),
            ),
          ),
        );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _import() async {
    setState(() => _busy = true);
    try {
      final raw = await _native.invokeMethod<String>('pickLearningBackup');
      if (raw == null || raw.trim().isEmpty) return;
      await _service.importJson(raw);
      await _load();
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'تم دمج التقدم دون حذف التقدم الحالي',
                'Progress merged without deleting current progress',
              ),
            ),
          ),
        );
    } on PlatformException catch (error) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'تعذر استيراد النسخة: ${error.message}',
                'Could not import backup: ${error.message}',
              ),
            ),
          ),
        );
    } on FormatException {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'ملف النسخة غير صالح أو من إصدار غير مدعوم.',
                'The backup is invalid or unsupported.',
              ),
            ),
          ),
        );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _p.background,
      appBar: AppBar(
        title: Text(_t('مركز التعلم', 'Learning center')),
        backgroundColor: _p.background,
        foregroundColor: _p.text,
        leading: pageBackButton(context),
        actions: [
          pageHomeButton(context),
          if (_busy)
            const Padding(
              padding: EdgeInsets.all(14),
              child: SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          else ...[
            IconButton(
              onPressed: _export,
              tooltip: _t('تصدير التقدم', 'Export progress'),
              icon: const Icon(Icons.upload_file_outlined),
            ),
            IconButton(
              onPressed: _import,
              tooltip: _t('استيراد التقدم', 'Import progress'),
              icon: const Icon(Icons.file_open_outlined),
            ),
          ],
        ],
        bottom: TabBar(
          controller: _tabController,
          labelColor: _p.accent,
          unselectedLabelColor: _p.muted,
          indicatorColor: _p.accent,
          tabs: [
            Tab(
              icon: const Icon(Icons.route_outlined),
              text: _t('المسارات', 'Paths'),
            ),
            Tab(
              icon: const Icon(Icons.quiz_outlined),
              text: _t('اختبارات', 'Quizzes'),
            ),
            Tab(
              icon: const Icon(Icons.style_outlined),
              text: _t('بطاقات', 'Cards'),
            ),
          ],
        ),
      ),
      body: _loading
          ? Center(child: CircularProgressIndicator(color: _p.accent))
          : Column(
              children: [
                if (_loadError != null)
                  MaterialBanner(
                    content: Text(_loadError!),
                    leading: Icon(Icons.info_outline, color: _p.accent),
                    actions: [
                      TextButton(onPressed: _load, child: Text(_t('إعادة المحاولة', 'Retry'))),
                    ],
                  ),
                Expanded(child: TabBarView(controller: _tabController, children: [_pathsTab(), _quizTab(), _flashcardsTab()])),
              ],
            ),
    );
  }

  Widget _pathsTab() {
    final completed = _progress.completedLessons.length;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: [
        _heroCard(completed),
        const SizedBox(height: 12),
        ...learningPaths.map(_pathCard),
      ],
    );
  }

  Widget _heroCard(int completed) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      gradient: LinearGradient(colors: [_p.heroStart, _p.surface]),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: _p.accent.withValues(alpha: .24)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.auto_awesome_outlined, color: _p.accent),
            const SizedBox(width: 8),
            Text(
              _t('مساراتك المحلية', 'Your local learning paths'),
              style: TextStyle(
                color: _p.text,
                fontWeight: FontWeight.w900,
                fontSize: 16,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          _t(
            'تقدم محفوظ على جهازك: $completed درساً مكتملًا. الاستيراد يدمج البيانات ولا يمسحها.',
            'Progress stays on device: $completed completed lessons. Import merges data and never erases it.',
          ),
          style: TextStyle(color: _p.muted, height: 1.45, fontSize: 12),
        ),
      ],
    ),
  );

  Widget _pathCard(LearningPath path) {
    final done = _service.pathCompleted(path);
    final ratio = path.lessonIds.isEmpty ? 0.0 : done / path.lessonIds.length;
    return Card(
      color: _p.surface,
      margin: const EdgeInsets.only(bottom: 10),
      child: ExpansionTile(
        leading: Icon(Icons.route_rounded, color: _p.accent),
        title: Text(
          _en ? path.titleEn : path.titleAr,
          style: TextStyle(color: _p.text, fontWeight: FontWeight.w800),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(
              '${_level(path.level)} · $done/${path.lessonIds.length}',
              style: TextStyle(color: _p.muted, fontSize: 11),
            ),
            const SizedBox(height: 5),
            LinearProgressIndicator(
              value: ratio,
              minHeight: 4,
              color: _p.accent,
              backgroundColor: _p.border,
            ),
          ],
        ),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text(
              _en ? path.descriptionEn : path.descriptionAr,
              style: TextStyle(color: _p.muted, height: 1.4, fontSize: 12),
            ),
          ),
          ...path.lessonIds.map(
            (id) => _lessonTile(
              learningLessons.firstWhere((lesson) => lesson.id == id),
            ),
          ),
        ],
      ),
    );
  }

  Widget _lessonTile(LearningLesson lesson) {
    final done = _progress.completedLessons.contains(lesson.id);
    return ListTile(
      leading: Icon(
        done ? Icons.check_circle_rounded : Icons.play_circle_outline_rounded,
        color: done ? _p.accent : _p.muted,
      ),
      title: Text(
        _en ? lesson.titleEn : lesson.titleAr,
        style: TextStyle(
          color: _p.text,
          fontWeight: FontWeight.w700,
          fontSize: 13,
        ),
      ),
      subtitle: Text(
        _en ? lesson.summaryEn : lesson.summaryAr,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(color: _p.muted, fontSize: 11),
      ),
      trailing: Text(
        _level(lesson.level),
        style: TextStyle(
          color: _p.accent,
          fontSize: 9,
          fontWeight: FontWeight.w800,
        ),
      ),
      onTap: () => _showLesson(lesson),
    );
  }

  Future<void> _showLesson(LearningLesson lesson) async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: _p.surface,
        title: Text(
          _en ? lesson.titleEn : lesson.titleAr,
          style: TextStyle(color: _p.text, fontWeight: FontWeight.w900),
        ),
        content: SingleChildScrollView(
          child: Text(
            _en ? lesson.bodyEn : lesson.bodyAr,
            style: TextStyle(color: _p.muted, height: 1.55),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(_t('إغلاق', 'Close')),
          ),
          FilledButton.icon(
            onPressed: () async {
              await _complete(lesson);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            icon: const Icon(Icons.check),
            label: Text(_t('تمت القراءة', 'Mark complete')),
          ),
        ],
      ),
    );
  }

  Widget _quizTab() {
    final question = learningQuestions[_quizIndex];
    final options = _en ? question.optionsEn : question.optionsAr;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
      children: [
        Text(
          _t(
            'اختبار قصير · سؤال ${_quizIndex + 1} من ${learningQuestions.length}',
            'Short quiz · question ${_quizIndex + 1} of ${learningQuestions.length}',
          ),
          style: TextStyle(color: _p.accent, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 10),
        Card(
          color: _p.surface,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _en ? question.promptEn : question.promptAr,
                  style: TextStyle(
                    color: _p.text,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    height: 1.35,
                  ),
                ),
                const SizedBox(height: 12),
                RadioGroup<int>(
                  groupValue: _selectedOption,
                  onChanged: (value) {
                    if (_answered) return;
                    setState(() => _selectedOption = value);
                  },
                  child: Column(
                    children: List.generate(
                      options.length,
                      (index) => RadioListTile<int>(
                        value: index,
                        title: Text(
                          options[index],
                          style: TextStyle(color: _p.text, fontSize: 13),
                        ),
                        activeColor: _p.accent,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ),
                ),
                if (_answered) ...[
                  const Divider(),
                  Text(
                    _selectedOption == question.correctIndex
                        ? _t('إجابة صحيحة', 'Correct answer')
                        : _t(
                            'الإجابة الصحيحة: ${options[question.correctIndex]}',
                            'Correct answer: ${options[question.correctIndex]}',
                          ),
                    style: TextStyle(
                      color: _selectedOption == question.correctIndex
                          ? _p.accent
                          : _p.accent2,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    _en ? question.explanationEn : question.explanationAr,
                    style: TextStyle(color: _p.muted, height: 1.4),
                  ),
                ],
                const SizedBox(height: 8),
                Row(
                  children: [
                    Text(
                      '${_t('النتيجة الحالية', 'Current score')}: $_quizScore',
                      style: TextStyle(color: _p.muted, fontSize: 12),
                    ),
                    const Spacer(),
                    FilledButton(
                      onPressed: _answered
                          ? _nextQuestion
                          : (_selectedOption == null ? null : _answer),
                      child: Text(
                        _answered ? _t('التالي', 'Next') : _t('تحقق', 'Check'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _answer() async {
    final question = learningQuestions[_quizIndex];
    final correct = _selectedOption == question.correctIndex;
    if (correct) _quizScore++;
    await _service.recordQuiz(question.pathId, correct ? 1 : 0);
    if (mounted) setState(() => _answered = true);
  }

  void _nextQuestion() {
    setState(() {
      _quizIndex = (_quizIndex + 1) % learningQuestions.length;
      if (_quizIndex == 0) _quizScore = 0;
      _selectedOption = null;
      _answered = false;
    });
  }

  Widget _flashcardsTab() {
    final card = learningFlashcards[_flashIndex];
    final text = _flipped
        ? (_en ? card.backEn : card.backAr)
        : (_en ? card.frontEn : card.frontAr);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
      children: [
        Text(
          _t(
            'بطاقة ${_flashIndex + 1} من ${learningFlashcards.length}',
            'Card ${_flashIndex + 1} of ${learningFlashcards.length}',
          ),
          style: TextStyle(color: _p.accent, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 10),
        GestureDetector(
          onTap: () => setState(() => _flipped = !_flipped),
          child: Container(
            constraints: const BoxConstraints(minHeight: 230),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [_p.heroStart, _p.surface]),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: _p.accent.withValues(alpha: .3)),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  _flipped ? Icons.lightbulb_outline : Icons.help_outline,
                  size: 40,
                  color: _p.accent,
                ),
                const SizedBox(height: 18),
                Text(
                  text,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _p.text,
                    fontSize: 21,
                    height: 1.35,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  _t('اضغط لقلب البطاقة', 'Tap to flip'),
                  style: TextStyle(color: _p.muted, fontSize: 11),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Text(
          _t('كيف كانت المراجعة؟', 'How did you recall it?'),
          style: TextStyle(color: _p.text, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _rateCard(card, 0),
                icon: const Icon(Icons.replay_rounded),
                label: Text(_t('أراجعها', 'Review')),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.icon(
                onPressed: () => _rateCard(card, 2),
                icon: const Icon(Icons.check_rounded),
                label: Text(_t('أعرفها', 'Know it')),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Future<void> _rateCard(LearningFlashcard card, int rating) async {
    final value = await _service.rateCard(card.id, rating);
    if (!mounted) return;
    setState(() {
      _progress = value;
      _flashIndex = (_flashIndex + 1) % learningFlashcards.length;
      _flipped = false;
    });
  }
}
