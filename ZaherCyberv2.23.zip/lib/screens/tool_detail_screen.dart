import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/tool_project.dart';
import '../models/tool_release.dart';
import '../services/download_manager.dart';
import '../services/github_catalog_service.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../widgets/page_navigation_controls.dart';

class ToolDetailScreen extends StatefulWidget {
  final ToolProject project;
  final GitHubCatalogService catalog;
  final DownloadManagerService downloads;
  final VoidCallback onOpenDownloads;

  const ToolDetailScreen({
    super.key,
    required this.project,
    required this.catalog,
    required this.downloads,
    required this.onOpenDownloads,
  });

  @override
  State<ToolDetailScreen> createState() => _ToolDetailScreenState();
}

class _ToolDetailScreenState extends State<ToolDetailScreen> {
  ToolRelease? _release;
  String? _license;
  String? _fdroidVersion;
  bool _loading = true;
  String? _selectedPlatform;
  String? _error;
  bool _showNotes = false;

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;

  @override
  void initState() {
    super.initState();
    _selectedPlatform = widget.project.platforms.contains('android')
        ? 'android'
        : (widget.project.platforms.contains('windows')
              ? 'windows'
              : widget.project.platforms.firstOrNull);
    _load();
  }

  Future<void> _load({bool force = false}) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait<Object?>([
        widget.catalog.latestRelease(widget.project, force: force),
        widget.catalog.repositoryLicense(widget.project),
        if (widget.project.fdroidPackageId != null)
          widget.catalog.fdroidSuggestedVersion(
            widget.project.fdroidPackageId!,
          ),
      ]);
      if (!mounted) return;
      setState(() {
        _release = results[0] as ToolRelease?;
        _license = results[1] as String?;
        if (widget.project.fdroidPackageId != null)
          _fdroidVersion = results[2] as String?;
        _loading = false;
      });
    } catch (error) {
      if (mounted)
        setState(() {
          _loading = false;
          _error = error.toString();
        });
    }
  }

  List<ReleaseAsset> get _filteredAssets {
    final platform = _selectedPlatform ?? 'windows';
    return (_release?.assets ?? const <ReleaseAsset>[]).where((asset) {
      final name = asset.name.toLowerCase();
      if (platform == 'android') return name.endsWith('.apk');
      if (platform == 'windows') {
        if (name.endsWith('.exe') ||
            name.endsWith('.msi') ||
            name.endsWith('.msixbundle') ||
            name.endsWith('.7z'))
          return true;
        if (!name.endsWith('.zip')) return false;
        return !RegExp(r'linux|darwin|macos|\.src|source[-_]').hasMatch(name);
      }
      if (platform == 'linux') {
        return name.endsWith('.deb') ||
            name.endsWith('.rpm') ||
            name.endsWith('.appimage') ||
            name.endsWith('.flatpak') ||
            name.endsWith('.tar.gz') ||
            name.endsWith('.tgz') ||
            (name.endsWith('.zip') &&
                RegExp(r'linux|unix|amd64|x86_64').hasMatch(name));
      }
      return false;
    }).toList();
  }

  String _platformName(String id) => switch (id) {
    'android' => copy(context, 'Android', 'Android'),
    'windows' => copy(context, 'Windows', 'Windows'),
    'linux' => copy(context, 'Linux', 'Linux'),
    _ => id,
  };

  Future<void> _open(String url) async {
    final uri = Uri.tryParse(url);
    if (uri != null && uri.scheme == 'https')
      await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _download(ReleaseAsset asset) async {
    try {
      await widget.downloads.startDownload(
        projectId: widget.project.id,
        projectName: widget.project.name,
        fileName: asset.name,
        url: asset.url,
        expectedSha256: asset.sha256,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            copy(
              context,
              'بدأ التنزيل أو اكتمل. راقب التقدم من مدير التنزيلات.',
              'Download started or completed. Track it in Downloads.',
            ),
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${copy(context, 'تعذر بدء التنزيل:', 'Could not start download:')} $error',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = (String ar, String en) => copy(context, ar, en);
    final project = widget.project;
    final p = _p;
    final desc = Localizations.localeOf(context).languageCode == 'en'
        ? project.descriptionEn
        : project.descriptionAr;
    final platforms = project.platforms.toList();
    return Directionality(
      textDirection: appTextDirection(context),
      child: Scaffold(
        backgroundColor: p.background,
        appBar: AppBar(
          leading: pageBackButton(context),
          title: Text(
            project.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          actions: [
            pageHomeButton(context),
            IconButton(
              onPressed: () => _load(force: true),
              tooltip: t('تحديث بيانات الإصدار', 'Refresh release data'),
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [p.heroStart, p.surface]),
                borderRadius: BorderRadius.circular(23),
                border: Border.all(color: p.accent.withValues(alpha: .25)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.shield_outlined, color: p.accent, size: 27),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          project.name,
                          style: TextStyle(
                            color: p.text,
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      if (project.discovered)
                        _tag(t('اكتُشف حديثاً', 'Discovered'), p.accent2),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    desc,
                    style: TextStyle(
                      color: p.muted,
                      height: 1.55,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: [
                      for (final platform in platforms)
                        _tag(_platformName(platform), p.accent),
                      _tag(project.category, p.accent2),
                      if ((_license ?? project.licenseHint) != null)
                        _tag(
                          'SPDX: ${_license ?? project.licenseHint}',
                          p.muted,
                        ),
                      if (project.difficulty != null)
                        _tag(
                          t(
                            'الصعوبة: ${project.difficulty == 'advanced'
                                ? 'متقدم'
                                : project.difficulty == 'intermediate'
                                ? 'متوسط'
                                : 'مبتدئ'}',
                            'Difficulty: ${project.difficulty}',
                          ),
                          p.muted,
                        ),
                      if (project.repositoryStatus == 'not_archived')
                        _tag(
                          t(
                            'المستودع غير مؤرشف عند الفحص',
                            'Repository not archived when checked',
                          ),
                          p.muted,
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                color: p.accent2.withValues(alpha: .08),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: p.accent2.withValues(alpha: .22)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.verified_user_outlined,
                    color: p.accent2,
                    size: 19,
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      t(
                        'قبل التنزيل: تحقق من المستودع والإصدار والمنصة والترخيص. قارن SHA-256 ببصمة الناشر إذا نشرها؛ البصمة المحسوبة محلياً وحدها لا تثبت هوية الناشر. التطبيق لا يختبر الأداة نيابةً عنك.',
                        'Before downloading: verify the repository, release, platform, and license. Compare SHA-256 with a publisher-provided value when available; a locally computed hash alone does not authenticate the publisher. The app does not test the tool for you.',
                      ),
                      style: TextStyle(
                        color: p.muted,
                        fontSize: 10,
                        height: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Text(
                    t('الإصدار الرسمي الأحدث', 'Latest official release'),
                    style: TextStyle(
                      color: p.text,
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                if (_loading)
                  SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: p.accent,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 10),
            if (_release != null) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: p.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            _release!.title.isEmpty
                                ? _release!.tag
                                : _release!.title,
                            style: TextStyle(
                              color: p.text,
                              fontWeight: FontWeight.w800,
                              fontSize: 15,
                            ),
                          ),
                        ),
                        _tag(_release!.tag, p.accent),
                      ],
                    ),
                    if (_release!.publishedAt != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(
                          '${t('نُشر:', 'Published:')} ${_release!.publishedAt!.toLocal().toString().substring(0, 10)}${_release!.cached ? ' · ${t('من الذاكرة المؤقتة', 'cached')}' : ''}',
                          style: TextStyle(color: p.muted, fontSize: 11),
                        ),
                      ),
                    if (_release!.notes.trim().isNotEmpty) ...[
                      const SizedBox(height: 12),
                      InkWell(
                        onTap: () => setState(() => _showNotes = !_showNotes),
                        child: Row(
                          children: [
                            Icon(
                              Icons.notes_rounded,
                              color: p.accent,
                              size: 18,
                            ),
                            const SizedBox(width: 7),
                            Text(
                              _showNotes
                                  ? t(
                                      'إخفاء ملاحظات الإصدار',
                                      'Hide release notes',
                                    )
                                  : t(
                                      'عرض ملاحظات الإصدار',
                                      'Show release notes',
                                    ),
                              style: TextStyle(
                                color: p.accent,
                                fontWeight: FontWeight.w700,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (_showNotes)
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: SelectableText(
                            _release!.notes.length > 2500
                                ? '${_release!.notes.substring(0, 2500)}…'
                                : _release!.notes,
                            style: TextStyle(
                              color: p.muted,
                              height: 1.5,
                              fontSize: 11,
                            ),
                          ),
                        ),
                    ],
                  ],
                ),
              ),
            ] else if (_error != null || !_loading) ...[
              Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  t(
                    'لم يتوفر إصدار GitHub آلي لهذه الأداة الآن. استخدم صفحة المصدر الرسمية للتحقق من النسخة.',
                    'No GitHub release metadata is available right now. Use the official source page to confirm the current version.',
                  ),
                  style: TextStyle(color: p.muted, height: 1.5, fontSize: 12),
                ),
              ),
            ],
            if (project.fdroidPackageId != null) ...[
              const SizedBox(height: 12),
              FutureBuilder<String?>(
                future: widget.catalog.fdroidSuggestedVersion(
                  project.fdroidPackageId!,
                ),
                builder: (context, snapshot) => Text(
                  '${t('معلومات عرض F-Droid:', 'F-Droid display metadata:')} ${snapshot.data ?? _fdroidVersion ?? t('استخدم صفحة المصدر', 'open source page')}',
                  style: TextStyle(color: p.muted, fontSize: 11),
                ),
              ),
            ],
            const SizedBox(height: 21),
            Text(
              t('التنزيلات المتاحة', 'Available downloads'),
              style: TextStyle(
                color: p.text,
                fontSize: 17,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            if (platforms.length > 1)
              Wrap(
                spacing: 8,
                children: [
                  for (final platform in platforms)
                    ChoiceChip(
                      label: Text(_platformName(platform)),
                      selected: _selectedPlatform == platform,
                      onSelected: (_) =>
                          setState(() => _selectedPlatform = platform),
                    ),
                ],
              ),
            const SizedBox(height: 6),
            if (_filteredAssets.isEmpty)
              Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      t(
                        'لا توجد حزمة تنزيل مباشرة لهذا النظام في الإصدار الحالي.',
                        'This release has no direct downloadable package for the selected platform.',
                      ),
                      style: TextStyle(
                        color: p.muted,
                        height: 1.5,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      t(
                        'يمكنك فتح المصدر الرسمي لمراجعة طريقة التثبيت، ومنها F-Droid للتطبيقات المتوافقة.',
                        'Open the official source for installation instructions, including F-Droid for compatible apps.',
                      ),
                      style: TextStyle(
                        color: p.muted,
                        height: 1.5,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              )
            else ...[
              for (final asset in _filteredAssets) _assetCard(asset),
            ],
            const SizedBox(height: 10),
            FilledButton.icon(
              onPressed: () => _open(_release?.releaseUrl ?? project.sourceUrl),
              icon: const Icon(Icons.open_in_new_rounded),
              label: Text(t('صفحة الإصدار الرسمية', 'Official release page')),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => _open(project.sourceUrl),
              icon: const Icon(Icons.public_rounded),
              label: Text(
                t('موقع / مستودع المشروع', 'Project website / repository'),
              ),
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: p.accent2.withValues(alpha: .08),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: p.accent2.withValues(alpha: .25)),
              ),
              child: Text(
                t(
                  'نزّل من النطاق الرسمي فقط وتحقق من المنصة والمعمارية والتوقيع. عند تثبيت APK سيعرض Android إذن المصادر غير المعروفة وشاشة تأكيد النظام؛ التطبيق لا يثبت بصمت. أدوات الاختبار تستخدم فقط ضمن صلاحية مكتوبة.',
                  'Download only from official project domains and check platform, architecture and signatures. Installing an APK requires Android permission and confirmation; ZaherCyber never installs silently. Use security tools only with written authorization.',
                ),
                style: TextStyle(color: p.muted, height: 1.55, fontSize: 11),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _assetCard(ReleaseAsset asset) {
    final p = _p;
    final t = (String ar, String en) => copy(context, ar, en);
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Icon(Icons.archive_outlined, color: p.accent, size: 21),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  asset.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: p.text,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${_bytes(asset.size)} · ${asset.sha256 == null ? t('بصمة الملف غير مرفقة من المصدر', 'No publisher SHA-256 supplied') : 'SHA-256 ${asset.sha256!.substring(0, asset.sha256!.length > 12 ? 12 : asset.sha256!.length)}…'}',
                  style: TextStyle(color: p.muted, fontSize: 9),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filledTonal(
            onPressed: () => _download(asset),
            tooltip: t('تنزيل والتحقق من الملف', 'Download and verify'),
            icon: const Icon(Icons.download_rounded),
          ),
        ],
      ),
    );
  }

  Widget _tag(String label, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
    decoration: BoxDecoration(
      color: color.withValues(alpha: .1),
      borderRadius: BorderRadius.circular(30),
    ),
    child: Text(
      label,
      style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 10),
    ),
  );

  String _bytes(int size) {
    if (size < 1024) return '$size B';
    if (size < 1024 * 1024) return '${(size / 1024).toStringAsFixed(1)} KB';
    if (size < 1024 * 1024 * 1024)
      return '${(size / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(size / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }
}

extension _LastOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
