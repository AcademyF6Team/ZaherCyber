import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/article.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../widgets/page_navigation_controls.dart';

class ArticleDetailScreen extends StatelessWidget {
  final Article article;
  final bool isSaved;
  final ValueChanged<Article> onToggleSaved;

  const ArticleDetailScreen({
    super.key,
    required this.article,
    required this.isSaved,
    required this.onToggleSaved,
  });

  Future<void> _openSource() async {
    final uri = Uri.tryParse(article.link);
    if (uri != null && uri.scheme == 'https') {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _share() =>
      const MethodChannel('com.zahercyber/native').invokeMethod<void>(
        'shareText',
        {'title': article.title, 'text': '${article.title}\n${article.link}'},
      );

  @override
  Widget build(BuildContext context) {
    final t = (String ar, String en) => copy(context, ar, en);
    final palette = Theme.of(context).extension<AppPalette>()!;
    final timestamp = article.publishedAt?.toLocal().toString();
    return Directionality(
      textDirection: appTextDirection(context),
      child: Scaffold(
        backgroundColor: palette.background,
        appBar: AppBar(
          title: Text(t('تفاصيل الخبر', 'Story details')),
          leading: pageBackButton(context),
          actions: [
            pageHomeButton(context),
            IconButton(
              onPressed: () => onToggleSaved(article),
              tooltip: t('حفظ الخبر', 'Save story'),
              icon: Icon(
                isSaved
                    ? Icons.bookmark_rounded
                    : Icons.bookmark_border_rounded,
                color: palette.accent,
              ),
            ),
            IconButton(
              onPressed: _share,
              tooltip: t('مشاركة', 'Share'),
              icon: const Icon(Icons.share_outlined),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 30),
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _tag(article.source, palette.accent),
                _tag(article.category, palette.accent2),
                _tag(article.language.toUpperCase(), palette.muted),
              ],
            ),
            const SizedBox(height: 18),
            Text(
              article.title,
              style: TextStyle(
                color: palette.text,
                fontSize: 25,
                height: 1.35,
                fontWeight: FontWeight.w900,
              ),
            ),
            if (timestamp != null) ...[
              const SizedBox(height: 10),
              Text(
                timestamp.length > 16 ? timestamp.substring(0, 16) : timestamp,
                style: TextStyle(color: palette.muted, fontSize: 12),
              ),
            ],
            const SizedBox(height: 22),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: palette.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: palette.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.format_quote_rounded, color: palette.accent),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          t('النص المتاح من الناشر', 'Publisher-provided text'),
                          style: TextStyle(
                            color: palette.accent,
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SelectableText(
                    article.summary.isEmpty ? article.title : article.summary,
                    style: TextStyle(
                      color: palette.text,
                      height: 1.75,
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    t(
                      'يعرض التطبيق النص الذي يتيحه موجز الناشر، وقد يكون مقتطفاً لا المقال كاملاً. استخدم الرابط الرسمي لقراءة النص الكامل.',
                      'The app displays the text supplied in the publisher feed, which may be an excerpt rather than the full article. Use the official link for the complete text.',
                    ),
                    style: TextStyle(
                      color: palette.muted,
                      height: 1.5,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: _openSource,
              icon: const Icon(Icons.open_in_new_rounded),
              label: Text(
                t(
                  'قراءة الخبر في المصدر الأصلي',
                  'Read full story at the source',
                ),
              ),
            ),
            const SizedBox(height: 12),
            SelectableText(
              article.link,
              textAlign: TextAlign.center,
              style: TextStyle(color: palette.muted, fontSize: 10),
            ),
            const SizedBox(height: 28),
            Text(
              t(
                'تنبيه: ZaherCyber يعرض موجزات ناشرين مستقلين؛ تبقى حقوق المحتوى للمصدر الأصلي.',
                'Note: ZaherCyber displays feeds from independent publishers; article rights remain with the original source.',
              ),
              textAlign: TextAlign.center,
              style: TextStyle(color: palette.muted, fontSize: 10, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tag(String text, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
    decoration: BoxDecoration(
      color: color.withValues(alpha: .10),
      borderRadius: BorderRadius.circular(30),
    ),
    child: Text(
      text,
      style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700),
    ),
  );
}
