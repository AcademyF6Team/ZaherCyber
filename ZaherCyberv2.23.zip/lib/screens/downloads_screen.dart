import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/download_manager.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';

class DownloadsScreen extends StatefulWidget {
  static const MethodChannel _native = MethodChannel('com.zahercyber/native');
  final DownloadManagerService downloads;
  const DownloadsScreen({super.key, required this.downloads});

  @override
  State<DownloadsScreen> createState() => _DownloadsScreenState();
}

class _DownloadsScreenState extends State<DownloadsScreen> {
  String _statusFilter = 'all';
  DownloadManagerService get downloads => widget.downloads;

  @override
  Widget build(BuildContext context) {
    final p = Theme.of(context).extension<AppPalette>()!;
    final t = (String ar, String en) => copy(context, ar, en);
    return Directionality(
      textDirection: appTextDirection(context),
      child: AnimatedBuilder(
        animation: downloads,
        builder: (context, _) {
          final allJobs = downloads.jobs;
          final jobs = allJobs.where((job) {
            if (_statusFilter == 'all') return true;
            if (_statusFilter == 'stopped') {
              return !const {
                'downloading',
                'completed',
                'failed',
              }.contains(job.status);
            }
            return job.status == _statusFilter;
          }).toList();
          final filters = <(String, String, String)>[
            ('all', 'الكل', 'All'),
            ('downloading', 'جارٍ', 'Downloading'),
            ('completed', 'مكتمل', 'Complete'),
            ('failed', 'فاشل', 'Failed'),
            ('stopped', 'متوقف', 'Stopped'),
          ];
          return CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 23, 20, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        t('مدير التنزيلات', 'Download manager'),
                        style: TextStyle(
                          color: p.text,
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        t(
                          'ملفات الإصدارات الرسمية · ${jobs.length} عنصر',
                          '${allJobs.length} official release file(s)',
                        ),
                        style: TextStyle(color: p.muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: p.accent2.withValues(alpha: .08),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: p.accent2.withValues(alpha: .2),
                      ),
                    ),
                    child: Text(
                      t(
                        'تُحفظ الملفات في Downloads/ZaherCyber. في Android 9 وأقدم سيطلب التطبيق إذن التخزين قبل النسخ؛ وفي Android 10 فأحدث يستخدم مساحة التنزيلات النظامية دون إذن تخزين عام. ملفات Windows تُحفظ على الهاتف فقط ولا تعمل على Android.',
                        'Files are saved in Downloads/ZaherCyber. Android 9 and earlier asks for storage permission before copying; Android 10+ uses the system Downloads collection without broad storage access. Windows files are stored on the phone but cannot run on Android.',
                      ),
                      style: TextStyle(
                        color: p.muted,
                        height: 1.5,
                        fontSize: 11,
                      ),
                    ),
                  ),
                ),
              ),
              if (allJobs.isNotEmpty)
                SliverToBoxAdapter(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsetsDirectional.fromSTEB(14, 0, 14, 8),
                    child: Row(
                      children: [
                        for (final item in filters)
                          Padding(
                            padding: const EdgeInsetsDirectional.only(end: 6),
                            child: ChoiceChip(
                              label: Text(
                                item.$3 == 'All' ||
                                        Localizations.localeOf(context)
                                                .languageCode !=
                                            'en'
                                    ? item.$2
                                    : item.$3,
                              ),
                              selected: _statusFilter == item.$1,
                              onSelected: (_) =>
                                  setState(() => _statusFilter = item.$1),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              if (allJobs.isEmpty)
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.download_for_offline_outlined,
                            color: p.accent.withValues(alpha: .65),
                            size: 54,
                          ),
                          const SizedBox(height: 12),
                          Text(
                            t('لا توجد تنزيلات بعد', 'No downloads yet'),
                            style: TextStyle(
                              color: p.text,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            t(
                              'افتح الترسانة واختر إصداراً رسمياً للتنزيل.',
                              'Choose an official release in the Arsenal to download it.',
                            ),
                            textAlign: TextAlign.center,
                            style: TextStyle(color: p.muted, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else if (jobs.isEmpty)
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Center(
                    child: Text(
                      t(
                        'لا توجد تنزيلات بهذه الحالة.',
                        'No downloads in this status.',
                      ),
                      style: TextStyle(color: p.muted),
                    ),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(14, 3, 14, 28),
                  sliver: SliverList.builder(
                    itemCount: jobs.length,
                    itemBuilder: (context, index) =>
                        _jobCard(context, jobs[index], p),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  Widget _jobCard(BuildContext context, ManagedDownload job, AppPalette p) {
    final t = (String ar, String en) => copy(context, ar, en);
    final isRunning = job.status == 'downloading';
    final progress = job.total > 0
        ? (job.received / job.total).clamp(0.0, 1.0).toDouble()
        : null;
    final status = switch (job.status) {
      'downloading' => t('جارٍ التنزيل', 'Downloading'),
      'completed' => t('اكتمل', 'Complete'),
      'failed' => t('فشل', 'Failed'),
      'cancelled' => t('أُلغي', 'Cancelled'),
      'interrupted' => t('متوقف — أعد المحاولة', 'Interrupted — retry'),
      _ => job.status,
    };
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: job.status == 'failed'
              ? p.accent2.withValues(alpha: .45)
              : p.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 39,
                height: 39,
                decoration: BoxDecoration(
                  color: p.accent.withValues(alpha: .1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  job.fileName.toLowerCase().endsWith('.apk')
                      ? Icons.android
                      : Icons.insert_drive_file_outlined,
                  color: p.accent,
                  size: 20,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      job.fileName,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: p.text,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      job.projectName,
                      style: TextStyle(color: p.muted, fontSize: 10),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () => downloads.delete(job),
                tooltip: t('حذف من القائمة', 'Remove'),
                icon: Icon(Icons.delete_outline, color: p.muted, size: 19),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (isRunning)
            LinearProgressIndicator(
              value: progress,
              minHeight: 5,
              borderRadius: BorderRadius.circular(20),
              color: p.accent,
              backgroundColor: p.raised,
            ),
          if (isRunning) ...[
            const SizedBox(height: 6),
            Text(
              '${_size(job.received)}${job.total > 0 ? ' / ${_size(job.total)}' : ''}',
              style: TextStyle(color: p.muted, fontSize: 10),
            ),
          ],
          const SizedBox(height: 7),
          Row(
            children: [
              Icon(
                job.status == 'completed'
                    ? Icons.check_circle_outline
                    : (job.status == 'failed'
                          ? Icons.error_outline
                          : Icons.downloading_rounded),
                size: 15,
                color: job.status == 'completed'
                    ? p.accent
                    : (job.status == 'failed' ? p.accent2 : p.muted),
              ),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  status,
                  style: TextStyle(
                    color: job.status == 'failed' ? p.accent2 : p.muted,
                    fontSize: 10,
                  ),
                ),
              ),
              if (job.status == 'completed')
                Text(
                  job.expectedSha256 == null
                      ? t(
                          'SHA-256 غير متاح من الناشر',
                          'Publisher SHA-256 unavailable',
                        )
                      : t('تم التحقق من SHA-256', 'SHA-256 verified'),
                  style: TextStyle(color: p.accent, fontSize: 9),
                ),
            ],
          ),
          if (job.publicLocation != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                t(
                  'حُفظت نسخة في مجلد التنزيلات العام.',
                  'A copy was saved to public Downloads.',
                ),
                style: TextStyle(color: p.muted, fontSize: 9),
              ),
            ),
          if (job.error != null)
            Padding(
              padding: const EdgeInsets.only(top: 5),
              child: Text(
                job.error!,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: p.accent2, fontSize: 10),
              ),
            ),
          if (isRunning ||
              job.status == 'completed' ||
              job.status == 'failed' ||
              job.status == 'interrupted' ||
              job.status == 'cancelled') ...[
            const SizedBox(height: 6),
            Wrap(
              alignment: WrapAlignment.end,
              spacing: 2,
              children: [
                if (isRunning)
                  IconButton(
                    onPressed: () => downloads.cancel(job.id),
                    tooltip: t('إلغاء التنزيل', 'Cancel download'),
                    icon: Icon(Icons.cancel_outlined, color: p.accent2),
                  ),
                if (job.status == 'failed' ||
                    job.status == 'interrupted' ||
                    job.status == 'cancelled')
                  IconButton(
                    onPressed: () => downloads.restart(job),
                    tooltip: t('إعادة المحاولة', 'Retry'),
                    icon: Icon(Icons.refresh_rounded, color: p.accent),
                  ),
                if (job.status == 'completed') ...[
                  if (job.fileName.toLowerCase().endsWith('.apk'))
                    IconButton.filledTonal(
                      onPressed: () => _install(context, job, p),
                      tooltip: t('فتح مثبت Android', 'Open Android installer'),
                      icon: const Icon(Icons.install_mobile_outlined),
                    ),
                  IconButton(
                    onPressed: () => _share(context, job),
                    tooltip: t('مشاركة الملف', 'Share file'),
                    icon: Icon(Icons.share_outlined, color: p.accent),
                  ),
                ],
              ],
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _install(
    BuildContext context,
    ManagedDownload job,
    AppPalette p,
  ) async {
    try {
      final result = await downloads.installApk(job);
      if (!context.mounted) return;
      final text = result == 'permission_required'
          ? copy(
              context,
              'فعّل إذن تثبيت التطبيقات لهذا التطبيق في شاشة Android التي فُتحت، ثم ارجع واضغط تثبيت مرة أخرى.',
              'Allow installs from this app in the Android settings screen, return, then tap install again.',
            )
          : (result == 'installer_opened'
                ? copy(
                    context,
                    'تم فتح مثبت Android؛ راجع اسم التطبيق والصلاحيات قبل الموافقة.',
                    'Android installer opened. Review the app name and permissions before confirming.',
                  )
                : copy(
                    context,
                    'تعذر فتح مثبت Android.',
                    'Could not open Android installer.',
                  ));
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(text),
          backgroundColor: p.raised,
          duration: const Duration(seconds: 6),
        ),
      );
    } catch (error) {
      if (context.mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '${copy(context, 'تعذر التثبيت:', 'Install unavailable:')} $error',
            ),
          ),
        );
    }
  }

  Future<void> _share(BuildContext context, ManagedDownload job) async {
    try {
      await DownloadsScreen._native.invokeMethod<void>('shareFile', {
        'path': job.localPath,
        'fileName': job.fileName,
        'mimeType': _mimeType(job.fileName),
      });
    } catch (error) {
      if (context.mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '${copy(context, 'تعذرت مشاركة الملف:', 'Could not share file:')} $error',
            ),
          ),
        );
    }
  }

  String _mimeType(String name) {
    final lower = name.toLowerCase();
    if (lower.endsWith('.apk'))
      return 'application/vnd.android.package-archive';
    if (lower.endsWith('.exe'))
      return 'application/vnd.microsoft.portable-executable';
    if (lower.endsWith('.msi')) return 'application/x-msi';
    if (lower.endsWith('.zip')) return 'application/zip';
    if (lower.endsWith('.7z')) return 'application/x-7z-compressed';
    return 'application/octet-stream';
  }

  String _size(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024)
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }
}
