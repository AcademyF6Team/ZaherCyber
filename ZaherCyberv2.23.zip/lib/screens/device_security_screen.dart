import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../widgets/page_navigation_controls.dart';

class DeviceSecurityScreen extends StatefulWidget {
  const DeviceSecurityScreen({super.key});

  @override
  State<DeviceSecurityScreen> createState() => _DeviceSecurityScreenState();
}

class _DeviceSecurityScreenState extends State<DeviceSecurityScreen> {
  static const _channel = MethodChannel('com.zahercyber/native');
  Map<String, dynamic> _snapshot = const {};
  bool _loading = true;
  String? _error;

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  String _t(String ar, String en) => copy(context, ar, en);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'deviceSecuritySnapshot',
      );
      if (!mounted) return;
      setState(() {
        _snapshot = (result ?? const {}).map(
          (key, value) => MapEntry(key.toString(), value),
        );
        _loading = false;
      });
    } on PlatformException catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error =
            error.message ??
            _t(
              'تعذر قراءة معلومات الجهاز.',
              'Could not read device information.',
            );
      });
    }
  }

  String _value(String key, [String fallback = '—']) =>
      _snapshot[key]?.toString() ?? fallback;
  bool _flag(String key) =>
      _snapshot[key] == true || _snapshot[key]?.toString() == 'true';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _p.background,
      appBar: AppBar(
        title: Text(_t('فحص أمان الجهاز', 'Device security check')),
        backgroundColor: _p.background,
        foregroundColor: _p.text,
        leading: pageBackButton(context),
        actions: [
          pageHomeButton(context),
          IconButton(
            onPressed: _loading ? null : _load,
            tooltip: _t('تحديث الفحص', 'Refresh check'),
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          _notice(),
          const SizedBox(height: 14),
          if (_loading)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(28),
                child: CircularProgressIndicator(),
              ),
            )
          else if (_error != null)
            _errorCard()
          else ...[
            _statusCard(),
            const SizedBox(height: 10),
            _check(
              'Android API / release',
              '${_value('sdk')} · ${_value('release')}',
              true,
            ),
            _check(
              _t('تحديث أمان النظام', 'Security patch'),
              _value('securityPatch'),
              _snapshot['securityPatch'] != null,
            ),
            _check(
              _t('وضع المطور', 'Developer options'),
              _flag('developerMode')
                  ? _t(
                      'مفعّل — راجعه إذا لم تكن تحتاجه',
                      'Enabled — review if not needed',
                    )
                  : _t('غير مفعّل', 'Disabled'),
              !_flag('developerMode'),
            ),
            _check(
              _t('تثبيت تطبيقات غير معروفة', 'Install unknown apps'),
              _flag('canRequestPackageInstalls')
                  ? _t('السماح موجود لهذا التطبيق', 'Allowed for this app')
                  : _t('غير مسموح', 'Not allowed'),
              !_flag('canRequestPackageInstalls'),
            ),
            _check(
              _t('نطاق التخزين', 'Storage scope'),
              _flag('scopedStorage')
                  ? _t('MediaStore / نطاق محمي', 'Scoped MediaStore')
                  : _t('تخزين قديم', 'Legacy storage'),
              _flag('scopedStorage'),
            ),
            _check(
              _t('نسخة التطبيق', 'App build'),
              _flag('debuggable')
                  ? _t(
                      'Debug — لا تستخدمها للإنتاج',
                      'Debug — do not use for production',
                    )
                  : _t('Release build', 'Release build'),
              !_flag('debuggable'),
            ),
          ],
          const SizedBox(height: 14),
          Text(
            _t('حدود الفحص', 'Check limits'),
            style: TextStyle(
              color: _p.text,
              fontWeight: FontWeight.w900,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            _t(
              'هذه مؤشرات محلية آمنة وليست شهادة بأن الجهاز خالٍ من البرمجيات الخبيثة. لا يقرأ التطبيق ملفاتك، ولا يفحص التطبيقات الأخرى، ولا يحاول اكتشاف صلاحيات root أو تجاوز حماية النظام. استخدم Google Play Protect وتحديثات الشركة المصنّعة عند الحاجة.',
              'These are safe local indicators, not proof that the device is malware-free. The app does not read your files, inspect other apps, or attempt root detection or bypasses. Use Google Play Protect and the manufacturer’s updates when needed.',
            ),
            style: TextStyle(color: _p.muted, height: 1.5, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _notice() => Card(
    color: _p.surface,
    child: Padding(
      padding: const EdgeInsets.all(15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.shield_outlined, color: _p.accent, size: 28),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _t(
                'فحص محلي للتهيئة والخصائص الأمنية فقط؛ لا يرفع البيانات ولا ينفذ تغييرات.',
                'Local configuration and security-property checks only; no data upload and no changes are made.',
              ),
              style: TextStyle(color: _p.text, height: 1.45),
            ),
          ),
        ],
      ),
    ),
  );

  Widget _statusCard() => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      gradient: LinearGradient(colors: [_p.heroStart, _p.surface]),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: _p.accent.withValues(alpha: .25)),
    ),
    child: Row(
      children: [
        Icon(Icons.monitor_heart_outlined, color: _p.accent, size: 30),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            _t('لقطة حالة النظام جاهزة', 'System status snapshot ready'),
            style: TextStyle(color: _p.text, fontWeight: FontWeight.w800),
          ),
        ),
        Icon(Icons.check_circle_outline_rounded, color: _p.accent),
      ],
    ),
  );

  Widget _check(String label, String value, bool good) => Card(
    color: _p.surface,
    margin: const EdgeInsets.only(bottom: 8),
    child: ListTile(
      leading: Icon(
        good ? Icons.check_circle_outline_rounded : Icons.warning_amber_rounded,
        color: good ? _p.accent : _p.accent2,
      ),
      title: Text(
        label,
        style: TextStyle(color: _p.text, fontWeight: FontWeight.w700),
      ),
      subtitle: Text(value, style: TextStyle(color: _p.muted, height: 1.35)),
    ),
  );

  Widget _errorCard() => Card(
    color: _p.surface,
    child: ListTile(
      leading: Icon(Icons.error_outline, color: _p.accent2),
      title: Text(_error!, style: TextStyle(color: _p.text)),
      trailing: IconButton(
        onPressed: _load,
        icon: Icon(Icons.refresh, color: _p.accent),
      ),
    ),
  );
}
