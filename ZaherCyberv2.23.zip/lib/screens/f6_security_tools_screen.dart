import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/f6_security_tools.dart';
import '../models/external_resource.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../widgets/page_navigation_controls.dart';

class F6SecurityToolsScreen extends StatefulWidget {
  const F6SecurityToolsScreen({super.key});

  @override
  State<F6SecurityToolsScreen> createState() => _F6SecurityToolsScreenState();
}

class _F6SecurityToolsScreenState extends State<F6SecurityToolsScreen> {
  final _searchController = TextEditingController();
  String _category = 'all';

  AppPalette get _palette => Theme.of(context).extension<AppPalette>()!;
  bool get _english => Localizations.localeOf(context).languageCode == 'en';
  String _text(String ar, String en) => copy(context, ar, en);

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<String> get _categories => [
    'all',
    ...f6SecurityTools
        .map((tool) => _english ? tool.categoryEn : tool.categoryAr)
        .toSet(),
  ];

  List<ExternalResource> get _filteredTools {
    final query = _searchController.text.trim().toLowerCase();
    return f6SecurityTools.where((tool) {
      final category = _english ? tool.categoryEn : tool.categoryAr;
      final searchable = [
        tool.nameAr,
        tool.nameEn,
        tool.descriptionAr,
        tool.descriptionEn,
        tool.categoryAr,
        tool.categoryEn,
      ].join(' ').toLowerCase();
      return (_category == 'all' || category == _category) &&
          (query.isEmpty || searchable.contains(query));
    }).toList();
  }

  Future<void> _openTool(ExternalResource tool) async {
    final message = [
      _text(
        'ستفتح الآن خدمة أو مشروعاً خارجياً: ${tool.nameAr}.',
        'You are about to open an external service or project: ${tool.nameEn}.',
      ),
      _text(
        'لا يرسل ZaherCyber بياناتك تلقائياً. قد يعالج الموقع عنوان IP أو النص أو الرابط الذي تدخله وفق سياسته. لا تستخدم حسابات أو بيانات لا تملك تصريحاً باستخدامها.',
        'ZaherCyber does not send your data automatically. The site may process your IP address or any text/link you enter under its policy. Use only accounts and data you are authorized to use.',
      ),
      _text(tool.accessAr, tool.accessEn),
    ].join('\n\n');
    final consent = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(_text('تأكيد فتح أداة خارجية', 'Confirm external tool')),
        content: SingleChildScrollView(child: Text(message)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(_text('إلغاء', 'Cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(_text('فتح الرابط الرسمي', 'Open official link')),
          ),
        ],
      ),
    );
    if (consent != true || !mounted) return;
    final uri = Uri.tryParse(tool.url);
    if (uri == null || uri.scheme != 'https') {
      _showMessage(_text('الرابط غير صالح.', 'Invalid link.'));
      return;
    }
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        _showMessage(_text('تعذر فتح الرابط.', 'Could not open the link.'));
      }
    } catch (_) {
      if (mounted) {
        _showMessage(_text('تعذر فتح الرابط الآن.', 'Could not open the link right now.'));
      }
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _downloadFromSource(ExternalResource tool) async {
    final url = tool.downloadUrl;
    if (url == null) return;
    final consent = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(_text('تنزيل من المصدر الرسمي', 'Download from official source')),
        content: SingleChildScrollView(child: Text([
          _text('سيتم فتح صفحة التنزيل خارج ZaherCyber: ${tool.nameAr}.', 'The official download page will open outside ZaherCyber: ${tool.nameEn}.'),
          _text(tool.trustAr, tool.trustEn),
          _text('راجع اسم الحزمة والتوقيع والصلاحيات قبل التثبيت. لا يتم تثبيت APK تلقائياً ولا يرسل التطبيق بياناتك.', 'Review package name, signature, and permissions before installing. APKs are not installed automatically and ZaherCyber sends no data.'),
        ].join('\n\n'))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: Text(_text('إلغاء', 'Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(_text('فتح صفحة التنزيل', 'Open download page'))),
        ],
      ),
    );
    if (consent != true || !mounted) return;
    final uri = Uri.tryParse(url);
    if (uri == null || uri.scheme != 'https') {
      _showMessage(_text('رابط التنزيل غير صالح.', 'Invalid download link.'));
      return;
    }
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) _showMessage(_text('تعذر فتح صفحة التنزيل.', 'Could not open the download page.'));
    } catch (_) {
      if (mounted) _showMessage(_text('تعذر فتح صفحة التنزيل الآن.', 'Could not open the download page right now.'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final tools = _filteredTools;
    return Scaffold(
      backgroundColor: _palette.background,
      appBar: AppBar(
        leading: pageBackButton(context),
        title: Text(_text('F6 Security Tools', 'F6 Security Tools')),
        actions: [pageHomeButton(context)],
      ),
      body: Column(
        children: [
          _header(),
          _arsenalSummary(),
          _recipeStrip(),
          _searchAndFilters(),
          Expanded(
            child: tools.isEmpty
                ? Center(
                    child: Text(
                      _text('لا توجد أدوات مطابقة.', 'No matching tools.'),
                      style: TextStyle(color: _palette.muted),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(14, 4, 14, 26),
                    itemCount: tools.length,
                    itemBuilder: (_, index) => _toolCard(tools[index]),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _header() => Container(
        width: double.infinity,
        margin: const EdgeInsets.fromLTRB(14, 12, 14, 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_palette.heroStart, _palette.surface],
            begin: AlignmentDirectional.topStart,
            end: AlignmentDirectional.bottomEnd,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _palette.accent.withValues(alpha: .25)),
        ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: _palette.accent.withValues(alpha: .14),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(Icons.security_update_good_rounded, color: _palette.accent, size: 30),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _text('أدوات ومصادر منتقاة', 'Curated tools and sources'),
                    style: TextStyle(color: _palette.text, fontWeight: FontWeight.w900, fontSize: 17),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    _text(
                      'روابط رسمية مصنفة للـOSINT والتحليل والأدوات المساندة. لا يتم تضمين كود المشاريع أو تشغيله داخل ZaherCyber.',
                      'Classified official links for OSINT, analysis, and supporting utilities. Projects are not embedded or executed inside ZaherCyber.',
                    ),
                    style: TextStyle(color: _palette.muted, height: 1.35, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _arsenalSummary() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 4, 14, 2),
    child: Row(children: [
      Expanded(child: _stat(Icons.widgets_outlined, '${f6SecurityTools.length}', _text('مصدر منتقى', 'curated'))),
      const SizedBox(width: 7),
      Expanded(child: _stat(Icons.lock_outline, _text('محلي', 'Local'), _text('أدوات الجهاز', 'on-device tools'))),
      const SizedBox(width: 7),
      Expanded(child: _stat(Icons.gpp_maybe_outlined, _text('تصريح', 'Auth'), _text('قبل الاختبار', 'before testing'))),
    ]),
  );

  Widget _stat(IconData icon, String value, String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
    decoration: BoxDecoration(color: _palette.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: _palette.border)),
    child: Column(children: [Icon(icon, size: 17, color: _palette.accent), const SizedBox(height: 3), Text(value, style: TextStyle(color: _palette.text, fontWeight: FontWeight.w900, fontSize: 12)), Text(label, textAlign: TextAlign.center, style: TextStyle(color: _palette.muted, fontSize: 9))]),
  );

  Widget _recipeStrip() => SizedBox(
    height: 46,
    child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6), children: [
      _recipe(_text('وصفة OSINT', 'OSINT recipe'), 'OSINT'),
      _recipe(_text('أمن الويب', 'Web security'), 'Web'),
      _recipe(_text('تحليل التهديد', 'Threat intel'), 'Threat'),
      _recipe(_text('أمن الهاتف', 'Mobile security'), 'Mobile'),
    ]),
  );

  Widget _recipe(String label, String query) => Padding(padding: const EdgeInsetsDirectional.only(end: 6), child: ActionChip(avatar: Icon(Icons.auto_awesome_outlined, size: 15, color: _palette.accent), label: Text(label), onPressed: () { _searchController.text = query; setState(() {}); }));

  Widget _searchAndFilters() => Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 2),
            child: TextField(
              key: const ValueKey('f6-security-tools-search'),
              controller: _searchController,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                labelText: _text('ابحث في الأدوات', 'Search tools'),
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _searchController.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _searchController.clear();
                          setState(() {});
                        },
                        icon: const Icon(Icons.clear_rounded),
                      ),
                border: const OutlineInputBorder(),
              ),
            ),
          ),
          SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              children: [
                for (final category in _categories)
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 7),
                    child: ChoiceChip(
                      key: ValueKey('f6-security-category-$category'),
                      selected: _category == category,
                      label: Text(
                        category == 'all' ? _text('الكل', 'All') : category,
                      ),
                      onSelected: (_) => setState(() => _category = category),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(16, 0, 16, 3),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                '${_filteredTools.length} ${_text('أدوات', 'tools')}',
                style: TextStyle(color: _palette.muted, fontSize: 12),
              ),
            ),
          ),
        ],
      );

  Widget _toolCard(ExternalResource tool) {
    final category = _english ? tool.categoryEn : tool.categoryAr;
    return Card(
      key: ValueKey('f6-security-tool-${tool.id}'),
      color: _palette.surface,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(tool.icon, color: _palette.accent, size: 25),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _english ? tool.nameEn : tool.nameAr,
                    style: TextStyle(color: _palette.text, fontWeight: FontWeight.w900, fontSize: 16),
                  ),
                ),
                Chip(label: Text(category, style: const TextStyle(fontSize: 10))),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              _english ? tool.descriptionEn : tool.descriptionAr,
              style: TextStyle(color: _palette.muted, height: 1.4),
            ),
            const SizedBox(height: 8),
            Text(
              _english ? tool.accessEn : tool.accessAr,
              style: TextStyle(color: _palette.text, fontSize: 12, height: 1.35),
            ),
            if (tool.processesSubmittedData)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  _text('تنبيه: راجع البيانات قبل إرسالها للخدمة.', 'Notice: review data before sending it to the service.'),
                  style: TextStyle(color: _palette.accent2, fontSize: 11, fontWeight: FontWeight.w800),
                ),
              ),
            const SizedBox(height: 8),
            Wrap(
              alignment: WrapAlignment.end,
              spacing: 7,
              runSpacing: 6,
              children: [
                OutlinedButton.icon(
                  onPressed: () => _openTool(tool),
                  icon: const Icon(Icons.open_in_new_rounded, size: 17),
                  label: Text(_text('المصدر', 'Source')),
                ),
                if (tool.downloadUrl != null)
                  FilledButton.icon(
                    onPressed: () => _downloadFromSource(tool),
                    icon: const Icon(Icons.download_rounded, size: 17),
                    label: Text(_text('تنزيل رسمي', 'Official download')),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
