import 'dart:async';

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../utils/app_version.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key, required this.onFinished});

  final VoidCallback onFinished;

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _pageController = PageController();
  int _page = 0;

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  bool get _en => Localizations.localeOf(context).languageCode == 'en';
  String _t(String ar, String en) => copy(context, ar, en);

  final _pages = const [
    (
      Icons.radar_rounded,
      'ZaherCyber — مركزك السيبراني',
      'ZaherCyber — your cyber workspace',
      'أخبار ومعرفة ومختبرات وأدوات عملية في مساحة واحدة، مع واجهة F6-OS واضحة وسريعة.',
      'News, knowledge, labs, and practical tools in one clear F6-OS workspace.',
    ),
    (
      Icons.dashboard_customize_outlined,
      'كل ما تحتاجه في مكان واحد',
      'Everything in one workspace',
      'الأخبار، مركز الحماية، أكاديمية F6-Team، مختبر CTF، FAHES، وأدوات API وSecurity Workbench.',
      'News, Protection Center, F6-Team Academy, CTF Lab, FAHES, API tools, and Security Workbench.',
    ),
    (
      Icons.lock_outline_rounded,
      'خصوصيتك أولاً',
      'Privacy first',
      'المحتوى المحلي يعمل دون اتصال حيثما أمكن. لا تُرسل الروابط أو البيانات إلى خدمة خارجية إلا بعد موافقتك الصريحة.',
      'Local content works offline where possible. Links and data are not sent to external services without your explicit consent.',
    ),
    (
      Icons.school_rounded,
      'تعلّم، افحص، وتحقق',
      'Learn, inspect, and verify',
      'استخدم مركز التعلم وF6 Security Tools ومصادر التدريب بمسؤولية، وافحص فقط ما تملكه أو تملك تصريحاً لفحصه.',
      'Use Learning Center and F6 Security Tools responsibly. Inspect only what you own or are authorized to assess.',
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _next() {
    if (_page == _pages.length - 1) {
      widget.onFinished();
      return;
    }
    _pageController.nextPage(
      duration: const Duration(milliseconds: 320),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: const ValueKey('onboarding-screen'),
      backgroundColor: _p.background,
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: AlignmentDirectional.topEnd,
              child: TextButton(
                onPressed: widget.onFinished,
                child: Text(_t('تخطي', 'Skip')),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                itemCount: _pages.length,
                onPageChanged: (value) => setState(() => _page = value),
                itemBuilder: (_, index) => _pageView(_pages[index]),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var index = 0; index < _pages.length; index++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: index == _page ? 28 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: index == _page ? _p.accent : _p.border,
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _next,
                  icon: Icon(_page == _pages.length - 1 ? Icons.rocket_launch_rounded : Icons.arrow_forward_rounded),
                  label: Text(_page == _pages.length - 1 ? _t('ابدأ الآن', 'Start now') : _t('التالي', 'Next')),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _pageView((IconData, String, String, String, String) page) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 132,
              height: 132,
              decoration: BoxDecoration(
                color: _p.accent.withValues(alpha: .12),
                shape: BoxShape.circle,
                border: Border.all(color: _p.accent.withValues(alpha: .5), width: 2),
                boxShadow: [BoxShadow(color: _p.accent.withValues(alpha: .16), blurRadius: 34)],
              ),
              child: Icon(page.$1, size: 68, color: _p.accent),
            ),
            const SizedBox(height: 30),
            Text(
              _en ? page.$3 : page.$2,
              textAlign: TextAlign.center,
              style: TextStyle(color: _p.text, fontSize: 26, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 16),
            Text(
              _en ? page.$5 : page.$4,
              textAlign: TextAlign.center,
              style: TextStyle(color: _p.muted, fontSize: 16, height: 1.6),
            ),
          ],
        ),
      );
}

class CyberBootScreen extends StatefulWidget {
  const CyberBootScreen({super.key, required this.onFinished});

  final VoidCallback onFinished;

  @override
  State<CyberBootScreen> createState() => _CyberBootScreenState();
}

class _CyberBootScreenState extends State<CyberBootScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animation;
  Timer? _finishTimer;
  int _line = 0;
  bool _canContinue = false;
  bool _completed = false;
  static const _lines = [
    'F6-OS / SECURE BOOT',
    'Loading local intelligence core...',
    'Checking privacy boundary...',
    'Mounting learning and tools...',
    'Workspace ready.',
  ];

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;

  @override
  void initState() {
    super.initState();
    _animation = AnimationController(vsync: this, duration: const Duration(milliseconds: 1900))
      ..addListener(() {
        if (!mounted) return;
        final next = (_animation.value * _lines.length).floor().clamp(0, _lines.length - 1).toInt();
        if (next != _line) setState(() => _line = next);
      })
      ..forward();
    _finishTimer = Timer(const Duration(milliseconds: 2100), _finish);
    Future<void>.delayed(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _canContinue = true);
    });
  }

  void _finish() {
    if (!mounted || _completed) return;
    _completed = true;
    widget.onFinished();
  }

  @override
  void dispose() {
    _finishTimer?.cancel();
    _animation.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: const ValueKey('cyber-boot-screen'),
      backgroundColor: const Color(0xff020708),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Icon(Icons.shield_moon_rounded, size: 86, color: _p.accent),
              ),
              const SizedBox(height: 28),
              Text('ZAHERCYBER', style: TextStyle(color: _p.text, fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 3)),
              const SizedBox(height: 5),
              Text('F6-OS // SECURE RESUME', style: TextStyle(color: _p.accent2, letterSpacing: 1.5, fontSize: 12)),
              const SizedBox(height: 28),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _p.surface.withValues(alpha: .72),
                  border: Border.all(color: _p.accent.withValues(alpha: .35)),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (var i = 0; i <= _line; i++)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Text(
                          '> ${_lines[i]}',
                          style: TextStyle(color: i == _line ? _p.accent : _p.muted, fontFamily: 'monospace', fontSize: 12),
                        ),
                      ),
                    const SizedBox(height: 9),
                    LinearProgressIndicator(value: _animation.value, color: _p.accent, backgroundColor: _p.border),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 8,
                runSpacing: 8,
                children: [
                  _statusChip(Icons.lock_outline, 'LOCAL-FIRST'),
                  _statusChip(Icons.verified_user_outlined, 'PRIVACY READY'),
                  _statusChip(Icons.tag_rounded, 'v$appVersion'),
                ],
              ),
              const SizedBox(height: 18),
              AnimatedOpacity(
                opacity: _canContinue ? 1 : .35,
                duration: const Duration(milliseconds: 250),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _canContinue ? _finish : null,
                    icon: const Icon(Icons.arrow_forward_rounded),
                    label: const Text('استئناف مساحة العمل'),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Center(
                child: TextButton(
                  onPressed: _finish,
                  child: const Text('تخطي الإقلاع'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statusChip(IconData icon, String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
    decoration: BoxDecoration(
      color: _p.surface.withValues(alpha: .72),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: _p.border),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 14, color: _p.accent),
      const SizedBox(width: 5),
      Text(label, style: TextStyle(color: _p.muted, fontSize: 9, letterSpacing: 1.1, fontWeight: FontWeight.w800)),
    ]),
  );
}
