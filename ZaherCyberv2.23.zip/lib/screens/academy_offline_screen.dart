import 'dart:async';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../widgets/page_navigation_controls.dart';

class AcademyOfflineScreen extends StatefulWidget {
  const AcademyOfflineScreen({super.key, required this.isArabic});

  final bool isArabic;

  @override
  State<AcademyOfflineScreen> createState() => _AcademyOfflineScreenState();
}

class _AcademyOfflineScreenState extends State<AcademyOfflineScreen> {
  static const _background = Color(0xFF080B12);
  static const _linkBridge = r'''(() => {
    if (window.__zaherExternalLinksInstalled) return;
    window.__zaherExternalLinksInstalled = true;
    document.addEventListener('click', (event) => {
      const element = event.target instanceof Element ? event.target : null;
      const anchor = element ? element.closest('a[href]') : null;
      if (!anchor) return;
      const destination = new URL(anchor.href, document.baseURI);
      const localOrigin = new URL(document.baseURI).origin;
      if ((destination.protocol === 'https:' || destination.protocol === 'http:') &&
          destination.origin !== localOrigin) {
        event.preventDefault();
        event.stopPropagation();
        AcademyExternalLink.postMessage(destination.href);
      }
    }, true);
  })();''';

  late final WebViewController _controller;
  bool _isLoading = true;
  double _progress = 0;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(_background)
      ..addJavaScriptChannel(
        'AcademyExternalLink',
        onMessageReceived: (message) =>
            unawaited(_openExternal(message.message)),
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (progress) {
            if (!mounted) return;
            setState(() {
              _progress = progress / 100;
              _isLoading = progress < 100;
            });
          },
          onPageStarted: (_) {
            if (!mounted) return;
            setState(() {
              _isLoading = true;
              _error = null;
              _progress = 0;
            });
          },
          onPageFinished: (_) {
            if (!mounted) return;
            setState(() {
              _isLoading = false;
              _progress = 1;
            });
            unawaited(_installExternalLinkBridge());
          },
          onWebResourceError: (error) {
            if (error.isForMainFrame != true || !mounted) return;
            setState(() {
              _isLoading = false;
              _error = error.description;
            });
          },
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.prevent;
            if (_isLocalUri(uri)) return NavigationDecision.navigate;
            if ({'https', 'http', 'mailto', 'tel'}.contains(uri.scheme)) {
              unawaited(_openExternal(uri.toString()));
            }
            return NavigationDecision.prevent;
          },
        ),
      );
    unawaited(_loadAcademy());
  }

  bool _isLocalUri(Uri uri) {
    if (uri.scheme == 'file' || uri.scheme == 'about') return true;
    if (uri.scheme.isEmpty) return true;
    return const {
      'appassets.androidplatform.net',
      'localhost',
      '127.0.0.1',
    }.contains(uri.host.toLowerCase());
  }

  Future<void> _loadAcademy() async {
    try {
      await _controller.loadFlutterAsset('assets/academy_offline/index.html');
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = error.toString();
      });
    }
  }

  Future<void> _installExternalLinkBridge() async {
    try {
      await _controller.runJavaScript(_linkBridge);
    } catch (_) {
      // The navigation delegate remains as a fallback if script injection fails.
    }
  }

  Future<void> _openExternal(String rawUrl) async {
    final uri = Uri.tryParse(rawUrl);
    if (uri == null ||
        !{'https', 'http', 'mailto', 'tel'}.contains(uri.scheme)) {
      return;
    }

    var opened = false;
    try {
      opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened) {
        opened = await launchUrl(uri, mode: LaunchMode.platformDefault);
      }
    } catch (_) {
      opened = false;
    }

    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            widget.isArabic
                ? 'تعذر فتح الرابط. تحقق من تثبيت التطبيق أو اتصال الإنترنت.'
                : 'Could not open the link. Check the app or internet connection.',
          ),
        ),
      );
    }
  }

  Future<void> _retry() async {
    if (!mounted) return;
    setState(() {
      _error = null;
      _isLoading = true;
      _progress = 0;
    });
    await _loadAcademy();
  }

  Future<void> _goBack() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
    } else if (mounted) {
      await Navigator.of(context).maybePop();
    }
  }

  Future<void> _goForward() async {
    if (await _controller.canGoForward()) await _controller.goForward();
  }

  @override
  Widget build(BuildContext context) {
    final textColor = Colors.white.withValues(alpha: .92);
    final mutedColor = Colors.white.withValues(alpha: .66);

    return Scaffold(
      backgroundColor: _background,
      appBar: AppBar(
        backgroundColor: _background,
        foregroundColor: textColor,
        title: const Text('Academy F6-Team'),
        leading: pageBackButton(context, onPressed: _goBack),
        actions: [
          IconButton(
            tooltip: widget.isArabic
                ? 'للأمام داخل الأكاديمية'
                : 'Forward in academy',
            onPressed: _goForward,
            icon: const Icon(Icons.arrow_forward_rounded),
          ),
          pageHomeButton(context),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_isLoading)
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: LinearProgressIndicator(
                value: _progress == 0 ? null : _progress,
                minHeight: 2,
                color: const Color(0xFF65A9FF),
                backgroundColor: const Color(0xFF182337),
              ),
            ),
          if (_error != null)
            Positioned.fill(
              child: ColoredBox(
                color: _background,
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.error_outline_rounded,
                          color: Color(0xFF65A9FF),
                          size: 42,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          widget.isArabic
                              ? 'تعذر فتح محتوى الأكاديمية المحفوظ.'
                              : 'Could not open the bundled Academy content.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: textColor,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          widget.isArabic
                              ? 'أعد المحاولة. لا يتطلب هذا المحتوى اتصالاً بالإنترنت.'
                              : 'Try again. This content does not require internet access.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: mutedColor, fontSize: 12),
                        ),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: _retry,
                          icon: const Icon(Icons.refresh_rounded),
                          label: Text(
                            widget.isArabic ? 'إعادة المحاولة' : 'Retry',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
