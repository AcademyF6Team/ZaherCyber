import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/api_catalog.dart';
import '../data/security_library.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';

class SecurityWorkbenchScreen extends StatefulWidget {
  const SecurityWorkbenchScreen({super.key});

  @override
  State<SecurityWorkbenchScreen> createState() => _SecurityWorkbenchScreenState();
}

class _SecurityWorkbenchScreenState extends State<SecurityWorkbenchScreen> {
  int _tab = 0;
  String _query = '';
  String _category = 'all';
  String _libraryQuery = '';
  String _libraryCategory = 'all';
  final Set<String> _favorites = {};
  final List<String> _reports = [];
  final TextEditingController _localInput = TextEditingController();
  String _localOutput = '';

  @override
  void dispose() {
    _localInput.dispose();
    super.dispose();
  }

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  bool get _en => Localizations.localeOf(context).languageCode == 'en';
  String _t(String ar, String en) => copy(context, ar, en);

  List<String> get _categories => [
    'all',
    ...{for (final item in apiCatalog) _en ? item.categoryEn : item.categoryAr},
  ];

  List<ApiCatalogItem> get _filtered {
    final term = _query.trim().toLowerCase();
    return apiCatalog.where((item) {
      final category = _en ? item.categoryEn : item.categoryAr;
      final text = '${item.name} ${item.descriptionAr} ${item.descriptionEn} ${item.categoryAr} ${item.categoryEn}'.toLowerCase();
      return (_category == 'all' || category == _category) &&
          (term.isEmpty || text.contains(term));
    }).toList();
  }

  List<String> get _libraryCategories => [
    'all',
    ...{for (final item in securityLibrary) _en ? item.categoryEn : item.categoryAr},
  ];

  List<SecurityLibraryItem> get _filteredLibrary => securityLibrary.where((item) {
    final category = _en ? item.categoryEn : item.categoryAr;
    final term = _libraryQuery.trim().toLowerCase();
    final text = '${item.name} ${item.descriptionAr} ${item.descriptionEn} ${item.categoryAr} ${item.categoryEn}'.toLowerCase();
    return (_libraryCategory == 'all' || category == _libraryCategory) &&
        (term.isEmpty || text.contains(term));
  }).toList();

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(_t('مركز العمل الأمني', 'Security Workbench')),
      actions: [
        IconButton(
          tooltip: _t('معلومات الخصوصية', 'Privacy information'),
          onPressed: _privacyDialog,
          icon: const Icon(Icons.privacy_tip_outlined),
        ),
      ],
    ),
    body: IndexedStack(
      index: _tab,
      children: [
        _overview(),
        _apiHub(),
        _playground(),
        _libraryPage(),
        _localTools(),
        _reportsPage(),
        _healthPage(),
        _responsePage(),
      ],
    ),
    bottomNavigationBar: NavigationBar(
      selectedIndex: _tab,
      labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
      onDestinationSelected: (value) => setState(() => _tab = value),
      destinations: [
        NavigationDestination(icon: const Icon(Icons.space_dashboard_outlined), selectedIcon: const Icon(Icons.space_dashboard), label: _t('لوحة', 'Mission')),
        NavigationDestination(icon: const Icon(Icons.api_outlined), selectedIcon: const Icon(Icons.api), label: _t('API Hub', 'API Hub')),
        NavigationDestination(icon: const Icon(Icons.science_outlined), selectedIcon: const Icon(Icons.science), label: _t('مختبر', 'Lab')),
        NavigationDestination(icon: const Icon(Icons.menu_book_outlined), selectedIcon: const Icon(Icons.menu_book), label: _t('المكتبة', 'Library')),
        NavigationDestination(icon: const Icon(Icons.build_outlined), selectedIcon: const Icon(Icons.build), label: _t('محلي', 'Local')),
        NavigationDestination(icon: const Icon(Icons.description_outlined), selectedIcon: const Icon(Icons.description), label: _t('تقارير', 'Reports')),
        NavigationDestination(icon: const Icon(Icons.health_and_safety_outlined), selectedIcon: const Icon(Icons.health_and_safety), label: _t('الصحة', 'Health')),
        NavigationDestination(icon: const Icon(Icons.warning_amber_outlined), selectedIcon: const Icon(Icons.warning), label: _t('استجابة', 'Response')),
      ],
    ),
  );

  Widget _scroll(Widget child) => SafeArea(
    child: SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
      child: child,
    ),
  );

  Widget _overview() => _scroll(Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      _hero(),
      const SizedBox(height: 12),
      _sectionTitle(_t('مساحات العمل', 'Workspaces'), Icons.apps_outlined),
      _actionGrid([
        _action(Icons.api_outlined, 'دليل 80 API', '80 curated APIs', () => setState(() => _tab = 1)),
        _action(Icons.science_outlined, 'مختبر API', 'Safe API playground', () => setState(() => _tab = 2)),
        _action(Icons.menu_book_outlined, 'مكتبة الأمن', 'Security Library', () => setState(() => _tab = 3)),
        _action(Icons.build_outlined, 'أدوات محلية', 'Private local tools', () => setState(() => _tab = 4)),
        _action(Icons.description_outlined, 'تقارير الفحص', 'Local reports', () => setState(() => _tab = 5)),
        _action(Icons.health_and_safety_outlined, 'صحة الخدمات', 'Service health', () => setState(() => _tab = 6)),
        _action(Icons.warning_amber_outlined, 'استجابة حادث', 'Incident response', () => setState(() => _tab = 7)),
        _action(Icons.school_outlined, 'خطة تعلم', 'Learning mission', () => _showLearningPlan()),
      ]),
      const SizedBox(height: 18),
      _sectionTitle(_t('أرقام المساحة', 'Workbench metrics'), Icons.insights_outlined),
      Row(children: [
        Expanded(child: _metric('${apiCatalog.length}', _t('مصدر منتقى', 'Curated APIs'), Icons.api_outlined)),
        const SizedBox(width: 8),
        Expanded(child: _metric('${apiCatalog.where((e) => !e.requiresKey).length}', _t('بلا مفتاح', 'No key listed'), Icons.key_off_outlined)),
        const SizedBox(width: 8),
        Expanded(child: _metric('${_reports.length}', _t('تقرير محلي', 'Local reports'), Icons.description_outlined)),
      ]),
      const SizedBox(height: 18),
      _infoPanel(
        Icons.shield_outlined,
        _t('مبدأ الاستخدام المسؤول', 'Responsible-use principle'),
        _t('يفحص التطبيق ما تملكه أو تملك تصريحًا لفحصه فقط. لا تُدخل كلمات مرور أو رموز جلسات أو روابط داخلية في خدمة خارجية.', 'Inspect only assets you own or are authorized to assess. Never enter passwords, session tokens, or private URLs into an external service.'),
      ),
    ],
  ));

  Widget _hero() => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      gradient: LinearGradient(colors: [_p.heroStart, _p.heroEnd]),
      border: Border.all(color: _p.accent.withValues(alpha: .35)),
    ),
    child: Row(children: [
      Icon(Icons.security_rounded, size: 42, color: _p.accent),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('ZaherCyber Workbench', style: TextStyle(color: _p.text, fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        Text(_t('لوحة واحدة للتعلم، الفحص، المصادر، والتعامل مع الحوادث.', 'One workspace for learning, research, checks, and response.'), style: TextStyle(color: _p.muted, height: 1.35)),
      ])),
    ]),
  );

  Widget _apiHub() => Column(children: [
    Padding(padding: const EdgeInsets.fromLTRB(14, 12, 14, 4), child: TextField(
      onChanged: (value) => setState(() => _query = value),
      decoration: InputDecoration(
        hintText: _t('ابحث في 80 API ومصدرًا...', 'Search 80 APIs and sources...'),
        prefixIcon: const Icon(Icons.search),
        suffixIcon: _query.isEmpty ? null : IconButton(onPressed: () { setState(() { _query = ''; }); }, icon: const Icon(Icons.clear)),
      ),
    )),
    SizedBox(height: 52, child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      scrollDirection: Axis.horizontal,
      itemCount: _categories.length,
      separatorBuilder: (_, __) => const SizedBox(width: 6),
      itemBuilder: (_, index) {
        final category = _categories[index];
        return ChoiceChip(label: Text(category == 'all' ? _t('الكل', 'All') : category), selected: _category == category, onSelected: (_) => setState(() => _category = category));
      },
    )),
    Expanded(child: ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 20),
      itemCount: _filtered.length,
      itemBuilder: (_, index) => _apiCard(_filtered[index]),
    )),
  ]);

  Widget _apiCard(ApiCatalogItem item) {
    final category = _en ? item.categoryEn : item.categoryAr;
    final description = _en ? item.descriptionEn : item.descriptionAr;
    final favorite = _favorites.contains(item.id);
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Icon(apiCategoryIcon(category), color: _p.accent),
          const SizedBox(width: 9),
          Expanded(child: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w800))),
          IconButton(tooltip: _t('حفظ', 'Save'), onPressed: () => setState(() => favorite ? _favorites.remove(item.id) : _favorites.add(item.id)), icon: Icon(favorite ? Icons.star : Icons.star_border, color: favorite ? _p.accent : _p.muted)),
          IconButton(tooltip: _t('فتح الموقع', 'Open website'), onPressed: () => _openUrl(item.url), icon: const Icon(Icons.open_in_new_rounded)),
        ]),
        Text(category, style: TextStyle(color: _p.accent2, fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 5),
        Text(description, style: TextStyle(color: _p.muted, height: 1.3)),
        const SizedBox(height: 8),
        Wrap(spacing: 6, runSpacing: 5, children: [
          _badge(item.requiresKey ? _t('مفتاح مطلوب', 'API key') : _t('بلا مفتاح ظاهر', 'No key listed'), item.requiresKey ? Colors.orange : _p.accent),
          if (item.processesSubmittedData) _badge(_t('يرسل إدخالًا خارجيًا', 'Sends submitted data'), Colors.redAccent),
          _badge('HTTPS', _p.accent2),
        ]),
      ])),
    );
  }

  Widget _playground() => _scroll(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    _sectionTitle(_t('مختبر API آمن', 'Safe API Playground'), Icons.science_outlined),
    _infoPanel(Icons.school_outlined, _t('تعلم قبل الاتصال', 'Learn before connecting'), _t('هذه التمارين تستخدم خدمات بيانات تجريبية ولا تتطلب مفاتيح أو بيانات شخصية. لا تستخدمها لاختبار أهداف حقيقية.', 'These exercises use demo services and do not need keys or personal data. Never use them to test real targets.')),
    const SizedBox(height: 12),
    _labTile('GET وJSON', 'GET & JSON', _t('اقرأ استجابة JSON وافهم بنية الحقول.', 'Read a JSON response and understand fields.'), 'https://jsonplaceholder.typicode.com/todos/1'),
    _labTile('HTTP Status Codes', 'HTTP Status Codes', _t('افهم الفرق بين 2xx و4xx و5xx.', 'Understand 2xx, 4xx, and 5xx.'), 'https://httpbin.org/status/200'),
    _labTile('Headers وEcho', 'Headers & Echo', _t('جرّب طلبًا لا يعرض بيانات حساسة.', 'Try an echo request without sensitive data.'), 'https://httpbin.org/get?source=zahercyber'),
    _labTile('OpenAPI', 'OpenAPI', _t('تعلّم قراءة التوثيق قبل استعمال API.', 'Learn to read documentation before using an API.'), 'https://www.openapis.org/'),
  ]));

  Widget _labTile(String ar, String en, String detail, String url) => Card(child: ListTile(leading: Icon(Icons.play_circle_outline, color: _p.accent), title: Text(_t(ar, en)), subtitle: Text(detail), trailing: const Icon(Icons.arrow_forward_ios, size: 15), onTap: () => _openUrl(url)));

  Widget _libraryPage() => Column(children: [
    Padding(padding: const EdgeInsets.fromLTRB(14, 12, 14, 4), child: TextField(
      onChanged: (value) => setState(() => _libraryQuery = value),
      decoration: InputDecoration(
        hintText: _t('ابحث في مكتبة الأمن...', 'Search Security Library...'),
        prefixIcon: const Icon(Icons.search),
      ),
    )),
    SizedBox(height: 52, child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      scrollDirection: Axis.horizontal,
      itemCount: _libraryCategories.length,
      separatorBuilder: (_, __) => const SizedBox(width: 6),
      itemBuilder: (_, index) {
        final category = _libraryCategories[index];
        return ChoiceChip(
          label: Text(category == 'all' ? _t('الكل', 'All') : category),
          selected: _libraryCategory == category,
          onSelected: (_) => setState(() => _libraryCategory = category),
        );
      },
    )),
    Expanded(child: ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 20),
      itemCount: _filteredLibrary.length,
      itemBuilder: (_, index) => _libraryCard(_filteredLibrary[index]),
    )),
  ]);

  Widget _libraryCard(SecurityLibraryItem item) {
    final category = _en ? item.categoryEn : item.categoryAr;
    final description = _en ? item.descriptionEn : item.descriptionAr;
    return Card(margin: const EdgeInsets.only(bottom: 9), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(children: [
        Icon(securityLibraryIcon(category), color: item.restricted ? Colors.redAccent : _p.accent),
        const SizedBox(width: 9),
        Expanded(child: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w800))),
        if (!item.restricted) IconButton(tooltip: _t('فتح المصدر', 'Open source'), onPressed: () => _openUrl(item.url), icon: const Icon(Icons.open_in_new_rounded)),
      ]),
      Text(category, style: TextStyle(color: item.restricted ? Colors.redAccent : _p.accent2, fontSize: 12, fontWeight: FontWeight.w700)),
      const SizedBox(height: 5),
      Text(description, style: TextStyle(color: _p.muted, height: 1.3)),
      const SizedBox(height: 8),
      Wrap(spacing: 6, runSpacing: 5, children: [
        _badge(_en ? item.typeEn : item.typeAr, item.restricted ? Colors.redAccent : _p.accent),
        _badge(item.level, _p.accent2),
        if (item.restricted) _badge(_t('غير مدمج أو مستبعد', 'Not embedded or excluded'), Colors.redAccent),
      ]),
    ])));
  }

  Widget _localTools() => _scroll(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    _sectionTitle(_t('أدوات محلية خاصة', 'Private local tools'), Icons.build_outlined),
    _infoPanel(Icons.lock_outline, _t('المعالجة على الجهاز', 'On-device processing'), _t('هذه الأدوات لا ترسل المدخلات إلى الإنترنت: JSON، الرابط، Unicode، JWT، والبصمة. لا تدخل أسرارًا في سجل أو لقطة شاشة.', 'These tools do not send input online: JSON, URL, Unicode, JWT, and hashing. Do not enter secrets into logs or screenshots.')),
    const SizedBox(height: 12),
    TextField(controller: _localInput, maxLines: 5, decoration: InputDecoration(labelText: _t('إدخال محلي', 'Local input'), hintText: _t('ألصق JSON أو رابطًا أو نصًا عامًا...', 'Paste JSON, a URL, or public text...'))),
    const SizedBox(height: 10),
    Wrap(spacing: 8, runSpacing: 8, children: [
      _toolButton(Icons.data_object, 'تنسيق JSON', 'Format JSON', () => _runLocalTool('json')),
      _toolButton(Icons.link, 'تحليل الرابط', 'Inspect URL', () => _runLocalTool('url')),
      _toolButton(Icons.fingerprint, 'SHA-256', 'SHA-256', () => _runLocalTool('hash')),
      _toolButton(Icons.text_fields, 'Unicode', 'Unicode', () => _runLocalTool('unicode')),
      _toolButton(Icons.token_outlined, 'معلومات JWT', 'JWT info', () => _runLocalTool('jwt')),
    ]),
    const SizedBox(height: 12),
    if (_localOutput.isNotEmpty) Card(child: Padding(padding: const EdgeInsets.all(13), child: SelectableText(_localOutput, style: TextStyle(color: _p.text, height: 1.4)))),
    const SizedBox(height: 14),
    _sectionTitle(_t('وصفات جاهزة', 'API recipes'), Icons.auto_awesome_outlined),
    _recipe('فحص رابط مصرح', 'Authorized URL check', 'URLhaus + ThreatFox + urlscan.io', _t('ابدأ بالمصادر العامة، ثم راجع الخصوصية قبل إرسال الرابط.', 'Start with public sources, then review privacy before submitting a URL.')),
    _recipe('بحث CVE', 'CVE research', 'NVD + CISA KEV + OSV', _t('اربط المعرّف بالمنتج والإصدار ولا تعتبر الدرجة حكمًا نهائيًا.', 'Connect the ID to product and version; a score is not a final verdict.')),
    _recipe('تأمين موقع تملكه', 'Secure an owned site', 'SSL Labs + SecurityHeaders + OWASP', _t('لا تفحص نطاقًا دون ملكية أو تفويض واضح.', 'Do not assess a domain without ownership or clear authorization.')),
  ]));

  Widget _toolButton(IconData icon, String ar, String en, VoidCallback onPressed) => OutlinedButton.icon(onPressed: onPressed, icon: Icon(icon, size: 18), label: Text(_t(ar, en)));
  Widget _recipe(String ar, String en, String sources, String detail) => Card(child: ListTile(leading: Icon(Icons.route_outlined, color: _p.accent), title: Text(_t(ar, en)), subtitle: Text('$sources\n$detail'), isThreeLine: true));

  void _runLocalTool(String type) {
    final input = _localInput.text.trim();
    if (input.isEmpty) {
      setState(() => _localOutput = _t('أدخل قيمة عامة أولًا.', 'Enter a public value first.'));
      return;
    }
    String output;
    try {
      switch (type) {
        case 'json':
          output = const JsonEncoder.withIndent('  ').convert(jsonDecode(input));
          break;
        case 'url':
          final uri = Uri.tryParse(input);
          output = uri == null || !uri.hasScheme
              ? _t('الرابط غير صالح أو بلا scheme.', 'Invalid URL or missing scheme.')
              : '${_t('المخطط', 'Scheme')}: ${uri.scheme}\n${_t('المضيف', 'Host')}: ${uri.host}\n${_t('المسار', 'Path')}: ${uri.path}\n${_t('HTTPS', 'HTTPS')}: ${uri.scheme == 'https'}';
          break;
        case 'hash':
          output = 'SHA-256: ${sha256.convert(utf8.encode(input))}';
          break;
        case 'unicode':
          final suspicious = input.runes.where((rune) => rune > 127).length;
          output = '${_t('عدد المحارف', 'Characters')}: ${input.runes.length}\n${_t('محارف خارج ASCII', 'Non-ASCII characters')}: $suspicious\n${_t('ملاحظة: افحص النطاق بصريًا ولا تعتبر التشابه Unicode دليلًا وحيدًا.', 'Note: inspect domains visually; Unicode similarity alone is not proof.')}' ;
          break;
        case 'jwt':
          final parts = input.split('.');
          output = parts.length == 3
              ? _t('يتكون الإدخال من ثلاثة أجزاء JWT. لم يتم فك أو إرسال التوقيع.', 'Input has three JWT segments. Signature was not decoded or sent.')
              : _t('ليس له شكل JWT من ثلاثة أجزاء.', 'It does not have the three-part JWT shape.');
          break;
        default:
          output = '';
      }
    } catch (_) {
      output = _t('تعذر تحليل الإدخال محليًا.', 'Could not parse the input locally.');
    }
    setState(() => _localOutput = output);
  }

  Widget _reportsPage() => _scroll(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    _sectionTitle(_t('تقارير محلية', 'Local reports'), Icons.description_outlined),
    _infoPanel(Icons.lock_outline, _t('خصوصية افتراضية', 'Private by default'), _t('التقارير التالية محلية داخل الذاكرة الحالية. لا يتم رفعها إلى خادم.', 'These reports stay local in the current session. They are not uploaded.')),
    const SizedBox(height: 10),
    FilledButton.icon(onPressed: () { setState(() => _reports.add('${_t('تقرير فحص تجريبي', 'Demo check report')} #${_reports.length + 1}')); }, icon: const Icon(Icons.add), label: Text(_t('إنشاء تقرير تجريبي', 'Create demo report'))),
    const SizedBox(height: 12),
    if (_reports.isEmpty) _empty(_t('لا توجد تقارير بعد.', 'No reports yet.')),
    for (final report in _reports.reversed) Card(child: ListTile(leading: Icon(Icons.article_outlined, color: _p.accent), title: Text(report), subtitle: Text(_t('نتيجة تعليمية — ليست حكمًا أمنيًا نهائيًا', 'Educational result — not a final security verdict')), trailing: IconButton(onPressed: () => setState(() => _reports.remove(report)), icon: const Icon(Icons.delete_outline)))),
  ]));

  Widget _healthPage() => _scroll(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    _sectionTitle(_t('صحة الخدمات', 'Service health'), Icons.health_and_safety_outlined),
    _infoPanel(Icons.info_outline, _t('فحص يدوي لا مراقبة مستمرة', 'Manual checks, not continuous monitoring'), _t('لا يرسل التطبيق طلبات خلفية جماعية. افتح المصدر للتحقق عند الحاجة، واحترم حدوده وشروطه.', 'The app does not run bulk background requests. Open a source when needed and respect its limits and terms.')),
    const SizedBox(height: 10),
    for (final item in apiCatalog.take(12)) Card(child: ListTile(leading: Icon(Icons.circle, size: 12, color: _p.accent), title: Text(item.name), subtitle: Text(_t('جاهز للفحص اليدوي · ${item.requiresKey ? 'يتطلب مفتاحًا' : 'لا مفتاح ظاهر'}', 'Manual check ready · ${item.requiresKey ? 'key required' : 'no key listed'}')), trailing: IconButton(onPressed: () => _openUrl(item.url), icon: const Icon(Icons.open_in_new)))),
  ]));

  Widget _responsePage() => _scroll(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    _sectionTitle(_t('استجابة الحوادث', 'Incident response'), Icons.warning_amber_outlined),
    _responseStep('1', _t('أوقف التفاعل الخطر', 'Stop the risky interaction'), _t('لا تضغط روابط إضافية ولا تدخل رمز تحقق أو كلمة مرور.', 'Do not click further or enter a password or verification code.')),
    _responseStep('2', _t('احفظ السياق', 'Preserve context'), _t('احتفظ بالرابط والوقت ولقطات الشاشة دون نشر بيانات حساسة.', 'Keep the URL, time, and screenshots without exposing sensitive data.')),
    _responseStep('3', _t('أمّن الحساب', 'Secure the account'), _t('غيّر كلمة المرور من القناة الرسمية وفعل MFA من إعدادات الحساب.', 'Change the password through the official channel and enable MFA.')),
    _responseStep('4', _t('تحقق من المصدر', 'Verify the source'), _t('استخدم دليل API أو المصادر الرسمية فقط، ولا تعتبر عدم وجود نتيجة دليل أمان.', 'Use official sources only; no-result is not proof of safety.')),
    _responseStep('5', _t('صعّد عند الحاجة', 'Escalate when needed'), _t('في حادث مؤسسي أو فقدان أموال أو بيانات حساسة تواصل مع الجهة المختصة.', 'For enterprise incidents, financial loss, or sensitive data contact the appropriate authority.')),
  ]));

  Widget _responseStep(String number, String title, String body) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [CircleAvatar(radius: 15, backgroundColor: _p.accent, foregroundColor: _p.background, child: Text(number, style: const TextStyle(fontWeight: FontWeight.w900))), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 4), Text(body, style: TextStyle(color: _p.muted, height: 1.35))]))])));

  Widget _sectionTitle(String title, IconData icon) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(children: [Icon(icon, color: _p.accent), const SizedBox(width: 8), Text(title, style: TextStyle(color: _p.text, fontWeight: FontWeight.w900, fontSize: 17))]));
  Widget _metric(String value, String label, IconData icon) => Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8), child: Column(children: [Icon(icon, size: 20, color: _p.accent2), const SizedBox(height: 4), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)), Text(label, textAlign: TextAlign.center, style: TextStyle(color: _p.muted, fontSize: 11))])));
  Widget _badge(String text, Color color) => Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(8), border: Border.all(color: color.withValues(alpha: .3))), child: Text(text, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)));
  Widget _infoPanel(IconData icon, String title, String body) => Card(child: Padding(padding: const EdgeInsets.all(13), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: _p.accent2), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 4), Text(body, style: TextStyle(color: _p.muted, height: 1.35))]))])));
  Widget _empty(String text) => Padding(padding: const EdgeInsets.all(28), child: Center(child: Text(text, style: TextStyle(color: _p.muted))));
  Widget _action(IconData icon, String ar, String en, VoidCallback onTap) => Card(child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [Icon(icon, color: _p.accent), const SizedBox(width: 10), Expanded(child: Text(_t(ar, en), style: const TextStyle(fontWeight: FontWeight.w700))), const Icon(Icons.arrow_forward_ios, size: 14)]))));
  Widget _actionGrid(List<Widget> actions) => GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: 2.7, children: actions);

  Future<void> _openUrl(String value) async {
    final uri = Uri.tryParse(value.trim());
    if (uri == null || !uri.hasScheme) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  void _showLearningPlan() => showDialog<void>(context: context, builder: (_) => AlertDialog(title: Text(_t('خطة تعلم مقترحة', 'Suggested learning mission')), content: Text(_t('ابدأ بالخصوصية وأمن الحسابات، ثم API وHTTP، ثم تحليل الروابط وCVE، وبعدها الاستجابة للحوادث. أكمل درسًا واحدًا واحفظ ملاحظاتك محليًا.', 'Start with privacy and account security, then API and HTTP, URL and CVE analysis, and incident response. Complete one lesson and keep notes locally.')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(_t('إغلاق', 'Close')))]));
  void _privacyDialog() => showDialog<void>(context: context, builder: (_) => AlertDialog(title: Text(_t('الخصوصية والحدود', 'Privacy & limits')), content: Text(_t('هذا الكتالوج دليل منتقى، وليس ضمانًا لجودة أو توفر كل خدمة. لا نرسل طلبات تلقائية جماعية ولا نخزن مفاتيح API. راجع شروط كل خدمة قبل الاستخدام.', 'This is a curated directory, not a guarantee of service quality or availability. We do not run bulk requests or store API keys. Review each service terms before use.')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(_t('فهمت', 'Understood')))]));
}
