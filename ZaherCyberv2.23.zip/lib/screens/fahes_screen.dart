import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/fahes_service.dart';
import '../services/url_audit_service.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';

class FahesScreen extends StatefulWidget {
  const FahesScreen({super.key});

  @override
  State<FahesScreen> createState() => _FahesScreenState();
}

class _FahesScreenState extends State<FahesScreen> {
  final _url = TextEditingController();
  final _urlhausKey = TextEditingController();
  final _threatFoxKey = TextEditingController();
  final _audit = UrlAuditService();
  final _fahes = FahesService();
  UrlAuditResult? _localResult;
  FahesCheckResult? _remoteResult;
  bool _busy = false;
  bool _showUrlhausKey = false;
  bool _showThreatFoxKey = false;

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  bool get _en => Localizations.localeOf(context).languageCode == 'en';
  String _t(String ar, String en) => copy(context, ar, en);

  @override
  void dispose() {
    _url.dispose();
    _urlhausKey.dispose();
    _threatFoxKey.dispose();
    _fahes.dispose();
    super.dispose();
  }

  void _runLocal() {
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() {
      _localResult = _audit.analyze(_url.text);
      _remoteResult = null;
    });
  }

  Future<bool> _confirmExternal() async =>
      await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: Text(
            _t(
              'إرسال الرابط إلى قواعد خارجية؟',
              'Send URL to external databases?',
            ),
          ),
          content: SingleChildScrollView(
            child: Text(
              _t(
                'سيُرسل الرابط كاملاً، بما فيه المسار ومعاملات الاستعلام، إلى PhishTank. وسيُرسل أيضاً إلى URLhaus وThreatFox إذا أدخلت مفاتيحهما. قد تحتفظ هذه الخدمات بالاستعلامات وفق سياساتها. لا تستخدم رابطاً داخلياً أو خاصاً أو يحوي رمز دخول أو استعادة كلمة مرور. الفحص المحلي وحده لا يرسل شيئاً. هل توافق على الفحص الخارجي الآن؟',
                'The complete URL, including path and query parameters, will be sent to PhishTank and also to URLhaus and ThreatFox if their keys are entered. These services may retain queries under their policies. Do not submit private or internal links or URLs containing login or password-reset tokens. Local-only analysis sends nothing. Do you consent to external checks now?',
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: Text(_t('إلغاء', 'Cancel')),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: Text(_t('أوافق وأتابع', 'I agree and continue')),
            ),
          ],
        ),
      ) ??
      false;

  Future<void> _checkSources() async {
    FocusManager.instance.primaryFocus?.unfocus();
    final local = _audit.analyze(_url.text);
    setState(() {
      _localResult = local;
      _remoteResult = null;
    });
    if (!local.valid || !await _confirmExternal() || !mounted) return;
    setState(() => _busy = true);
    try {
      final result = await _fahes.checkUrl(
        url: local.normalizedUrl!,
        localAudit: local,
        urlhausAuthKey: _urlhausKey.text,
        threatFoxAuthKey: _threatFoxKey.text,
      );
      if (mounted) setState(() => _remoteResult = result);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'تعذّر إكمال الفحص. تحقق من الاتصال وحاول لاحقاً.',
                'The check could not be completed. Check your connection and try again.',
              ),
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openAuthPortal() async {
    try {
      await launchUrl(
        Uri.https('auth.abuse.ch'),
        mode: LaunchMode.externalApplication,
      );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'تعذّر فتح صفحة التسجيل.',
                'Could not open the registration page.',
              ),
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    final local = _localResult;
    return Material(
      key: const ValueKey('fahes-screen'),
      color: p.background,
      borderRadius: BorderRadius.circular(22),
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(14, 10, 8, 8),
              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: p.accent.withValues(alpha: .12),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Icon(Icons.travel_explore_rounded, color: p.accent),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _t('فاحص | FAHES', 'FAHES | URL Checker'),
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text(
                          _t(
                            'تحليل محلي وقواعد سمعة مجتمعية',
                            'Local analysis and community reputation sources',
                          ),
                          style: TextStyle(color: p.muted, fontSize: 10),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: _t('إغلاق', 'Close'),
                    onPressed: _busy ? null : () => Navigator.of(context).pop(),
                    icon: Icon(Icons.close_rounded, color: p.muted),
                  ),
                ],
              ),
            ),
            Divider(height: 1, color: p.border),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(14),
                children: [
                  _privacyNotice(p),
                  const SizedBox(height: 12),
                  TextField(
                    key: const ValueKey('fahes-url-input'),
                    controller: _url,
                    keyboardType: TextInputType.url,
                    textInputAction: TextInputAction.search,
                    autocorrect: false,
                    enableSuggestions: false,
                    onSubmitted: (_) => _runLocal(),
                    decoration: InputDecoration(
                      labelText: _t('الرابط المراد فحصه', 'URL to check'),
                      hintText: 'https://example.com/path',
                      prefixIcon: Icon(Icons.link_rounded, color: p.accent),
                    ),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    key: const ValueKey('fahes-local-check'),
                    onPressed: _busy ? null : _runLocal,
                    icon: const Icon(Icons.phonelink_lock_rounded),
                    label: Text(_t('تحليل محلي فقط', 'Local-only analysis')),
                  ),
                  ExpansionTile(
                    key: const ValueKey('fahes-optional-keys'),
                    tilePadding: EdgeInsets.zero,
                    childrenPadding: const EdgeInsets.only(bottom: 8),
                    leading: Icon(Icons.key_rounded, color: p.accent),
                    title: Text(
                      _t(
                        'مفاتيح اختيارية لـURLhaus وThreatFox',
                        'Optional URLhaus and ThreatFox keys',
                      ),
                    ),
                    subtitle: Text(
                      _t(
                        'PhishTank يقبل طلبات قليلة دون مفتاح',
                        'PhishTank accepts low-volume lookups without a key',
                      ),
                    ),
                    children: [
                      _keyField(
                        _urlhausKey,
                        'URLhaus Auth-Key',
                        _showUrlhausKey,
                        () =>
                            setState(() => _showUrlhausKey = !_showUrlhausKey),
                      ),
                      const SizedBox(height: 8),
                      _keyField(
                        _threatFoxKey,
                        'ThreatFox Auth-Key',
                        _showThreatFoxKey,
                        () => setState(
                          () => _showThreatFoxKey = !_showThreatFoxKey,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        _t(
                          'المفاتيح لا تُحفظ وتبقى في ذاكرة هذه النافذة. لا تضعها في الشيفرة أو ترسلها لأحد.',
                          'Keys are not saved and remain only in this window memory. Never embed or share them.',
                        ),
                        style: TextStyle(color: p.muted, fontSize: 10),
                      ),
                      Align(
                        alignment: AlignmentDirectional.centerStart,
                        child: TextButton.icon(
                          onPressed: _openAuthPortal,
                          icon: const Icon(Icons.open_in_new_rounded, size: 16),
                          label: Text(
                            _t(
                              'الحصول على Auth-Key مجاني',
                              'Get a free Auth-Key',
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  FilledButton.icon(
                    key: const ValueKey('fahes-check-sources'),
                    onPressed: _busy ? null : _checkSources,
                    icon: const Icon(Icons.travel_explore_rounded),
                    label: Text(
                      _t(
                        'فحص قواعد التهديد الثلاث',
                        'Check the three threat databases',
                      ),
                    ),
                  ),
                  if (_busy) ...[
                    const SizedBox(height: 12),
                    LinearProgressIndicator(color: p.accent),
                    const SizedBox(height: 6),
                    Text(
                      _t(
                        'جارٍ التحقق من المصادر المتاحة…',
                        'Checking available sources…',
                      ),
                      style: TextStyle(color: p.muted, fontSize: 10),
                    ),
                  ],
                  if (local != null) ...[
                    const SizedBox(height: 13),
                    if (!local.valid)
                      _invalidCard(p, local)
                    else
                      _localResultCard(p, local),
                  ],
                  if (_remoteResult != null) ...[
                    const SizedBox(height: 12),
                    _remoteCard(p, _remoteResult!),
                  ],
                  const SizedBox(height: 12),
                  _limits(p),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _keyField(
    TextEditingController controller,
    String label,
    bool shown,
    VoidCallback toggle,
  ) => TextField(
    controller: controller,
    obscureText: !shown,
    autocorrect: false,
    enableSuggestions: false,
    decoration: InputDecoration(
      labelText: label,
      prefixIcon: const Icon(Icons.key_rounded),
      suffixIcon: IconButton(
        tooltip: shown
            ? _t('إخفاء المفتاح', 'Hide key')
            : _t('إظهار المفتاح', 'Show key'),
        onPressed: toggle,
        icon: Icon(
          shown ? Icons.visibility_off_rounded : Icons.visibility_rounded,
        ),
      ),
    ),
  );

  Widget _privacyNotice(AppPalette p) => Container(
    key: const ValueKey('fahes-local-privacy'),
    padding: const EdgeInsets.all(11),
    decoration: BoxDecoration(
      color: Colors.green.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(13),
      border: Border.all(color: Colors.green.withValues(alpha: .4)),
    ),
    child: Text(
      _t(
        'التحليل المحلي لا يرسل شيئاً. فحص قواعد التهديد خارجي واختياري، ويطلب موافقتك قبل إرسال الرابط.',
        'Local analysis sends nothing. Threat database checks are external and optional; consent is requested before sending the URL.',
      ),
      style: const TextStyle(fontSize: 11),
    ),
  );

  Widget _invalidCard(AppPalette p, UrlAuditResult result) => Container(
    padding: const EdgeInsets.all(11),
    decoration: BoxDecoration(
      color: Colors.red.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.red.withValues(alpha: .4)),
    ),
    child: Text(
      _en ? result.errorEn ?? '' : result.errorAr ?? '',
      style: TextStyle(color: p.text, fontSize: 11),
    ),
  );

  Widget _localResultCard(AppPalette p, UrlAuditResult result) => Container(
    key: const ValueKey('fahes-local-result'),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: p.surface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: p.border),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _t('التحليل البنيوي المحلي', 'Local structural analysis'),
          style: TextStyle(
            color: p.text,
            fontWeight: FontWeight.w900,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 5),
        SelectableText(
          result.normalizedUrl ?? '',
          style: TextStyle(color: p.muted, fontSize: 10),
        ),
        const SizedBox(height: 5),
        for (final finding in result.findings)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              '• ${_en ? finding.titleEn : finding.titleAr}: ${_en ? finding.detailEn : finding.detailAr}',
              style: TextStyle(color: p.muted, fontSize: 10),
            ),
          ),
      ],
    ),
  );

  Widget _remoteCard(AppPalette p, FahesCheckResult result) => Container(
    key: const ValueKey('fahes-remote-results'),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: p.surface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: p.border),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _t('نتائج قواعد التهديد', 'Threat database results'),
          style: TextStyle(
            color: p.text,
            fontWeight: FontWeight.w900,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 8),
        for (final source in result.sources) ...[
          _sourceCard(p, source),
          const SizedBox(height: 7),
        ],
        Text(
          _t(
            '«غير مدرج» تعني عدم العثور في هذه القاعدة فقط، ولا تثبت أن الرابط آمن. قد تكون قواعد البيانات متأخرة أو غير شاملة.',
            '“Not listed” only means no match in this database; it does not prove safety. Threat feeds can be delayed or incomplete.',
          ),
          style: TextStyle(color: p.muted, fontSize: 10),
        ),
      ],
    ),
  );

  Widget _sourceCard(AppPalette p, FahesSourceResult result) {
    final verdict = result.verdict;
    final color = switch (verdict) {
      FahesVerdict.listed => Colors.redAccent,
      FahesVerdict.unverified => Colors.orangeAccent,
      FahesVerdict.notListed => Colors.lightGreen,
      FahesVerdict.keyRequired => Colors.amber,
      FahesVerdict.unavailable => p.muted,
    };
    final status = switch (verdict) {
      FahesVerdict.listed => _t(
        'مدرج كمؤشر تهديد',
        'Listed as a threat indicator',
      ),
      FahesVerdict.unverified => _t(
        'السجل غير مؤكد/غير نشط',
        'Unconfirmed or inactive record',
      ),
      FahesVerdict.notListed => _t(
        'غير مدرج في هذه القاعدة',
        'Not listed in this database',
      ),
      FahesVerdict.keyRequired => _t(
        'مفتاح Auth-Key مطلوب',
        'Auth-Key required',
      ),
      FahesVerdict.unavailable => _t('تعذّر التحقق', 'Could not check'),
    };
    return Container(
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(
        color: p.raised,
        borderRadius: BorderRadius.circular(11),
        border: BorderDirectional(start: BorderSide(color: color, width: 3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  result.source,
                  style: TextStyle(
                    color: p.text,
                    fontWeight: FontWeight.w900,
                    fontSize: 11,
                  ),
                ),
              ),
              Text(
                status,
                style: TextStyle(
                  color: color,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 3),
          Text(
            _sourceDetail(result),
            style: TextStyle(color: p.muted, fontSize: 10),
          ),
          if (result.recordCount != null)
            Text(
              '${_t('السجلات المطابقة', 'Matching records')}: ${result.recordCount}',
              style: TextStyle(color: p.muted, fontSize: 9),
            ),
        ],
      ),
    );
  }

  String _sourceDetail(FahesSourceResult result) {
    if (_en) return result.detail ?? '';
    return switch (result.verdict) {
      FahesVerdict.listed when result.source == 'PhishTank' =>
        'ظهر الرابط في PhishTank كتقرير تصيد موثّق ونشط.',
      FahesVerdict.listed when result.source == 'URLhaus' =>
        'ظهر الرابط في قاعدة URLhaus المختصة بروابط توزيع البرمجيات الخبيثة. ${result.detail ?? ''}',
      FahesVerdict.listed =>
        'ظهر مؤشر مطابق في ThreatFox. ${result.detail ?? ''}',
      FahesVerdict.unverified =>
        'ظهر سجل في PhishTank لكن التقرير غير مؤكد أو غير نشط.',
      FahesVerdict.notListed when result.source == 'PhishTank' =>
        'لم يُعثر على سجل تصيد مطابق في PhishTank.',
      FahesVerdict.notListed when result.source == 'URLhaus' =>
        'لم يُعثر على سجل توزيع برمجيات خبيثة مطابق في URLhaus.',
      FahesVerdict.notListed => 'لم يُعثر على مؤشر مطابق في ThreatFox.',
      FahesVerdict.keyRequired =>
        'لم يُرسل الرابط إلى هذه الخدمة؛ أدخل مفتاح Auth-Key الشخصي.',
      FahesVerdict.unavailable =>
        'تعذّر الوصول إلى المصدر أو قراءة جوابه. لا يعني ذلك أن الرابط آمن.',
    };
  }

  Widget _limits(AppPalette p) => Container(
    padding: const EdgeInsets.all(11),
    decoration: BoxDecoration(
      color: p.raised,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: p.border),
    ),
    child: Text(
      _t(
        'FAHES يجمع قواعد مجتمعية متخصصة وليس ماسحاً متعدد المحركات مثل VirusTotal. PhishTank يركّز على التصيد، وURLhaus على روابط توزيع البرمجيات الخبيثة، وThreatFox على مؤشرات الاختراق. النتيجة غير المدرجة لا تثبت السلامة. لا تفحص روابط سرية أو داخلية عبر المصادر الخارجية.',
        'FAHES combines specialized community databases; it is not a multi-engine scanner like VirusTotal. PhishTank focuses on phishing, URLhaus on malware URLs, and ThreatFox on threat indicators. A non-match does not prove safety. Never send private or internal URLs to external sources.',
      ),
      style: TextStyle(color: p.muted, fontSize: 10),
    ),
  );
}
