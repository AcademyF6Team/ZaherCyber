import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/project_links.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../utils/app_version.dart';
import '../widgets/page_navigation_controls.dart';

class AboutCenterScreen extends StatelessWidget {
  const AboutCenterScreen({
    super.key,
    required this.locale,
    required this.onManageSources,
    required this.onClearFeedCache,
    required this.onClearBookmarks,
    required this.onClearLearningProgress,
    required this.onResetDesktop,
    required this.onOpenProtection,
    required this.sourceCount,
    required this.projectCount,
    required this.resourceCount,
    required this.quarantinedCount,
  });

  final Locale locale;
  final VoidCallback onManageSources;
  final Future<void> Function() onClearFeedCache;
  final Future<void> Function() onClearBookmarks;
  final Future<void> Function() onClearLearningProgress;
  final Future<void> Function() onResetDesktop;
  final VoidCallback onOpenProtection;
  final int sourceCount;
  final int projectCount;
  final int resourceCount;
  final int quarantinedCount;

  String _t(BuildContext context, String ar, String en) =>
      copy(context, ar, en);

  @override
  Widget build(BuildContext context) {
    final p = Theme.of(context).extension<AppPalette>()!;
    return Scaffold(
      backgroundColor: p.background,
      appBar: AppBar(
        backgroundColor: p.background,
        foregroundColor: p.text,
        leading: pageBackButton(context),
        actions: pageNavigationActions(context),
        title: Text(_t(context, 'حول التطبيق', 'About ZaherCyber')),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          _hero(context, p),
          const SizedBox(height: 16),
          _tile(
            context,
            p,
            Icons.privacy_tip_outlined,
            _t(
              context,
              'الخصوصية وإدارة البيانات',
              'Privacy & data management',
            ),
            _t(
              context,
              'خريطة البيانات المحلية والاتصالات وخيارات المسح.',
              'Local data, network activity, and separate clear-data actions.',
            ),
            () => _open(context, _privacyPage(context, p)),
          ),
          _tile(
            context,
            p,
            Icons.health_and_safety_outlined,
            _t(context, 'السلامة والتنزيلات', 'Safety & downloads'),
            _t(
              context,
              'الأذونات، التحقق من الملفات، وإرشادات الاستخدام الآمن.',
              'Permissions, file verification, and safe-use guidance.',
            ),
            () => _open(context, _safetyPage(context, p)),
          ),
          _tile(
            context,
            p,
            Icons.rss_feed_rounded,
            _t(context, 'المصادر والمحتوى', 'Sources & content'),
            _t(
              context,
              '$sourceCount مصدر · $quarantinedCount مؤرشف مؤقتاً بعد إخفاقات متكررة',
              '$sourceCount feeds · $quarantinedCount temporarily quarantined after repeated failures',
            ),
            () => _open(context, _sourcesPage(context, p)),
          ),
          _tile(
            context,
            p,
            Icons.help_outline_rounded,
            _t(context, 'دليل الاستخدام والمساعدة', 'User guide & help'),
            _t(
              context,
              'أسئلة شائعة حول التحديث والتنزيل وحجم النص.',
              'FAQs about refreshes, downloads, and text size.',
            ),
            () => _open(context, _helpPage(context, p)),
          ),
          _tile(
            context,
            p,
            Icons.groups_2_outlined,
            _t(context, 'المشروع والفريق', 'Project & team'),
            _t(
              context,
              'الهدف، بيانات المطور، الأكاديمية، والقناة الرسمية.',
              'Mission, developer, academy, and official channel.',
            ),
            () => _open(context, _projectPage(context, p)),
          ),
        ],
      ),
    );
  }

  Widget _hero(BuildContext context, AppPalette p) => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: p.surface,
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: p.border),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [p.accent.withValues(alpha: .17), p.surface],
      ),
    ),
    child: Column(
      children: [
        Container(
          width: 70,
          height: 70,
          decoration: BoxDecoration(
            color: p.accent.withValues(alpha: .15),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Icon(Icons.security_rounded, color: p.accent, size: 38),
        ),
        const SizedBox(height: 12),
        Text(
          'ZaherCyber',
          style: TextStyle(
            color: p.text,
            fontSize: 23,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          _t(
            context,
            'مركز أخبار وتقنيات الأمن السيبراني',
            'Cybersecurity & technology intelligence',
          ),
          textAlign: TextAlign.center,
          style: TextStyle(color: p.muted, fontSize: 12),
        ),
        const SizedBox(height: 10),
        DecoratedBox(
          decoration: BoxDecoration(
            color: p.background,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: p.border),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Text(
              '${_t(context, 'الإصدار', 'Version')} $appVersionLabel',
              style: TextStyle(
                color: p.accent,
                fontWeight: FontWeight.w800,
                fontSize: 11,
              ),
            ),
          ),
        ),
      ],
    ),
  );

  Widget _tile(
    BuildContext context,
    AppPalette p,
    IconData icon,
    String title,
    String subtitle,
    VoidCallback onTap,
  ) => Padding(
    padding: const EdgeInsets.only(top: 9),
    child: Material(
      color: p.surface,
      borderRadius: BorderRadius.circular(17),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
        leading: Icon(icon, color: p.accent, size: 23),
        title: Text(
          title,
          style: TextStyle(
            color: p.text,
            fontWeight: FontWeight.w800,
            fontSize: 12,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(color: p.muted, fontSize: 10, height: 1.4),
        ),
        trailing: Icon(Icons.chevron_right_rounded, color: p.muted),
        onTap: onTap,
      ),
    ),
  );

  void _open(BuildContext context, Widget page) =>
      Navigator.of(context).push<void>(MaterialPageRoute(builder: (_) => page));

  Widget _subpage(
    BuildContext context,
    AppPalette p,
    String title,
    List<Widget> children,
  ) => Scaffold(
    backgroundColor: p.background,
    appBar: AppBar(
      backgroundColor: p.background,
      foregroundColor: p.text,
      leading: pageBackButton(context),
      actions: pageNavigationActions(context),
      title: Text(title),
    ),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
      children: children,
    ),
  );

  Widget _section(
    BuildContext context,
    AppPalette p,
    String title,
    String body, {
    IconData icon = Icons.info_outline,
  }) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: p.surface,
      borderRadius: BorderRadius.circular(17),
      border: Border.all(color: p.border),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: p.accent, size: 20),
        const SizedBox(width: 11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: p.text,
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                body,
                style: TextStyle(color: p.muted, fontSize: 11, height: 1.55),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _privacyPage(
    BuildContext context,
    AppPalette p,
  ) => _subpage(context, p, _t(context, 'الخصوصية والبيانات', 'Privacy & data'), [
    _section(
      context,
      p,
      _t(
        context,
        'بيانات تبقى على هذا الجهاز',
        'Data that stays on this device',
      ),
      _t(
        context,
        'المحفوظات ووسومها، إعدادات اللغة والثيم والنص، تقدم التعلم، تخصيص سطح المكتب، وحالة الموجزات ونسخها المخزنة تحفظ محلياً في مساحة التطبيق. لا يتطلب المشروع حساب مستخدم أو خادماً وسيطاً للموجزات.',
        'Bookmarks and their tags, language/theme/text preferences, learning progress, desktop personalization, feed-health state, and cached feeds are stored locally in app storage. The app does not require an account or a proxy server for feeds.',
      ),
      icon: Icons.phone_android_rounded,
    ),
    _section(
      context,
      p,
      _t(context, 'متى يتصل التطبيق؟', 'When the app connects'),
      _t(
        context,
        'عند تحديث الأخبار أو المقالات أو بيانات الثغرات/المشروعات، يتصل التطبيق مباشرةً بالنطاقات الناشرة. يرى الناشر طلب الشبكة وبيانات الاتصال المعتادة مثل عنوان IP؛ وعند فتح موقع خارجي تنطبق سياسة ذلك الموقع.',
        'When refreshing feeds, vulnerability data, or project releases, the app connects directly to publishers. A publisher can receive the network request and ordinary connection metadata such as your IP address. Opening an external site is subject to that site’s policy.',
      ),
      icon: Icons.public_rounded,
    ),
    _section(
      context,
      p,
      _t(context, 'خريطة البيانات', 'Data map'),
      _t(
        context,
        'المحفوظات: محلياً. تقدم التعلم: محلياً ويمكن تصديره من مركز التعلم. الأخبار والمقالات: ذاكرة مؤقتة محلية تُجلب من ناشريها. ملفات التنزيل: مجلد التنزيلات الذي تختاره/يستخدمه Android. لا تُمسح الملفات أو المحفوظات عند مسح ذاكرة الأخبار.',
        'Bookmarks: local. Learning progress: local and exportable from the Learning Center. News/tutorials: local cache fetched from publishers. Downloads: the Android downloads location. Clearing news cache does not remove bookmarks or downloaded files.',
      ),
      icon: Icons.account_tree_outlined,
    ),
    _section(
      context,
      p,
      _t(context, 'مسح بيانات محددة', 'Clear selected data'),
      _t(
        context,
        'كل إجراء أدناه منفصل ويعرض تأكيداً قبل التنفيذ. مسح تقدم التعلم لا يمس الأخبار أو المحفوظات. إعادة ضبط سطح المكتب لا تمس التقدم أو التنزيلات.',
        'Each action is separate and asks for confirmation. Clearing learning progress does not affect news or bookmarks. Resetting desktop personalization does not affect progress or downloads.',
      ),
      icon: Icons.delete_sweep_outlined,
    ),
    _action(
      context,
      p,
      Icons.cached_rounded,
      _t(context, 'مسح ذاكرة الأخبار والمقالات', 'Clear news/tutorial cache'),
      _t(
        context,
        'يحتفظ بالمحفوظات والتنزيلات.',
        'Keeps bookmarks and downloads.',
      ),
      onClearFeedCache,
    ),
    _action(
      context,
      p,
      Icons.bookmark_remove_outlined,
      _t(context, 'مسح المحفوظات والوسوم', 'Clear saved stories and tags'),
      _t(
        context,
        'يحذف عناصر المحفوظات والوسوم فقط.',
        'Removes bookmarks and tags only.',
      ),
      onClearBookmarks,
    ),
    _action(
      context,
      p,
      Icons.school_outlined,
      _t(context, 'مسح تقدم التعلم', 'Clear learning progress'),
      _t(
        context,
        'يحذف الدروس المكتملة ونتائج الاختبارات وتقييمات البطاقات فقط.',
        'Removes completed lessons, quiz scores, and flashcard ratings only.',
      ),
      onClearLearningProgress,
    ),
    _action(
      context,
      p,
      Icons.dashboard_customize_outlined,
      _t(
        context,
        'إعادة ضبط تخصيص سطح المكتب',
        'Reset desktop personalization',
      ),
      _t(
        context,
        'يعيد ترتيب التطبيقات والودجتس وخطة الاستعداد إلى الوضع الافتراضي.',
        'Resets app order, widgets, and readiness/defense checklists.',
      ),
      onResetDesktop,
    ),
  ]);

  Widget _safetyPage(
    BuildContext context,
    AppPalette p,
  ) => _subpage(context, p, _t(context, 'السلامة والتنزيلات', 'Safety & downloads'), [
    _section(
      context,
      p,
      _t(context, 'لا يوجد فحص للجهاز', 'No device scanning'),
      _t(
        context,
        'ZaherCyber يعرض الأخبار والمراجع ولا يفحص الهاتف أو يثبت أن الجهاز آمن. تمارين سطح المكتب تعليمية محلية وليست تحليلاً للشبكة أو الجهاز.',
        'ZaherCyber presents news and references; it does not scan your phone or certify it as secure. Desktop exercises are local learning activities, not device or network analysis.',
      ),
      icon: Icons.shield_outlined,
    ),
    _section(
      context,
      p,
      _t(context, 'تحقق من الملف قبل تثبيته', 'Verify files before installing'),
      _t(
        context,
        'استخدم صفحة الإصدار الرسمية، راجع اسم الناشر والمنصة والمعمارية والترخيص، وقارن SHA-256 ببصمة ينشرها المشروع عبر قناة مستقلة عند توفرها. البصمة المحسوبة محلياً وحدها لا تثبت هوية الناشر.',
        'Use the official release page, check publisher, platform, architecture, and license, and compare SHA-256 with a value published independently by the project when available. A locally calculated hash alone does not prove publisher identity.',
      ),
      icon: Icons.verified_outlined,
    ),
    _section(
      context,
      p,
      _t(context, 'أذونات Android', 'Android permissions'),
      _t(
        context,
        'على Android 10 فأحدث يستخدم التطبيق MediaStore للتنزيلات دون إذن تخزين عام. في Android 9 وأقدم قد يظهر إذن تخزين قديم عند اختيار النسخ إلى مجلد التنزيلات. تثبيت APK يمر عبر مثبت النظام وباختيار المستخدم؛ لا يوجد تثبيت صامت.',
        'On Android 10+, downloads use MediaStore without broad storage access. Android 9 and earlier may request legacy storage access when copying to Downloads. APK installation uses the system installer after user action; there is no silent installation.',
      ),
      icon: Icons.admin_panel_settings_outlined,
    ),
    _action(
      context,
      p,
      Icons.health_and_safety_outlined,
      _t(context, 'فتح مركز الحماية', 'Open Protection Center'),
      _t(
        context,
        'أدلة عامة للحماية والاستجابة، وليست تشخيصاً.',
        'General hardening and response guides, not a diagnosis.',
      ),
      () async {
        onOpenProtection();
      },
      confirm: false,
    ),
  ]);

  Widget _sourcesPage(
    BuildContext context,
    AppPalette p,
  ) => _subpage(context, p, _t(context, 'المصادر والمحتوى', 'Sources & content'), [
    _section(
      context,
      p,
      _t(context, 'مصادر الناشرين', 'Publisher sources'),
      _t(
        context,
        'الأخبار والشروحات تأتي من موجزات الناشرين. قد تتغير الروابط أو الصيغ أو سياسات الوصول. يعرض التطبيق المصدر ورابط المقال الأصلي متى توفر.',
        'News and tutorials come from publisher feeds. URLs, formats, and access policies may change. The app shows the publisher and original article link when available.',
      ),
      icon: Icons.rss_feed_rounded,
    ),
    _section(
      context,
      p,
      _t(context, 'التعطل والإخفاء المؤقت', 'Temporary feed quarantine'),
      _t(
        context,
        'بعد ثلاث إخفاقات مؤهلة تمتد على 48 ساعة على الأقل، يُستبعد المصدر مؤقتاً من التحديث المعتاد ولا يُحذف من القائمة. أخطاء الشبكة العامة التي تفشل فيها كل المصادر معاً لا تُحتسب. تُتجنب أخطاء 401/403/429 لتقليل الإخفاء الخاطئ. يُعاد فحص المصدر المؤرشف كل 24 ساعة عندما يكون التطبيق مفتوحاً، أو يمكن استعادته يدوياً.',
        'After at least three eligible failures spanning 48 hours, a feed is temporarily excluded from routine refresh, not deleted. A whole-cycle connectivity failure is not counted. 401/403/429 responses are excluded to reduce false positives. Quarantined feeds are rechecked every 24 hours while the app is open, or can be restored manually.',
      ),
      icon: Icons.timer_outlined,
    ),
    _section(
      context,
      p,
      _t(context, 'محتوى دفاعي وتعليمي', 'Defensive learning content'),
      _t(
        context,
        'المراجع الخارجية أدوات قراءة وتدريب. استخدم المختبرات ضمن بيئة تملكها أو لديك إذن صريح لاختبارها، واتبع الترخيص وشروط كل ناشر.',
        'External references are for reading and training. Use labs only in environments you own or are explicitly authorized to test, and follow each publisher’s terms and license.',
      ),
      icon: Icons.school_outlined,
    ),
    _action(
      context,
      p,
      Icons.manage_search_rounded,
      _t(context, 'إدارة المصادر', 'Manage feeds'),
      _t(
        context,
        'ابحث، عطّل، أو استعد مصدراً مؤرشفاً.',
        'Search, disable, or restore a quarantined source.',
      ),
      () async {
        onManageSources();
      },
      confirm: false,
    ),
  ]);

  Widget _helpPage(
    BuildContext context,
    AppPalette p,
  ) => _subpage(context, p, _t(context, 'المساعدة وإمكانية الوصول', 'Help & accessibility'), [
    _section(
      context,
      p,
      _t(context, 'دليل البدء السريع', 'Quick start guide'),
      _t(
        context,
        'ابدأ من سطح F6-OS: افتح الأخبار لمتابعة المستجدات، مركز الحماية لقائمة الأمان، المعرفة والأكاديمية للتعلم، FAHES لفحص الروابط التي تملك تصريحاً بفحصها، وWorkbench للأدوات المحلية وكتالوج API والتقارير. استخدم البحث العام للوصول السريع، واحفظ ما تريد الرجوع إليه لاحقاً.',
        'Start at F6-OS: use News for updates, Protection for the security checklist, Knowledge and Academy for learning, FAHES for authorized link checks, and Workbench for local tools, API catalog, and reports. Use global search and save items for later.',
      ),
      icon: Icons.menu_book_outlined,
    ),
    _section(
      context,
      p,
      _t(context, 'ما الذي يعمل محلياً؟', 'What works locally?'),
      _t(
        context,
        'أدوات JSON وJWT وURL والبصمة وبعض أدوات الخصوصية تعمل على الجهاز. لا تضع رموزاً أو مفاتيح حقيقية في الحقول. العناصر الخارجية تفتح في المتصفح بعد موافقتك وقد تعالج البيانات وفق سياسة الناشر.',
        'JSON, JWT, URL, hash, and privacy utilities work on-device. Never paste real secrets or tokens. External resources open in the browser after your consent and follow the publisher policy.',
      ),
      icon: Icons.phonelink_lock_outlined,
    ),
    _section(
      context,
      p,
      _t(context, 'الصلاحيات والإشعارات', 'Permissions & notifications'),
      _t(
        context,
        'يطلب التطبيق إذن الإشعارات بعد إكمال الترحيب لإرسال تحديثات التطبيق والأخبار والتنبيهات. يمكنك رفضه والاستمرار. لا يطلب التطبيق الكاميرا أو الميكروفون أو جهات الاتصال أو الموقع.',
        'The app requests notifications after onboarding for app updates, news, and alerts. You can deny them and continue. The app does not request camera, microphone, contacts, or location access.',
      ),
      icon: Icons.notifications_active_outlined,
    ),
    _section(
      context,
      p,
      _t(context, 'المحتوى الحساس', 'Sensitive content'),
      _t(
        context,
        'الموارد التي تحتاج تفويضاً أو قد تُستخدم بشكل ضار مصنفة كمقيدة ولا يتم تشغيلها أو تحميلها داخل التطبيق. استخدم المختبرات التعليمية فقط على بيئات تملكها أو لديك تصريح لاختبارها.',
        'Resources requiring authorization or capable of misuse are marked restricted and are not executed or downloaded in-app. Use training labs only on environments you own or are authorized to test.',
      ),
      icon: Icons.gpp_maybe_outlined,
    ),
    _section(
      context,
      p,
      _t(context, 'لماذا لم يتحدث مصدر؟', 'Why did a feed not refresh?'),
      _t(
        context,
        'قد يكون الاتصال منقطعاً أو الناشر يحدّ الطلبات أو غيّر صيغة الموجز. تحقق من الشبكة، افتح إدارة المصادر، واستعد المصدر يدوياً إذا تأكدت من عودته.',
        'Connectivity, publisher rate limits, or a changed feed format can interrupt updates. Check the network and use Manage Feeds to restore a source if it is available again.',
      ),
      icon: Icons.sync_problem_rounded,
    ),
    _section(
      context,
      p,
      _t(
        context,
        'لماذا لا يظهر إذن التخزين؟',
        'Why is storage permission absent?',
      ),
      _t(
        context,
        'Android 10 فأحدث يدعم الحفظ عبر MediaStore دون إذن تخزين عام. على الإصدارات الأقدم لا يُطلب الإذن إلا عند اختيار إجراء يحتاج إليه.',
        'Android 10+ supports MediaStore downloads without broad storage permission. Older versions request permission only for an action that needs it.',
      ),
      icon: Icons.folder_open_outlined,
    ),
    _section(
      context,
      p,
      _t(context, 'تكبير النص وقارئ الشاشة', 'Text scaling & screen readers'),
      _t(
        context,
        'استخدم إعداد حجم النص في الإعدادات، مع تكبير الخط في النظام. أضيفت تسميات لأزرار الإجراءات؛ وقد يختلف التفاف النص حسب لغة الجهاز وحجم الشاشة.',
        'Use the text-size control in Settings along with system font scaling. Actions use descriptive labels; wrapping can vary with device language and screen size.',
      ),
      icon: Icons.accessibility_new_rounded,
    ),
    _section(
      context,
      p,
      _t(
        context,
        'التوفر والتحديث في الخلفية',
        'Availability & background refresh',
      ),
      _t(
        context,
        'تعتمد الروابط على الناشرين والاتصال. التحديث يجري عند فتح التطبيق أو أثناء بقائه نشطاً وفق إعداد الفاصل؛ قد يوقف Android التطبيق بعد إغلاقه.',
        'Links depend on publishers and connectivity. Refresh occurs on launch or while the app is active according to the chosen interval; Android may suspend work after closure.',
      ),
      icon: Icons.wifi_rounded,
    ),
  ]);

  Widget _projectPage(
    BuildContext context,
    AppPalette p,
  ) => _subpage(context, p, _t(context, 'المشروع والفريق', 'Project & team'), [
    _section(
      context,
      p,
      _t(context, 'عن ZaherCyber', 'About ZaherCyber'),
      _t(
        context,
        'مركز عربي/إنجليزي للأخبار التقنية والأمن السيبراني، ومشروعات مفتوحة المصدر، ومسارات تعلّم وأدلة حماية.',
        'An Arabic/English hub for technology and cybersecurity news, open-source projects, learning paths, and protection guides.',
      ),
      icon: Icons.security_rounded,
    ),
    _section(
      context,
      p,
      _t(context, 'برمجة وتطوير', 'Programming & development'),
      locale.languageCode == 'ar'
          ? 'زاهر عباس آل عاشور'
          : 'Zaher Abbas Al-Ashour',
      icon: Icons.person_outline_rounded,
    ),
    _section(
      context,
      p,
      _t(context, 'الأكاديمية', 'Academy'),
      'F6-Team',
      icon: Icons.school_outlined,
    ),
    _section(
      context,
      p,
      _t(context, 'محتوى منسق', 'Curated content'),
      '$sourceCount ${_t(context, 'موجزاً', 'feeds')} · $projectCount ${_t(context, 'مشروعاً', 'projects')} · $resourceCount ${_t(context, 'مرجعاً', 'references')}',
      icon: Icons.library_books_outlined,
    ),
    _action(
      context,
      p,
      Icons.campaign_outlined,
      _t(context, 'قناة ZaherCyber الرسمية', 'Official ZaherCyber channel'),
      _t(
        context,
        'إعلانات المشروع؛ تفتح خدمة خارجية.',
        'Project announcements; opens an external service.',
      ),
      () async => _openUrl('${zaherCyberProjectTelegramUrl}'),
      confirm: false,
    ),
  ]);

  Widget _action(
    BuildContext context,
    AppPalette p,
    IconData icon,
    String title,
    String subtitle,
    Future<void> Function() action, {
    bool confirm = true,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Material(
      color: p.surface,
      borderRadius: BorderRadius.circular(16),
      child: ListTile(
        leading: Icon(icon, color: p.accent),
        title: Text(
          title,
          style: TextStyle(
            color: p.text,
            fontWeight: FontWeight.w800,
            fontSize: 12,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(color: p.muted, fontSize: 10),
        ),
        onTap: () => confirm
            ? _confirmAndRun(context, p, title, subtitle, action)
            : action(),
      ),
    ),
  );

  Future<void> _confirmAndRun(
    BuildContext context,
    AppPalette p,
    String title,
    String body,
    Future<void> Function() action,
  ) async {
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: p.surface,
        title: Text(title, style: TextStyle(color: p.text)),
        content: Text(body, style: TextStyle(color: p.muted, height: 1.45)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(_t(context, 'إلغاء', 'Cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(_t(context, 'تأكيد', 'Confirm')),
          ),
        ],
      ),
    );
    if (accepted == true && context.mounted) await action();
  }

  Future<void> _openUrl(String value) async {
    final uri = Uri.tryParse(value);
    if (uri != null && uri.scheme == 'https')
      await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}
