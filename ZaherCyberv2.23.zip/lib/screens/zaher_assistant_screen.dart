import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../widgets/page_navigation_controls.dart';

class ZaherAssistantScreen extends StatefulWidget {
  const ZaherAssistantScreen({super.key, this.onOpenSection});

  final ValueChanged<String>? onOpenSection;

  @override
  State<ZaherAssistantScreen> createState() => _ZaherAssistantScreenState();
}

class _Answer {
  const _Answer(this.titleAr, this.titleEn, this.bodyAr, this.bodyEn, this.section, this.icon);
  final String titleAr;
  final String titleEn;
  final String bodyAr;
  final String bodyEn;
  final String? section;
  final IconData icon;
}

class _ZaherAssistantScreenState extends State<ZaherAssistantScreen> {
  final _input = TextEditingController();
  final List<_Answer> _messages = [];
  bool get _en => Localizations.localeOf(context).languageCode == 'en';
  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  String _t(String ar, String en) => copy(context, ar, en);

  static const _answers = <_Answer>[
    _Answer('دليل التطبيق', 'App guide', 'استخدم سطح F6-OS للوصول إلى الأخبار، الحماية، المعرفة، FAHES، الترسانة، والأدوات. افتح «حول التطبيق → دليل الاستخدام» لشرح كامل.', 'Use F6-OS to reach News, Protection, Knowledge, FAHES, Arsenal, and tools. Open About → User guide for the full guide.', null, Icons.menu_book_outlined),
    _Answer('مركز الحماية', 'Protection Center', 'يحتوي على قائمة تقوية، درجة تقدم محلية، حسابات بلا أسرار، أدلة حوادث، سجل محلي، قائمة متابعة، وتذكيرات وخصوصية.', 'It contains hardening checklists, a local score, secret-free account tracking, incident playbooks, a local log, watchlist, reminders, and privacy tools.', 'protection', Icons.health_and_safety_outlined),
    _Answer('FAHES', 'FAHES', 'افتح FAHES لفحص رابط تملكه أو لديك تصريح بفحصه. التحليل المحلي لا يرسل الرابط، والفحص الخارجي يحتاج موافقة منفصلة.', 'Open FAHES to inspect a URL you own or are authorized to assess. Local analysis does not send the URL; external checks require separate consent.', 'fahes', Icons.radar_rounded),
    _Answer('الترسانة', 'Arsenal', 'الترسانة كتالوج أدوات ومصادر رسمية. استخدم البحث والتصنيفات، راجع متطلبات كل أداة، ولا تستخدم أي أداة على هدف بلا تصريح.', 'Arsenal is a catalog of official tools and sources. Search and filter it, review requirements, and never test an unauthorized target.', 'arsenal', Icons.security_update_good_rounded),
    _Answer('Workbench', 'Workbench', 'افتح مركز العمل الأمني للوصول إلى API Hub، المختبر، Security Library، الأدوات المحلية، التقارير، صحة الخدمات، والاستجابة للحوادث.', 'Open Security Workbench for API Hub, the lab, Security Library, local tools, reports, service health, and incident response.', 'security-workbench', Icons.hub_outlined),
    _Answer('الإشعارات', 'Notifications', 'يُطلب إذن الإشعارات بعد الترحيب لتحديثات التطبيق والأخبار وCVE والدروس. يمكنك الرفض ومتابعة استخدام التطبيق.', 'Notifications are requested after onboarding for app updates, news, CVEs, and lessons. You can deny them and continue.', null, Icons.notifications_active_outlined),
  ];

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  void _ask([String? preset]) {
    final query = (preset ?? _input.text).trim().toLowerCase();
    if (query.isEmpty) return;
    final answer = _answers.firstWhere((item) {
      final text = '${item.titleAr} ${item.titleEn} ${item.bodyAr} ${item.bodyEn}'.toLowerCase();
      return query.split(' ').any((word) => word.length > 2 && text.contains(word));
    }, orElse: () => _answers.first);
    setState(() => _messages.add(answer));
    _input.clear();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: _p.background,
    appBar: AppBar(leading: pageBackButton(context), actions: [pageHomeButton(context)], title: Text(_t('Zaher Assistant', 'Zaher Assistant'))),
    body: Column(children: [
      _intro(),
      Expanded(child: _messages.isEmpty ? _suggestions() : ListView.builder(padding: const EdgeInsets.all(14), itemCount: _messages.length, itemBuilder: (_, index) => _answerCard(_messages[index]))),
      _composer(),
    ]),
  );

  Widget _intro() => Padding(padding: const EdgeInsets.fromLTRB(14, 14, 14, 4), child: Card(color: _p.surface, child: ListTile(leading: CircleAvatar(backgroundColor: _p.accent.withValues(alpha: .16), child: Icon(Icons.auto_awesome, color: _p.accent)), title: Text(_t('مساعد محلي', 'Local assistant'), style: TextStyle(color: _p.text, fontWeight: FontWeight.w900)), subtitle: Text(_t('يشرح التطبيق من قاعدة معرفة داخلية دون إرسال سؤالك للخارج.', 'Explains the app from an internal knowledge base without sending your question outside.'), style: TextStyle(color: _p.muted, fontSize: 11)))));

  Widget _suggestions() => ListView(padding: const EdgeInsets.all(14), children: [Text(_t('اسأل عن أي قسم', 'Ask about any section'), style: TextStyle(color: _p.text, fontWeight: FontWeight.w800)), const SizedBox(height: 9), Wrap(spacing: 7, runSpacing: 7, children: [for (final item in _answers) ActionChip(avatar: Icon(item.icon, size: 16), label: Text(_en ? item.titleEn : item.titleAr), onPressed: () => _ask(_en ? item.titleEn : item.titleAr))])]);

  Widget _answerCard(_Answer answer) => Card(
    color: _p.surface,
    margin: const EdgeInsets.only(bottom: 10),
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(children: [
            Icon(answer.icon, color: _p.accent),
            const SizedBox(width: 8),
            Expanded(child: Text(
              _en ? answer.titleEn : answer.titleAr,
              style: TextStyle(color: _p.text, fontWeight: FontWeight.w900),
            )),
          ]),
          const SizedBox(height: 8),
          Text(_en ? answer.bodyEn : answer.bodyAr, style: TextStyle(color: _p.muted, height: 1.45)),
          if (answer.section != null)
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: Padding(
                padding: const EdgeInsets.only(top: 8),
                child: FilledButton.icon(
                  onPressed: () => widget.onOpenSection?.call(answer.section!),
                  icon: const Icon(Icons.open_in_new, size: 16),
                  label: Text(_t('فتح القسم', 'Open section')),
                ),
              ),
            ),
        ],
      ),
    ),
  );

  Widget _composer() => SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(12, 6, 12, 10), child: Row(children: [Expanded(child: TextField(controller: _input, onSubmitted: (_) => _ask(), decoration: InputDecoration(hintText: _t('مثال: كيف أستخدم FAHES؟', 'Example: How do I use FAHES?'), prefixIcon: const Icon(Icons.chat_bubble_outline)))), const SizedBox(width: 7), IconButton.filled(onPressed: _ask, icon: const Icon(Icons.send_rounded))])));
}
