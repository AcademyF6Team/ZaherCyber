import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/article.dart';
import '../models/kev_item.dart';
import '../models/protection_content.dart';
import 'device_security_screen.dart';
import '../models/tool_project.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../utils/kev_watch_match.dart';

class _ProtectionAccount {
  _ProtectionAccount({required this.id, required this.name, this.mfa = false, this.recovery = false, this.sessions = false, this.alerts = false});
  final String id;
  final String name;
  bool mfa;
  bool recovery;
  bool sessions;
  bool alerts;

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'mfa': mfa, 'recovery': recovery, 'sessions': sessions, 'alerts': alerts};

  factory _ProtectionAccount.fromJson(Map<String, dynamic> json) => _ProtectionAccount(
    id: json['id']?.toString() ?? 'custom',
    name: json['name']?.toString() ?? json['id']?.toString() ?? 'Account',
    mfa: json['mfa'] == true,
    recovery: json['recovery'] == true,
    sessions: json['sessions'] == true,
    alerts: json['alerts'] == true,
  );
}

class _IncidentRecord {
  _IncidentRecord({required this.id, required this.title, required this.severity, required this.status, required this.createdAt, this.notes = ''});
  final String id;
  final String title;
  final String severity;
  String status;
  final String createdAt;
  final String notes;

  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'severity': severity, 'status': status, 'createdAt': createdAt, 'notes': notes};

  factory _IncidentRecord.fromJson(Map<String, dynamic> json) => _IncidentRecord(
    id: json['id']?.toString() ?? DateTime.now().toIso8601String(),
    title: json['title']?.toString() ?? 'Incident',
    severity: json['severity']?.toString() ?? 'medium',
    status: json['status']?.toString() ?? 'open',
    createdAt: json['createdAt']?.toString() ?? DateTime.now().toIso8601String(),
    notes: json['notes']?.toString() ?? '',
  );
}

class ProtectionCenterScreen extends StatefulWidget {
  final List<ProtectionCheck> checks;
  final List<IncidentPlaybook> playbooks;
  final List<KevItem> kevItems;
  final List<Article> articles;
  final List<ToolProject> tools;
  final bool isLoadingKev;
  final Future<void> Function() onRefreshKev;

  const ProtectionCenterScreen({
    super.key,
    required this.checks,
    required this.playbooks,
    required this.kevItems,
    required this.articles,
    required this.tools,
    required this.isLoadingKev,
    required this.onRefreshKev,
  });

  @override
  State<ProtectionCenterScreen> createState() => _ProtectionCenterScreenState();
}

class _ProtectionCenterScreenState extends State<ProtectionCenterScreen> {
  static const _checksKey = 'protection_checks_done_v1';
  static const _stepsKey = 'protection_playbook_steps_done_v1';
  static const _watchKey = 'protection_watch_terms_v1';
  static const _accountsKey = 'protection_accounts_v1';
  static const _incidentsKey = 'protection_incident_log_v1';
  static const _remindersKey = 'protection_reminders_v1';

  final TextEditingController _watchInput = TextEditingController();
  final List<ScrollController> _branchScrollControllers = List.generate(
    7,
    (_) => ScrollController(),
  );
  final Set<String> _doneChecks = {};
  final Set<String> _doneSteps = {};
  final List<String> _watchTerms = [];
  final List<_ProtectionAccount> _accounts = [];
  final List<_IncidentRecord> _incidentLog = [];
  final Set<String> _reminders = {};
  int _page = 0;
  String? _selectedIncidentId;
  String _platform = 'all';
  bool _loaded = false;
  bool _showBranchScrollTop = false;

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  bool get _isEnglish => Localizations.localeOf(context).languageCode == 'en';
  String _t(String ar, String en) => copy(context, ar, en);

  @override
  void initState() {
    super.initState();
    for (final controller in _branchScrollControllers) {
      controller.addListener(_onBranchScroll);
    }
    _loadLocalState();
  }

  @override
  void didUpdateWidget(covariant ProtectionCenterScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.checks != widget.checks ||
        oldWidget.playbooks != widget.playbooks) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    _watchInput.dispose();
    for (final controller in _branchScrollControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _loadLocalState() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    final accountJson = prefs.getStringList(_accountsKey) ?? const [];
    final incidentJson = prefs.getStringList(_incidentsKey) ?? const [];
    setState(() {
      _doneChecks.addAll(prefs.getStringList(_checksKey) ?? const []);
      _doneSteps.addAll(prefs.getStringList(_stepsKey) ?? const []);
      _watchTerms.addAll(prefs.getStringList(_watchKey) ?? const []);
      _accounts
        ..clear()
        ..addAll(accountJson.map((item) => _ProtectionAccount.fromJson(jsonDecode(item) as Map<String, dynamic>)));
      _incidentLog
        ..clear()
        ..addAll(incidentJson.map((item) => _IncidentRecord.fromJson(jsonDecode(item) as Map<String, dynamic>)));
      _reminders.addAll(prefs.getStringList(_remindersKey) ?? const []);
      if (_accounts.isEmpty) {
        _accounts.addAll([
          _ProtectionAccount(id: 'google', name: 'Google'),
          _ProtectionAccount(id: 'telegram', name: 'Telegram'),
          _ProtectionAccount(id: 'github', name: 'GitHub'),
          _ProtectionAccount(id: 'email', name: _t('البريد الإلكتروني', 'Email')),
        ]);
      }
      _loaded = true;
    });
  }

  Future<void> _saveProtectionState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_accountsKey, _accounts.map((item) => jsonEncode(item.toJson())).toList());
    await prefs.setStringList(_incidentsKey, _incidentLog.map((item) => jsonEncode(item.toJson())).toList());
    await prefs.setStringList(_remindersKey, _reminders.toList());
  }

  void _onBranchScroll() {
    if (!mounted) return;
    final controller = _branchScrollControllers[_page];
    final shouldShow = controller.hasClients && controller.offset > 360;
    if (shouldShow != _showBranchScrollTop) {
      setState(() => _showBranchScrollTop = shouldShow);
    }
  }

  void _goToPage(int page) {
    setState(() {
      _page = page;
      final controller = _branchScrollControllers[page];
      _showBranchScrollTop = controller.hasClients && controller.offset > 360;
    });
  }

  void _openIncident(String playbookId) {
    setState(() {
      _selectedIncidentId = playbookId;
      _page = 2;
      final controller = _branchScrollControllers[2];
      _showBranchScrollTop = controller.hasClients && controller.offset > 360;
    });
  }

  Future<void> _toggleDone(
    Set<String> values,
    String storageKey,
    String id,
  ) async {
    setState(() {
      if (!values.add(id)) values.remove(id);
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(storageKey, values.toList()..sort());
  }

  Future<void> _addWatchTerm([String? raw]) async {
    final value = (raw ?? _watchInput.text).trim();
    if (value.isEmpty) return;
    final exists = _watchTerms.any(
      (term) => term.toLowerCase() == value.toLowerCase(),
    );
    if (!exists) {
      setState(() => _watchTerms.add(value));
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_watchKey, _watchTerms);
    }
    _watchInput.clear();
  }

  Future<void> _removeWatchTerm(String term) async {
    setState(() => _watchTerms.remove(term));
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_watchKey, _watchTerms);
  }

  Future<void> _pickProject() async {
    var query = '';
    final selected = await showModalBottomSheet<ToolProject>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _p.surface,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) {
          final matches = widget.tools
              .where((project) {
                final text =
                    '${project.name} ${project.githubRepo ?? ''} ${project.category}';
                return query.trim().isEmpty ||
                    text.toLowerCase().contains(query.trim().toLowerCase());
              })
              .take(60)
              .toList();
          return SafeArea(
            child: SizedBox(
              height: MediaQuery.sizeOf(context).height * .78,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                _t(
                                  'أضف منتجاً من الترسانة',
                                  'Add a project from the Arsenal',
                                ),
                                style: TextStyle(
                                  color: _p.text,
                                  fontSize: 17,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                            IconButton(
                              tooltip: _t('إغلاق', 'Close'),
                              onPressed: () => Navigator.pop(sheetContext),
                              icon: const Icon(Icons.close_rounded),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          autofocus: true,
                          onChanged: (value) =>
                              setSheetState(() => query = value),
                          decoration: InputDecoration(
                            prefixIcon: const Icon(Icons.search_rounded),
                            hintText: _t(
                              'ابحث باسم المشروع أو المستودع',
                              'Search project or repository',
                            ),
                            filled: true,
                            fillColor: _p.raised,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: BorderSide.none,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      primary: false,
                      itemCount: matches.length,
                      itemBuilder: (context, index) {
                        final project = matches[index];
                        return ListTile(
                          leading: Icon(
                            Icons.widgets_outlined,
                            color: _p.accent,
                          ),
                          title: Text(
                            project.name,
                            style: TextStyle(color: _p.text),
                          ),
                          subtitle: Text(
                            project.githubRepo ?? project.category,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: _p.muted),
                          ),
                          onTap: () => Navigator.pop(sheetContext, project),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
    if (selected != null) await _addWatchTerm(selected.name);
  }

  Future<void> _openOfficial(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) return;
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t('تعذر فتح الرابط الآن.', 'Could not open the link.'),
            ),
          ),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t('تعذر فتح الرابط الآن.', 'Could not open the link.'),
            ),
          ),
        );
      }
    }
  }

  int get _totalDone => _doneChecks.length + _doneSteps.length;
  int get _totalActions =>
      widget.checks.length +
      widget.playbooks.fold<int>(
        0,
        (sum, playbook) => sum + playbook.steps.length,
      );

  @override
  Widget build(BuildContext context) {
    final title = _page == 0
        ? _t('مركز الحماية', 'Protection center')
        : _page == 1
        ? _t('تقوية الأجهزة', 'Device hardening')
        : _page == 2
        ? _t('الاستجابة للحوادث', 'Incident response')
        : _page == 3
        ? _t('قائمة المتابعة', 'Watchlist')
        : _page == 4
        ? _t('حساباتي', 'My accounts')
        : _page == 5
        ? _t('سجل الحوادث', 'Incident log')
        : _page == 6
        ? _t('الخصوصية والتذكيرات', 'Privacy & reminders')
        : _t('مركز الحماية', 'Protection center');
    return ColoredBox(
      color: _p.background,
      child: Column(
        children: [
          _header(title),
          SizedBox(
            height: 43,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                _pageChip(
                  0,
                  _t('نظرة عامة', 'Overview'),
                  Icons.shield_outlined,
                ),
                _pageChip(
                  1,
                  _t('تقوية الأجهزة', 'Hardening'),
                  Icons.phonelink_lock_rounded,
                ),
                _pageChip(
                  2,
                  _t('الحوادث', 'Incidents'),
                  Icons.emergency_outlined,
                ),
                _pageChip(
                  3,
                  _t('المتابعة', 'Watchlist'),
                  Icons.notifications_active_outlined,
                ),
                _pageChip(4, _t('حساباتي', 'Accounts'), Icons.account_circle_outlined),
                _pageChip(5, _t('السجل', 'Log'), Icons.history_rounded),
                _pageChip(6, _t('الخصوصية', 'Privacy'), Icons.privacy_tip_outlined),
              ],
            ),
          ),
          Expanded(
            child: IndexedStack(
              index: _page,
              children: [_overview(), _hardening(), _incidents(), _watchlist(), _accountsPage(), _incidentLogPage(), _privacyPage()],
            ),
          ),
        ],
      ),
    );
  }

  Widget _header(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(17, 14, 17, 9),
    child: Row(
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: _p.accent.withValues(alpha: .14),
            borderRadius: BorderRadius.circular(17),
          ),
          child: Icon(
            Icons.health_and_safety_rounded,
            color: _p.accent,
            size: 29,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: _p.text,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              Text(
                _t(
                  'خطوات دفاعية عملية · تقدم محفوظ محلياً',
                  'Defensive actions · progress saved locally',
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: _p.muted, fontSize: 10),
              ),
            ],
          ),
        ),
        if (_page != 0)
          IconButton(
            tooltip: _t('العودة', 'Back'),
            onPressed: () => _goToPage(0),
            icon: Icon(Icons.arrow_back_rounded, color: _p.accent),
          ),
        if (_showBranchScrollTop)
          IconButton(
            key: const ValueKey('protection-scroll-to-top'),
            tooltip: _t('العودة إلى أعلى القسم', 'Back to top'),
            onPressed: () => _branchScrollControllers[_page].animateTo(
              0,
              duration: const Duration(milliseconds: 320),
              curve: Curves.easeOutCubic,
            ),
            icon: Icon(Icons.vertical_align_top_rounded, color: _p.accent),
          ),
      ],
    ),
  );

  Widget _pageChip(int index, String label, IconData icon) => Padding(
    padding: const EdgeInsetsDirectional.only(end: 7),
    child: ChoiceChip(
      avatar: Icon(icon, size: 15),
      label: Text(label),
      selected: _page == index,
      showCheckmark: false,
      onSelected: (_) => _goToPage(index),
      selectedColor: _p.accent.withValues(alpha: .2),
      backgroundColor: _p.surface,
      labelStyle: TextStyle(
        color: _p.text,
        fontSize: 10,
        fontWeight: FontWeight.w700,
      ),
      side: BorderSide(color: _page == index ? _p.accent : _p.border),
      visualDensity: VisualDensity.compact,
    ),
  );

  Widget _overview() => ListView(
    primary: false,
    controller: _branchScrollControllers[0],
    key: const PageStorageKey('protection-overview'),
    padding: const EdgeInsets.fromLTRB(14, 10, 14, 26),
    children: [
      _notice(
        Icons.verified_user_outlined,
        _t('مركز دفاعي وتعليمي', 'Defensive guidance'),
        _t(
          'لا يفحص التطبيق جهازك ولا يرسل قائمة المتابعة أو إنجازاتك إلى خادم. الإرشادات عامة؛ عند حادث مؤسسي أو خسارة مالية أو خطر على أشخاص، تواصل مع فريق الأمن أو الجهة المختصة.',
          'The app does not scan your device or upload your watchlist or progress. Guidance is general; for an organizational incident, financial loss, or risk to people, contact your security team or the relevant authority.',
        ),
      ),
      const SizedBox(height: 12),
      _quickResponsePanel(),
      const SizedBox(height: 12),
      Card(
        color: _p.surface,
        child: ListTile(
          leading: Icon(Icons.phonelink_setup_outlined, color: _p.accent),
          title: Text(
            _t('فحص أمان الجهاز محلياً', 'Local device security check'),
            style: TextStyle(color: _p.text, fontWeight: FontWeight.w800),
          ),
          subtitle: Text(
            _t(
              'قراءة إصدار Android وتصحيح الأمان ووضع المطور ونطاق التخزين دون تعديل الجهاز.',
              'Read Android version, security patch, developer mode, and storage scope without changing the device.',
            ),
            style: TextStyle(color: _p.muted, height: 1.35, fontSize: 11),
          ),
          trailing: Icon(
            Icons.arrow_forward_ios_rounded,
            color: _p.accent,
            size: 16,
          ),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => const DeviceSecurityScreen(),
            ),
          ),
        ),
      ),
      const SizedBox(height: 12),
      _progressCard(),
      const SizedBox(height: 12),
      _overviewAction(
        Icons.phonelink_lock_rounded,
        _t('قوائم تقوية الأجهزة', 'Device hardening checklists'),
        _t(
          'إجراءات عملية لـ Android وWindows وLinux، مع الأولوية والمرجع الرسمي.',
          'Practical Android, Windows, and Linux steps with priorities and official references.',
        ),
        '${widget.checks.length} ${_t('إجراء', 'actions')}',
        1,
      ),
      _overviewAction(
        Icons.emergency_outlined,
        _t('أدلة الاستجابة للحوادث', 'Incident-response playbooks'),
        _t(
          'تعامل خطوة بخطوة مع الحسابات المخترقة والتصيد والفدية وفقد الهاتف وتسرب الأسرار.',
          'Step-by-step help for compromised accounts, phishing, ransomware, lost phones, and leaked secrets.',
        ),
        '${widget.playbooks.length} ${_t('دليل', 'playbooks')}',
        2,
      ),
      _overviewAction(
        Icons.notifications_active_outlined,
        _t('قائمة متابعة المنتجات', 'Product watchlist'),
        _t(
          'تابع كلمات تختارها، واعرض المطابقات النصية في أحدث 300 سجل من CISA KEV للثغرات المستغلة المعروفة.',
          'Track terms you choose and see text matches in the latest 300 cached CISA KEV records.',
        ),
        '${_watchTerms.length} ${_t('عنصر متابع', 'tracked')}',
        3,
      ),
      _overviewAction(
        Icons.account_circle_outlined,
        _t('حساباتي المهمة', 'Important accounts'),
        _t('راجع MFA والاسترداد والجلسات والتنبيهات دون حفظ أي أسرار.', 'Review MFA, recovery, sessions, and alerts without storing secrets.'),
        '${_accounts.length} ${_t('حسابات', 'accounts')}',
        4,
      ),
      _overviewAction(
        Icons.history_rounded,
        _t('سجل الحوادث المحلي', 'Local incident log'),
        _t('سجل حالات الحماية والإجراءات مع حالات مفتوح وقيد المعالجة ومغلق.', 'Track protection incidents and actions with open, in-progress, and closed states.'),
        '${_incidentLog.length} ${_t('حوادث', 'incidents')}',
        5,
      ),
      _overviewAction(
        Icons.privacy_tip_outlined,
        _t('الخصوصية والتذكيرات', 'Privacy & reminders'),
        _t('تحكم بالتذكيرات المحلية وصدّر أو احذف بيانات مركز الحماية.', 'Control local reminders and export or delete protection data.'),
        _t('إدارة', 'Manage'),
        6,
      ),
      const SizedBox(height: 8),
      _notice(
        Icons.info_outline_rounded,
        _t('ماذا تعني المطابقة؟', 'What does a match mean?'),
        _t(
          'CISA KEV يسرد ثغرات تؤكد CISA أنها استُغلت فعلياً. المطابقة هنا نصية تقريبية بأسماء المنتجات؛ عدم ظهور نتيجة لا يعني خلو المنتج من الثغرات. لا يصدر التطبيق إشعاراً خارجياً أو يفحص الأجهزة.',
          'تعرض CISA KEV الثغرات التي تؤكد CISA استغلالها. المطابقة نصية تقريبية لأسماء المنتجات؛ عدم ظهور نتيجة لا يعني خلو المنتج من الثغرات. تعرض التنبيهات داخل التطبيق فقط ولا يفحص التطبيق الجهاز.',
        ),
      ),
    ],
  );

  Widget _progressCard() {
    final ratio = _totalActions == 0
        ? 0.0
        : (_totalDone / _totalActions).clamp(0.0, 1.0);
    return _surface(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.checklist_rounded, color: _p.accent),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    _t(
                      'تقدمك المحفوظ على هذا الجهاز',
                      'Progress saved on this device',
                    ),
                    style: TextStyle(
                      color: _p.text,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                Text(
                  '$_totalDone / $_totalActions',
                  style: TextStyle(
                    color: _p.accent,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: ratio,
                minHeight: 7,
                backgroundColor: _p.raised,
                color: _p.accent,
              ),
            ),
            const SizedBox(height: 9),
            Row(
              children: [
                Icon(Icons.shield_outlined, color: _p.accent, size: 15),
                const SizedBox(width: 6),
                Text(
                  _t(
                    'درجة الحماية المحلية: ${(ratio * 100).round()}/100',
                    'Local protection score: ${(ratio * 100).round()}/100',
                  ),
                  style: TextStyle(
                    color: _p.accent,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 7),
            Text(
              _loaded
                  ? _t(
                      'يمكنك تغيير الاختيارات لاحقاً؛ لا تُرسل هذه البيانات إلى أي جهة.',
                      'You can change these selections later; this data is not sent anywhere.',
                    )
                  : _t('جارٍ تحميل تقدمك المحلي…', 'Loading local progress…'),
              style: TextStyle(color: _p.muted, fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }

  Widget _quickResponsePanel() => _surface(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.flash_on_rounded, color: _p.accent),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  _t('ماذا حدث؟ ابدأ من هنا', 'What happened? Start here'),
                  style: TextStyle(
                    color: _p.text,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 5),
          Text(
            _t(
              'اختر الحالة الأقرب لفتح دليلها مباشرةً؛ لا تُدخل كلمات مرور أو رموز تحقق في هذا التطبيق.',
              'Choose the closest situation to open its guide. Never enter passwords or verification codes in this app.',
            ),
            style: TextStyle(color: _p.muted, fontSize: 10, height: 1.45),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            runSpacing: 3,
            children: [
              _quickResponseChoice(
                'account-takeover-response-01',
                'حساب مخترق',
                'Compromised account',
                Icons.person_off_outlined,
              ),
              _quickResponseChoice(
                'phishing-incident-response',
                'رسالة أو ملف مشبوه',
                'Suspicious message or file',
                Icons.mark_email_unread_outlined,
              ),
              _quickResponseChoice(
                'ransomware-mobile-incident-response',
                'فدية على هاتف',
                'Mobile ransomware',
                Icons.enhanced_encryption_outlined,
              ),
              _quickResponseChoice(
                'lost-phone-response-android',
                'هاتف مفقود',
                'Lost phone',
                Icons.phone_android_rounded,
              ),
              _quickResponseChoice(
                'github-secret-leak-recovery',
                'رمز أو سر مكشوف',
                'Leaked token or secret',
                Icons.vpn_key_outlined,
              ),
            ],
          ),
        ],
      ),
    ),
  );

  Widget _quickResponseChoice(
    String playbookId,
    String titleAr,
    String titleEn,
    IconData icon,
  ) {
    if (!widget.playbooks.any((playbook) => playbook.id == playbookId)) {
      return const SizedBox.shrink();
    }
    return ActionChip(
      key: ValueKey<String>('quick-response-$playbookId'),
      avatar: Icon(icon, color: _p.accent, size: 16),
      label: Text(_t(titleAr, titleEn)),
      onPressed: () => _openIncident(playbookId),
      backgroundColor: _p.raised,
      side: BorderSide(color: _p.border),
      visualDensity: VisualDensity.compact,
    );
  }

  Widget _overviewAction(
    IconData icon,
    String title,
    String detail,
    String count,
    int target,
  ) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: Material(
      color: _p.surface,
      borderRadius: BorderRadius.circular(17),
      child: InkWell(
        borderRadius: BorderRadius.circular(17),
        onTap: () => _goToPage(target),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Row(
            children: [
              Icon(icon, color: _p.accent, size: 27),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: _p.text,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      detail,
                      style: TextStyle(
                        color: _p.muted,
                        fontSize: 11,
                        height: 1.45,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 7),
              Column(
                children: [
                  Text(
                    count,
                    style: TextStyle(
                      color: _p.accent,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded, color: _p.muted),
                ],
              ),
            ],
          ),
        ),
      ),
    ),
  );

  Widget _accountsPage() => ListView(
    primary: false,
    controller: _branchScrollControllers[4],
    padding: const EdgeInsets.fromLTRB(14, 8, 14, 26),
    children: [
      _sectionIntro(
        _t('حساباتي المهمة', 'Important accounts'),
        _t('سجل حالة الحماية فقط. لا تحفظ كلمات المرور أو رموز التحقق أو مفاتيح API هنا.', 'Track security status only. Never store passwords, verification codes, or API keys here.'),
      ),
      const SizedBox(height: 10),
      _surface(child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [
        Icon(Icons.shield_outlined, color: _p.accent),
        const SizedBox(width: 9),
        Expanded(child: Text(_t('حالة الحسابات', 'Account readiness'), style: TextStyle(color: _p.text, fontWeight: FontWeight.w800))),
        Text('${_accountScore()}%', style: TextStyle(color: _p.accent, fontWeight: FontWeight.w900, fontSize: 20)),
      ]))),
      const SizedBox(height: 10),
      for (final account in _accounts) _accountCard(account),
    ],
  );

  int _accountScore() {
    if (_accounts.isEmpty) return 0;
    final total = _accounts.length * 4;
    final done = _accounts.fold<int>(0, (sum, item) => sum + [item.mfa, item.recovery, item.sessions, item.alerts].where((value) => value).length);
    return ((done / total) * 100).round();
  }

  Widget _accountCard(_ProtectionAccount account) => Card(
    color: _p.surface,
    margin: const EdgeInsets.only(bottom: 9),
    child: ExpansionTile(
      leading: CircleAvatar(backgroundColor: _p.accent.withValues(alpha: .14), child: Icon(Icons.account_circle_outlined, color: _p.accent)),
      title: Text(account.name, style: TextStyle(color: _p.text, fontWeight: FontWeight.w800)),
      subtitle: Text(_t('لا تحفظ أسراراً هنا', 'No secrets are stored here'), style: TextStyle(color: _p.muted, fontSize: 10)),
      children: [
        _accountCheck(account, 'mfa', _t('المصادقة متعددة العوامل مفعلة', 'MFA is enabled'), account.mfa),
        _accountCheck(account, 'recovery', _t('وسائل الاسترداد محدثة', 'Recovery methods are current'), account.recovery),
        _accountCheck(account, 'sessions', _t('تمت مراجعة الجلسات والأجهزة', 'Sessions and devices were reviewed'), account.sessions),
        _accountCheck(account, 'alerts', _t('التنبيهات الأمنية مفعلة', 'Security alerts are enabled'), account.alerts),
      ],
    ),
  );

  Widget _accountCheck(_ProtectionAccount account, String key, String label, bool value) => CheckboxListTile(
    dense: true,
    value: value,
    activeColor: _p.accent,
    title: Text(label, style: TextStyle(color: _p.text, fontSize: 12)),
    onChanged: (next) async {
      setState(() {
        if (key == 'mfa') account.mfa = next ?? false;
        if (key == 'recovery') account.recovery = next ?? false;
        if (key == 'sessions') account.sessions = next ?? false;
        if (key == 'alerts') account.alerts = next ?? false;
      });
      await _saveProtectionState();
    },
  );

  Widget _incidentLogPage() => ListView(
    primary: false,
    controller: _branchScrollControllers[5],
    padding: const EdgeInsets.fromLTRB(14, 8, 14, 26),
    children: [
      _sectionIntro(_t('سجل الحوادث المحلي', 'Local incident log'), _t('سجل نوع الحادث والإجراءات فقط. لا تحفظ كلمات المرور أو الأدلة الحساسة داخل هذا السجل.', 'Record incident type and actions only. Do not store passwords or sensitive evidence here.')),
      const SizedBox(height: 9),
      FilledButton.icon(onPressed: _addIncident, icon: const Icon(Icons.add), label: Text(_t('تسجيل حادث', 'Log incident'))),
      const SizedBox(height: 10),
      if (_incidentLog.isEmpty) _empty(_t('لا توجد حوادث مسجلة.', 'No incidents logged.')),
      for (final item in _incidentLog) _incidentCard(item),
    ],
  );

  Widget _incidentCard(_IncidentRecord item) => Card(
    color: _p.surface,
    margin: const EdgeInsets.only(bottom: 9),
    child: ListTile(
      leading: Icon(item.severity == 'high' ? Icons.warning_rounded : Icons.history_rounded, color: item.severity == 'high' ? Colors.orangeAccent : _p.accent),
      title: Text(item.title, style: TextStyle(color: _p.text, fontWeight: FontWeight.w800)),
      subtitle: Text('${item.status} · ${item.createdAt.substring(0, 10)}${item.notes.isEmpty ? '' : '\n${item.notes}'}', style: TextStyle(color: _p.muted, fontSize: 10, height: 1.4)),
      trailing: PopupMenuButton<String>(onSelected: (value) async { setState(() => item.status = value); await _saveProtectionState(); }, itemBuilder: (_) => [
        PopupMenuItem(value: 'open', child: Text(_t('مفتوح', 'Open'))),
        PopupMenuItem(value: 'in_progress', child: Text(_t('قيد المعالجة', 'In progress'))),
        PopupMenuItem(value: 'closed', child: Text(_t('مغلق', 'Closed'))),
      ]),
    ),
  );

  Future<void> _addIncident() async {
    final title = TextEditingController();
    final notes = TextEditingController();
    var severity = 'medium';
    final result = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
      title: Text(_t('تسجيل حادث محلي', 'Log local incident')),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: title, decoration: InputDecoration(labelText: _t('العنوان', 'Title'))),
        TextField(controller: notes, decoration: InputDecoration(labelText: _t('ملاحظات غير حساسة', 'Non-sensitive notes'))),
        DropdownButtonFormField<String>(value: severity, decoration: InputDecoration(labelText: _t('الخطورة', 'Severity')), items: const [DropdownMenuItem(value: 'low', child: Text('Low')), DropdownMenuItem(value: 'medium', child: Text('Medium')), DropdownMenuItem(value: 'high', child: Text('High'))], onChanged: (value) => setDialogState(() => severity = value ?? 'medium')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: Text(_t('إلغاء', 'Cancel'))), FilledButton(onPressed: () => Navigator.pop(dialogContext, title.text.trim().isNotEmpty), child: Text(_t('حفظ', 'Save')))],
    )));
    if (result == true) {
      setState(() => _incidentLog.insert(0, _IncidentRecord(id: DateTime.now().microsecondsSinceEpoch.toString(), title: title.text.trim(), severity: severity, status: 'open', createdAt: DateTime.now().toIso8601String(), notes: notes.text.trim())));
      await _saveProtectionState();
    }
    title.dispose();
    notes.dispose();
  }

  Widget _privacyPage() => ListView(
    primary: false,
    controller: _branchScrollControllers[6],
    padding: const EdgeInsets.fromLTRB(14, 8, 14, 26),
    children: [
      _sectionIntro(_t('الخصوصية والتذكيرات', 'Privacy & reminders'), _t('كل بيانات مركز الحماية التالية تحفظ محلياً على هذا الجهاز ويمكن حذفها في أي وقت.', 'Protection data is stored locally on this device and can be deleted at any time.')),
      const SizedBox(height: 10),
      _surface(child: Column(children: [
        _reminderTile('weekly', _t('مراجعة الحماية أسبوعياً', 'Weekly protection review')),
        _reminderTile('monthly', _t('مراجعة جلسات الحسابات شهرياً', 'Monthly account-session review')),
        _reminderTile('backup', _t('اختبار استعادة النسخة الاحتياطية', 'Test backup restoration')),
      ])),
      const SizedBox(height: 10),
      _surface(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(_t('البيانات المحلية', 'Local data'), style: TextStyle(color: _p.text, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Text(_t('${_doneChecks.length} فحوصات · ${_watchTerms.length} عناصر متابعة · ${_incidentLog.length} حوادث · ${_accounts.length} حسابات', '${_doneChecks.length} checks · ${_watchTerms.length} watch terms · ${_incidentLog.length} incidents · ${_accounts.length} accounts'), style: TextStyle(color: _p.muted, fontSize: 11)),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: _showProtectionExport, icon: const Icon(Icons.ios_share_outlined), label: Text(_t('عرض تصدير محلي', 'Show local export'))),
        TextButton.icon(onPressed: _clearProtectionData, icon: const Icon(Icons.delete_outline), label: Text(_t('حذف بيانات مركز الحماية', 'Delete protection data'))),
      ]))),
    ],
  );

  Widget _reminderTile(String id, String label) => SwitchListTile.adaptive(value: _reminders.contains(id), onChanged: (value) async { setState(() { if (value) { _reminders.add(id); } else { _reminders.remove(id); } }); await _saveProtectionState(); }, title: Text(label, style: TextStyle(color: _p.text, fontSize: 12)), subtitle: Text(_t('تفضيل محلي؛ لا ينشئ إشعاراً دون موافقة منفصلة.', 'Local preference; it does not create notifications without separate consent.'), style: TextStyle(color: _p.muted, fontSize: 10)));

  Future<void> _showProtectionExport() async {
    final payload = JsonEncoder.withIndent('  ').convert({'checks': _doneChecks.toList(), 'steps': _doneSteps.toList(), 'watchTerms': _watchTerms, 'accounts': _accounts.map((item) => item.toJson()).toList(), 'incidents': _incidentLog.map((item) => item.toJson()).toList()});
    if (!mounted) return;
    await showDialog<void>(context: context, builder: (_) => AlertDialog(title: Text(_t('تصدير محلي', 'Local export')), content: SingleChildScrollView(child: SelectableText(payload, style: const TextStyle(fontSize: 10))), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(_t('إغلاق', 'Close')))]));
  }

  Future<void> _clearProtectionData() async {
    final confirmed = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: Text(_t('حذف بيانات الحماية؟', 'Delete protection data?')), content: Text(_t('سيتم حذف التقدم والحسابات والسجل وقائمة المتابعة من هذا الجهاز.', 'Progress, accounts, incident log, and watchlist will be deleted from this device.')), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: Text(_t('إلغاء', 'Cancel'))), FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(_t('حذف', 'Delete')))]));
    if (confirmed != true) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_checksKey); await prefs.remove(_stepsKey); await prefs.remove(_watchKey); await prefs.remove(_accountsKey); await prefs.remove(_incidentsKey); await prefs.remove(_remindersKey);
    if (!mounted) return;
    setState(() { _doneChecks.clear(); _doneSteps.clear(); _watchTerms.clear(); _accounts.clear(); _incidentLog.clear(); _reminders.clear(); });
  }

  Widget _hardening() {
    final availablePlatforms =
        widget.checks.map((item) => item.platform).toSet().toList()..sort();
    final shown = widget.checks
        .where(
          (item) =>
              _platform == 'all' || item.platform.toLowerCase() == _platform,
        )
        .toList();
    final done = shown.where((item) => _doneChecks.contains(item.id)).length;
    return ListView(
      primary: false,
      controller: _branchScrollControllers[1],
      key: const PageStorageKey('protection-hardening'),
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 26),
      children: [
        _sectionIntro(
          _t('قوائم تقوية الأجهزة', 'Device hardening'),
          _t(
            'اختر نظاماً، ثم افتح كل خطوة واقرأ المرجع الرسمي. ضع علامة على ما طبقته فعلاً؛ تقدمك يبقى على هذا الجهاز.',
            'Choose a platform, open each step, and read the official reference. Mark only steps you have actually completed; progress stays on this device.',
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 40,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              _filterChip('all', _t('كل الأنظمة', 'All platforms')),
              for (final platform in availablePlatforms)
                _filterChip(platform.toLowerCase(), platform),
            ],
          ),
        ),
        const SizedBox(height: 8),
        _progressStrip(
          done,
          shown.length,
          _t('إجراءات هذا النظام', 'Actions for this platform'),
        ),
        const SizedBox(height: 10),
        if (shown.isEmpty)
          _empty(
            _t(
              'لا توجد خطوات لهذا النظام بعد.',
              'No steps for this platform yet.',
            ),
          ),
        for (final item in shown) _checkCard(item),
      ],
    );
  }

  Widget _filterChip(String value, String label) => Padding(
    padding: const EdgeInsetsDirectional.only(end: 7),
    child: ChoiceChip(
      label: Text(label),
      selected: _platform == value,
      showCheckmark: false,
      onSelected: (_) => setState(() => _platform = value),
      selectedColor: _p.accent.withValues(alpha: .2),
      backgroundColor: _p.surface,
      side: BorderSide(color: _platform == value ? _p.accent : _p.border),
      labelStyle: TextStyle(
        color: _p.text,
        fontSize: 10,
        fontWeight: FontWeight.w700,
      ),
      visualDensity: VisualDensity.compact,
    ),
  );

  Widget _checkCard(ProtectionCheck item) {
    final checked = _doneChecks.contains(item.id);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: _p.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(17),
          side: BorderSide(color: _p.border),
        ),
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            key: PageStorageKey<String>('hardening_${item.id}'),
            tilePadding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 2,
            ),
            childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            leading: Checkbox(
              value: checked,
              onChanged: (_) => _toggleDone(_doneChecks, _checksKey, item.id),
              activeColor: _p.accent,
            ),
            title: Text(
              _isEnglish ? item.titleEn : item.titleAr,
              style: TextStyle(
                color: _p.text,
                fontSize: 13,
                fontWeight: FontWeight.w800,
              ),
            ),
            subtitle: Text(
              _isEnglish ? item.groupEn : item.groupAr,
              style: TextStyle(color: _p.muted, fontSize: 10),
            ),
            trailing: _riskBadge(item.risk),
            children: [
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: Text(
                  _isEnglish ? item.detailEn : item.detailAr,
                  style: TextStyle(color: _p.text, height: 1.5, fontSize: 12),
                ),
              ),
              const SizedBox(height: 10),
              _referenceButton(item.sourceTitle, item.officialUrl),
            ],
          ),
        ),
      ),
    );
  }

  Widget _incidents() {
    final selectedId =
        widget.playbooks.any((playbook) => playbook.id == _selectedIncidentId)
        ? _selectedIncidentId
        : null;
    final visiblePlaybooks = widget.playbooks.where(
      (playbook) => selectedId == null || playbook.id == selectedId,
    );
    return ListView(
      primary: false,
      controller: _branchScrollControllers[2],
      key: const PageStorageKey('protection-incidents'),
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 26),
      children: [
        _sectionIntro(
          _t('أدلة الاستجابة للحوادث', 'Incident-response playbooks'),
          _t(
            'إذا كان هناك خطر مباشر على الأشخاص، اتصل بخدمات الطوارئ المحلية أولاً. للحوادث الرقمية ابدأ بالاحتواء وحماية الأشخاص والبيانات؛ لا تحذف الأدلة ولا تعِد تشغيل جهاز قد يكون ضمن تحقيق مؤسسي قبل الرجوع للمسؤول المختص.',
            'If people face immediate danger, contact local emergency services first. For digital incidents, prioritize containment and safety; do not erase evidence or reboot a device that may be part of an organizational investigation before consulting the responsible team.',
          ),
        ),
        const SizedBox(height: 8),
        if (selectedId != null)
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: TextButton.icon(
              key: const ValueKey('incident-show-all-guides'),
              onPressed: () => setState(() => _selectedIncidentId = null),
              icon: const Icon(Icons.list_alt_rounded),
              label: Text(_t('عرض جميع الأدلة', 'Show all playbooks')),
            ),
          ),
        for (final playbook in visiblePlaybooks)
          _playbookCard(playbook, initiallyExpanded: selectedId == playbook.id),
      ],
    );
  }

  Widget _playbookCard(
    IncidentPlaybook playbook, {
    bool initiallyExpanded = false,
  }) {
    final title = _isEnglish ? playbook.titleEn : playbook.titleAr;
    final summary = _isEnglish ? playbook.summaryEn : playbook.summaryAr;
    final expert = _isEnglish ? playbook.whenExpertEn : playbook.whenExpertAr;
    final done = List.generate(
      playbook.steps.length,
      (i) => _doneSteps.contains('${playbook.id}:$i'),
    ).where((v) => v).length;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: _p.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(17),
          side: BorderSide(color: _p.border),
        ),
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            key: PageStorageKey<String>(
              'playbook_${playbook.id}_${initiallyExpanded ? 'quick' : 'all'}',
            ),
            initiallyExpanded: initiallyExpanded,
            tilePadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 5,
            ),
            childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            leading: CircleAvatar(
              backgroundColor: _p.accent.withValues(alpha: .14),
              child: Icon(Icons.emergency_outlined, color: _p.accent, size: 19),
            ),
            title: Text(
              title,
              style: TextStyle(
                color: _p.text,
                fontSize: 13,
                fontWeight: FontWeight.w800,
              ),
            ),
            subtitle: Text(
              '$done/${playbook.steps.length} ${_t('خطوات', 'steps')}',
              style: TextStyle(color: _p.muted, fontSize: 10),
            ),
            children: [
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: Text(
                  summary,
                  style: TextStyle(color: _p.text, height: 1.5, fontSize: 12),
                ),
              ),
              const SizedBox(height: 8),
              for (var i = 0; i < playbook.steps.length; i++)
                _responseStep(playbook, i),
              _notice(
                Icons.support_agent_rounded,
                _t('متى تطلب المساعدة؟', 'When to escalate'),
                expert,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _responseStep(IncidentPlaybook playbook, int index) {
    final step = playbook.steps[index];
    final key = '${playbook.id}:$index';
    final checked = _doneSteps.contains(key);
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: _p.raised.withValues(alpha: .45),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: index == 0 ? _p.accent.withValues(alpha: .55) : _p.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (index == 0)
            Padding(
              padding: const EdgeInsetsDirectional.only(start: 44, bottom: 5),
              child: Align(
                alignment: AlignmentDirectional.centerStart,
                child: Text(
                  _t('ابدأ بهذه الخطوة أولاً', 'First action'),
                  style: TextStyle(
                    color: _p.accent,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Checkbox(
                value: checked,
                onChanged: (_) => _toggleDone(_doneSteps, _stepsKey, key),
                activeColor: _p.accent,
              ),
              const SizedBox(width: 5),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${index + 1}. ${_isEnglish ? step.titleEn : step.titleAr}',
                      style: TextStyle(
                        color: _p.text,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _isEnglish ? step.detailEn : step.detailAr,
                      style: TextStyle(
                        color: _p.muted,
                        height: 1.45,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              _riskBadge(step.risk),
            ],
          ),
          Padding(
            padding: const EdgeInsetsDirectional.only(start: 44),
            child: _referenceButton(step.sourceTitle, step.officialUrl),
          ),
        ],
      ),
    );
  }

  Widget _watchlist() {
    final matches = _watchTerms.isEmpty
        ? const <KevItem>[]
        : widget.kevItems
              .where((item) => matchesKevWatchTerms(item, _watchTerms))
              .toList();
    final matchedArticles = _watchTerms.isEmpty
        ? const <Article>[]
        : widget.articles
              .where(
                (article) => matchesWatchTermsInText(
                  '${article.title} ${article.summary} ${article.source}',
                  _watchTerms,
                ),
              )
              .take(12)
              .toList();
    return ListView(
      primary: false,
      controller: _branchScrollControllers[3],
      key: const PageStorageKey('protection-watchlist'),
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 26),
      children: [
        _sectionIntro(
          _t('متابعة المنتجات والثغرات', 'Product and vulnerability watchlist'),
          _t(
            'أضف أسماء منتجات أو مشاريع. تُحفظ القائمة محلياً وتُطابق نصياً مع أحدث 300 سجل مخزن من CISA KEV؛ قد تختلف أسماء المورد والمنتج عن الاسم الذي تضيفه.',
            'Add product or project names. The list is stored locally and matched against the latest 300 cached CISA KEV records; vendor/product aliases may differ from the name you enter.',
          ),
        ),
        const SizedBox(height: 9),
        _surface(
          child: Padding(
            padding: const EdgeInsets.all(13),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _watchInput,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => _addWatchTerm(),
                        decoration: InputDecoration(
                          hintText: _t(
                            'مثال: OpenSSL أو Microsoft Exchange',
                            'e.g. OpenSSL or Microsoft Exchange',
                          ),
                          prefixIcon: const Icon(Icons.search_rounded),
                          filled: true,
                          fillColor: _p.raised,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 10,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(13),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 7),
                    IconButton.filledTonal(
                      onPressed: () => _addWatchTerm(),
                      icon: const Icon(Icons.add_rounded),
                      tooltip: _t('إضافة', 'Add'),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: OutlinedButton.icon(
                    onPressed: _pickProject,
                    icon: const Icon(Icons.widgets_outlined, size: 17),
                    label: Text(_t('أضف من الترسانة', 'Add from Arsenal')),
                  ),
                ),
                if (_watchTerms.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Wrap(
                      spacing: 6,
                      runSpacing: 2,
                      children: [
                        for (final term in _watchTerms)
                          InputChip(
                            label: Text(
                              term,
                              style: TextStyle(color: _p.text, fontSize: 10),
                            ),
                            onDeleted: () => _removeWatchTerm(term),
                            deleteIconColor: _p.muted,
                            backgroundColor: _p.raised,
                            side: BorderSide(color: _p.border),
                          ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: Text(
                _t('مطابقات CISA KEV', 'CISA KEV matches'),
                style: TextStyle(
                  color: _p.text,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                ),
              ),
            ),
            IconButton(
              onPressed: widget.isLoadingKev
                  ? null
                  : () => widget.onRefreshKev(),
              icon: widget.isLoadingKev
                  ? SizedBox(
                      width: 19,
                      height: 19,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: _p.accent,
                      ),
                    )
                  : Icon(Icons.refresh_rounded, color: _p.accent),
              tooltip: _t('تحديث قاعدة CISA', 'Refresh CISA catalog'),
            ),
          ],
        ),
        if (_watchTerms.isEmpty)
          _empty(
            _t(
              'أضف منتجاً أو مشروعاً لعرض التطابقات.',
              'Add a product or project to see matching entries.',
            ),
          )
        else if (widget.isLoadingKev && widget.kevItems.isEmpty)
          const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: CircularProgressIndicator(),
            ),
          )
        else if (matches.isEmpty)
          _empty(
            _t(
              'لا توجد مطابقة حالية في أحدث 300 سجل من CISA KEV. هذا لا يثبت خلو المنتج من الثغرات؛ قد يكون السجل أقدم أو يستخدم اسماً مختلفاً.',
              'No current match in the latest 300 CISA KEV records. This does not prove the product has no vulnerabilities; an entry may be older or use another name.',
            ),
          )
        else ...[
          _notice(
            Icons.info_outline_rounded,
            _t(
              '${matches.length} مطابقة محتملة',
              '${matches.length} possible matches',
            ),
            _t(
              'هذه مطابقة نصية تقريبية لعناصر KEV المعروفة فقط، وليست فحصاً شاملاً لكل CVE. تحقق من المنتج والإصدار المتأثر في المصدر قبل اتخاذ إجراء.',
              'This is approximate text matching of known KEV entries only, not a full CVE scan. Verify the affected product and version in the source before acting.',
            ),
          ),
          const SizedBox(height: 8),
          for (final item in matches) _kevCard(item),
        ],
        const SizedBox(height: 12),
        Text(
          _t('مستجدات الموجزات المطابقة', 'Matching feed updates'),
          style: TextStyle(
            color: _p.text,
            fontWeight: FontWeight.w900,
            fontSize: 15,
          ),
        ),
        const SizedBox(height: 6),
        if (_watchTerms.isEmpty)
          _empty(
            _t(
              'أضف كلمات متابعة للبحث في الأخبار والنشرات المحفوظة.',
              'Add watch terms to search cached news and advisories.',
            ),
          )
        else if (matchedArticles.isEmpty)
          _empty(
            _t(
              'لا توجد مواد مخزنة تطابق كلماتك حالياً؛ هذا لا يعني عدم وجود إعلان لدى الناشر.',
              'No cached items currently match your terms; this does not mean a publisher has no advisory.',
            ),
          )
        else
          for (final article in matchedArticles) _articleCard(article),
        const SizedBox(height: 8),
        _notice(
          Icons.notifications_none_rounded,
          _t('تنبيه داخل التطبيق فقط', 'In-app notice only'),
          _t(
            'لا يرسل التطبيق إشعارات دفع أو يراقب المنتجات في الخلفية. راجع هذه الصفحة أو حدّث CISA KEV يدوياً؛ ويُعاد جلب البيانات وفق دورة التطبيق واتصال الشبكة.',
            'يعرض التطبيق التنبيهات داخل التطبيق فقط ولا يراقب المنتجات خارج التطبيق. أعد فتح هذه الصفحة أو حدّث CISA KEV يدوياً؛ تعتمد البيانات على دورة التحديث والاتصال بالشبكة.',
          ),
        ),
      ],
    );
  }

  Widget _articleCard(Article article) {
    final date = article.publishedAt
        ?.toLocal()
        .toIso8601String()
        .split('T')
        .first;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: _surface(
        child: InkWell(
          borderRadius: BorderRadius.circular(17),
          onTap: () => _openOfficial(article.link),
          child: Padding(
            padding: const EdgeInsets.all(13),
            child: Row(
              children: [
                Icon(Icons.article_outlined, color: _p.accent),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        article.source,
                        style: TextStyle(
                          color: _p.accent,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        article.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: _p.text,
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      if (article.summary.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          article.summary,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: _p.muted,
                            fontSize: 10,
                            height: 1.35,
                          ),
                        ),
                      ],
                      if (date != null) ...[
                        const SizedBox(height: 4),
                        Text(
                          date,
                          style: TextStyle(color: _p.muted, fontSize: 9),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Icon(Icons.open_in_new_rounded, color: _p.muted, size: 17),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _kevCard(KevItem item) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: _surface(
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    item.cveId,
                    style: TextStyle(
                      color: _p.accent,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                _kevUseBadge(item.knownRansomwareUse),
              ],
            ),
            const SizedBox(height: 5),
            Text(
              '${item.vendor} · ${item.product}',
              style: TextStyle(
                color: _p.text,
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 4),
            Text(item.name, style: TextStyle(color: _p.muted, fontSize: 11)),
            if (item.description.isNotEmpty) ...[
              const SizedBox(height: 5),
              Text(
                item.description,
                style: TextStyle(color: _p.muted, fontSize: 10, height: 1.4),
              ),
            ],
            const SizedBox(height: 5),
            Text(
              '${_t('أضيف إلى KEV', 'Added to KEV')}: ${item.dateAdded}',
              style: TextStyle(color: _p.muted, fontSize: 9),
            ),
            if (item.requiredAction.isNotEmpty) ...[
              const SizedBox(height: 7),
              Text(
                '${_t('الإجراء المطلوب لدى CISA', 'CISA required action')}: ${item.requiredAction}',
                style: TextStyle(color: _p.text, height: 1.4, fontSize: 10),
              ),
            ],
            Align(
              alignment: AlignmentDirectional.centerEnd,
              child: TextButton.icon(
                onPressed: () => _openOfficial(
                  'https://nvd.nist.gov/vuln/detail/${item.cveId}',
                ),
                icon: const Icon(Icons.open_in_new_rounded, size: 15),
                label: Text(_t('تحقق من تفاصيل CVE', 'Verify CVE details')),
              ),
            ),
          ],
        ),
      ),
    ),
  );

  Widget _sectionIntro(String title, String detail) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        title,
        style: TextStyle(
          color: _p.text,
          fontSize: 16,
          fontWeight: FontWeight.w900,
        ),
      ),
      const SizedBox(height: 5),
      Text(
        detail,
        style: TextStyle(color: _p.muted, fontSize: 11, height: 1.5),
      ),
    ],
  );

  Widget _progressStrip(int done, int total, String label) => _surface(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
      child: Row(
        children: [
          Icon(Icons.check_circle_outline_rounded, color: _p.accent, size: 19),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                color: _p.text,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Text(
            '$done/$total',
            style: TextStyle(color: _p.accent, fontWeight: FontWeight.w900),
          ),
        ],
      ),
    ),
  );

  Widget _referenceButton(String title, String url) => Align(
    alignment: AlignmentDirectional.centerStart,
    child: TextButton.icon(
      onPressed: () => _openOfficial(url),
      icon: const Icon(Icons.open_in_new_rounded, size: 15),
      label: Text(
        _t('المصدر الرسمي: $title', 'Official source: $title'),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      ),
      style: TextButton.styleFrom(
        foregroundColor: _p.accent,
        padding: const EdgeInsets.symmetric(horizontal: 2),
      ),
    ),
  );

  Widget _kevUseBadge(bool knownRansomwareUse) {
    final color = knownRansomwareUse
        ? const Color(0xffe85d75)
        : const Color(0xffd79b3b);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .14),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        knownRansomwareUse
            ? _t('استخدام فدية معروف', 'Known ransomware use')
            : _t('استغلال معروف', 'Known exploited'),
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.w800,
          fontSize: 9,
        ),
      ),
    );
  }

  Widget _riskBadge(String risk) {
    final color = risk == 'high'
        ? const Color(0xffe85d75)
        : risk == 'medium'
        ? const Color(0xffd79b3b)
        : const Color(0xff42b8a3);
    final text = risk == 'high'
        ? _t('أولوية عالية', 'High priority')
        : risk == 'medium'
        ? _t('أولوية متوسطة', 'Medium priority')
        : _t('تحسين إضافي', 'Additional hardening');
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .14),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.w800,
          fontSize: 9,
        ),
      ),
    );
  }

  Widget _notice(IconData icon, String title, String text) => Container(
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(
      color: _p.accent.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(15),
      border: Border.all(color: _p.accent.withValues(alpha: .23)),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: _p.accent, size: 19),
        const SizedBox(width: 9),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: _p.text,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                text,
                style: TextStyle(color: _p.muted, height: 1.45, fontSize: 10),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _empty(String text) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
    child: Center(
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(color: _p.muted, height: 1.5, fontSize: 11),
      ),
    ),
  );

  Widget _surface({required Widget child}) => Container(
    decoration: BoxDecoration(
      color: _p.surface,
      borderRadius: BorderRadius.circular(17),
      border: Border.all(color: _p.border),
    ),
    child: child,
  );
}
