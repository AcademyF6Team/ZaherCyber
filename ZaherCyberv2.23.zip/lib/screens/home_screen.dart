import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/learning_content.dart';
import '../data/learning_resources.dart';
import '../data/project_links.dart';
import '../data/protection_guides.dart';
import '../data/sources.dart';
import '../data/tool_projects.dart';
import '../models/article.dart';
import '../models/kev_item.dart';
import '../models/tool_project.dart';
import '../models/tool_release.dart';
import '../services/download_manager.dart';
import '../services/feed_service.dart';
import '../services/github_catalog_service.dart';
import '../services/source_health_service.dart';
import '../services/vulnerability_service.dart';
import '../theme/app_theme.dart';
import '../utils/app_copy.dart';
import '../widgets/page_navigation_controls.dart';
import 'academy_offline_screen.dart';
import 'article_detail_screen.dart';
import 'ctf_hub_screen.dart';
import 'cyber_desktop_screen.dart';
import 'about_center_screen.dart';
import 'downloads_screen.dart';
import 'learning_center_screen.dart';
import 'external_resources_screen.dart';
import 'f6_security_tools_screen.dart';
import 'fahes_screen.dart';
import 'security_workbench_screen.dart';
import 'zaher_assistant_screen.dart';
import 'protection_center_screen.dart';
import 'tool_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  final Locale locale;
  final ValueChanged<Locale> onLocaleChanged;
  final ValueChanged<int> onThemeChanged;

  const HomeScreen({
    super.key,
    required this.locale,
    required this.onLocaleChanged,
    required this.onThemeChanged,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  static const List<double> _textScaleOptions = [1.0, 1.1, 1.2];
  final FeedService _feeds = FeedService();
  final FeedService _tutorialFeeds = FeedService();
  final FeedSourceHealthService _newsSourceHealth = FeedSourceHealthService(
    'news_source_health_v1',
  );
  final FeedSourceHealthService _tutorialSourceHealth = FeedSourceHealthService(
    'tutorial_source_health_v1',
  );
  final GitHubCatalogService _catalog = GitHubCatalogService();
  final DownloadManagerService _downloads = DownloadManagerService();
  final VulnerabilityService _vulnerabilities = VulnerabilityService();
  final TextEditingController _newsSearch = TextEditingController();
  final TextEditingController _toolSearch = TextEditingController();
  final TextEditingController _sourceSearch = TextEditingController();
  final TextEditingController _tutorialSearch = TextEditingController();
  final ScrollController _homeScrollController = ScrollController();
  final ScrollController _toolScrollController = ScrollController();
  final ScrollController _knowledgeScrollController = ScrollController();
  final Map<String, Future<ToolRelease?>> _releaseFutures = {};

  List<Article> _articles = [];
  List<Article> _tutorialArticles = [];
  List<KevItem> _kevItems = [];
  List<KevItem> _protectionKevItems = [];
  List<ToolProject> _discoveredProjects = [];
  final Map<String, Article> _savedArticles = {};
  final Map<String, String> _savedTags = {};
  static const _savedTagIds = ['later', 'learning', 'threat', 'incident'];
  String _savedFilter = 'all';
  final Set<String> _disabledSources = {};
  int _tab = 0;
  bool _desktopShowingNews = false;
  int _desktopResetToken = 0;
  bool _openedFromDesktop = false;
  bool _sectionSwitching = false;
  late final AnimationController _sectionFade;
  String _newsCategory = 'all';
  String _toolPlatform = 'all';
  String _toolCategory = 'all';
  String _toolLicense = 'all';
  String _toolDifficulty = 'all';
  String _newsQuery = '';
  String _toolQuery = '';
  String _tutorialQuery = '';
  String _tutorialCategory = 'all';
  bool _loadingNews = false;
  bool _loadingTutorials = false;
  bool _newsRefreshError = false;
  bool _tutorialRefreshError = false;
  bool _loadingKev = true;
  bool _discovering = false;
  bool _autoRefresh = true;
  bool _autoDiscover = true;
  bool _compactCards = false;
  bool _showHomeScrollTop = false;
  bool _showToolScrollTop = false;
  bool _showKnowledgeScrollTop = false;
  double _textScale = 1.0;
  int _refreshIntervalMinutes = 30;
  DateTime? _lastRefresh;
  DateTime? _lastTutorialRefresh;
  Timer? _automaticRefreshTimer;
  late final AnimationController _radarAnimation;

  AppPalette get _p => Theme.of(context).extension<AppPalette>()!;
  String _t(String ar, String en) => copy(context, ar, en);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _radarAnimation = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 7),
    )..repeat();
    _sectionFade = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 170),
      value: 1,
    );
    _homeScrollController.addListener(_updateHomeScrollTop);
    _toolScrollController.addListener(_updateToolScrollTop);
    _knowledgeScrollController.addListener(_updateKnowledgeScrollTop);
    _configureRefreshTimer();
    unawaited(_bootstrap());
  }

  void _updateHomeScrollTop() {
    if (!mounted) return;
    final shouldShow =
        _homeScrollController.hasClients && _homeScrollController.offset > 520;
    if (shouldShow != _showHomeScrollTop) {
      setState(() => _showHomeScrollTop = shouldShow);
    }
  }

  void _updateToolScrollTop() {
    if (!mounted) return;
    final shouldShow =
        _toolScrollController.hasClients && _toolScrollController.offset > 520;
    if (shouldShow != _showToolScrollTop) {
      setState(() => _showToolScrollTop = shouldShow);
    }
  }

  void _updateKnowledgeScrollTop() {
    if (!mounted) return;
    final shouldShow =
        _knowledgeScrollController.hasClients &&
        _knowledgeScrollController.offset > 420;
    if (shouldShow != _showKnowledgeScrollTop) {
      setState(() => _showKnowledgeScrollTop = shouldShow);
    }
  }

  void _configureRefreshTimer() {
    _automaticRefreshTimer?.cancel();
    _automaticRefreshTimer = Timer.periodic(
      Duration(minutes: _refreshIntervalMinutes),
      (_) {
        if (!_autoRefresh ||
            WidgetsBinding.instance.lifecycleState !=
                AppLifecycleState.resumed) {
          return;
        }
        unawaited(_refreshNews(silent: true));
        unawaited(_refreshTutorials(silent: true));
        unawaited(_refreshKev());
        unawaited(_loadDiscoveredProjects());
      },
    );
  }

  Future<void> _bootstrap() async {
    await _downloads.initialize();
    await Future.wait([_newsSourceHealth.load(), _tutorialSourceHealth.load()]);
    final prefs = await SharedPreferences.getInstance();
    final cachedArticles = _decodeArticles(prefs.getString('feed_cache_v2'));
    final cachedTutorials = _decodeArticles(
      prefs.getString('tutorial_cache_v1'),
    );
    final saved = _decodeArticles(prefs.getString('saved_articles_v2'));
    final rawSavedTags = prefs.getString('saved_article_tags_v1');
    if (rawSavedTags != null) {
      try {
        final decoded = jsonDecode(rawSavedTags);
        if (decoded is Map) {
          _savedTags.addAll({
            for (final entry in decoded.entries)
              if (_savedTagIds.contains(entry.value.toString()))
                entry.key.toString(): entry.value.toString(),
          });
        }
      } catch (_) {
        // A malformed tag map must not affect saved articles.
      }
    }
    final oldFavoriteUrls =
        prefs.getStringList('favorites')?.toSet() ?? <String>{};
    for (final item in saved) {
      _savedArticles[item.link] = item;
    }
    for (final item in cachedArticles.where(
      (e) => oldFavoriteUrls.contains(e.link),
    )) {
      _savedArticles.putIfAbsent(item.link, () => item);
    }
    _disabledSources.addAll(
      prefs.getStringList('disabled_sources_v1') ?? const [],
    );
    _lastRefresh = DateTime.tryParse(
      prefs.getString('feed_last_refresh') ?? '',
    );
    _lastTutorialRefresh = DateTime.tryParse(
      prefs.getString('tutorial_last_refresh') ?? '',
    );
    _autoRefresh = prefs.getBool('auto_refresh_enabled') ?? true;
    _autoDiscover = prefs.getBool('auto_discover_projects') ?? true;
    final savedInterval = prefs.getInt('feed_refresh_minutes') ?? 30;
    _refreshIntervalMinutes = const [15, 30, 60].contains(savedInterval)
        ? savedInterval
        : 30;
    _compactCards = prefs.getBool('compact_news_cards') ?? false;
    final savedTextScale = prefs.getDouble('accessible_text_scale_v1') ?? 1.0;
    _textScale = _textScaleOptions.contains(savedTextScale)
        ? savedTextScale
        : 1.0;
    _configureRefreshTimer();
    final oldTranslationKeys = prefs
        .getKeys()
        .where((key) => key.startsWith('translation_ar_v1_'))
        .toList();
    for (final key in oldTranslationKeys) {
      await prefs.remove(key);
    }
    await prefs.remove('translation_cache_keys_v1');
    await prefs.remove('translation_wifi_only');
    await prefs.remove('show_decorative_stickers');
    await prefs.remove('decorative_sticker_pack');
    if (mounted) {
      setState(() {
        _articles = cachedArticles;
        _tutorialArticles = cachedTutorials;
      });
    }
    unawaited(_loadDiscoveredProjects());
    unawaited(_refreshKev());
    if (_autoRefresh) {
      unawaited(_refreshNews(silent: true));
      unawaited(_refreshTutorials(silent: true));
    }
  }

  List<Article> _decodeArticles(String? raw) {
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List)
          .whereType<Map>()
          .map((row) => Article.fromJson(Map<String, dynamic>.from(row)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> _loadDiscoveredProjects({bool force = false}) async {
    if (!_autoDiscover && !force) return;
    if (_discovering) return;
    if (mounted) setState(() => _discovering = true);
    try {
      final items = await _catalog.discoverOpenSourceProjects(force: force);
      if (mounted) setState(() => _discoveredProjects = items);
    } finally {
      if (mounted) setState(() => _discovering = false);
    }
  }

  Future<void> _refreshNews({bool silent = false}) async {
    if (_loadingNews) return;
    if (mounted) {
      setState(() {
        _loadingNews = true;
        _newsRefreshError = false;
      });
    }
    try {
      final candidateUrls = newsSources
          .where((source) => !_disabledSources.contains(source.url))
          .map((source) => source.url);
      final probes = _newsSourceHealth.probesDueFor(candidateUrls);
      await _newsSourceHealth.markProbesStarted(probes);
      final items = await _feeds.fetchAll(
        excludedUrls: {
          ..._disabledSources,
          ..._newsSourceHealth.quarantinedUrls.difference(probes),
        },
      );
      await _newsSourceHealth.recordCycle(
        successfulUrls: _feeds.lastSuccessfulUrls,
        failures: _feeds.lastSourceFailures,
        globalConnectivityFailure: _feeds.lastCycleWasGlobalConnectivityFailure,
      );
      _newsRefreshError =
          _feeds.lastFailedSources > 0 && _feeds.lastSuccessfulSources == 0;
      final prefs = await SharedPreferences.getInstance();
      if (_feeds.lastSuccessfulSources > 0) {
        _lastRefresh = DateTime.now();
        await prefs.setString(
          'feed_last_refresh',
          _lastRefresh!.toIso8601String(),
        );
      }
      if (items.isNotEmpty) {
        _articles = items.take(450).toList();
        await prefs.setString(
          'feed_cache_v2',
          jsonEncode(_articles.map((e) => e.toJson()).toList()),
        );
      }
      if (mounted) setState(() {});
      if (!silent && items.isEmpty && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'لم تتوفر مقالات جديدة؛ أُبقيت الأخبار المحفوظة محلياً.',
                'No new stories were available; cached items were kept.',
              ),
            ),
          ),
        );
      }
    } catch (_) {
      _newsRefreshError = true;
      if (!silent && mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'تعذر الاتصال بالمصادر الآن. تحقق من الشبكة ثم أعد المحاولة.',
                'Could not reach the feeds. Check your connection and try again.',
              ),
            ),
          ),
        );
    } finally {
      if (mounted) setState(() => _loadingNews = false);
    }
  }

  Future<void> _refreshTutorials({bool silent = false}) async {
    if (_loadingTutorials) return;
    if (mounted) {
      setState(() {
        _loadingTutorials = true;
        _tutorialRefreshError = false;
      });
    }
    try {
      final candidateUrls = tutorialSources
          .where((source) => !_disabledSources.contains(source.url))
          .map((source) => source.url);
      final probes = _tutorialSourceHealth.probesDueFor(candidateUrls);
      await _tutorialSourceHealth.markProbesStarted(probes);
      final items = await _tutorialFeeds.fetchAll(
        excludedUrls: {
          ..._disabledSources,
          ..._tutorialSourceHealth.quarantinedUrls.difference(probes),
        },
        sources: tutorialSources,
      );
      await _tutorialSourceHealth.recordCycle(
        successfulUrls: _tutorialFeeds.lastSuccessfulUrls,
        failures: _tutorialFeeds.lastSourceFailures,
        globalConnectivityFailure:
            _tutorialFeeds.lastCycleWasGlobalConnectivityFailure,
      );
      _tutorialRefreshError =
          _tutorialFeeds.lastFailedSources > 0 &&
          _tutorialFeeds.lastSuccessfulSources == 0;
      final prefs = await SharedPreferences.getInstance();
      if (_tutorialFeeds.lastSuccessfulSources > 0) {
        _lastTutorialRefresh = DateTime.now();
        await prefs.setString(
          'tutorial_last_refresh',
          _lastTutorialRefresh!.toIso8601String(),
        );
      }
      if (items.isNotEmpty) {
        _tutorialArticles = items.take(300).toList();
        await prefs.setString(
          'tutorial_cache_v1',
          jsonEncode(_tutorialArticles.map((item) => item.toJson()).toList()),
        );
      }
      if (mounted) setState(() {});
      if (!silent && items.isEmpty && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'لا تتوفر مقالات جديدة الآن؛ أُبقيت المقالات المحفوظة محلياً.',
                'No new tutorials are available; cached articles were kept.',
              ),
            ),
          ),
        );
      }
    } catch (_) {
      _tutorialRefreshError = true;
      if (!silent && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _t(
                'تعذر تحديث المقالات التعليمية الآن. تحقق من الاتصال ثم أعد المحاولة.',
                'Tutorial feeds could not be refreshed. Check your connection and retry.',
              ),
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _loadingTutorials = false);
    }
  }

  String _formatRefreshTime(DateTime? value) {
    if (value == null) {
      return _t('لا يوجد تحديث ناجح بعد', 'No successful update yet');
    }
    final date = value.toLocal();
    String twoDigits(int part) => part.toString().padLeft(2, '0');
    return '${date.year}-${twoDigits(date.month)}-${twoDigits(date.day)} '
        '${twoDigits(date.hour)}:${twoDigits(date.minute)}';
  }

  Widget _feedStatusCard({required bool tutorials}) {
    final service = tutorials ? _tutorialFeeds : _feeds;
    final loading = tutorials ? _loadingTutorials : _loadingNews;
    final failed = tutorials ? _tutorialRefreshError : _newsRefreshError;
    final failedSources = service.lastFailedSources;
    final successfulSources = service.lastSuccessfulSources;
    final sources = tutorials ? tutorialSources : newsSources;
    final quarantinedUrls = tutorials
        ? _tutorialSourceHealth.quarantinedUrls
        : _newsSourceHealth.quarantinedUrls;
    final enabledCount = sources
        .where(
          (source) =>
              !_disabledSources.contains(source.url) &&
              !quarantinedUrls.contains(source.url),
        )
        .length;
    final quarantinedCount = sources
        .where((source) => quarantinedUrls.contains(source.url))
        .length;
    final lastRefresh = tutorials ? _lastTutorialRefresh : _lastRefresh;
    final warning = failed || failedSources > 0;
    final color = warning ? Colors.orange : _p.accent;
    final duplicateNote = service.lastDuplicateCount > 0
        ? _t(
            ' · أُخفي ${service.lastDuplicateCount} عنواناً مكرراً',
            ' · ${service.lastDuplicateCount} duplicate headlines hidden',
          )
        : '';
    final subtitle = loading
        ? _t('جارٍ الاتصال بموجزات الناشرين…', 'Refreshing publisher feeds…')
        : enabledCount == 0 && quarantinedCount > 0
        ? _t(
            'عُزلت الموجزات المتعثرة مؤقتاً؛ راجع مركز التطبيق لاستعادتها.',
            'Unavailable feeds were temporarily quarantined; review the app center to restore them.',
          )
        : enabledCount == 0
        ? _t(
            'كل الموجزات معطّلة. فعّل مصادر من إعدادات إدارة المحتوى.',
            'All feeds are disabled. Enable sources in feed settings.',
          )
        : failed
        ? _t(
            'تعذر تحديث المصادر الآن. المحتوى المحفوظ باقٍ، ويمكن إعادة المحاولة.',
            'Feeds could not be refreshed. Cached content remains available; retry when ready.',
          )
        : failedSources > 0
        ? _t(
            'تعذر الوصول إلى $failedSources من $enabledCount مصدر؛ قد يتأخر بعض المحتوى.',
            '$failedSources of $enabledCount feeds could not be reached; some items may be delayed.',
          )
        : _t(
            'تحديث ناجح من $successfulSources من $enabledCount مصدر. آخر نجاح: ${_formatRefreshTime(lastRefresh)}$duplicateNote',
            'Updated successfully from $successfulSources of $enabledCount feeds. Last success: ${_formatRefreshTime(lastRefresh)}$duplicateNote',
          );
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: Container(
        padding: const EdgeInsetsDirectional.fromSTEB(12, 9, 7, 9),
        decoration: BoxDecoration(
          color: _p.surface,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: color.withValues(alpha: .35)),
        ),
        child: Row(
          children: [
            Icon(
              loading
                  ? Icons.sync_rounded
                  : warning
                  ? Icons.warning_amber_rounded
                  : Icons.schedule_rounded,
              color: color,
              size: 19,
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Text(
                subtitle,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: _p.muted, fontSize: 10, height: 1.35),
              ),
            ),
            const SizedBox(width: 4),
            if (loading)
              SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: color),
              )
            else
              IconButton(
                tooltip: _t('إعادة محاولة التحديث', 'Retry feed refresh'),
                visualDensity: VisualDensity.compact,
                onPressed: () =>
                    tutorials ? _refreshTutorials() : _refreshNews(),
                icon: Icon(Icons.refresh_rounded, color: color, size: 20),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _refreshKev({bool force = false}) async {
    if (mounted) setState(() => _loadingKev = true);
    try {
      final items = await _vulnerabilities.latest(force: force);
      final watchlistItems = await _vulnerabilities.watchlistCatalog();
      if (mounted)
        setState(() {
          _kevItems = items;
          _protectionKevItems = watchlistItems;
          _loadingKev = false;
        });
    } catch (_) {
      if (mounted) setState(() => _loadingKev = false);
    }
  }

  void _syncAutoRefresh(bool enabled) async {
    setState(() => _autoRefresh = enabled);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('auto_refresh_enabled', enabled);
    if (enabled) {
      unawaited(_refreshNews(silent: true));
      unawaited(_refreshTutorials(silent: true));
    }
  }

  Future<void> _setRefreshInterval(int minutes) async {
    setState(() => _refreshIntervalMinutes = minutes);
    _configureRefreshTimer();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('feed_refresh_minutes', minutes);
    if (_autoRefresh) {
      unawaited(_refreshNews(silent: true));
      unawaited(_refreshTutorials(silent: true));
    }
  }

  Future<void> _setCompactCards(bool enabled) async {
    setState(() => _compactCards = enabled);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('compact_news_cards', enabled);
  }

  Future<void> _setTextScale(double scale) async {
    if (!_textScaleOptions.contains(scale)) return;
    setState(() => _textScale = scale);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('accessible_text_scale_v1', scale);
  }

  String _textScaleLabel(double scale) => scale == 1.0
      ? _t('عادي', 'Default')
      : scale == 1.1
      ? _t('كبير', 'Large')
      : _t('أكبر', 'Extra large');

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      if (!_radarAnimation.isAnimating) _radarAnimation.repeat();
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden) {
      _radarAnimation.stop();
    }
    if (state == AppLifecycleState.resumed &&
        _autoRefresh &&
        (_lastRefresh == null ||
            DateTime.now().difference(_lastRefresh!) >
                Duration(minutes: _refreshIntervalMinutes))) {
      unawaited(_refreshNews(silent: true));
      unawaited(_refreshTutorials(silent: true));
      unawaited(_refreshKev());
      unawaited(_loadDiscoveredProjects());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _automaticRefreshTimer?.cancel();
    _newsSearch.dispose();
    _toolSearch.dispose();
    _sourceSearch.dispose();
    _tutorialSearch.dispose();
    _homeScrollController.dispose();
    _toolScrollController.dispose();
    _knowledgeScrollController.dispose();
    _feeds.dispose();
    _tutorialFeeds.dispose();
    _catalog.dispose();
    _downloads.dispose();
    _vulnerabilities.dispose();
    _radarAnimation.dispose();
    _sectionFade.dispose();
    super.dispose();
  }

  Future<void> _selectTab(int index, {bool fromDesktop = false}) async {
    if (_sectionSwitching) return;
    if (index == _tab && !(index == 0 && _desktopShowingNews)) {
      if (index == 0 && _openedFromDesktop) {
        setState(() => _openedFromDesktop = false);
      }
      return;
    }
    FocusManager.instance.primaryFocus?.unfocus();
    _sectionSwitching = true;
    try {
      await _sectionFade.reverse();
      if (!mounted) return;
      setState(() {
        _tab = index;
        _desktopShowingNews = false;
        _openedFromDesktop = fromDesktop && index != 0;
      });
      await _sectionFade.forward();
    } finally {
      _sectionSwitching = false;
    }
  }

  Future<void> _openDesktopPage(String section) async {
    if (section == 'news') {
      if (_sectionSwitching) return;
      FocusManager.instance.primaryFocus?.unfocus();
      _sectionSwitching = true;
      try {
        await _sectionFade.reverse();
        if (!mounted) return;
        setState(() {
          _tab = 0;
          _desktopShowingNews = true;
          _openedFromDesktop = true;
        });
        await _sectionFade.forward();
      } finally {
        _sectionSwitching = false;
      }
      return;
    }
    final index = switch (section) {
      'arsenal' => 1,
      'learn' => 2,
      'protect' => 3,
      'saved' => 4,
      'downloads' => 5,
      'settings' => 6,
      _ => 0,
    };
    await _selectTab(index, fromDesktop: true);
  }

  Future<void> _searchFromDesktop(String query) async {
    final term = query.trim().toLowerCase();
    if (term.isEmpty) return;
    final toolsMatch = _allTools.any(
      (tool) =>
          '${tool.name} ${tool.category} ${tool.descriptionAr} ${tool.descriptionEn} ${tool.githubRepo ?? ''}'
              .toLowerCase()
              .contains(term),
    );
    if (toolsMatch) {
      _toolSearch.text = query;
      setState(() {
        _toolQuery = query;
        _toolPlatform = 'all';
        _toolCategory = 'all';
      });
      await _selectTab(1, fromDesktop: true);
      return;
    }
    final tutorialMatch = _tutorialArticles.any(
      (article) =>
          '${article.title} ${article.source} ${article.summary} ${article.category}'
              .toLowerCase()
              .contains(term),
    );
    if (tutorialMatch) {
      _tutorialSearch.text = query;
      _tutorialQuery = query;
      _tutorialCategory = 'all';
      await _selectTab(2, fromDesktop: true);
      if (mounted) _openKnowledgePage(_tutorialsPage());
      return;
    }
    final newsMatch = _articles.any(
      (article) =>
          '${article.title} ${article.source} ${article.summary} ${article.category}'
              .toLowerCase()
              .contains(term),
    );
    if (newsMatch) {
      _newsSearch.text = query;
      setState(() {
        _newsQuery = query;
        _newsCategory = 'all';
      });
      await _openDesktopPage('news');
      return;
    }
    const appRoutes = <String, String>{
      'news': 'news',
      'الأخبار': 'news',
      'arsenal': 'arsenal',
      'الترسانة': 'arsenal',
      'knowledge': 'learn',
      'المعرفة': 'learn',
      'protection': 'protect',
      'الحماية': 'protect',
      'fahes': 'fahes',
      'فاحص': 'fahes',
      'saved': 'saved',
      'المحفوظات': 'saved',
      'downloads': 'downloads',
      'التنزيلات': 'downloads',
      'settings': 'settings',
      'الإعدادات': 'settings',
      'security workbench': 'security-workbench',
      'مركز العمل الأمني': 'security-workbench',
      'api hub': 'security-workbench',
      'دليل api': 'security-workbench',
      'assistant': 'zaher-assistant',
      'المساعد': 'zaher-assistant',
      'zaher assistant': 'zaher-assistant',
    };
    for (final entry in appRoutes.entries) {
      if (term == entry.key || term.contains(entry.key)) {
        if (entry.value == 'security-workbench') {
          await Navigator.of(context).push<void>(
            MaterialPageRoute<void>(builder: (_) => const SecurityWorkbenchScreen()),
          );
          return;
        }
        if (entry.value == 'zaher-assistant') {
          await Navigator.of(context).push<void>(MaterialPageRoute<void>(builder: (_) => ZaherAssistantScreen(onOpenSection: (section) => _searchFromDesktop(section))));
          return;
        }
        if (entry.value == 'fahes') {
          await _openFahes();
          return;
        }
        await _openDesktopPage(entry.value);
        return;
      }
    }
    if (term.contains('security-workbench') || term.contains('api hub')) {
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => const SecurityWorkbenchScreen()),
      );
      return;
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _t(
              'لم أجد تطابقاً في الأخبار أو الأدوات أو المقالات المحمّلة.',
              'No match found in cached news, tools, or tutorials.',
            ),
          ),
        ),
      );
    }
  }

  Future<void> _openDesktopArticle(Article article) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ArticleDetailScreen(
          article: article,
          isSaved: _savedArticles.containsKey(article.link),
          onToggleSaved: _toggleSaved,
        ),
      ),
    );
    if (mounted) setState(() {});
  }

  Future<void> _openFahes() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 22),
        clipBehavior: Clip.antiAlias,
        child: SizedBox(
          width: 560,
          height: MediaQuery.sizeOf(dialogContext).height * .88,
          child: const FahesScreen(),
        ),
      ),
    );
  }

  void _handleSystemBack() {
    if (_desktopShowingNews) {
      unawaited(_selectTab(0));
    } else if (_tab != 0 && _openedFromDesktop) {
      unawaited(_selectTab(0));
    }
  }

  Widget _desktopAndNews() => Stack(
    children: [
      Offstage(
        offstage: _desktopShowingNews,
        child: TickerMode(
          enabled: !_desktopShowingNews,
          child: CyberDesktopScreen(
            resetToken: _desktopResetToken,
            onOpenLearning: (lessonId) => Navigator.of(context).push<void>(
              MaterialPageRoute<void>(
                builder: (_) => LearningCenterScreen(initialLessonId: lessonId),
              ),
            ),
            articles: _articles,
            lastUpdated: _lastRefresh,
            isUpdating: _loadingNews,
            updateFailed: _newsRefreshError || _tutorialRefreshError,
            updatedSources:
                _feeds.lastSuccessfulSources +
                _tutorialFeeds.lastSuccessfulSources,
            failedSources:
                _feeds.lastFailedSources + _tutorialFeeds.lastFailedSources,
            onRefresh: () async {
              await Future.wait([_refreshNews(), _refreshTutorials()]);
            },
            onGlobalSearch: (query) => unawaited(_searchFromDesktop(query)),
            onOpenSection: (section) => unawaited(_openDesktopPage(section)),
            onOpenAcademy: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => AcademyOfflineScreen(
                  isArabic:
                      Localizations.localeOf(context).languageCode != 'en',
                ),
              ),
            ),
            onOpenCtf: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const CtfHubScreen()),
            ),
            onOpenExternalResources: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const ExternalResourcesScreen()),
            ),
            onOpenSecurityTools: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const F6SecurityToolsScreen()),
            ),
            onOpenWorkbench: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const SecurityWorkbenchScreen()),
            ),
            onOpenAssistant: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => ZaherAssistantScreen(onOpenSection: (section) => _searchFromDesktop(section))),
            ),
            onOpenArticle: _openDesktopArticle,
          ),
        ),
      ),
      Offstage(
        offstage: !_desktopShowingNews,
        child: TickerMode(enabled: _desktopShowingNews, child: _homePage()),
      ),
    ],
  );

  Widget _desktopReturnBar() => Material(
    color: _p.surface,
    child: Padding(
      padding: const EdgeInsetsDirectional.fromSTEB(8, 4, 14, 4),
      child: Row(
        children: [
          IconButton(
            tooltip: _t('العودة إلى F6-OS', 'Back to F6-OS'),
            onPressed: () => unawaited(_selectTab(0)),
            icon: Icon(Icons.arrow_back_rounded, color: _p.accent, size: 19),
          ),
          Expanded(
            child: Text(
              'F6-OS  /  ${_desktopSectionName(_tab)}',
              style: TextStyle(
                color: _p.text,
                fontSize: 11,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          Icon(Icons.space_dashboard_outlined, color: _p.muted, size: 17),
        ],
      ),
    ),
  );

  String _desktopSectionName(int index) => switch (index) {
    1 => _t('الترسانة', 'ARSENAL'),
    2 => _t('المعرفة', 'KNOWLEDGE'),
    3 => _t('مركز الحماية', 'PROTECTION'),
    4 => _t('المحفوظات', 'SAVED'),
    5 => _t('التنزيلات', 'DOWNLOADS'),
    6 => _t('الإعدادات', 'SETTINGS'),
    _ => _t('الأخبار', 'NEWS'),
  };

  @override
  Widget build(BuildContext context) {
    final p = _p;
    final t = _t;
    final inheritedMedia = MediaQuery.of(context);
    final systemTextScale = inheritedMedia.textScaler.scale(1.0);
    return Directionality(
      textDirection: appTextDirection(context),
      child: MediaQuery(
        data: inheritedMedia.copyWith(
          textScaler: TextScaler.linear(systemTextScale * _textScale),
        ),
        child: PopScope<void>(
          canPop: !(_desktopShowingNews || (_tab != 0 && _openedFromDesktop)),
          onPopInvokedWithResult: (didPop, result) {
            if (!didPop) _handleSystemBack();
          },
          child: Scaffold(
            backgroundColor: p.background,
            floatingActionButton:
                _tab == 0 && _desktopShowingNews && _showHomeScrollTop
                ? FloatingActionButton.small(
                    heroTag: 'news-scroll-to-top',
                    tooltip: t(
                      'العودة إلى أعلى الأخبار',
                      'Back to top of news',
                    ),
                    backgroundColor: p.accent,
                    foregroundColor: p.background,
                    onPressed: () => _homeScrollController.animateTo(
                      0,
                      duration: const Duration(milliseconds: 320),
                      curve: Curves.easeOutCubic,
                    ),
                    child: const Icon(Icons.vertical_align_top_rounded),
                  )
                : _tab == 1 && _showToolScrollTop
                ? FloatingActionButton.small(
                    heroTag: 'arsenal-scroll-to-top',
                    tooltip: t(
                      'العودة إلى أعلى الترسانة',
                      'Back to top of arsenal',
                    ),
                    backgroundColor: p.accent,
                    foregroundColor: p.background,
                    onPressed: () => _toolScrollController.animateTo(
                      0,
                      duration: const Duration(milliseconds: 320),
                      curve: Curves.easeOutCubic,
                    ),
                    child: const Icon(Icons.vertical_align_top_rounded),
                  )
                : null,
            body: SafeArea(
              child: Column(
                children: [
                  if (_tab != 0 && _openedFromDesktop) _desktopReturnBar(),
                  Expanded(
                    child: FadeTransition(
                      opacity: _sectionFade,
                      child: IndexedStack(
                        index: _tab,
                        children: [
                          _desktopAndNews(),
                          _toolHub(),
                          _learningHub(),
                          ProtectionCenterScreen(
                            checks: protectionChecks,
                            playbooks: incidentPlaybooks,
                            kevItems: _protectionKevItems,
                            articles: [..._articles, ..._tutorialArticles],
                            tools: _allTools,
                            isLoadingKev: _loadingKev,
                            onRefreshKev: () => _refreshKev(force: true),
                          ),
                          _savedPage(),
                          DownloadsScreen(downloads: _downloads),
                          _settingsPage(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: NavigationBar(
              height: 67,
              backgroundColor: p.surface,
              indicatorColor: p.accent.withValues(alpha: .15),
              selectedIndex: _openedFromDesktop && _tab != 0 ? 0 : _tab,
              labelBehavior:
                  NavigationDestinationLabelBehavior.onlyShowSelected,
              onDestinationSelected: (index) => unawaited(_selectTab(index)),
              destinations: [
                NavigationDestination(
                  icon: const Icon(Icons.space_dashboard_outlined),
                  selectedIcon: Icon(
                    Icons.space_dashboard_rounded,
                    color: p.accent,
                  ),
                  label: 'F6-OS',
                ),
                NavigationDestination(
                  icon: const Icon(Icons.shield_outlined),
                  selectedIcon: Icon(Icons.shield_rounded, color: p.accent),
                  label: t('الترسانة', 'Arsenal'),
                ),
                NavigationDestination(
                  icon: const Icon(Icons.school_outlined),
                  selectedIcon: Icon(Icons.school_rounded, color: p.accent),
                  label: t('المعرفة', 'Learn'),
                ),
                NavigationDestination(
                  icon: const Icon(Icons.health_and_safety_outlined),
                  selectedIcon: Icon(
                    Icons.health_and_safety_rounded,
                    color: p.accent,
                  ),
                  label: t('الحماية', 'Protect'),
                ),
                NavigationDestination(
                  icon: const Icon(Icons.bookmark_border_rounded),
                  selectedIcon: Icon(Icons.bookmark_rounded, color: p.accent),
                  label: t('المحفوظات', 'Saved'),
                ),
                NavigationDestination(
                  icon: const Icon(Icons.download_outlined),
                  selectedIcon: Icon(Icons.download_rounded, color: p.accent),
                  label: t('التنزيلات', 'Downloads'),
                ),
                NavigationDestination(
                  icon: const Icon(Icons.tune_rounded),
                  selectedIcon: Icon(Icons.tune_rounded, color: p.accent),
                  label: t('الإعدادات', 'Settings'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _homePage() {
    final entries = _filteredArticles;
    return RefreshIndicator(
      color: _p.accent,
      backgroundColor: _p.surface,
      onRefresh: () => _refreshNews(),
      child: CustomScrollView(
        controller: _homeScrollController,
        slivers: [
          if (_desktopShowingNews)
            SliverToBoxAdapter(child: _desktopReturnBar()),
          SliverToBoxAdapter(child: _topBar()),
          SliverToBoxAdapter(child: _hero()),
          SliverToBoxAdapter(child: _feedStatusCard(tutorials: false)),
          SliverToBoxAdapter(child: _newsSearchBox()),
          SliverToBoxAdapter(child: _newsCategoryRail()),
          SliverToBoxAdapter(
            child: _filterSummary(
              keyName: 'news-filter-summary',
              visibleCount: entries.length,
              totalCount: _articles.length,
              active: _newsCategory != 'all' || _newsQuery.trim().isNotEmpty,
              onClear: _clearNewsFilters,
            ),
          ),
          SliverToBoxAdapter(
            child: _sectionHeader(
              _t('آخر المستجدات', 'Latest intelligence'),
              trailing: _loadingNews
                  ? _t('جارٍ التحديث…', 'Updating…')
                  : '${entries.length} ${_t('خبر', 'stories')}',
            ),
          ),
          if (_loadingNews && entries.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: Center(child: CircularProgressIndicator(color: _p.accent)),
            )
          else if (entries.isEmpty)
            SliverToBoxAdapter(child: _emptyNews())
          else
            SliverList.builder(
              itemCount: entries.length,
              itemBuilder: (context, index) => _articleCard(entries[index]),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 20)),
        ],
      ),
    );
  }

  List<Article> get _filteredArticles {
    final query = _newsQuery.trim().toLowerCase();
    return _articles
        .where((article) {
          final matchesCategory = _matchesNewsCategory(article);
          final matchesQuery =
              query.isEmpty ||
              '${article.title} ${article.source} ${article.summary} ${article.category}'
                  .toLowerCase()
                  .contains(query);
          return matchesCategory && matchesQuery;
        })
        .take(260)
        .toList();
  }

  bool _matchesNewsCategory(Article article) {
    final value = article.category.toLowerCase();
    final title = article.title.toLowerCase();
    switch (_newsCategory) {
      case 'cyber':
        return value.contains('cyber') ||
            value.contains('security') ||
            value.contains('threat') ||
            value.contains('alert') ||
            value.contains('أمن');
      case 'vuln':
        return value.contains('exploit') ||
            value.contains('vulnerability') ||
            value.contains('cve') ||
            title.contains('cve-') ||
            title.contains('vulnerability');
      case 'tech':
        return value.contains('technology') ||
            value.contains('android') ||
            value.contains('tech') ||
            value.contains('software') ||
            value.contains('programming') ||
            value.contains('developer') ||
            value.contains('artificial intelligence') ||
            value.contains('machine learning') ||
            value == 'ai' ||
            value.contains('linux') ||
            value.contains('cloud') ||
            value.contains('hardware');
      case 'ai':
        return value == 'ai' ||
            value.contains('artificial intelligence') ||
            value.contains('machine learning') ||
            value.contains('ai ');
      case 'developer':
        return value.contains('programming') ||
            value.contains('developer') ||
            value.contains('software') ||
            value.contains('devops') ||
            value.contains('programming');
      case 'linux':
        return value.contains('linux');
      case 'cloud':
        return value.contains('cloud') || value.contains('devops');
      case 'arabic':
        return article.language.toUpperCase() == 'AR';
      case 'privacy':
        return value.contains('privacy');
      case 'android':
        return value.contains('android');
      case 'opensource':
        return value.contains('open source') || value.contains('open-source');
      case 'threat':
        return value.contains('threat') || value.contains('alert');
      case 'appsec':
        return value.contains('appsec') || value.contains('cloud');
      default:
        return true;
    }
  }

  List<String> get _newsCategories => const [
    'all',
    'cyber',
    'vuln',
    'tech',
    'ai',
    'developer',
    'linux',
    'cloud',
    'arabic',
    'privacy',
    'android',
    'opensource',
    'threat',
    'appsec',
  ];

  String _categoryLabel(String id) => switch (id) {
    'all' => _t('الكل', 'All'),
    'cyber' => _t('سيبراني', 'Cyber'),
    'vuln' => _t('ثغرات', 'Vulnerabilities'),
    'tech' => _t('تقنية', 'Technology'),
    'ai' => _t('ذكاء اصطناعي', 'AI'),
    'developer' => _t('برمجة وتطوير', 'Development'),
    'linux' => 'Linux',
    'cloud' => _t('السحابة', 'Cloud'),
    'arabic' => _t('عربي', 'Arabic'),
    'privacy' => _t('خصوصية', 'Privacy'),
    'android' => 'Android',
    'opensource' => _t('مفتوح المصدر', 'Open source'),
    'threat' => _t('تهديدات', 'Threat intel'),
    'appsec' => 'AppSec',
    _ => id,
  };

  Widget _topBar() {
    final p = _p;
    return Padding(
      padding: const EdgeInsets.fromLTRB(19, 15, 15, 7),
      child: Row(
        children: [
          Container(
            width: 45,
            height: 45,
            decoration: BoxDecoration(
              color: p.accent.withValues(alpha: .12),
              border: Border.all(color: p.accent.withValues(alpha: .3)),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Icon(Icons.security_rounded, color: p.accent, size: 25),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'ZAHERCYBER',
                  style: TextStyle(
                    color: p.text,
                    letterSpacing: 1.4,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _t('مركز الأمن والتقنية', 'Cyber & technology intelligence'),
                  style: TextStyle(color: p.muted, fontSize: 10),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: _showSources,
            tooltip: _t('مصادر الأخبار', 'News sources'),
            icon: Icon(Icons.rss_feed_rounded, color: p.accent),
          ),
          IconButton(
            onPressed: () => _refreshNews(),
            tooltip: _t('تحديث الأخبار', 'Refresh news'),
            icon: Icon(
              _loadingNews ? Icons.sync_rounded : Icons.refresh_rounded,
              color: p.text,
            ),
          ),
        ],
      ),
    );
  }

  Widget _hero() {
    final p = _p;
    final activeFeeds = allFeedSources.length - _disabledSources.length;
    final onlineFeeds =
        _feeds.lastSuccessfulSources + _tutorialFeeds.lastSuccessfulSources;
    final refreshedAt = _lastRefresh?.toLocal();
    final lastUpdateLabel = refreshedAt == null
        ? _t('بانتظار أول تحديث مباشر', 'Waiting for the first live refresh')
        : _t(
            'آخر تحديث ${refreshedAt.hour.toString().padLeft(2, '0')}:${refreshedAt.minute.toString().padLeft(2, '0')}',
            'Last refresh ${refreshedAt.hour.toString().padLeft(2, '0')}:${refreshedAt.minute.toString().padLeft(2, '0')}',
          );
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 7, 16, 14),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [p.heroStart, p.surface, p.heroEnd],
        ),
        border: Border.all(color: p.accent.withValues(alpha: .25)),
        boxShadow: [
          BoxShadow(
            color: p.accent.withValues(alpha: .06),
            blurRadius: 24,
            offset: const Offset(0, 9),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AnimatedBuilder(
                animation: _radarAnimation,
                builder: (context, child) => Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: p.accent,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: p.accent.withValues(
                          alpha: .35 + (_radarAnimation.value * .55),
                        ),
                        blurRadius: 5 + (_radarAnimation.value * 8),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                _t('رادار المعرفة المفتوحة', 'OPEN-SOURCE INTELLIGENCE RADAR'),
                style: TextStyle(
                  color: p.accent,
                  letterSpacing: 1.1,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const Spacer(),
              Icon(Icons.bolt_rounded, color: p.accent),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _t(
                        'حالة النظام: يقظة\nسيبرانية.',
                        'SYSTEM STATUS: CYBER\nAWARE.',
                      ),
                      style: TextStyle(
                        color: p.text,
                        fontSize: 25,
                        height: 1.12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -.4,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      _t(
                        'أخبار حيّة، ترسانة مفتوحة المصدر، ومراجع عملية — مراقبة مستمرة للمشهد.',
                        'Live feeds, an open-source arsenal and practical references — continuous scene monitoring.',
                      ),
                      style: TextStyle(
                        color: p.muted,
                        fontSize: 11,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              SizedBox(
                width: 112,
                height: 112,
                child: CustomPaint(
                  painter: _CyberRadarPainter(
                    accent: p.accent,
                    border: p.border,
                    progress: _radarAnimation,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: p.background.withValues(alpha: .42),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: p.border.withValues(alpha: .7)),
            ),
            child: Row(
              children: [
                Icon(Icons.radar_rounded, color: p.accent, size: 15),
                const SizedBox(width: 7),
                Expanded(
                  child: Text(
                    _t(
                      'الوحدات: FEEDS · TOOLS · KNOWLEDGE · PROTECT',
                      'MODULES: FEEDS · TOOLS · KNOWLEDGE · PROTECT',
                    ),
                    style: TextStyle(
                      color: p.muted,
                      fontSize: 9,
                      letterSpacing: .5,
                    ),
                  ),
                ),
                Text(
                  _loadingNews ? 'SYNC' : 'READY',
                  style: TextStyle(
                    color: p.accent,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _metric('$activeFeeds', _t('مصدر أخبار', 'active feeds')),
              _metric(
                '${toolProjects.length}+',
                _t('مشروع مفتوح', 'curated tools'),
              ),
              _metric(
                _loadingNews
                    ? 'LIVE'
                    : (onlineFeeds > 0 ? '$onlineFeeds' : 'AUTO'),
                _t('تحديث الإنترنت', 'online feeds'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.schedule_rounded, color: p.muted, size: 13),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  lastUpdateLabel,
                  style: TextStyle(color: p.muted, fontSize: 9),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _metric(String value, String label) => Expanded(
    child: Container(
      margin: const EdgeInsetsDirectional.only(end: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: _p.background.withValues(alpha: .42),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: _p.border.withValues(alpha: .7)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            style: TextStyle(
              color: _p.accent,
              fontWeight: FontWeight.w900,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: _p.muted, fontSize: 9),
          ),
        ],
      ),
    ),
  );

  Widget _newsSearchBox() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
    child: TextField(
      controller: _newsSearch,
      onChanged: (value) => setState(() => _newsQuery = value),
      decoration: InputDecoration(
        hintText: _t(
          'ابحث في الأخبار والمصادر والموجزات…',
          'Search stories, sources and summaries…',
        ),
        prefixIcon: Icon(Icons.search_rounded, color: _p.accent),
        suffixIcon: _newsQuery.isEmpty
            ? null
            : IconButton(
                onPressed: () {
                  _newsSearch.clear();
                  setState(() => _newsQuery = '');
                },
                icon: Icon(Icons.close, color: _p.muted),
              ),
      ),
    ),
  );

  Widget _newsCategoryRail() => SizedBox(
    height: 43,
    child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      scrollDirection: Axis.horizontal,
      itemCount: _newsCategories.length,
      separatorBuilder: (_, __) => const SizedBox(width: 7),
      itemBuilder: (context, index) {
        final id = _newsCategories[index];
        final selected = _newsCategory == id;
        return ChoiceChip(
          label: Text(_categoryLabel(id)),
          selected: selected,
          showCheckmark: false,
          onSelected: (_) => setState(() => _newsCategory = id),
          selectedColor: _p.accent,
          backgroundColor: _p.surface,
          labelStyle: TextStyle(
            color: selected ? _p.background : _p.text,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
          side: BorderSide(color: selected ? _p.accent : _p.border),
        );
      },
    ),
  );

  Widget _sectionHeader(String title, {String? trailing}) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 21, 20, 10),
    child: Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              color: _p.text,
              fontSize: 17,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        if (trailing != null)
          Text(trailing, style: TextStyle(color: _p.muted, fontSize: 10)),
      ],
    ),
  );

  Widget _filterSummary({
    required String keyName,
    required int visibleCount,
    required int totalCount,
    required bool active,
    required VoidCallback onClear,
  }) {
    if (!active) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(17, 1, 17, 3),
      child: Container(
        padding: const EdgeInsetsDirectional.fromSTEB(11, 4, 5, 4),
        decoration: BoxDecoration(
          color: _p.accent.withValues(alpha: .07),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _p.accent.withValues(alpha: .18)),
        ),
        child: Row(
          children: [
            Icon(Icons.filter_alt_outlined, color: _p.accent, size: 17),
            const SizedBox(width: 7),
            Expanded(
              child: Text(
                _t(
                  'النتائج: $visibleCount من $totalCount',
                  'Results: $visibleCount of $totalCount',
                ),
                style: TextStyle(
                  color: _p.muted,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            TextButton.icon(
              key: ValueKey<String>(keyName),
              onPressed: onClear,
              icon: const Icon(Icons.filter_alt_off_outlined, size: 15),
              label: Text(_t('مسح المرشحات', 'Clear filters')),
              style: TextButton.styleFrom(
                visualDensity: VisualDensity.compact,
                padding: const EdgeInsets.symmetric(horizontal: 7),
                foregroundColor: _p.accent,
                textStyle: const TextStyle(fontSize: 10),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _clearNewsFilters() {
    _newsSearch.clear();
    setState(() {
      _newsQuery = '';
      _newsCategory = 'all';
    });
  }

  void _clearToolFilters() {
    _toolSearch.clear();
    setState(() {
      _toolQuery = '';
      _toolPlatform = 'all';
      _toolCategory = 'all';
      _toolLicense = 'all';
      _toolDifficulty = 'all';
    });
  }

  void _clearTutorialFilters() {
    _tutorialSearch.clear();
    setState(() {
      _tutorialQuery = '';
      _tutorialCategory = 'all';
    });
  }

  Widget _articleCard(Article article) {
    final p = _p;
    final saved = _savedArticles.containsKey(article.link);
    final excerpt = article.summary.trim();
    return Container(
      margin: EdgeInsets.fromLTRB(15, 3, 15, _compactCards ? 5 : 9),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: p.border.withValues(alpha: .8)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(19),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => ArticleDetailScreen(
              article: article,
              isSaved: saved,
              onToggleSaved: _toggleSaved,
            ),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(15, 13, 12, 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _sourcePill(article.source),
                  const Spacer(),
                  if (article.publishedAt != null)
                    Text(
                      _shortDate(article.publishedAt!),
                      style: TextStyle(color: p.muted, fontSize: 9),
                    ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: () => _toggleSaved(article),
                    tooltip: _t('حفظ الخبر', 'Save story'),
                    icon: Icon(
                      saved
                          ? Icons.bookmark_rounded
                          : Icons.bookmark_border_rounded,
                      color: saved ? p.accent : p.muted,
                      size: 20,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 3),
              Text(
                article.title,
                maxLines: _compactCards ? 2 : 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: p.text,
                  fontSize: 15,
                  height: 1.4,
                  fontWeight: FontWeight.w800,
                ),
              ),
              if (excerpt.isNotEmpty && !_compactCards) ...[
                const SizedBox(height: 6),
                Text(
                  excerpt,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: p.muted, height: 1.5, fontSize: 11),
                ),
              ],
              const SizedBox(height: 11),
              Row(
                children: [
                  Icon(Icons.sell_outlined, size: 13, color: p.accent2),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(
                      _displayCategory(article.category),
                      style: TextStyle(color: p.accent2, fontSize: 10),
                    ),
                  ),
                  Icon(Icons.language_rounded, color: p.muted, size: 14),
                  const SizedBox(width: 5),
                  Text(
                    article.language,
                    style: TextStyle(color: p.muted, fontSize: 9),
                  ),
                  const SizedBox(width: 7),
                  Icon(Icons.arrow_forward_rounded, color: p.muted, size: 14),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sourcePill(String source) => Flexible(
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: _p.accent.withValues(alpha: .1),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Text(
        source,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: _p.accent,
          fontSize: 9,
          fontWeight: FontWeight.w800,
        ),
      ),
    ),
  );

  String _displayCategory(String category) {
    final value = category.toLowerCase();
    if (value.startsWith('tutorial')) {
      final area = value.split('·').last.trim();
      return switch (area) {
        'web security' => _t('شرح · أمن الويب', 'Tutorial · Web security'),
        'programming' => _t('شرح · البرمجة', 'Tutorial · Programming'),
        'developer tools' => _t(
          'شرح · أدوات المطورين',
          'Tutorial · Developer tools',
        ),
        'cloud & linux' => _t(
          'شرح · السحابة وLinux',
          'Tutorial · Cloud & Linux',
        ),
        'android & ai' => _t(
          'شرح · Android والذكاء الاصطناعي',
          'Tutorial · Android & AI',
        ),
        'open source' => _t('شرح · مفتوح المصدر', 'Tutorial · Open source'),
        'linux' => _t('شرح · Linux', 'Tutorial · Linux'),
        _ => _t('شرح تعليمي', 'Tutorial'),
      };
    }
    if (value.contains('cyber') ||
        value.contains('security') ||
        value.contains('أمن'))
      return _t('أمن سيبراني', 'Cybersecurity');
    if (value.contains('threat'))
      return _t('استخبارات تهديدات', 'Threat intelligence');
    if (value.contains('exploit') || value.contains('vulnerab'))
      return _t('ثغرات واستغلال', 'Vulnerabilities');
    if (value.contains('technology')) return _t('تقنية', 'Technology');
    if (value == 'ai' ||
        value.contains('artificial intelligence') ||
        value.contains('machine learning')) {
      return _t('ذكاء اصطناعي', 'Artificial intelligence');
    }
    if (value.contains('programming') ||
        value.contains('developer') ||
        value.contains('software') ||
        value.contains('devops')) {
      return _t('برمجة وتطوير', 'Programming & development');
    }
    if (value.contains('linux')) return 'Linux';
    if (value.contains('hardware'))
      return _t('أجهزة وتقنية', 'Hardware & tech');
    if (value.contains('android')) return 'Android';
    if (value.contains('privacy')) return _t('خصوصية', 'Privacy');
    if (value.contains('cloud')) return _t('أمن السحابة', 'Cloud security');
    if (value.contains('appsec')) return 'AppSec';
    if (value.contains('open source')) return _t('مفتوح المصدر', 'Open source');
    return category;
  }

  String _shortDate(DateTime value) {
    final local = value.toLocal();
    final month = local.month.toString().padLeft(2, '0');
    final day = local.day.toString().padLeft(2, '0');
    return '${local.year}-$month-$day';
  }

  Widget _emptyNews() => Padding(
    padding: const EdgeInsets.all(27),
    child: Column(
      children: [
        Icon(
          Icons.rss_feed_rounded,
          color: _p.accent.withValues(alpha: .7),
          size: 42,
        ),
        const SizedBox(height: 12),
        Text(
          _t('لا توجد نتائج في هذا القسم', 'No stories in this view'),
          style: TextStyle(
            color: _p.text,
            fontSize: 15,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 7),
        Text(
          _t(
            'بدّل التصنيف أو وسّع البحث. يمكن أن يتعذر موجز ناشر مؤقتاً؛ اسحب للأسفل لإعادة المحاولة أو أدر المصادر من الإعدادات.',
            'Change the category or broaden your query. A publisher feed may be temporarily unavailable; pull to refresh or manage feeds in Settings.',
          ),
          textAlign: TextAlign.center,
          style: TextStyle(color: _p.muted, height: 1.55, fontSize: 11),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: () => _refreshNews(),
          icon: const Icon(Icons.refresh_rounded),
          label: Text(_t('تحديث الموجزات', 'Refresh feeds')),
        ),
      ],
    ),
  );

  Future<void> _toggleSaved(Article article) async {
    setState(() {
      if (_savedArticles.containsKey(article.link)) {
        _savedArticles.remove(article.link);
        _savedTags.remove(article.link);
      } else {
        _savedArticles[article.link] = article;
      }
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'saved_articles_v2',
      jsonEncode(_savedArticles.values.map((e) => e.toJson()).toList()),
    );
    await prefs.setStringList('favorites', _savedArticles.keys.toList());
    await prefs.setString('saved_article_tags_v1', jsonEncode(_savedTags));
  }

  Widget _toolHub() {
    final all = _allTools;
    final query = _toolQuery.trim().toLowerCase();
    final filtered = all.where((project) {
      final platformMatches =
          _toolPlatform == 'all' || project.platforms.contains(_toolPlatform);
      final categoryMatches =
          _toolCategory == 'all' || project.category == _toolCategory;
      final licenseMatches = _toolLicense == 'all'
          ? true
          : _toolLicense == 'unknown'
          ? project.licenseHint == null
          : project.licenseHint == _toolLicense;
      final difficultyMatches = _toolDifficulty == 'all'
          ? true
          : _toolDifficulty == 'unknown'
          ? project.difficulty == null
          : project.difficulty == _toolDifficulty;
      final desc = Localizations.localeOf(context).languageCode == 'en'
          ? project.descriptionEn
          : project.descriptionAr;
      final queryMatches =
          query.isEmpty ||
          '${project.name} $desc ${project.category} ${project.githubRepo ?? ''}'
              .toLowerCase()
              .contains(query);
      return platformMatches &&
          categoryMatches &&
          licenseMatches &&
          difficultyMatches &&
          queryMatches;
    }).toList();
    final p = _p;
    return CustomScrollView(
      controller: _toolScrollController,
      slivers: [
        SliverToBoxAdapter(
          child: _pageHeader(
            _t('الترسانة الرقمية', 'The digital arsenal'),
            _t(
              'مشاريع مفتوحة المصدر · تحديثات وإصدارات من مستودعاتها الرسمية',
              'Open-source projects · releases fetched from official repositories',
            ),
            Icons.shield_moon_outlined,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [p.heroStart, p.surface]),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: p.accent.withValues(alpha: .2)),
              ),
              child: Row(
                children: [
                  Icon(Icons.cloud_sync_rounded, color: p.accent, size: 23),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _t(
                        '${toolProjects.length} مشروعاً منسقاً + اكتشاف يومي لمشاريع مرخّصة من GitHub.',
                        '${toolProjects.length} curated projects + daily discovery of licensed GitHub repositories.',
                      ),
                      style: TextStyle(
                        color: p.text,
                        fontSize: 11,
                        height: 1.45,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: _discovering
                        ? null
                        : () => _loadDiscoveredProjects(force: true),
                    tooltip: _t('اكتشاف مشاريع جديدة', 'Discover new projects'),
                    icon: _discovering
                        ? SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: p.accent,
                            ),
                          )
                        : Icon(Icons.manage_search_rounded, color: p.accent),
                  ),
                ],
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 9, 16, 2),
            child: Card(
              color: p.surface,
              child: ListTile(
                leading: Icon(Icons.flag_circle_outlined, color: p.accent),
                title: Text(
                  _t('مختبر CTF وفعاليات حية', 'CTF lab & live events'),
                  style: TextStyle(color: p.text, fontWeight: FontWeight.w800),
                ),
                subtitle: Text(
                  _t(
                    'فعاليات CTFtime وأوامر تحليل محلية للنسخ فقط، دون تنفيذ أو استهداف تلقائي.',
                    'CTFtime events and copy-only local analysis commands; no execution or automatic targeting.',
                  ),
                  style: TextStyle(color: p.muted, fontSize: 11, height: 1.35),
                ),
                trailing: Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: p.accent,
                  size: 16,
                ),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const CtfHubScreen()),
                ),
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 11, 16, 6),
            child: TextField(
              controller: _toolSearch,
              onChanged: (value) => setState(() => _toolQuery = value),
              decoration: InputDecoration(
                hintText: _t('ابحث في الترسانة…', 'Search the arsenal…'),
                prefixIcon: Icon(Icons.search, color: p.accent),
                suffixIcon: _toolQuery.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _toolSearch.clear();
                          setState(() => _toolQuery = '');
                        },
                        icon: Icon(Icons.close, color: p.muted),
                      ),
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 43,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _toolFilterChip('all', _t('الكل', 'All')),
                _toolFilterChip('android', 'Android'),
                _toolFilterChip('windows', 'Windows'),
                _toolFilterChip('linux', 'Linux'),
                _toolFilterChip('macos', 'macOS'),
                _toolFilterChip('web', 'Web'),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 43,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _toolCategoryChip('all', _t('كل المجالات', 'All fields')),
                for (final category
                    in (all.map((e) => e.category).toSet().toList()..sort()))
                  _toolCategoryChip(category, _toolCategoryLabel(category)),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 43,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _toolMetaChip(
                  'all',
                  _t('كل التراخيص', 'All licenses'),
                  _toolLicense,
                  (id) => setState(() => _toolLicense = id),
                ),
                _toolMetaChip(
                  'unknown',
                  _t('غير محدد', 'Unspecified'),
                  _toolLicense,
                  (id) => setState(() => _toolLicense = id),
                ),
                for (final license
                    in (all
                        .map((item) => item.licenseHint)
                        .whereType<String>()
                        .toSet()
                        .toList()
                      ..sort()))
                  _toolMetaChip(
                    license,
                    license,
                    _toolLicense,
                    (id) => setState(() => _toolLicense = id),
                  ),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 43,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _toolMetaChip(
                  'all',
                  _t('كل المستويات', 'All levels'),
                  _toolDifficulty,
                  (id) => setState(() => _toolDifficulty = id),
                ),
                _toolMetaChip(
                  'unknown',
                  _t('غير محدد', 'Unspecified'),
                  _toolDifficulty,
                  (id) => setState(() => _toolDifficulty = id),
                ),
                _toolMetaChip(
                  'beginner',
                  _t('مبتدئ', 'Beginner'),
                  _toolDifficulty,
                  (id) => setState(() => _toolDifficulty = id),
                ),
                _toolMetaChip(
                  'intermediate',
                  _t('متوسط', 'Intermediate'),
                  _toolDifficulty,
                  (id) => setState(() => _toolDifficulty = id),
                ),
                _toolMetaChip(
                  'advanced',
                  _t('متقدم', 'Advanced'),
                  _toolDifficulty,
                  (id) => setState(() => _toolDifficulty = id),
                ),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: _filterSummary(
            keyName: 'tool-filter-summary',
            visibleCount: filtered.length,
            totalCount: all.length,
            active:
                _toolPlatform != 'all' ||
                _toolCategory != 'all' ||
                _toolLicense != 'all' ||
                _toolDifficulty != 'all' ||
                _toolQuery.trim().isNotEmpty,
            onClear: _clearToolFilters,
          ),
        ),
        SliverToBoxAdapter(
          child: _sectionHeader(
            _t('المشاريع والأدوات', 'Projects & tools'),
            trailing: '${filtered.length}',
          ),
        ),
        if (filtered.isEmpty)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                _t(
                  'لا توجد أداة مطابقة. جرّب تصفية أخرى أو اكتشف مشاريع جديدة.',
                  'No matching projects. Try another filter or discover new projects.',
                ),
                textAlign: TextAlign.center,
                style: TextStyle(color: p.muted),
              ),
            ),
          )
        else
          SliverList.builder(
            itemCount: filtered.length,
            itemBuilder: (context, index) => _toolCard(filtered[index]),
          ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 25),
            child: Text(
              _t(
                'كل تنزيل مباشر يأتي من رابط HTTPS للإصدار الرسمي. إذا لم ينشر المشروع ملفاً تنفيذياً، يظهر رابط المصدر بدلاً من ملف غير موثوق.',
                'Direct downloads come from official HTTPS release assets. If a project publishes no binary, the source page is shown instead of an untrusted file.',
              ),
              style: TextStyle(color: p.muted, height: 1.5, fontSize: 10),
            ),
          ),
        ),
      ],
    );
  }

  List<ToolProject> get _allTools {
    final repos = toolProjects
        .map((e) => e.githubRepo?.toLowerCase())
        .whereType<String>()
        .toSet();
    return [
      ...toolProjects,
      ..._discoveredProjects.where(
        (project) =>
            project.githubRepo == null ||
            !repos.contains(project.githubRepo!.toLowerCase()),
      ),
    ];
  }

  Widget _toolFilterChip(String id, String label) => Padding(
    padding: const EdgeInsetsDirectional.only(end: 7),
    child: ChoiceChip(
      label: Text(label),
      selected: _toolPlatform == id,
      showCheckmark: false,
      onSelected: (_) => setState(() => _toolPlatform = id),
      selectedColor: _p.accent,
      backgroundColor: _p.surface,
      labelStyle: TextStyle(
        color: _toolPlatform == id ? _p.background : _p.text,
        fontSize: 10,
        fontWeight: FontWeight.w700,
      ),
      side: BorderSide(color: _toolPlatform == id ? _p.accent : _p.border),
    ),
  );

  Widget _toolMetaChip(
    String id,
    String label,
    String selected,
    ValueChanged<String> onSelected,
  ) => Padding(
    padding: const EdgeInsetsDirectional.only(end: 7),
    child: ChoiceChip(
      label: Text(label),
      selected: selected == id,
      showCheckmark: false,
      onSelected: (_) => onSelected(id),
      selectedColor: _p.accent,
      backgroundColor: _p.surface,
      labelStyle: TextStyle(
        color: selected == id ? _p.background : _p.text,
        fontSize: 10,
        fontWeight: FontWeight.w700,
      ),
      side: BorderSide(color: selected == id ? _p.accent : _p.border),
    ),
  );

  String _toolCategoryLabel(String id) {
    if (Localizations.localeOf(context).languageCode == 'en') return id;
    const labels = <String, String>{
      'Android apps': 'تطبيقات أندرويد',
      'Android privacy': 'خصوصية أندرويد',
      'Android security': 'أمن أندرويد',
      'App store': 'متاجر التطبيقات',
      'AppSec': 'أمن التطبيقات',
      'Assessment': 'التقييم الأمني',
      'Asset discovery': 'حصر الأصول',
      'Cloud security': 'أمن السحابة',
      'DFIR': 'التحقيق والاستجابة',
      'DevSecOps': 'أمن التطوير والتشغيل',
      'Artificial Intelligence': 'الذكاء الاصطناعي وتعلم الآلة',
      'Developer tools': 'أدوات المطورين',
      'Encryption': 'التشفير',
      'Endpoint': 'أمن الأجهزة الطرفية',
      'Infrastructure': 'البنية التحتية',
      'Malware analysis': 'تحليل البرمجيات الضارة',
      'Media': 'الوسائط',
      'Network': 'الشبكات',
      'Network defense': 'دفاع الشبكات',
      'OSINT': 'استخبارات المصادر المفتوحة',
      'Passwords': 'كلمات المرور',
      'Privacy': 'الخصوصية',
      'Purple team': 'الفريق البنفسجي',
      'Reverse engineering': 'الهندسة العكسية',
      'SIEM': 'إدارة وتحليل الأحداث الأمنية',
      'System': 'الأنظمة',
      'Terminal': 'الطرفية',
      'Threat defense': 'دفاع التهديدات',
      'Threat detection': 'كشف التهديدات',
      'Threat intelligence': 'استخبارات التهديدات',
      'Training lab': 'مختبرات التدريب',
      'Updates': 'التحديثات',
      'Wireless': 'الشبكات اللاسلكية',
      'Discovered': 'مكتشف حديثاً',
    };
    return labels[id] ?? id;
  }

  Widget _toolCategoryChip(String id, String label) => Padding(
    padding: const EdgeInsetsDirectional.only(end: 7),
    child: ChoiceChip(
      label: Text(label),
      selected: _toolCategory == id,
      showCheckmark: false,
      onSelected: (_) => setState(() => _toolCategory = id),
      selectedColor: _p.accent.withValues(alpha: .9),
      backgroundColor: _p.surface,
      labelStyle: TextStyle(
        color: _toolCategory == id ? _p.background : _p.text,
        fontSize: 9,
        fontWeight: FontWeight.w700,
      ),
      side: BorderSide(color: _toolCategory == id ? _p.accent : _p.border),
    ),
  );

  Widget _toolCard(ToolProject project) {
    final p = _p;
    final desc = Localizations.localeOf(context).languageCode == 'en'
        ? project.descriptionEn
        : project.descriptionAr;
    final future = project.githubRepo == null
        ? null
        : _releaseFutures.putIfAbsent(
            project.githubRepo!.toLowerCase(),
            () => _catalog.latestRelease(project),
          );
    return Container(
      margin: const EdgeInsets.fromLTRB(15, 3, 15, 9),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: p.border),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _openTool(project),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 43,
                height: 43,
                decoration: BoxDecoration(
                  color: p.accent.withValues(alpha: .1),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  _toolIcon(project.category),
                  color: p.accent,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            project.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: p.text,
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                            ),
                          ),
                        ),
                        if (project.discovered)
                          _pill(_t('مكتشف', 'New'), p.accent2),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(
                      desc,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: p.muted,
                        fontSize: 10,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Wrap(
                      spacing: 5,
                      children: [
                        for (final platform in project.platforms)
                          _miniTag(platform.toUpperCase(), p.accent),
                      ],
                    ),
                    if (future != null)
                      FutureBuilder<ToolRelease?>(
                        future: future,
                        builder: (context, snapshot) {
                          final release = snapshot.data;
                          final label = release != null
                              ? '${_t('آخر إصدار', 'Latest')}: ${release.tag.isEmpty ? release.title : release.tag}'
                              : (snapshot.connectionState ==
                                        ConnectionState.waiting
                                    ? _t(
                                        'جارٍ التحقق من المصدر…',
                                        'Checking source…',
                                      )
                                    : _t(
                                        'عرض المصدر الرسمي',
                                        'Open official source',
                                      ));
                          return Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.cloud_done_outlined,
                                  color: release == null ? p.muted : p.accent,
                                  size: 14,
                                ),
                                const SizedBox(width: 5),
                                Expanded(
                                  child: Text(
                                    label,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: release == null
                                          ? p.muted
                                          : p.accent,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                                if (release != null)
                                  Text(
                                    '${release.assets.length} ${_t('ملف', 'files')}',
                                    style: TextStyle(
                                      color: p.muted,
                                      fontSize: 8,
                                    ),
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Icon(Icons.arrow_forward_ios_rounded, color: p.muted, size: 14),
            ],
          ),
        ),
      ),
    );
  }

  IconData _toolIcon(String category) {
    final value = category.toLowerCase();
    if (value.contains('password')) return Icons.password_rounded;
    if (value.contains('network') || value.contains('wireless'))
      return Icons.router_rounded;
    if (value.contains('malware') || value.contains('reverse'))
      return Icons.biotech_rounded;
    if (value.contains('android') || value.contains('terminal'))
      return Icons.terminal_rounded;
    if (value.contains('privacy') || value.contains('encrypt'))
      return Icons.lock_outline_rounded;
    if (value.contains('osint')) return Icons.travel_explore_rounded;
    if (value.contains('appsec') || value.contains('assessment'))
      return Icons.bug_report_outlined;
    return Icons.security_rounded;
  }

  Widget _miniTag(String label, Color color) => Container(
    margin: const EdgeInsetsDirectional.only(end: 3),
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
    decoration: BoxDecoration(
      color: color.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(30),
    ),
    child: Text(
      label,
      style: TextStyle(color: color, fontSize: 8, fontWeight: FontWeight.w800),
    ),
  );

  Widget _pill(String text, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
    decoration: BoxDecoration(
      color: color.withValues(alpha: .1),
      borderRadius: BorderRadius.circular(30),
    ),
    child: Text(
      text,
      style: TextStyle(color: color, fontSize: 8, fontWeight: FontWeight.w800),
    ),
  );

  void _openTool(ToolProject project) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ToolDetailScreen(
          project: project,
          catalog: _catalog,
          downloads: _downloads,
          onOpenDownloads: () {
            Navigator.of(context).pop();
            setState(() => _tab = 5);
          },
        ),
      ),
    );
  }

  Widget _learningHub() {
    final p = _p;
    final sections = learningResourceSections;
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: _pageHeader(
            _t('مركز المعرفة', 'Knowledge center'),
            _t(
              'اختر مجالاً لفتح مكتبته وصفحاته الداخلية',
              'Choose a topic to open its own library and pages',
            ),
            Icons.school_outlined,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 5),
            child: _featureCard(
              _t('تدرّب بمسؤولية', 'Practice responsibly'),
              _t(
                'نفّذ الاختبارات فقط في مختبرات تملكها أو ضمن إذن مكتوب محدد.',
                'Test only in labs you own or under explicit written authorization.',
              ),
              Icons.verified_user_outlined,
              p.accent2,
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: _knowledgeEntry(
            title: 'Academy F6-Team',
            description: _t(
              'محتوى الأكاديمية ومساراتها محفوظة داخل التطبيق للقراءة دون إنترنت.',
              'Academy content and learning paths are bundled for offline reading.',
            ),
            icon: Icons.auto_stories_rounded,
            count: _t('أوفلاين · 4 محاور', 'Offline · 4 pillars'),
            onTap: () => _openKnowledgePage(
              AcademyOfflineScreen(
                isArabic: widget.locale.languageCode == 'ar',
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: _knowledgeEntry(
            title: _t('الشروحات والمقالات', 'Tutorials & articles'),
            description: _t(
              'مقالات حية من الناشرين، مع بحث وتصفية حسب المجال.',
              'Live publisher articles, searchable and filterable by topic.',
            ),
            icon: Icons.article_outlined,
            count: _loadingTutorials
                ? _t('جارٍ التحديث…', 'Updating…')
                : '${_tutorialArticles.length} ${_t('مقالة', 'articles')}',
            onTap: () => _openKnowledgePage(_tutorialsPage()),
          ),
        ),
        SliverToBoxAdapter(
          child: _knowledgeEntry(
            title: _t(
              'مركز التعلم والاختبارات',
              'Learning & assessment center',
            ),
            description: _t(
              'مسارات منظمة، دروس قصيرة، اختبارات وبطاقات مراجعة مع حفظ التقدم محلياً.',
              'Structured paths, short lessons, quizzes and review cards with local progress.',
            ),
            icon: Icons.school_rounded,
            count:
                '${learningPaths.length} ${_t('مسارات', 'paths')} · ${learningQuestions.length} ${_t('أسئلة', 'questions')}',
            onTap: () => _openKnowledgePage(const LearningCenterScreen()),
          ),
        ),
        SliverToBoxAdapter(
          child: _knowledgeEntry(
            title: _t('مسارات ومختبرات', 'Learning paths & labs'),
            description: _t(
              'منصات تدريب تفاعلية ومختبرات مصممة للتعلم القانوني.',
              'Interactive training platforms and purpose-built legal labs.',
            ),
            icon: Icons.route_rounded,
            count:
                '${learningResourceSections.length} ${_t('مسارات', 'topic groups')}',
            onTap: () => _openKnowledgePage(_learningPathsPage()),
          ),
        ),
        SliverToBoxAdapter(
          child: _knowledgeEntry(
            title: _t(
              'رادار الثغرات المستغلة · CISA KEV',
              'CISA KEV exploited-vulnerability radar',
            ),
            description: _t(
              'قائمة رسمية بالثغرات التي رُصد استغلالها فعلياً.',
              'Official catalog of vulnerabilities known to be exploited.',
            ),
            icon: Icons.warning_amber_rounded,
            count: _loadingKev
                ? _t('تحديث…', 'Updating…')
                : '${_kevItems.length}',
            onTap: () => _openKnowledgePage(_kevPage()),
          ),
        ),
        SliverToBoxAdapter(
          child: _knowledgeEntry(
            title: _t('المراجع حسب التخصص', 'References by specialty'),
            description: _t(
              '${sections.length} مجالاً؛ افتح المجال لرؤية مراجعه فقط.',
              '${sections.length} specialties; open a topic to see its references.',
            ),
            icon: Icons.category_outlined,
            count: '${sections.length} ${_t('مجالات', 'topics')}',
            onTap: () => _openKnowledgePage(_referenceDirectoryPage()),
          ),
        ),
        SliverToBoxAdapter(
          child: _knowledgeEntry(
            title: _t('مراجع سريعة إضافية', 'Additional quick references'),
            description: _t(
              'معايير وأدوات ومصادر مهنية مختارة.',
              'Selected standards, tools and professional resources.',
            ),
            icon: Icons.bookmarks_outlined,
            count:
                '${sections.fold<int>(0, (sum, section) => sum + section.items.length)} ${_t('مرجعاً', 'references')}',
            onTap: () => _openKnowledgePage(_quickReferencesPage()),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 26),
            child: Text(
              _t(
                'تُفتح المقالات والمراجع من ناشريها. تعامل مع المختبرات والعينات داخل بيئات معزولة وبإذن صريح.',
                'Articles and references open from their publishers. Use labs and samples only in isolated environments and with explicit authorization.',
              ),
              style: TextStyle(color: p.muted, fontSize: 10, height: 1.5),
            ),
          ),
        ),
      ],
    );
  }

  Widget _knowledgeEntry({
    required String title,
    required String description,
    required IconData icon,
    required String count,
    required VoidCallback onTap,
  }) {
    final p = _p;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          borderRadius: BorderRadius.circular(17),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color: p.border),
            ),
            child: Row(
              children: [
                Container(
                  width: 43,
                  height: 43,
                  decoration: BoxDecoration(
                    color: p.accent.withValues(alpha: .1),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Icon(icon, color: p.accent),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: p.text,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        description,
                        style: TextStyle(
                          color: p.muted,
                          fontSize: 10,
                          height: 1.45,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        count,
                        style: TextStyle(
                          color: p.accent,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right_rounded, color: p.muted),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openKnowledgePage(Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }

  Widget _knowledgeScaffold({
    required String title,
    required String subtitle,
    required IconData icon,
    required List<Widget> slivers,
  }) => Scaffold(
    backgroundColor: _p.background,
    body: SafeArea(
      child: CustomScrollView(
        controller: _knowledgeScrollController,
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(10, 5, 10, 0),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.of(context).maybePop(),
                    tooltip: _t('رجوع', 'Back'),
                    icon: Icon(Icons.arrow_back_rounded, color: _p.accent),
                  ),
                  const Spacer(),
                  if (_showKnowledgeScrollTop)
                    IconButton(
                      key: const ValueKey('knowledge-scroll-to-top'),
                      onPressed: () => _knowledgeScrollController.animateTo(
                        0,
                        duration: const Duration(milliseconds: 320),
                        curve: Curves.easeOutCubic,
                      ),
                      tooltip: _t('العودة إلى أعلى المعرفة', 'Back to top'),
                      icon: Icon(
                        Icons.vertical_align_top_rounded,
                        color: _p.accent,
                      ),
                    ),
                  pageHomeButton(context),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(child: _pageHeader(title, subtitle, icon)),
          ...slivers,
          const SliverToBoxAdapter(child: SizedBox(height: 25)),
        ],
      ),
    ),
  );

  Widget _tutorialsPage() => StatefulBuilder(
    builder: (pageContext, pageSetState) {
      Future<void> refreshPage() async {
        await _refreshTutorials();
        if (pageContext.mounted) pageSetState(() {});
      }

      final categories = <String>[
        'all',
        ...tutorialSources.map((s) => s.category).toSet(),
      ];
      final query = _tutorialQuery.trim().toLowerCase();
      final items = _tutorialArticles.where((article) {
        final categoryMatch =
            _tutorialCategory == 'all' || article.category == _tutorialCategory;
        final queryMatch =
            query.isEmpty ||
            '${article.title} ${article.source} ${article.summary}'
                .toLowerCase()
                .contains(query);
        return categoryMatch && queryMatch;
      }).toList();

      return _knowledgeScaffold(
        title: _t('الشروحات والمقالات', 'Tutorials & articles'),
        subtitle: _t(
          'مقالات نصية مباشرة من موجزات الناشرين',
          'Text articles from live publisher feeds',
        ),
        icon: Icons.article_outlined,
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 7, 16, 6),
              child: TextField(
                controller: _tutorialSearch,
                onChanged: (value) =>
                    pageSetState(() => _tutorialQuery = value),
                style: TextStyle(color: _p.text, fontSize: 12),
                decoration: InputDecoration(
                  hintText: _t(
                    'ابحث في العناوين والمصادر…',
                    'Search titles and sources…',
                  ),
                  prefixIcon: Icon(Icons.search_rounded, color: _p.muted),
                  suffixIcon: _tutorialQuery.isEmpty
                      ? null
                      : IconButton(
                          tooltip: _t('مسح البحث', 'Clear search'),
                          onPressed: () {
                            _tutorialSearch.clear();
                            pageSetState(() => _tutorialQuery = '');
                          },
                          icon: Icon(Icons.close_rounded, color: _p.muted),
                        ),
                  filled: true,
                  fillColor: _p.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: _p.border),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: _p.border),
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 44,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: categories.length,
                separatorBuilder: (_, _) => const SizedBox(width: 7),
                itemBuilder: (context, index) {
                  final category = categories[index];
                  final selected = _tutorialCategory == category;
                  return ChoiceChip(
                    label: Text(
                      category == 'all'
                          ? _t('الكل', 'All')
                          : _displayCategory(category),
                    ),
                    selected: selected,
                    onSelected: (_) =>
                        pageSetState(() => _tutorialCategory = category),
                    selectedColor: _p.accent.withValues(alpha: .2),
                    labelStyle: TextStyle(
                      color: selected ? _p.accent : _p.muted,
                      fontSize: 10,
                    ),
                    side: BorderSide(color: selected ? _p.accent : _p.border),
                    showCheckmark: false,
                  );
                },
              ),
            ),
          ),
          SliverToBoxAdapter(child: _feedStatusCard(tutorials: true)),
          SliverToBoxAdapter(
            child: _filterSummary(
              keyName: 'tutorial-filter-summary',
              visibleCount: items.length,
              totalCount: _tutorialArticles.length,
              active:
                  _tutorialCategory != 'all' ||
                  _tutorialQuery.trim().isNotEmpty,
              onClear: () {
                _clearTutorialFilters();
                pageSetState(() {});
              },
            ),
          ),
          SliverToBoxAdapter(
            child: _sectionHeader(
              _t('المقالات', 'Articles'),
              trailing: _loadingTutorials
                  ? _t('جارٍ التحديث…', 'Updating…')
                  : '${items.length}',
            ),
          ),
          if (_loadingTutorials && _tutorialArticles.isEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Center(
                  child: CircularProgressIndicator(color: _p.accent),
                ),
              ),
            )
          else if (items.isEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: _knowledgeEntry(
                  title: _t('لا توجد مقالات مطابقة', 'No matching articles'),
                  description: _t(
                    'غيّر التصفية أو حدّث الموجزات.',
                    'Change the filter or refresh the feeds.',
                  ),
                  icon: Icons.search_off_rounded,
                  count: '',
                  onTap: refreshPage,
                ),
              ),
            )
          else
            SliverList.builder(
              itemCount: items.length,
              itemBuilder: (_, index) => _articleCard(items[index]),
            ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: OutlinedButton.icon(
                onPressed: _loadingTutorials ? null : refreshPage,
                icon: const Icon(Icons.refresh_rounded),
                label: Text(_t('تحديث الموجزات', 'Refresh feeds')),
              ),
            ),
          ),
        ],
      );
    },
  );

  Widget _learningPathsPage() => _knowledgeScaffold(
    title: _t('مسارات ومختبرات', 'Learning paths & labs'),
    subtitle: _t(
      'روابط تدريب ومختبرات تعليمية قانونية',
      'Legal training and learning labs',
    ),
    icon: Icons.route_rounded,
    slivers: [
      for (final item
          in <({String name, String ar, String en, String url, IconData icon})>[
            (
              name: 'TryHackMe',
              ar: 'مسارات تفاعلية من الأساسيات إلى المسارات المتخصصة.',
              en: 'Guided paths from foundations to specialist topics.',
              url: 'https://tryhackme.com/',
              icon: Icons.route_rounded,
            ),
            (
              name: 'Hack The Box Academy',
              ar: 'تعلم عملي ومختبرات تدريبية مهيأة.',
              en: 'Hands-on training paths and purpose-built labs.',
              url: 'https://academy.hackthebox.com/',
              icon: Icons.dns_outlined,
            ),
            (
              name: 'PortSwigger Web Security Academy',
              ar: 'مختبرات مجانية لأمن تطبيقات الويب ومرجع للتعلم.',
              en: 'Free web application security labs and learning material.',
              url: 'https://portswigger.net/web-security',
              icon: Icons.language_rounded,
            ),
            (
              name: 'OverTheWire',
              ar: 'ألعاب تعليمية عملية للشبكات وLinux والأمن.',
              en: 'Practical wargames for networking, Linux and security.',
              url: 'https://overthewire.org/wargames/',
              icon: Icons.sports_esports_outlined,
            ),
            (
              name: 'picoCTF',
              ar: 'مسابقات وتحديات تعليمية بمستويات متنوعة.',
              en: 'Educational challenges and competitions at multiple levels.',
              url: 'https://picoctf.org/',
              icon: Icons.flag_outlined,
            ),
            (
              name: 'CyberDefenders',
              ar: 'مختبرات تحقيق رقمي واستجابة للحوادث.',
              en: 'Digital forensics and incident response labs.',
              url: 'https://cyberdefenders.org/',
              icon: Icons.find_in_page_outlined,
            ),
          ])
        SliverToBoxAdapter(
          child: _resourceCard(
            item.name,
            _t(item.ar, item.en),
            item.url,
            item.icon,
          ),
        ),
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: _featureCard(
            _t('تذكير بالسلامة', 'Safety reminder'),
            _t(
              'تدرّب ضمن المختبرات المصرح بها فقط.',
              'Practice only in authorized labs.',
            ),
            Icons.verified_user_outlined,
            _p.accent2,
          ),
        ),
      ),
    ],
  );

  Widget _referenceDirectoryPage() => _knowledgeScaffold(
    title: _t('المراجع حسب التخصص', 'References by specialty'),
    subtitle: _t(
      'افتح مجالاً لعرض مراجعه دون ازدحام الصفحة',
      'Open a topic to see only its references',
    ),
    icon: Icons.category_outlined,
    slivers: [
      for (final section in learningResourceSections)
        SliverToBoxAdapter(
          child: _knowledgeEntry(
            title: _t(section.titleAr, section.titleEn),
            description: _t(
              'مراجع موثوقة مختارة لهذا المجال.',
              'Curated references for this specialty.',
            ),
            icon: section.items.first.icon,
            count: '${section.items.length} ${_t('مرجع', 'references')}',
            onTap: () => _openKnowledgePage(_referenceSectionPage(section)),
          ),
        ),
    ],
  );

  Widget _referenceSectionPage(
    LearningResourceSection section,
  ) => _knowledgeScaffold(
    title: _t(section.titleAr, section.titleEn),
    subtitle:
        '${section.items.length} ${_t('مرجعاً في هذا المجال', 'references in this topic')}',
    icon: section.items.first.icon,
    slivers: [
      for (final resource in section.items)
        SliverToBoxAdapter(
          child: _resourceCard(
            resource.name,
            _t(resource.descriptionAr, resource.descriptionEn),
            resource.url,
            resource.icon,
          ),
        ),
    ],
  );

  Widget _quickReferencesPage() {
    final items = <LearningResource>[
      LearningResource(
        name: 'MITRE ATT&CK',
        descriptionAr: 'قاعدة معرفة لتكتيكات وتقنيات الخصوم.',
        descriptionEn: 'A knowledge base of adversary tactics and techniques.',
        url: 'https://attack.mitre.org/',
        icon: Icons.account_tree_outlined,
      ),
      LearningResource(
        name: 'OWASP Top 10',
        descriptionAr: 'مخاطر أمن تطبيقات الويب ومرجع للمطورين.',
        descriptionEn:
            'Web application security risks and developer reference.',
        url: 'https://owasp.org/www-project-top-ten/',
        icon: Icons.web_asset_outlined,
      ),
      LearningResource(
        name: 'OWASP Cheat Sheet Series',
        descriptionAr: 'إرشادات تقنية عملية لتطوير تطبيقات أكثر أماناً.',
        descriptionEn:
            'Practical technical guidance for safer application development.',
        url: 'https://cheatsheetseries.owasp.org/',
        icon: Icons.menu_book_outlined,
      ),
      LearningResource(
        name: 'OWASP MASVS',
        descriptionAr: 'معيار للتحقق من أمن تطبيقات الهواتف المحمولة.',
        descriptionEn:
            'A standard for mobile application security verification.',
        url: 'https://mas.owasp.org/MASVS/',
        icon: Icons.phone_android_rounded,
      ),
      LearningResource(
        name: 'NIST Cybersecurity Framework',
        descriptionAr: 'إطار لإدارة مخاطر الأمن السيبراني.',
        descriptionEn: 'A framework for managing cybersecurity risk.',
        url: 'https://www.nist.gov/cyberframework',
        icon: Icons.policy_outlined,
      ),
      LearningResource(
        name: 'MITRE CWE',
        descriptionAr: 'قاموس نقاط الضعف البرمجية الشائعة.',
        descriptionEn: 'A dictionary of common software weaknesses.',
        url: 'https://cwe.mitre.org/',
        icon: Icons.dataset_outlined,
      ),
      LearningResource(
        name: 'abuse.ch',
        descriptionAr:
            'مشاريع مجتمع للتعامل مع بيانات التهديدات والبرمجيات الضارة.',
        descriptionEn: 'Community projects for threat and malware data.',
        url: 'https://abuse.ch/',
        icon: Icons.manage_search_rounded,
      ),
      LearningResource(
        name: 'MalwareBazaar',
        descriptionAr:
            'مستودع عينات بحثية؛ تعامل مع العينات في مختبر معزول فقط.',
        descriptionEn:
            'A research sample repository; handle samples only in an isolated lab.',
        url: 'https://bazaar.abuse.ch/',
        icon: Icons.coronavirus_outlined,
      ),
      LearningResource(
        name: 'OSINT Framework',
        descriptionAr: 'دليل منظم لمصادر وأدوات المعلومات المفتوحة.',
        descriptionEn:
            'A structured guide to open-source intelligence resources.',
        url: 'https://osintframework.com/',
        icon: Icons.hub_outlined,
      ),
      LearningResource(
        name: 'Bellingcat Online Investigation Toolkit',
        descriptionAr: 'موارد وأساليب للتحقيق بالمصادر المفتوحة.',
        descriptionEn: 'Open-source investigation tools and techniques.',
        url: 'https://bellingcat.gitbook.io/toolkit/',
        icon: Icons.travel_explore_rounded,
      ),
      LearningResource(
        name: 'CyberChef',
        descriptionAr: 'تحويل وتحليل بيانات وأدلة رقمية من المتصفح.',
        descriptionEn: 'Transform and inspect data artifacts in the browser.',
        url: 'https://gchq.github.io/CyberChef/',
        icon: Icons.science_outlined,
      ),
      LearningResource(
        name: 'The DFIR Report',
        descriptionAr: 'تقارير تحقيقات واستجابة لحوادث منشورة.',
        descriptionEn: 'Published incident response and forensic case reports.',
        url: 'https://thedfirreport.com/',
        icon: Icons.description_outlined,
      ),
      LearningResource(
        name: 'Velociraptor Documentation',
        descriptionAr: 'توثيق الجمع الجنائي والتحقيق عن بُعد.',
        descriptionEn:
            'Documentation for remote forensic collection and investigation.',
        url: 'https://docs.velociraptor.app/',
        icon: Icons.devices_other_rounded,
      ),
      LearningResource(
        name: 'REMnux',
        descriptionAr:
            'مجموعة أدوات Linux لتحليل البرمجيات الضارة في مختبر معزول.',
        descriptionEn:
            'A Linux toolkit for malware analysis in an isolated lab.',
        url: 'https://remnux.org/',
        icon: Icons.memory_rounded,
      ),
      LearningResource(
        name: 'NVD — National Vulnerability Database',
        descriptionAr: 'بيانات مرجعية للثغرات والتصنيفات الأمنية.',
        descriptionEn:
            'Reference data for vulnerabilities and security ratings.',
        url: 'https://nvd.nist.gov/',
        icon: Icons.warning_amber_rounded,
      ),
      LearningResource(
        name: 'FIRST CVSS',
        descriptionAr: 'معيار مشترك لتقدير شدة الثغرات.',
        descriptionEn: 'A common standard for vulnerability severity.',
        url: 'https://www.first.org/cvss/',
        icon: Icons.speed_rounded,
      ),
      LearningResource(
        name: 'ISC2 Certified in Cybersecurity',
        descriptionAr: 'معلومات الشهادة التأسيسية ومصادر التحضير الرسمية.',
        descriptionEn:
            'Entry-level certification information and official study resources.',
        url: 'https://www.isc2.org/certifications/cc',
        icon: Icons.workspace_premium_outlined,
      ),
    ];
    return _knowledgeScaffold(
      title: _t('مراجع سريعة إضافية', 'Additional quick references'),
      subtitle: _t(
        'أدوات ومعايير ومصادر مهنية',
        'Tools, standards and professional sources',
      ),
      icon: Icons.bookmarks_outlined,
      slivers: [
        for (final resource in items)
          SliverToBoxAdapter(
            child: _resourceCard(
              resource.name,
              _t(resource.descriptionAr, resource.descriptionEn),
              resource.url,
              resource.icon,
            ),
          ),
      ],
    );
  }

  Widget _kevPage() => _knowledgeScaffold(
    title: _t(
      'رادار الثغرات المستغلة · CISA KEV',
      'Known exploited vulnerability radar · CISA KEV',
    ),
    subtitle: _t(
      'قائمة رسمية من CISA وتُحدّث عبر الإنترنت',
      'CISA official catalog, refreshed online',
    ),
    icon: Icons.warning_amber_rounded,
    slivers: [
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  _t(
                    'قائمة الثغرات التي رُصد استغلالها فعلياً؛ قد تتطلب نتائجها اتصالاً بالإنترنت.',
                    'Vulnerabilities known to be exploited; current results require an internet connection.',
                  ),
                  style: TextStyle(color: _p.muted, fontSize: 10, height: 1.45),
                ),
              ),
              IconButton(
                onPressed: _loadingKev ? null : () => _refreshKev(force: true),
                tooltip: _t('تحديث قائمة CISA', 'Refresh CISA list'),
                icon: Icon(Icons.refresh, color: _p.accent),
              ),
            ],
          ),
        ),
      ),
      if (_loadingKev && _kevItems.isEmpty)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Center(child: CircularProgressIndicator(color: _p.accent)),
          ),
        )
      else if (_kevItems.isEmpty)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Text(
              _t(
                'قائمة CISA غير متاحة الآن؛ حاول التحديث لاحقاً.',
                'CISA list is unavailable right now; try refreshing later.',
              ),
              style: TextStyle(color: _p.muted),
            ),
          ),
        )
      else
        SliverList.builder(
          itemCount: _kevItems.length,
          itemBuilder: (_, index) => _kevCard(_kevItems[index]),
        ),
    ],
  );

  Widget _kevCard(KevItem item) {
    final p = _p;
    final url = 'https://nvd.nist.gov/vuln/detail/${item.cveId}';
    return Container(
      margin: const EdgeInsets.fromLTRB(15, 3, 15, 8),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _openUrl(url),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      item.cveId,
                      style: TextStyle(
                        color: p.accent,
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  Text(
                    item.dateAdded,
                    style: TextStyle(color: p.muted, fontSize: 9),
                  ),
                  if (item.knownRansomwareUse) ...[
                    const SizedBox(width: 7),
                    _pill(_t('فدية معروفة', 'Ransomware use'), p.accent2),
                  ],
                ],
              ),
              const SizedBox(height: 5),
              Text(
                '${item.vendor} · ${item.product}${item.name.isEmpty ? '' : ' — ${item.name}'}',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: p.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 11,
                ),
              ),
              if (item.description.isNotEmpty) ...[
                const SizedBox(height: 5),
                Text(
                  item.description,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: p.muted, height: 1.45, fontSize: 10),
                ),
              ],
              const SizedBox(height: 8),
              Text(
                _t('عرض سجل NVD الرسمي ←', 'Open official NVD record →'),
                style: TextStyle(
                  color: p.accent2,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pageHeader(String title, String subtitle, IconData icon) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 22, 20, 8),
    child: Row(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: _p.accent.withValues(alpha: .12),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Icon(icon, color: _p.accent, size: 25),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: _p.text,
                  fontSize: 21,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(color: _p.muted, fontSize: 10, height: 1.35),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _featureCard(
    String title,
    String subtitle,
    IconData icon,
    Color accent,
  ) => Container(
    margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        colors: [accent.withValues(alpha: .13), _p.surface],
      ),
      borderRadius: BorderRadius.circular(17),
      border: Border.all(color: accent.withValues(alpha: .2)),
    ),
    child: Row(
      children: [
        Icon(icon, color: accent, size: 23),
        const SizedBox(width: 11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: _p.text,
                  fontWeight: FontWeight.w800,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(color: _p.muted, fontSize: 10, height: 1.4),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _resourceCard(
    String name,
    String description,
    String url,
    IconData icon,
  ) => Container(
    margin: const EdgeInsets.fromLTRB(15, 3, 15, 7),
    decoration: BoxDecoration(
      color: _p.surface,
      borderRadius: BorderRadius.circular(15),
      border: Border.all(color: _p.border),
    ),
    child: ListTile(
      leading: Icon(icon, color: _p.accent, size: 22),
      title: Text(
        name,
        style: TextStyle(
          color: _p.text,
          fontSize: 12,
          fontWeight: FontWeight.w800,
        ),
      ),
      subtitle: Text(
        description,
        style: TextStyle(color: _p.muted, fontSize: 10, height: 1.4),
      ),
      trailing: Icon(Icons.open_in_new_rounded, color: _p.muted, size: 16),
      onTap: () => _openUrl(url),
    ),
  );

  String _savedTagLabel(String id) => switch (id) {
    'later' => _t('قراءة لاحقاً', 'Read later'),
    'learning' => _t('تعلّم', 'Learning'),
    'threat' => _t('استخبارات تهديد', 'Threat intel'),
    'incident' => _t('استجابة', 'Incident response'),
    'untagged' => _t('بلا وسم', 'Untagged'),
    _ => _t('الكل', 'All'),
  };

  Future<void> _setSavedTag(String link, String value) async {
    setState(() {
      if (value == 'none') {
        _savedTags.remove(link);
      } else {
        _savedTags[link] = value;
      }
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('saved_article_tags_v1', jsonEncode(_savedTags));
  }

  Widget _savedTagBar() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
    child: SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (final id in ['all', 'untagged', ..._savedTagIds])
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 6),
              child: ChoiceChip(
                label: Text(_savedTagLabel(id)),
                selected: _savedFilter == id,
                onSelected: (_) => setState(() => _savedFilter = id),
              ),
            ),
        ],
      ),
    ),
  );

  Widget _savedArticleCard(Article article) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Align(
        alignment: AlignmentDirectional.centerEnd,
        child: PopupMenuButton<String>(
          tooltip: _t('إضافة وسم للمحفوظ', 'Tag saved story'),
          onSelected: (value) => unawaited(_setSavedTag(article.link, value)),
          itemBuilder: (context) => [
            PopupMenuItem(
              value: 'none',
              child: Text(_t('إزالة الوسم', 'Remove tag')),
            ),
            for (final id in _savedTagIds)
              PopupMenuItem(value: id, child: Text(_savedTagLabel(id))),
          ],
          child: Chip(
            avatar: Icon(Icons.sell_outlined, size: 15, color: _p.accent),
            label: Text(
              _savedTags[article.link] == null
                  ? _t('إضافة وسم', 'Add tag')
                  : _savedTagLabel(_savedTags[article.link]!),
            ),
          ),
        ),
      ),
      _articleCard(article),
    ],
  );

  Widget _savedPage() {
    final allSaved = _savedArticles.values.toList()
      ..sort(
        (a, b) => (b.publishedAt ?? DateTime(2000)).compareTo(
          a.publishedAt ?? DateTime(2000),
        ),
      );
    final saved = allSaved.where((article) {
      if (_savedFilter == 'all') return true;
      if (_savedFilter == 'untagged')
        return !_savedTags.containsKey(article.link);
      return _savedTags[article.link] == _savedFilter;
    }).toList();
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: _pageHeader(
            _t('محفوظاتك', 'Saved stories'),
            _t(
              '${allSaved.length} خبر محفوظ محلياً على جهازك',
              '${allSaved.length} stories saved on this device',
            ),
            Icons.bookmarks_outlined,
          ),
        ),
        if (allSaved.isNotEmpty) SliverToBoxAdapter(child: _savedTagBar()),
        if (allSaved.isEmpty)
          SliverFillRemaining(
            hasScrollBody: false,
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(26),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.bookmark_border_rounded,
                      color: _p.accent.withValues(alpha: .65),
                      size: 50,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _t('لا توجد محفوظات بعد', 'Nothing saved yet'),
                      style: TextStyle(
                        color: _p.text,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _t(
                        'اضغط علامة الحفظ على أي خبر لإضافته هنا.',
                        'Tap the bookmark on a story to keep it here.',
                      ),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: _p.muted, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ),
          )
        else if (saved.isEmpty)
          SliverFillRemaining(
            hasScrollBody: false,
            child: Center(
              child: Text(
                _t(
                  'لا توجد محفوظات بهذا الوسم.',
                  'No saved stories with this tag.',
                ),
                style: TextStyle(color: _p.muted),
              ),
            ),
          )
        else
          SliverList.builder(
            itemCount: saved.length,
            itemBuilder: (context, index) => _savedArticleCard(saved[index]),
          ),
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
      ],
    );
  }

  Widget _settingsPage() {
    final p = _p;
    final isEnglish = Localizations.localeOf(context).languageCode == 'en';
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: _pageHeader(
            _t('الإعدادات', 'Settings'),
            _t('خصّص تجربة مركزك الأمني', 'Personalize your security hub'),
            Icons.tune_rounded,
          ),
        ),
        SliverToBoxAdapter(
          child: _sectionHeader(_t('اللغة والاتجاه', 'Language & direction')),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: p.border),
              ),
              child: Row(
                children: [
                  Icon(Icons.translate_rounded, color: p.accent),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _t('لغة التطبيق', 'App language'),
                      style: TextStyle(
                        color: p.text,
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: isEnglish ? 'en' : 'ar',
                      dropdownColor: p.surface,
                      style: TextStyle(color: p.text, fontSize: 12),
                      items: const [
                        DropdownMenuItem(value: 'ar', child: Text('العربية')),
                        DropdownMenuItem(value: 'en', child: Text('English')),
                      ],
                      onChanged: (value) {
                        if (value != null)
                          widget.onLocaleChanged(Locale(value));
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: _sectionHeader(
            _t(
              'اختر ثيمك من ${AppThemes.presets.length} ثيمات',
              'Choose from ${AppThemes.presets.length} themes',
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 105,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: AppThemes.presets.length,
              separatorBuilder: (_, __) => const SizedBox(width: 9),
              itemBuilder: (context, index) {
                final preset = AppThemes.presets[index];
                final selected =
                    Theme.of(context).extension<AppPalette>()!.accent ==
                    preset.palette.accent;
                return InkWell(
                  borderRadius: BorderRadius.circular(15),
                  onTap: () => widget.onThemeChanged(index),
                  child: Container(
                    width: 82,
                    padding: const EdgeInsets.all(9),
                    decoration: BoxDecoration(
                      color: preset.palette.surface,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: selected ? preset.palette.accent : p.border,
                        width: selected ? 2 : 1,
                      ),
                    ),
                    child: Column(
                      children: [
                        Container(
                          height: 33,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                preset.palette.background,
                                preset.palette.accent,
                              ],
                            ),
                            borderRadius: BorderRadius.circular(9),
                          ),
                          child: Center(
                            child: Icon(
                              selected
                                  ? Icons.check_circle
                                  : Icons.palette_outlined,
                              color: preset.palette.text,
                              size: 17,
                            ),
                          ),
                        ),
                        const SizedBox(height: 7),
                        Text(
                          isEnglish ? preset.nameEn : preset.nameAr,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: preset.palette.text,
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: _sectionHeader(_t('تخصيص عرض المحتوى', 'Content display')),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: p.border),
              ),
              child: SwitchListTile.adaptive(
                value: _compactCards,
                activeThumbColor: p.accent,
                title: Text(
                  _t('بطاقات أخبار مضغوطة', 'Compact news cards'),
                  style: TextStyle(
                    color: p.text,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
                subtitle: Text(
                  _t(
                    'تُظهر عناوين أكثر في الشاشة وتخفي المقتطفات.',
                    'Shows more headlines per screen and hides excerpts.',
                  ),
                  style: TextStyle(color: p.muted, fontSize: 10),
                ),
                secondary: Icon(Icons.view_agenda_outlined, color: p.accent),
                onChanged: _setCompactCards,
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: p.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.text_fields_rounded, color: p.accent),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          _t('حجم النص', 'Text size'),
                          style: TextStyle(
                            color: p.text,
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _t(
                      'يكبّر النصوص داخل التطبيق مع احترام تكبير الخط في إعدادات الجهاز.',
                      'Increase in-app text while respecting your device font-size setting.',
                    ),
                    style: TextStyle(color: p.muted, fontSize: 10, height: 1.4),
                  ),
                  const SizedBox(height: 9),
                  Wrap(
                    spacing: 7,
                    runSpacing: 6,
                    children: [
                      for (final scale in _textScaleOptions)
                        ChoiceChip(
                          selected: _textScale == scale,
                          onSelected: (_) => _setTextScale(scale),
                          label: Text(_textScaleLabel(scale)),
                          showCheckmark: false,
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: _sectionHeader(_t('التحديثات والمصادر', 'Updates & sources')),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: p.border),
              ),
              child: SwitchListTile.adaptive(
                value: _autoRefresh,
                activeThumbColor: p.accent,
                title: Text(
                  _t('تحديث الأخبار تلقائياً', 'Automatic news refresh'),
                  style: TextStyle(
                    color: p.text,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
                subtitle: Text(
                  _t(
                    'عند الفتح والعودة للتطبيق، وكل $_refreshIntervalMinutes دقيقة أثناء بقائه مفتوحاً.',
                    'On launch/resume and every $_refreshIntervalMinutes minutes while the app is open.',
                  ),
                  style: TextStyle(color: p.muted, fontSize: 10, height: 1.4),
                ),
                secondary: Icon(Icons.autorenew_rounded, color: p.accent),
                onChanged: _syncAutoRefresh,
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 3),
            child: Wrap(
              spacing: 8,
              runSpacing: 7,
              children: [
                for (final minutes in const [15, 30, 60])
                  ChoiceChip(
                    selected: _refreshIntervalMinutes == minutes,
                    onSelected: (_) => _setRefreshInterval(minutes),
                    label: Text(_t('كل $minutes دقيقة', 'Every $minutes min')),
                  ),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: _settingsTile(
            Icons.travel_explore_rounded,
            _t('الاكتشاف التلقائي للترسانة', 'Automatic arsenal discovery'),
            _autoDiscover
                ? _t(
                    'يومياً من مستودعات مفتوحة المصدر مرخّصة',
                    'Daily from licensed open-source repositories',
                  )
                : _t(
                    'متوقف · تبقى المشاريع المنسقة ظاهرة',
                    'Off · curated projects remain available',
                  ),
            () async {
              final enabled = !_autoDiscover;
              setState(() => _autoDiscover = enabled);
              final prefs = await SharedPreferences.getInstance();
              await prefs.setBool('auto_discover_projects', enabled);
              if (enabled) unawaited(_loadDiscoveredProjects(force: true));
            },
          ),
        ),
        SliverToBoxAdapter(
          child: _settingsTile(
            Icons.rss_feed_rounded,
            _t('إدارة مصادر المحتوى', 'Manage content feeds'),
            '${allFeedSources.length - _disabledSources.length}/${allFeedSources.length} ${_t('مفعّلة', 'enabled')}',
            _showSources,
          ),
        ),
        SliverToBoxAdapter(
          child: _settingsTile(
            Icons.cloud_sync_rounded,
            _t('تحديث دليل الأدوات', 'Refresh software catalogue'),
            _t(
              'مستودعات GitHub مرخّصة · يومياً',
              'Licensed GitHub projects · daily',
            ),
            () => _loadDiscoveredProjects(force: true),
          ),
        ),
        SliverToBoxAdapter(
          child: _settingsTile(
            Icons.warning_amber_rounded,
            _t('تحديث CISA KEV', 'Refresh CISA KEV'),
            _t(
              'قائمة الثغرات المستغلة المعروفة',
              'Known exploited vulnerabilities',
            ),
            () => _refreshKev(force: true),
          ),
        ),
        SliverToBoxAdapter(
          child: _settingsTile(
            Icons.download_rounded,
            _t('مدير التنزيلات', 'Download manager'),
            _t(
              'تقدم · تحقق من SHA-256 · تثبيت APK',
              'Progress · SHA-256 · APK install',
            ),
            () => setState(() => _tab = 5),
          ),
        ),
        SliverToBoxAdapter(
          child: _sectionHeader(_t('مركز التطبيق', 'App center')),
        ),
        SliverToBoxAdapter(
          child: _settingsTile(
            Icons.privacy_tip_outlined,
            _t('حول ZaherCyber والخصوصية', 'About ZaherCyber & privacy'),
            _t(
              'البيانات والسلامة والمصادر والمساعدة وبيانات المشروع',
              'Data, safety, sources, help, and project information',
            ),
            _showAbout,
          ),
        ),
        SliverToBoxAdapter(
          child: _settingsTile(
            Icons.campaign_outlined,
            _t('قناة ZaherCyber الرسمية', 'Official ZaherCyber channel'),
            _t(
              'ZaherCyber Project · إعلانات الإصدارات؛ لا يوجد فحص تحديث آلي',
              'ZaherCyber Project · release announcements; no automatic update check',
            ),
            () => _openUrl(zaherCyberProjectTelegramUrl),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 26),
            child: Text(
              _t(
                'مصادر الأخبار مستقلة؛ قد تختلف أوقات توفرها. تنزيل APK اختياري ويخضع لإذن Android وتأكيد المستخدم. تراخيص المشاريع تؤخذ من بيانات المصدر عند توفرها، وتحقق منها قبل الاستخدام المؤسسي.',
                'Feeds are independent and availability varies. APK downloads are optional and require Android permission plus user confirmation. Project license metadata is shown when available; verify before organizational use.',
              ),
              textAlign: TextAlign.center,
              style: TextStyle(color: p.muted, fontSize: 9, height: 1.55),
            ),
          ),
        ),
      ],
    );
  }

  Widget _settingsTile(
    IconData icon,
    String title,
    String subtitle,
    VoidCallback onTap,
  ) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 3),
    child: Material(
      color: _p.surface,
      borderRadius: BorderRadius.circular(15),
      child: ListTile(
        leading: Icon(icon, color: _p.accent, size: 21),
        title: Text(
          title,
          style: TextStyle(
            color: _p.text,
            fontSize: 12,
            fontWeight: FontWeight.w800,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(color: _p.muted, fontSize: 9),
        ),
        trailing: Icon(Icons.chevron_right_rounded, color: _p.muted),
        onTap: onTap,
      ),
    ),
  );

  Future<void> _clearNewsCache() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('feed_cache_v2');
    await prefs.remove('tutorial_cache_v1');
    final perSourceCacheKeys = prefs
        .getKeys()
        .where((key) => key.startsWith(FeedService.sourceCachePrefix))
        .toList();
    for (final key in perSourceCacheKeys) {
      await prefs.remove(key);
    }
    if (mounted) {
      setState(() {
        _articles = [];
        _tutorialArticles = [];
      });
    }
    if (_autoRefresh) {
      unawaited(_refreshNews(silent: true));
      unawaited(_refreshTutorials(silent: true));
    }
    if (mounted)
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _t(
              'تم مسح ذاكرة الأخبار والشروحات؛ لم تتأثر المحفوظات أو التنزيلات.',
              'News and tutorial caches cleared. Bookmarks and downloads were not changed.',
            ),
          ),
        ),
      );
  }

  void _showAbout() {
    final resourceCount = learningResourceSections.fold<int>(
      0,
      (count, section) => count + section.items.length,
    );
    Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => AboutCenterScreen(
          locale: widget.locale,
          sourceCount: allFeedSources.length,
          projectCount: toolProjects.length,
          resourceCount: resourceCount,
          quarantinedCount:
              _newsSourceHealth.quarantinedUrls.length +
              _tutorialSourceHealth.quarantinedUrls.length,
          onManageSources: _showSources,
          onClearFeedCache: _clearNewsCache,
          onClearBookmarks: _clearSavedArticles,
          onClearLearningProgress: _clearLearningProgress,
          onResetDesktop: _resetDesktopPersonalization,
          onOpenProtection: _openProtectionFromAbout,
        ),
      ),
    );
  }

  Future<void> _clearSavedArticles() async {
    setState(() {
      _savedArticles.clear();
      _savedTags.clear();
      _savedFilter = 'all';
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('saved_articles_v2');
    await prefs.remove('favorites');
    await prefs.remove('saved_article_tags_v1');
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _t(
            'تم مسح المحفوظات ووسومها فقط.',
            'Saved stories and tags only were cleared.',
          ),
        ),
      ),
    );
  }

  Future<void> _clearLearningProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('learning_progress_v2');
    await prefs.remove('learning_completed_v1');
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _t('تم مسح تقدم التعلم فقط.', 'Learning progress only was cleared.'),
        ),
      ),
    );
  }

  Future<void> _resetDesktopPersonalization() async {
    final prefs = await SharedPreferences.getInstance();
    for (final key in const [
      'desktop_hidden_widgets_v1',
      'desktop_favorite_apps_v1',
      'desktop_app_order_v1',
      'desktop_readiness_v1',
      'desktop_defense_plan_v1',
      'desktop_daily_question_v1',
      'desktop_recent_apps_v1',
    ]) {
      await prefs.remove(key);
    }
    if (!mounted) return;
    setState(() => _desktopResetToken++);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _t(
            'أُعيد تخصيص سطح المكتب إلى الوضع الافتراضي.',
            'Desktop personalization was reset.',
          ),
        ),
      ),
    );
  }

  void _openProtectionFromAbout() {
    Navigator.of(context).popUntil((route) => route.isFirst);
    if (mounted) setState(() => _tab = 3);
  }

  FeedSourceHealthService _healthForSource(String url) =>
      newsSources.any((source) => source.url == url)
      ? _newsSourceHealth
      : _tutorialSourceHealth;

  void _showSources() {
    _sourceSearch.clear();
    var query = '';
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _p.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (modalContext) => StatefulBuilder(
        builder: (modalContext, modalSetState) {
          final rows = allFeedSources
              .where(
                (source) =>
                    '${source.name} ${source.category} ${source.language}'
                        .toLowerCase()
                        .contains(query.toLowerCase()),
              )
              .toList();
          return SafeArea(
            child: SizedBox(
              height: MediaQuery.of(modalContext).size.height * .88,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(19, 17, 19, 8),
                    child: Row(
                      children: [
                        Icon(Icons.rss_feed_rounded, color: _p.accent),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _t('مكتبة المصادر', 'Feed library'),
                                style: TextStyle(
                                  color: _p.text,
                                  fontSize: 17,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              Text(
                                '${allFeedSources.where((source) => !_disabledSources.contains(source.url) && !_newsSourceHealth.quarantinedUrls.contains(source.url) && !_tutorialSourceHealth.quarantinedUrls.contains(source.url)).length}/${allFeedSources.length} ${_t('مصدر متاح', 'available feeds')} · ${_newsSourceHealth.quarantinedUrls.length + _tutorialSourceHealth.quarantinedUrls.length} ${_t('مؤرشف مؤقتاً', 'quarantined')}',
                                style: TextStyle(color: _p.muted, fontSize: 10),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(modalContext),
                          icon: Icon(Icons.close, color: _p.muted),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 7,
                    ),
                    child: TextField(
                      controller: _sourceSearch,
                      onChanged: (value) => modalSetState(() => query = value),
                      decoration: InputDecoration(
                        hintText: _t('ابحث عن مصدر…', 'Search sources…'),
                        prefixIcon: Icon(Icons.search, color: _p.accent),
                      ),
                    ),
                  ),
                  Expanded(
                    child: ListView.separated(
                      itemCount: rows.length,
                      separatorBuilder: (_, __) => Divider(
                        height: 1,
                        color: _p.border.withValues(alpha: .5),
                      ),
                      itemBuilder: (context, index) {
                        final source = rows[index];
                        final health = _healthForSource(source.url);
                        final matchingHealth = health.records
                            .where((record) => record.url == source.url)
                            .toList();
                        final healthRecord = matchingHealth.isEmpty
                            ? null
                            : matchingHealth.first;
                        final autoQuarantined =
                            healthRecord?.isQuarantined ?? false;
                        final manuallyDisabled = _disabledSources.contains(
                          source.url,
                        );
                        final enabled = !manuallyDisabled && !autoQuarantined;
                        final statusText = autoQuarantined
                            ? _t(
                                'عُزل بعد إخفاقات متكررة · اضغط للتجربة الآن',
                                'Quarantined after repeated failures · tap to retry',
                              )
                            : manuallyDisabled
                            ? _t('معطّل يدوياً', 'Disabled manually')
                            : _t('نشط', 'Active');
                        return SwitchListTile.adaptive(
                          value: enabled,
                          activeThumbColor: _p.accent,
                          secondary: Icon(
                            Icons.public_rounded,
                            color: enabled ? _p.accent : _p.muted,
                            size: 20,
                          ),
                          title: Text(
                            source.name,
                            style: TextStyle(
                              color: _p.text,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          subtitle: Text(
                            '${source.category} · ${source.language} · $statusText${healthRecord?.lastStatusCode == null ? '' : ' · HTTP ${healthRecord!.lastStatusCode}'}',
                            style: TextStyle(
                              color: autoQuarantined ? Colors.orange : _p.muted,
                              fontSize: 9,
                            ),
                          ),
                          onChanged: (value) async {
                            setState(() {
                              if (value) {
                                _disabledSources.remove(source.url);
                              } else {
                                _disabledSources.add(source.url);
                              }
                            });
                            if (value && autoQuarantined) {
                              await health.restore(source.url);
                            }
                            modalSetState(() {});
                            final prefs = await SharedPreferences.getInstance();
                            await prefs.setStringList(
                              'disabled_sources_v1',
                              _disabledSources.toList(),
                            );
                          },
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(13),
                    child: FilledButton.icon(
                      onPressed: () {
                        Navigator.pop(modalContext);
                        unawaited(_refreshNews());
                        unawaited(_refreshTutorials());
                      },
                      icon: const Icon(Icons.sync_rounded),
                      label: Text(
                        _t('حفظ وتحديث الأخبار', 'Save and refresh feeds'),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.tryParse(url);
    if (uri != null && uri.scheme == 'https')
      await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}

class _CyberRadarPainter extends CustomPainter {
  final Color accent;
  final Color border;
  final Animation<double> progress;

  _CyberRadarPainter({
    required this.accent,
    required this.border,
    required this.progress,
  }) : super(repaint: progress);

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.shortestSide / 2 - 5;
    final grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = border.withValues(alpha: .55);
    for (var i = 1; i <= 3; i++) {
      canvas.drawCircle(center, radius * i / 3, grid);
    }
    canvas.drawLine(
      Offset(center.dx - radius, center.dy),
      Offset(center.dx + radius, center.dy),
      grid,
    );
    canvas.drawLine(
      Offset(center.dx, center.dy - radius),
      Offset(center.dx, center.dy + radius),
      grid,
    );
    final angle = progress.value * math.pi * 2;
    final sweep = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..color = accent.withValues(alpha: .9);
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      angle - .65,
      1.15,
      false,
      sweep,
    );
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius * .72),
      angle + 2.1,
      .65,
      false,
      sweep..strokeWidth = 1,
    );

    final nodeAngle = angle + .8;
    final node = Offset(
      center.dx + math.cos(nodeAngle) * radius * .58,
      center.dy + math.sin(nodeAngle) * radius * .58,
    );
    final dot = Paint()..color = accent.withValues(alpha: .85);
    canvas.drawCircle(node, 3, dot);
    canvas.drawCircle(
      Offset(center.dx - radius * .32, center.dy + radius * .34),
      2,
      dot..color = accent.withValues(alpha: .45),
    );

    final pulse = .75 + math.sin(angle) * .2;
    canvas.drawCircle(
      center,
      5 + pulse * 2,
      Paint()..color = accent.withValues(alpha: .16),
    );
    canvas.drawCircle(center, 3, Paint()..color = accent);
  }

  @override
  bool shouldRepaint(covariant _CyberRadarPainter oldDelegate) =>
      oldDelegate.accent != accent || oldDelegate.border != border;
}
