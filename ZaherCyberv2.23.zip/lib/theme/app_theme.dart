import 'package:flutter/material.dart';

class AppPalette extends ThemeExtension<AppPalette> {
  final Color background;
  final Color surface;
  final Color raised;
  final Color accent;
  final Color accent2;
  final Color text;
  final Color muted;
  final Color border;
  final Color heroStart;
  final Color heroEnd;

  const AppPalette({
    required this.background,
    required this.surface,
    required this.raised,
    required this.accent,
    required this.accent2,
    required this.text,
    required this.muted,
    required this.border,
    required this.heroStart,
    required this.heroEnd,
  });

  @override
  AppPalette copyWith({
    Color? background,
    Color? surface,
    Color? raised,
    Color? accent,
    Color? accent2,
    Color? text,
    Color? muted,
    Color? border,
    Color? heroStart,
    Color? heroEnd,
  }) => AppPalette(
    background: background ?? this.background,
    surface: surface ?? this.surface,
    raised: raised ?? this.raised,
    accent: accent ?? this.accent,
    accent2: accent2 ?? this.accent2,
    text: text ?? this.text,
    muted: muted ?? this.muted,
    border: border ?? this.border,
    heroStart: heroStart ?? this.heroStart,
    heroEnd: heroEnd ?? this.heroEnd,
  );

  @override
  AppPalette lerp(ThemeExtension<AppPalette>? other, double t) {
    if (other is! AppPalette) return this;
    return AppPalette(
      background: Color.lerp(background, other.background, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      raised: Color.lerp(raised, other.raised, t)!,
      accent: Color.lerp(accent, other.accent, t)!,
      accent2: Color.lerp(accent2, other.accent2, t)!,
      text: Color.lerp(text, other.text, t)!,
      muted: Color.lerp(muted, other.muted, t)!,
      border: Color.lerp(border, other.border, t)!,
      heroStart: Color.lerp(heroStart, other.heroStart, t)!,
      heroEnd: Color.lerp(heroEnd, other.heroEnd, t)!,
    );
  }
}

class AppThemePreset {
  final String id;
  final String nameAr;
  final String nameEn;
  final AppPalette palette;
  final Brightness brightness;
  const AppThemePreset(
    this.id,
    this.nameAr,
    this.nameEn,
    this.palette,
    this.brightness,
  );
}

class AppThemes {
  static const presets = <AppThemePreset>[
    AppThemePreset(
      'emerald',
      'زمرد الظل',
      'Obsidian Emerald',
      AppPalette(
        background: Color(0xff07111c),
        surface: Color(0xff101e2b),
        raised: Color(0xff162738),
        accent: Color(0xff42e6b3),
        accent2: Color(0xff50b8ff),
        text: Color(0xfff1f7fa),
        muted: Color(0xff8da1b3),
        border: Color(0xff24384a),
        heroStart: Color(0xff123d3c),
        heroEnd: Color(0xff11202f),
      ),
      Brightness.dark,
    ),
    AppThemePreset(
      'violet',
      'نيون بنفسجي',
      'Midnight Purple',
      AppPalette(
        background: Color(0xff0c0918),
        surface: Color(0xff191429),
        raised: Color(0xff241b38),
        accent: Color(0xffc18bff),
        accent2: Color(0xff69d8ff),
        text: Color(0xfff8f3ff),
        muted: Color(0xffa99db9),
        border: Color(0xff382d4c),
        heroStart: Color(0xff32204c),
        heroEnd: Color(0xff16162c),
      ),
      Brightness.dark,
    ),
    AppThemePreset(
      'arctic',
      'ضوء قطبي',
      'Arctic Light',
      AppPalette(
        background: Color(0xfff2f6fb),
        surface: Color(0xffffffff),
        raised: Color(0xffe7eef7),
        accent: Color(0xff007f78),
        accent2: Color(0xff1267b1),
        text: Color(0xff10212d),
        muted: Color(0xff5e7180),
        border: Color(0xffd4e0eb),
        heroStart: Color(0xffd5f1ec),
        heroEnd: Color(0xffe3efff),
      ),
      Brightness.light,
    ),
    AppThemePreset(
      'amber',
      'كهرماني ليلي',
      'Cyber Amber',
      AppPalette(
        background: Color(0xff15100a),
        surface: Color(0xff231a10),
        raised: Color(0xff302317),
        accent: Color(0xffffc04d),
        accent2: Color(0xffff7f50),
        text: Color(0xfffff7e8),
        muted: Color(0xffb4a48c),
        border: Color(0xff473522),
        heroStart: Color(0xff473016),
        heroEnd: Color(0xff242016),
      ),
      Brightness.dark,
    ),
    AppThemePreset(
      'terminal',
      'تيرمنال أخضر',
      'Terminal Green',
      AppPalette(
        background: Color(0xff030806),
        surface: Color(0xff09130d),
        raised: Color(0xff102117),
        accent: Color(0xff4dff88),
        accent2: Color(0xff00d9b5),
        text: Color(0xffe3ffe9),
        muted: Color(0xff83a990),
        border: Color(0xff1a3825),
        heroStart: Color(0xff10331c),
        heroEnd: Color(0xff07150d),
      ),
      Brightness.dark,
    ),
    AppThemePreset(
      'dark',
      'دارك مود',
      'Dark Mode',
      AppPalette(
        background: Color(0xff050505),
        surface: Color(0xff101010),
        raised: Color(0xff1a1a1a),
        accent: Color(0xffd7d7d7),
        accent2: Color(0xff8ab4f8),
        text: Color(0xfff2f2f2),
        muted: Color(0xffa0a0a0),
        border: Color(0xff2a2a2a),
        heroStart: Color(0xff242424),
        heroEnd: Color(0xff101010),
      ),
      Brightness.dark,
    ),
    AppThemePreset(
      'ocean',
      'محيط أزرق',
      'Deep Ocean',
      AppPalette(
        background: Color(0xff06121d),
        surface: Color(0xff0d2131),
        raised: Color(0xff16334a),
        accent: Color(0xff50d4f2),
        accent2: Color(0xff7d9cff),
        text: Color(0xffeffbff),
        muted: Color(0xff8eabba),
        border: Color(0xff234459),
        heroStart: Color(0xff0a3b55),
        heroEnd: Color(0xff122242),
      ),
      Brightness.dark,
    ),
    AppThemePreset(
      'crimson',
      'قرمزي سايبري',
      'Crimson Cyber',
      AppPalette(
        background: Color(0xff17080e),
        surface: Color(0xff281019),
        raised: Color(0xff371724),
        accent: Color(0xffff6d83),
        accent2: Color(0xffffb35c),
        text: Color(0xfffff1f3),
        muted: Color(0xffc19aa4),
        border: Color(0xff51303b),
        heroStart: Color(0xff5b1b2d),
        heroEnd: Color(0xff2a1320),
      ),
      Brightness.dark,
    ),
    AppThemePreset(
      'sand',
      'رمال هادئة',
      'Warm Sand',
      AppPalette(
        background: Color(0xfff5f0e6),
        surface: Color(0xfffffdf8),
        raised: Color(0xffebe3d4),
        accent: Color(0xff7a592b),
        accent2: Color(0xff2e7882),
        text: Color(0xff28241d),
        muted: Color(0xff71695d),
        border: Color(0xffded4c3),
        heroStart: Color(0xffe9d8b9),
        heroEnd: Color(0xffd7e8e2),
      ),
      Brightness.light,
    ),
    AppThemePreset(
      'rose',
      'وردي ليلي',
      'Neon Rose',
      AppPalette(
        background: Color(0xff150b18),
        surface: Color(0xff24152a),
        raised: Color(0xff35203c),
        accent: Color(0xffff8bc9),
        accent2: Color(0xff79d7ff),
        text: Color(0xfffff3fb),
        muted: Color(0xffbea9bd),
        border: Color(0xff4d3453),
        heroStart: Color(0xff512342),
        heroEnd: Color(0xff1b203d),
      ),
      Brightness.dark,
    ),
  ];

  static ThemeData build(int index) {
    final preset = presets[index.clamp(0, presets.length - 1).toInt()];
    final p = preset.palette;
    final scheme = ColorScheme.fromSeed(
      seedColor: p.accent,
      brightness: preset.brightness,
      surface: p.surface,
    ).copyWith(primary: p.accent, secondary: p.accent2, onSurface: p.text);
    return ThemeData(
      useMaterial3: true,
      brightness: preset.brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: p.background,
      canvasColor: p.background,
      dividerColor: p.border,
      extensions: <ThemeExtension<dynamic>>[p],
      fontFamily: 'sans-serif',
      appBarTheme: AppBarTheme(
        backgroundColor: p.background,
        foregroundColor: p.text,
        elevation: 0,
      ),
      chipTheme: ChipThemeData(
        backgroundColor: p.surface,
        selectedColor: p.accent.withValues(alpha: .18),
        side: BorderSide(color: p.border),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: p.surface,
        hintStyle: TextStyle(color: p.muted),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: p.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: p.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: p.accent, width: 1.4),
        ),
      ),
    );
  }
}
