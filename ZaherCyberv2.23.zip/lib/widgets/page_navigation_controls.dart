import 'package:flutter/material.dart';

import '../utils/app_copy.dart';

Widget pageBackButton(BuildContext context, {VoidCallback? onPressed}) =>
    IconButton(
      key: const ValueKey('page-back-navigation'),
      tooltip: copy(context, 'رجوع', 'Back'),
      onPressed: onPressed ?? () => Navigator.of(context).maybePop(),
      icon: const Icon(Icons.arrow_back_rounded),
    );

Widget pageHomeButton(BuildContext context) => IconButton(
  key: const ValueKey('page-home-navigation'),
  tooltip: copy(context, 'الرئيسية · F6-OS', 'Home · F6-OS'),
  onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst),
  icon: const Icon(Icons.home_outlined),
);

List<Widget> pageNavigationActions(BuildContext context) => [
  pageHomeButton(context),
];
