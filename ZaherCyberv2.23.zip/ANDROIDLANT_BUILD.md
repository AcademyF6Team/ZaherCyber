# ZaherCyber — Androidlant Build Package

هذا الأرشيف مشروع Flutter كامل ومهيأ للرفع إلى Androidlant Compiler & Signer.

## البناء

ارفع ملف ZIP الذي يحتوي على `pubspec.yaml` و`android/` في جذر الأرشيف، ثم اختر **Build APK**.

الإصدار الحالي:

```text
2.23.0+42
```

## متطلبات البناء

- Flutter stable حديث.
- Android SDK Platform 36 أو أحدث مناسب للمنصة.
- JDK 17، لأن إعداد Android يستخدم Java 17 في `sourceCompatibility` و`targetCompatibility`.
- اتصال بالإنترنت لتنزيل حزم Flutter وGradle عند الحاجة.

## البناء المحلي المكافئ

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

الناتج المتوقع:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## ملاحظات مهمة

- لا توجد مفاتيح توقيع أو أسرار إرسال داخل المشروع. ملف `google-services.json` هو إعداد عميل Android عام وليس Service Account أو مفتاح خادم.
- تحليل FAHES المحلي لا يرسل الرابط. الفحص الخارجي اختياري ويتطلب موافقة؛ PhishTank يقبل الطلبات القليلة دون مفتاح، أما URLhaus وThreatFox فيحتاجان Auth-Key مجانيّاً اختيارياً لا يُضمّن في الأرشيف.
- لا ترفع مجلد `build/` أو `.dart_tool/`؛ منصة البناء تعيد إنشاءهما.
- النسخة الاحتياطية لتقدم التعلم تعمل محلياً داخل التطبيق.
- يتضمن التطبيق Firebase Cloud Messaging لإشعارات Android، مع قناة إشعارات محلية ورسائل المقدمة والخلفية. يجب أن يحتوي الأرشيف على `android/app/google-services.json`.
- تم تضمين قناة Android للإشعارات، إضافة إلى قناة استيراد وتصدير تقدم التعلم محلياً.
- يجب تنفيذ `flutter analyze` و`flutter test` وبناء APK Release على Androidlant بعد رفع هذا المصدر؛ بيئة الأرشيف الحالية لا تحتوي Flutter SDK.
