#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK not found. Install Flutter >= 3.32, add it to PATH, and retry." >&2
  exit 127
fi

flutter --version
flutter clean
flutter pub get
flutter analyze --no-pub
flutter test --no-pub
flutter build apk --release

echo
echo "APK ready: $ROOT/build/app/outputs/flutter-apk/app-release.apk"
