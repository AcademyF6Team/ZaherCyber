# ZaherCyber

تطبيق Flutter عربي/إنجليزي لأخبار التقنية والأمن السيبراني، وكتالوج أدوات مفتوحة المصدر، ومراجع عملية للمختصين والمتعلمين.

**البرمجة والتطوير:** زاهر عباس آل عاشور (Zaher Abbas Al-Ashour) · **الأكاديمية:** F6-Team · **الإصدار:** 2.23.0+42 · **المنصة:** Android.

## الميزات
- الإصدار 2.20.0 يحسن شاشة العودة إلى التطبيق عبر F6-OS Secure Resume، مع حالة الخصوصية، نسخة التطبيق، استئناف فوري وتخطي الإقلاع دون انتظار.
- الإصدار 2.20.1 يشرح الصلاحيات عند أول تشغيل، ويطلب إذن الإشعارات الحقيقي لتحديثات التطبيق والأخبار والتنبيهات، مع توضيح أن تثبيت APK لا يُطلب إلا عند اختيار المستخدم ذلك.
- الإصدار 2.20.2 يضيف صفحة دليل استخدام داخل مركز المساعدة، ويوسع واجهة أول تثبيت لتشرح أقسام الأخبار والحماية والتعلم وFAHES وWorkbench، وتظهر مرة واحدة فقط بعد التثبيت.
- الإصدار 2.21.0 يطور مركز الحماية إلى لوحة محلية تفاعلية تشمل الحسابات دون أسرار، سجل الحوادث، درجات الجاهزية، التذكيرات، تصدير البيانات وحذفها، مع تبويبات واختصارات مباشرة.
- الإصدار 2.22.0 يضيف Zaher Assistant المحلي لشرح أقسام التطبيق مع أزرار فتح مباشرة، ويطور الترسانة بملخص الأدوات ووصفات بحث سريعة وتصنيفات واضحة.
- الإصدار 2.22.1 يصلح أخطاء تركيب بطاقة إجابة المساعد ومسار فتح FAHES من أزرار المساعد.
- الإصدار 2.23.0 يضيف متاجر Android ومصادرها إلى الترسانة مع روابط تنزيل رسمية، مستوى ثقة، وتحذير قبل فتح صفحة التنزيل دون تثبيت صامت.
- الإصدار 2.19.0 يضيف ZaherCyber Workbench مع API Hub وSecurity Library ومختبر API وأدوات محلية للخصوصية والتقارير وصحة الخدمات والاستجابة للحوادث. يضم الكتالوج موارد API وتعليمية مجانية، مع تصنيف العناصر الحساسة ومنع تشغيلها أو تحميلها داخل التطبيق.
- الإصدار 2.15.0 يضيف onboarding من ثلاث صفحات يظهر مرة واحدة عند أول تثبيت، وشاشة إقلاع F6-OS سيبرانية عند التشغيل اللاحق، مع تخزين الحالة محلياً. كما يوسع F6 Security Tools إلى 18 مورداً، منها Shodan وCensys وurlscan.io وVirusTotal وAbuseIPDB وcrt.sh وHave I Been Pwned وMISP وMITRE ATT&CK وCISA KEV، مع وصف الوصول والتنبيهات قبل فتح الروابط.
- الإصدار 2.14.0 يضيف تطبيقاً داخلياً موحداً باسم **F6 Security Tools** مع بحث وبطاقات تصفية وتنقل آمن. يضم روابط MailAccess وHorus وUnfurl ضمن OSINT والتحقيق، ويضع Hugging Face Spaces وEGM Downloader وSkipii وDrift وDelphi Tools ضمن أدوات ومصادر مساندة، مع وصف الترخيص ومتطلبات الوصول وتحذير الخصوصية قبل فتح أي رابط.
- الإصدار 2.14.0 يصلح مسار «تابع تعلّمك» بإدارة صريحة لـ`TabController` ومعالجة فشل التقدم دون إسقاط مركز التعلم. أضيف تطبيق داخلي «مختبرات وخدمات خارجية» يبحث ويصفي 19 مصدراً رسمياً، ويعرض متطلبات الحساب والوصول دون ادعاء مجانية شاملة. لا يفتح أي موقع خارجياً قبل موافقة واضحة، ويعرض تنبيه عنوان IP ومعالجة بيانات الطلب، مع تحذير عزل Juice Shop وWebGoat وDVWA وcrAPI وVulnHub.
- الإصدار 2.14.0 يضيف **فاحص | FAHES**: تحليل محلي إضافة إلى استعلام اختياري بموافقة المستخدم إلى PhishTank (مفتاحه غير مطلوب للطلبات القليلة)، وURLhaus وThreatFox (يتطلبان Auth-Key مجانيّاً اختيارياً يدخله المستخدم ولا يُحفظ). لا يُرسل URL خارجياً قبل موافقة صريحة، وتظهر حالة كل قاعدة منفصلة؛ عدم وجود نتيجة لا يثبت السلامة. كما توحّدت أزرار الرجوع والرئيسية في الصفحات المتراكبة والفرعية. التفاصيل في `docs/release_2.14.0.md`.
- الإصدار 2.11.1 استبدل تكامل VirusTotal القديم بمدقّق محلي دون API، وهو موثق في `docs/release_2.11.1.md`.
- الإصدار 2.11.0 يحول الرئيسية إلى سطح **F6-OS** ذي التطبيقات المصغرة والتنقل الداخلي السلس. أرشيف هذا الإصدار التاريخي في `docs/release_2.11.0.md`؛ تكامل VirusTotal السابق أُزيل في 2.11.1.
- الإصدار 2.10.0 يضيف متابعة التطبيقات الأخيرة والعودة مباشرةً إلى الدرس التالي، وسوماً للمحفوظات، وفلاتر تنزيلات وترسانة موسعة، و13 مرجعاً جديداً وأداة Hayabusa. التفاصيل في `docs/release_2.10.0.md` و`docs/source_expansion_2.10.0.md`.
- يحافظ الإصدار 2.9.0 على مركز الخصوصية وموثوقية المصادر: عزل محلي بعد إخفاقات مؤهلة تمتد 48 ساعة دون حذف الرابط أو إخفاء المقالات المخزنة؛ التفاصيل في `docs/release_2.9.0.md`.

- 86 موجز RSS/Atom للأخبار التقنية والأمنية، بينها مصادر عربية مباشرة، إضافة إلى 7 موجزات مستقلة للشروحات والمقالات النصية. تُجلب العناصر الجديدة من الناشرين عند التحديث وتُحفظ محلياً عند نجاح الاتصال.
- سبعة أقسام رئيسية: سطح المكتب F6-OS، الترسانة، المعرفة، مركز الحماية، المحفوظات، التنزيلات، والإعدادات. الأخبار أصبحت تطبيقاً داخل سطح المكتب، وتبقى أقسام التطبيق المتخصصة متاحة من شريط التنقل الداخلي. يضم «المعرفة» مقالات حيّة ومسارات ومختبرات ومراجع تخصصية؛ أما مركز الحماية المستقل فيضم 42 إجراء تقوية موثقاً لـAndroid/Windows/Linux، و8 أدلة استجابة مفصلة تفتح مباشرةً عبر اختيارات «ماذا حدث؟»، وقائمة متابعة محلية تجمع مطابقات CISA KEV والموجزات المتصلة بالمنتجات.
- واجهة **Academy F6-Team** مضمّنة محلياً داخل «المعرفة» وتعمل دون اتصال لعرض المحتوى الثابت ودليل القنوات؛ أضيفت قناة **ZaherCyber Project**. فتح Telegram أو Facebook وسائر الروابط الخارجية ينتقل إلى التطبيق المناسب ويتطلب اتصالاً، وقد تتطلب القناة الخاصة حساب Telegram وصلاحية دخول.
- ترسانة تشمل 130 مشروعاً مفتوح المصدر عبر Android وWindows وLinux وmacOS والويب، منها LFX Community Data Platform (crowd.dev)، مع اكتشاف يومي لمستودعات GitHub المرخّصة في الأمن والذكاء الاصطناعي والتطوير والسحابة والخصوصية.
- بيانات أحدث إصدار وملفاته من GitHub عند توفرها؛ روابط F-Droid/المصدر الرسمي عند عدم وجود APK في GitHub.
- تنزيل مباشر داخل التطبيق لملفات الإصدارات الرسمية، مع تقدم وإلغاء وإعادة محاولة وحساب SHA-256 ومقارنته ببصمة الناشر عند توفرها.
- حفظ ملفات Android وWindows مباشرة في `Downloads/ZaherCyber` على الهاتف ومشاركتها؛ في Android 9 وأقدم يطلب التطبيق إذن التخزين قبل النسخ إلى المجلد العام، وفي Android 10+ يستخدم MediaStore دون إذن تخزين عام. لا يمكن تشغيل EXE/MSI على Android.
- تثبيت APK اختياري عبر مثبت Android النظامي وبموافقة المستخدم؛ تُمرر النسخة المؤقتة من مجلد cache خاص محدود بـFileProvider إلى المثبت، ولا يوجد تثبيت صامت.
- صفحة خبر تعرض مقتطف موجز الناشر وتاريخ النشر ورابط المقال الأصلي. المقتطف ليس المقال كاملاً.
- أُزيلت ترجمة الأخبار والمقالات ونماذج ML Kit من هذه النسخة بعد تعثر تنزيل النموذج على بعض الأجهزة؛ يُعرض المحتوى بلغته الأصلية مع مقتطف الناشر ورابطه، ولا يُرسل النص إلى خدمة ترجمة خارجية.
- رادار CISA KEV يعرض أحدث 60 بنداً، وقائمة متابعة المنتجات تطابق نصياً مع أحدث 300 سجل KEV مخزن، إضافة إلى الأخبار والموجزات التعليمية المحملة. التقدم وكلمات المتابعة محلية؛ لا يرسل التطبيق إشعارات دفع ولا يراقب الأجهزة/المنتجات في الخلفية. المطابقة تقريبية ولا تعني خلو المنتج من الثغرات عند عدم ظهور نتيجة.
- أدلة مركز الحماية ثنائية اللغة ومسنودة بروابط رسمية من Google وMicrosoft وCanonical/Ubuntu وCISA وNCSC وFTC وApple وGitHub؛ وهي إرشادات عامة وليست تشخيصاً أو بديلاً عن مسؤول النظام أو المختص.
- مكتبة معرفة تضم 148 مرجعاً ومختبراً عبر 36 مجالاً، مع دليل Open Source Alternative لاكتشاف المشاريع. يتضمن قسم المعرفة أيضاً مقالات تعليمية حيّة من موجزات ناشريها.
- صفحة الشروحات والمقالات تتضمن البحث والتصفية حسب المجال. تظهر المراجع ضمن صفحات فرعية حسب التخصص لتخفيف ازدحام مركز المعرفة.
- إعدادات تخصيص موسعة: 10 ثيمات، كثافة بطاقات قابلة للتغيير، حجم نص قابل للاختيار (عادي/كبير/أكبر) يُحفظ محلياً ويحترم تكبير الخط في النظام، اختيار فاصل التحديث (15/30/60 دقيقة)، وإدارة موجزات المحتوى. تظهر حالة تحديث الأخبار والمقالات وعدد المصادر الناجحة/المتعذرة ووقت آخر نجاح؛ وتعرض نتائج البحث عدد العناصر المطابقة مع زر لمسح المرشحات. أضيف زر عودة لأعلى قوائم الأخبار والترسانة الطويلة. مرشحات الترسانة تشمل Android وWindows وLinux وmacOS والويب، والمجال والترخيص ومستوى الخبرة.
- يظهر رابط قناة **ZaherCyber Project** أيضاً في «الإعدادات ← حول التطبيق» لمتابعة إعلانات الإصدارات. يفتح Telegram خارج التطبيق؛ ZaherCyber لا يتحقق تلقائياً من وجود إصدار أحدث.

## التحديث التلقائي وحدوده

تُحدّث الأخبار ومقالات الشروحات عند التشغيل والعودة إلى التطبيق، وعلى الفاصل الذي يختاره المستخدم (15 أو 30 أو 60 دقيقة) ما دام التطبيق مفتوحاً؛ ويمكن السحب للأسفل أو استخدام التحديث اليدوي. تستخدم الموجزات ETag وLast-Modified لإعادة استخدام المحتوى عند رد HTTP 304، مع تخزين محلي لكل مصدر. بيانات CISA KEV تُخزّن محلياً بحد أقصى 300 سجل حديث لمدة 8 ساعات، مع تحديث يدوي داخل المركز؛ ورادار المعرفة يعرض أحدث 60 منها. بيانات الإصدارات الرسمية لها تخزين مؤقت 12 ساعة، واكتشاف المستودعات المرخّصة يجري يومياً عبر GitHub. قائمة الناشرين نفسها منسقة داخل التطبيق؛ الذي يتجدد تلقائياً هو محتوى هذه الموجزات ونتائج اكتشاف المشاريع، وليس كل ناشر جديد على الإنترنت.

قد يوقف Android التنفيذ بعد إغلاق التطبيق؛ لذلك لا يوجد تحديث لحظي في الخلفية عندما يكون التطبيق مغلقاً. يعتمد التوفر على اتصال المستخدم والناشر وحدود GitHub API. لا يتطلب جلب الأخبار والمحتوى أو فاحص الروابط المحلي خادماً وسيطاً أو مفتاح API. أداة الروابط تحلل خصائص النص الموجود على الجهاز فقط.

## المتطلبات

Flutter **3.32+** وDart **3.8+**، Android SDK/Build Tools، Java 17 أو أحدث بحسب Flutter/AGP، واتصال إنترنت لجلب المحتوى. `minSdk` هو **24**. يتضمن المشروع Gradle Wrapper **8.14.3** وAndroid Gradle Plugin **8.11.1** وKotlin Plugin **2.2.20**. أبقِ AGP على إصدار 8؛ لا ترفعه إلى AGP 9 لهذا المشروع.

## بناء APK

بعد فك الضغط إلى مجلد المشروع، استخدم سكريبت النظام المناسب:

```bash
# Linux / macOS
chmod +x build_apk.sh
./build_apk.sh
```

```bat
:: Windows
build_apk.bat
```

ينفذ السكريبت `flutter clean` ثم `flutter pub get` و`flutter analyze --no-pub` و`flutter test --no-pub` وأخيراً `flutter build apk --release`، ويتوقف عند أول خطوة تفشل. ويمكن تشغيلها يدوياً بهذا الترتيب:

```bash
flutter clean
flutter pub get
flutter analyze --no-pub
flutter test --no-pub
flutter build apk --release
```

الناتج: `build/app/outputs/flutter-apk/app-release.apk`. لإنشاء APK منفصل لكل ABI استخدم `flutter build apk --split-per-abi`.

## تجهيز توقيع Release خاص بك

لا ترسل لي المفتاح أو كلمة المرور. أنشئ المفتاح على جهازك واحتفظ بنسخة احتياطية آمنة؛ **فقدان المفتاح يمنع توقيع تحديثات متوافقة للمستخدمين الحاليين**.

في Windows PowerShell (والأمر نفسه يعمل على أنظمة أخرى بعد تعديل المسار):

```powershell
New-Item -ItemType Directory -Force "$HOME\.android" | Out-Null
keytool -genkeypair -v -keystore "$HOME\.android\zahercyber-release.jks" -alias zahercyber -keyalg RSA -keysize 4096 -validity 10000
```

سيطلب `keytool` كلمة مرور للمخزن والمفتاح وبيانات شهادة؛ لا تضع هذه الأسرار في الرسائل. بعد نجاح الأمر، انسخ `android/key.properties.example` إلى `android/key.properties` واملأ القيم محلياً، مستخدماً مساراً مطلقاً بشرطات `/`:

```properties
storePassword=كلمة_مرور_المخزن
keyPassword=كلمة_مرور_المفتاح
keyAlias=zahercyber
storeFile=C:/Users/اسمك/.android/zahercyber-release.jks
```

بعدها شغّل `build_apk.bat` على Windows أو `./build_apk.sh` على Linux/macOS، أو نفّذ `flutter build apk --release`. سيستخدم Gradle مفتاحك إذا كان `android/key.properties` كاملاً وصحيحاً. **لا ترفع `android/key.properties` أو ملف `.jks` إلى Git أو تشاركه**؛ هما مستثنيان في `.gitignore`. إذا لم يوجد ملف الإعدادات، يسمح المشروع ببناء تجريبي موقّع بمفتاح debug؛ لا توزّع هذا التوقيع كتحديث Release.

ملف `android/local.properties` الذي ينشئه Flutter يخص مسار SDK المحلي ولا يحتاج إلى تعديل.

## التنزيل والسلامة

روابط التنزيل تُوجّه إلى HTTPS الرسمي للمشروع ولا يعاد استضافة البرامج. بعض المشروعات لا تنشر ملفاً قابلاً للتنزيل لكل منصة؛ عندئذ يظهر رابط المصدر بدلاً من اختلاق رابط. SHA-256 المحسوب محلياً لا يثبت هوية الناشر وحده؛ تحقق من التوقيع والترخيص والمعمارية قبل التثبيت. استخدم أدوات الأمن في مختبراتك أو بتفويض مكتوب فقط. تفاصيل الخصوصية في [SECURITY.md](SECURITY.md).

## بنية المصدر

`lib/data` للمصادر والمشاريع وأدلة الحماية، `lib/models` للنماذج، `lib/screens` للواجهات، `lib/services` للموجزات وGitHub والتنزيل وCISA KEV، `lib/theme` للألوان والثيمات، و`android/` لملفات Gradle والجسر الأصلي للتنزيل ومثبت النظام. تفاصيل مركز الحماية في [الدليل](docs/protection_center.md)، وتدقيق المصادر في [سجل البحث](docs/research_sources_2.3.0.md) و[دليل الموجزات](docs/content_feeds.md).

---

**English:** ZaherCyber 2.10.0 is an Arabic/English Flutter Android app with a desktop-style home workspace, 86 news feeds, 7 tutorial feeds, 130 curated open-source projects including crowd.dev and Hayabusa, 148 learning references across 36 topic groups, 10 themes, and an independent Protection Center with 42 cited Android/Windows/Linux hardening checks and 8 bilingual incident playbooks. Five quick-response choices route to the matching incident guide, open it directly, and highlight its first action. The desktop keeps the five most recently opened internal apps locally and can open the next incomplete lesson directly. Saved stories support local tags and filtering; Downloads can filter by status, and the Arsenal filters by platform, category, license and difficulty. About offers independent deletion of the feed cache, bookmarks/tags, learning progress, and desktop settings. The in-app release-history page was intentionally not added. The Knowledge section bundles the static Academy F6-Team interface and channel directory for offline reading, including ZaherCyber Project; the official project channel is also linked from Settings > About for release announcements, but the app does not automatically check for new versions. External social links open their corresponding apps and need internet, while access to a private Telegram channel remains subject to Telegram permissions. Local product-watch terms are text-matched against at most 300 recent cached CISA KEV entries and loaded news/tutorial articles; this is not a full CVE scan, and in-app notices only; there is no monitoring outside the app. CISA KEV is cached for 8 hours; the Knowledge radar shows 60 items. On-device article translation and ML Kit model downloads are absent because downloads remained stuck on some devices. Feeds refresh on launch/resume and at the selected 15/30/60-minute interval while open, using HTTP validators and per-source local caching; the app displays per-feed update status and search result counts with clear-filter actions. Settings provide locally saved text-size options that respect system scaling, and the long news/arsenal lists include a back-to-top control. Licensed GitHub project discovery runs daily. The source list itself is curated, and Android may suspend refresh after closure. Public Downloads permission is requested only on Android 9 and earlier, while Android 10+ uses scoped MediaStore.


## الإصدار 2.8.0 — سطح المكتب السيبراني (سجل تاريخي)
أصبحت الرئيسية مساحة سطح مكتب بتطبيقات تفتح الأقسام القائمة مع تلاشي قصير وحفظ حالة كل قسم، وزر عودة ظاهر وزر رجوع Android. يتضمن السطح بحثاً في الاختصارات والأخبار والأدوات والمقالات التعليمية المخزنة، ومساحات عمل، وترتيب التطبيقات بالسحب وتثبيتاً محلياً ووضع تركيز. تشمل الودجتس متابعة الأخبار والتعلم، سيناريوهات استجابة، مسرح تهديد توضيحياً، سؤال اليوم وقائمة استعداد وخطة دفاع ذاتية. الخدمات الخارجية لا تعمل تلقائياً؛ تظهر تحذيرات قبل خدمات تحليل النطاقات وOONI وOWASP crAPI. انظر `docs/desktop_2.8.0.md`.

## مركز التعلم 2.7.1
أضيف مركز تعلم مستقل داخل قسم المعرفة يضم 8 مسارات، 24 درساً، 16 اختباراً قصيراً، و16 بطاقة مراجعة. يحفظ التطبيق التقدم محلياً، ويدعم تصدير واستيراد نسخة JSON من التقدم عبر Downloads/ZaherCyber، مع دمج النسخة المستوردة دون حذف التقدم الحالي. المحتوى المضمن يعمل دون اتصال، ولا يتضمن هذا الإصدار مركز تنبيهات جديداً.

## الإصدار 2.7.2
أضيفت خمسة موجزات RSS/Atom رسمية جرى اختبار XML الخاص بها، وأربعة مشاريع دفاعية جديدة مع تراخيص مستخرجة من GitHub، وثمانية مراجع رسمية/تعليمية في تصنيف مستقل. انظر سجل التحقق التفصيلي في `docs/source_expansion_2.7.2.md`.

**English:** Version 2.7.2 adds five verified live RSS/Atom feeds, four non-duplicate defensive projects with repository license metadata, and eight curated platform/security-framework references. Source verification details are documented in `docs/source_expansion_2.7.2.md`.


## الإصدار 2.9.0 — مركز التطبيق وموثوقية المصادر

حدّثت صفحة «حول التطبيق» لتصبح مركزاً داخلياً يضم الخصوصية والبيانات والسلامة والتنزيلات والمصادر والمساعدة والفريق. تشمل إدارة البيانات مسح ذاكرة الموجزات أو تقدم التعلم أو تخصيص سطح المكتب كلٌّ على حدة وبعد تأكيد المستخدم. أضيفت آلية محلية لعزل موجزات RSS/Atom بعد ثلاث إخفاقات مؤهلة على الأقل تمتد 48 ساعة، مع استثناء أعطال الاتصال العامة ورموز 401/403/429، وإعادة فحص المصدر المؤرشف كل 24 ساعة أثناء استخدام التطبيق أو استعادته يدوياً. لا تحذف المصادر من تعريف التطبيق ولا تزامن حالتها بين الأجهزة؛ ذلك يتطلب خدمة مركزية. عند تعطل موجز، تبقى مقالاته المحفوظة محلياً ظاهرة.
