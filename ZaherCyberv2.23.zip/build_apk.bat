@echo off
setlocal
cd /d "%~dp0"
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter SDK was not found. Install Flutter 3.32 or later and add flutter to PATH.
  exit /b 127
)
flutter --version
if errorlevel 1 exit /b 1
flutter clean
if errorlevel 1 exit /b 1
flutter pub get
if errorlevel 1 exit /b 1
flutter analyze --no-pub
if errorlevel 1 exit /b 1
flutter test --no-pub
if errorlevel 1 exit /b 1
flutter build apk --release
if errorlevel 1 exit /b 1
echo.
echo APK ready: build\app\outputs\flutter-apk\app-release.apk
